# Liber Nehemi� - Caput 6

1. Factum est autem, cum audísset Sanabállat, et Tobías, et Gossem Arabs, et céteri inimíci nostri, quod ædificássem ego murum, et non esset in ipso resídua interrúptio (úsque ad tempus autem illud valvas non posúeram in portis),

2. misérunt Sanabállat et Gossem ad me, dicéntes : Veni, et percutiámus fœdus páriter in vículis in campo Ono. Ipsi autem cogitábant ut fácerent mihi malum.

3. Misi ergo ad eos núntios, dicens : Opus grande ego fácio, et non possum descéndere, ne forte negligátur cum vénero, et descéndero ad vos.

4. Misérunt autem ad me secúndum verbum hoc per quátuor vices : et respóndi eis juxta sermónem priórem.

5. Et misit ad me Sanabállat juxta verbum prius quinta vice púerum suum, et epístolam habébat in manu sua scriptam hoc modo :

6. In géntibus audítum est, et Gossem dixit, quod tu et Judǽi cogitétis rebelláre, et proptérea ædífices murum, et leváre te velis super eos regem : propter quam causam

7. et prophétas posúeris, qui prædícent de te in Jerúsalem, dicéntes : Rex in Judǽa est. Auditúrus est rex verba hæc : idcírco nunc veni, ut ineámus consílium páriter.

8. Et misi ad eos, dicens : Non est factum secúndum verba hæc, quæ tu lóqueris : de corde enim tuo tu compónis hæc.

9. Omnes enim hi terrébant nos, cogitántes quod cessárent manus nostræ ab ópere, et quiescerémus : quam ob causam magis confortávi manus meas.

10. Et ingréssus sum domum Semaíæ fílii Dalaíæ fílii Metábeel secréto. Qui ait : Tractémus nobíscum in domo Dei in médio templi, et claudámus portas ædis : quia ventúri sunt ut interfíciant te, et nocte ventúri sunt ad occidéndum te.

11. Et dixi : Num quisquam símilis mei fugit ? et quis ut ego ingrediétur templum, et vivet ? non ingrédiar.

12. Et intelléxi quod Deus non misísset eum, sed quasi vatícinans locútus esset ad me, et Tobías et Sanabállat conduxíssent eum.

13. Accéperat enim prétium, ut térritus fácerem, et peccárem, et habérent malum quod exprobrárent mihi.

14. Meménto mei, Dómine, pro Tobía et Sanabállat, juxta ópera eórum tália : sed et Noádiæ prophétæ, et ceterórum prophetárum, qui terrébant me.

15. Complétus est autem murus vigésimo quinto die mensis Elul, quinquagínta duóbus diébus.

16. Factum est ergo cum audíssent omnes inimíci nostri, ut timérent univérsæ gentes quæ erant in circúitu nostro, et concíderent intra semetípsos, et scirent quod a Deo factum esset opus hoc.

17. Sed et in diébus illis multæ optimátum Judæórum epístolæ mittebántur ad Tobíam, et a Tobía veniébant ad eos.

18. Multi enim erant in Judǽa habéntes juraméntum ejus, quia gener erat Sechéniæ fílii Área, et Johánan fílius ejus accéperat fíliam Mosóllam fílii Barachíæ :

19. sed et laudábant eum coram me, et verba mea nuntiábant ei : et Tobías mittébat epístolas ut terréret me.

