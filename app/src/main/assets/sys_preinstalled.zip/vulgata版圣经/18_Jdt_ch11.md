# Liber Judith - Caput 11

1. Tunc Holoférnes dixit ei : Æquo ánimo esto, et noli pavére in corde tuo : quóniam ego numquam nócui viro qui vóluit servíre Nabuchodonósor regi :

2. pópulus autem tuus, si non contempsísset me, non levássem lánceam meam super eum.

3. Nunc autem dic mihi, qua ex causa recessísti ab illis, et plácuit tibi ut veníres ad nos ?

4. Et dixit illi Judith : Sume verba ancíllæ tuæ, quóniam si secútus fúeris verba ancíllæ tuæ, perféctam rem fáciet Dóminus tecum.

5. Vivit enim Nabuchodonósor rex terræ, et vivit virtus ejus, quæ est in te ad correptiónem ómnium animárum errántium : quóniam non solum hómines sérviunt illi per te, sed et béstiæ agri obtémperant illi.

6. Nuntiátur enim ánimi tui indústria univérsis géntibus, et indicátum est omni sǽculo quóniam tu solus bonus et potens es in omni regno ejus : et disciplína tua ómnibus provínciis prædicátur.

7. Nec hoc latet, quod locútus est Áchior, nec illud ignorátur, quod ei jússeris eveníre.

8. Constat enim Deum nostrum sic peccátis offénsum, ut mandáverit per prophétas suos ad pópulum quod tradat eum pro peccátis suis.

9. Et quóniam sciunt se offendísse Deum suum fílii Israël, tremor tuus super ipsos est.

10. Ínsuper étiam fames invásit eos, et ab ariditáte aquæ jam inter mórtuos computántur.

11. Dénique hoc órdinant, ut interfícient pécora sua, et bibant sánguinem eórum :

12. et sancta Dómini Dei sui, quæ præcépit Deus non contíngi, in fruménto, vino, et óleo, hæc cogitavérunt impéndere, et volunt consúmere quæ nec mánibus déberent contíngere : ergo quóniam hæc fáciunt, certum est quod in perditiónem dabúntur.

13. Quod ego ancílla tua cognóscens, fugi ab illis, et misit me Dóminus hæc ipsa nuntiáre tibi.

14. Ego enim ancílla tua Deum colo, étiam nunc apud te : et éxiet ancílla tua, et orábo Deum,

15. et dicet mihi quando eis reddat peccátum suum, et véniens nuntiábo tibi, ita ut ego addúcam te per médiam Jerúsalem, et habébis omnem pópulum Israël, sicut oves quibus non est pastor, et non latrábit vel unus canis contra te :

16. quóniam hæc mihi dicta sunt per providéntiam Dei,

17. et quóniam irátus est illis Deus, hæc ipsa missa sum nuntiáre tibi.

18. Placuérunt autem ómnia verba hæc coram Holoférne, et coram púeris ejus, et mirabántur sapiéntiam ejus, et dicébant alter ad álterum :

19. Non est talis múlier super terram in aspéctu, in pulchritúdine, et in sensu verbórum.

20. Et dixit ad illam Holoférnes : Benefécit Deus, qui misit te ante pópulum, ut des illum tu in mánibus nostris :

21. et quóniam bona est promíssio tua, si fécerit mihi hoc Deus tuus, erit et Deus meus, et tu in domo Nabuchodonósor magna eris, et nomen tuum nominábitur in univérsa terra.

