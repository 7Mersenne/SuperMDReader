# Liber Genesis - Caput 9

1. Benedixítque Deus Noë et fíliis ejus. Et dixit ad eos : Créscite, et multiplicámini, et repléte terram.

2. Et terror vester ac tremor sit super cuncta animália terræ, et super omnes vólucres cæli, cum univérsis quæ movéntur super terram : omnes pisces maris mánui vestræ tráditi sunt.

3. Et omne, quod movétur et vivit, erit vobis in cibum : quasi ólera viréntia trádidi vobis ómnia.

4. Excépto, quod carnem cum sánguine non comedétis.

5. Sánguinem enim animárum vestrárum requíram de manu cunctárum bestiárum : et de manu hóminis, de manu viri, et fratris ejus requíram ánimam hóminis.

6. Quicúmque effúderit humánum sánguinem, fundétur sanguis illíus : ad imáginem quippe Dei factus est homo.

7. Vos autem créscite et multiplicámini, et ingredímini super terram, et impléte eam.

8. Hæc quoque dixit Deus ad Noë, et ad fílios ejus cum eo :

9. Ecce ego státuam pactum meum vobíscum, et cum sémine vestro post vos :

10. et ad omnem ánimam vivéntem, quæ est vobíscum, tam in volúcribus quam in juméntis et pecúdibus terræ cunctis, quæ egréssa sunt de arca, et univérsis béstiis terræ.

11. Státuam pactum meum vobíscum, et nequáquam ultra interficiétur omnis caro aquis dilúvii, neque erit deínceps dilúvium díssipans terram.

12. Dixítque Deus : Hoc signum fóederis quod do inter me et vos, et ad omnem ánimam vivéntem, quæ est vobíscum in generatiónes sempitérnas :

13. arcum meum ponam in núbibus, et erit signum fóederis inter me et inter terram.

14. Cumque obdúxero núbibus cælum, apparébit arcus meus in núbibus :

15. et recordábor fóederis mei vobíscum, et cum omni ánima vivénte quæ carnem végetat : et non erunt ultra aquæ dilúvii ad deléndum univérsam carnem.

16. Erítque arcus in núbibus, et vidébo illum, et recordábor fóederis sempitérni quod pactum est inter Deum et omnem ánimam vivéntem univérsæ carnis quæ est super terram.

17. Dixítque Deus ad Noë : Hoc erit signum fóederis, quod constítui inter me et omnem carnem super terram.

18. Erant ergo fílii Noë, qui egréssi sunt de arca, Sem, Cham et Japheth : porro Cham ipse est pater Chánaan.

19. Tres isti fílii sunt Noë : et ab his disseminátum est omne genus hóminum super univérsam terram.

20. Cœpítque Noë vir agrícola exercére terram, et plantávit víneam.

21. Bibénsque vinum inebriátus est, et nudátus in tabernáculo suo.

22. Quod cum vidísset Cham, pater Chánaan, verénda scílicet patris sui esse nudáta, nuntiávit duóbus frátribus suis foras.

23. At vero Sem et Japheth pállium imposuérunt húmeris suis, et incedéntes retrórsum, operuérunt verénda patris sui : faciésque eórum avérsæ erant, et patris virília non vidérunt.

24. Evígilans autem Noë ex vino, cum didicísset quæ fécerat ei fílius suus minor,

25. ait : Maledíctus Chánaan, servus servórum erit frátribus suis.

26. Dixítque : Benedíctus Dóminus Deus Sem, sit Chánaan servus ejus.

27. Dilátet Deus Japheth, et hábitet in tabernáculis Sem, sitque Chánaan servus ejus.

28. Vixit autem Noë post dilúvium trecéntis quinquagínta annis.

29. Et impléti sunt omnes dies ejus nongentórum quinquagínta annórum : et mórtuus est.

