# Liber Genesis - Caput 24

1. Erat autem Ábraham senex, dierúmque multórum : et Dóminus in cunctis benedíxerat ei.

2. Dixítque ad servum seniórem domus suæ, qui prǽerat ómnibus quæ habébat : Pone manum tuam subter femur meum,

3. ut adjúrem te per Dóminum Deum cæli et terræ, ut non accípias uxórem fílio meo de filiábus Chananæórum, inter quos hábito :

4. sed ad terram et cognatiónem meam proficiscáris et inde accípias uxórem fílio meo Ísaac.

5. Respóndit servus : Si nolúerit múlier veníre mecum in terram hanc, numquid redúcere débeo fílium tuum ad locum, de quo egréssus es ?

6. Dixítque Ábraham : Cave nequándo redúcas fílium meum illuc.

7. Dóminus Deus cæli, qui tulit me de domo patris mei, et de terra nativitátis meæ, qui locútus est mihi, et jurávit mihi, dicens : Sémini tuo dabo terram hanc : ipse mittet ángelum suum coram te, et accípies inde uxórem fílio meo :

8. sin autem múlier nolúerit sequi te, non tenéberis juraménto : fílium meum tantum ne redúcas illuc.

9. Pósuit ergo servus manum sub fémore Ábraham dómini sui, et jurávit illi super sermóne hoc.

10. Tulítque decem cámelos de grege dómini sui, et ábiit, ex ómnibus bonis ejus portans secum, profectúsque perréxit in Mesopotámiam ad urbem Nachor.

11. Cumque cámelos fecísset accúmbere extra óppidum juxta púteum aquæ véspere, témpore quo solent mulíeres égredi ad hauriéndam aquam, dixit :

12. Dómine Deus dómini mei Ábraham, occúrre, óbsecro, mihi hódie, et fac misericórdiam cum dómino meo Ábraham.

13. Ecce ego sto prope fontem aquæ, et fíliæ habitatórum hujus civitátis egrediéntur ad hauriéndam aquam.

14. Ígitur puélla, cui ego díxero : Inclína hýdriam tuam ut bibam : et illa respondérit : Bibe, quin et cámelis tuis dabo potum : ipsa est quam præparásti servo tuo Ísaac : et per hoc intélligam quod féceris misericórdiam cum dómino meo.

15. Necdum intra se verba compléverat, et ecce Rebécca egrediebátur, fília Báthuel, fílii Melchæ uxóris Nachor fratris Ábraham, habens hýdriam in scápula sua :

16. puélla decóra nimis, virgóque pulchérrima, et incógnita viro : descénderat autem ad fontem, et impléverat hýdriam, ac revertebátur.

17. Occurrítque ei servus, et ait : Pauxíllum aquæ mihi ad bibéndum præbe de hýdria tua.

18. Quæ respóndit : Bibe, dómine mi : celeritérque depósuit hýdriam super ulnam suam, et dedit ei potum.

19. Cumque ille bibísset, adjécit : Quin et cámelis tuis háuriam aquam, donec cuncti bibant.

20. Effundénsque hýdriam in canálibus, recúrrit ad púteum ut hauríret aquam : et haustam ómnibus cámelis dedit.

21. Ipse autem contemplabátur eam tácitus, scire volens utrum prósperum iter suum fecísset Dóminus, an non.

22. Postquam autem bibérunt cámeli, prótulit vir ináures áureas, appendéntes siclos duos, et armíllas tótidem pondo siclórum decem.

23. Dixítque ad eam : Cujus es fília ? índica mihi, est in domo patris tui locus ad manéndum ?

24. Quæ respóndit : Fília sum Bathúelis, fílii Melchæ, quem péperit ipsi Nachor.

25. Et áddidit, dicens : Paleárum quoque et fœni plúrimum est apud nos, et locus spatiósus ad manéndum.

26. Inclinávit se homo, et adorávit Dóminum,

27. dicens : Benedíctus Dóminus Deus dómini mei Ábraham, qui non ábstulit misericórdiam et veritátem suam a dómino meo, et recto itínere me perdúxit in domum fratris dómini mei.

28. Cucúrrit ítaque puélla, et nuntiávit in domum matris suæ ómnia quæ audíerat.

29. Habébat autem Rebécca fratrem nómine Laban, qui festínus egréssus est ad hóminem, ubi erat fons.

30. Cumque vidísset ináures et armíllas in mánibus soróris suæ, et audísset cuncta verba referéntis : Hæc locútus est mihi homo : venit ad virum qui stabat juxta cámelos, et prope fontem aquæ :

31. dixítque ad eum : Ingrédere, benedícte Dómini : cur foris stas ? præparávi domum, et locum cámelis.

32. Et introdúxit eum in hospítium : ac destrávit cámelos, dedítque páleas et fœnum, et aquam ad lavándos pedes ejus, et virórum qui vénerant cum eo.

33. Et appósitus est in conspéctu ejus panis. Qui ait : Non cómedam, donec loquar sermónes meos. Respóndit ei : Lóquere.

34. At ille : Servus, inquit, Ábraham sum :

35. et Dóminus benedíxit dómino meo valde, magnificatúsque est : et dedit ei oves et boves, argéntum et aurum, servos et ancíllas, cámelos et ásinos.

36. Et péperit Sara uxor dómini mei fílium dómino meo in senectúte sua, dedítque illi ómnia quæ habúerat.

37. Et adjurávit me dóminus meus, dicens : Non accípies uxórem fílio meo de filiábus Chananæórum, in quorum terra hábito :

38. sed ad domum patris mei perges, et de cognatióne mea accípies uxórem fílio meo.

39. Ego vero respóndi dómino meo : Quid si nolúerit veníre mecum múlier ?

40. Dóminus, ait, in cujus conspéctu ámbulo, mittet ángelum suum tecum, et díriget viam tuam : accipiésque uxórem fílio meo de cognatióne mea, et de domo patris mei.

41. Ínnocens eris a maledictióne mea, cum véneris ad propínquos meos, et non déderint tibi.

42. Veni ergo hódie ad fontem aquæ, et dixi : Dómine Deus dómini mei Ábraham, si direxísti viam meam, in qua nunc ámbulo,

43. ecce sto juxta fontem aquæ, et virgo, quæ egrediétur ad hauriéndam aquam, audíerit a me : Da mihi pauxíllum aquæ ad bibéndum ex hýdria tua :

44. et díxerit mihi : Et tu bibe, et cámelis tuis háuriam : ipsa est múlier, quam præparávit Dóminus fílio dómini mei.

45. Dumque hæc tácitus mecum vólverem, appáruit Rebécca véniens cum hýdria, quam portábat in scápula : descendítque ad fontem, et hausit aquam. Et aío ad eam : Da mihi páululum bíbere.

46. Quæ festínans depósuit hýdriam de húmero, et dixit mihi : Et tu bibe, et cámelis tuis tríbuam potum. Bibi, et adaquávit cámelos.

47. Interrogavíque eam, et dixi : Cujus es fília ? Quæ respóndit : Fília Bathúelis sum, fílii Nachor, quem péperit ei Melcha. Suspéndi ítaque ináures ad ornándam fáciem ejus, et armíllas pósui in mánibus ejus.

48. Pronúsque adorávi Dóminum, benedícens Dómino Deo dómini mei Ábraham, qui perdúxit me recto itínere, ut súmerem fíliam fratris dómini mei fílio ejus.

49. Quam ob rem si fácitis misericórdiam et veritátem cum dómino meo, indicáte mihi : sin autem áliud placet, et hoc dícite mihi, ut vadam ad dextram, sive ad sinístram.

50. Responderúntque Laban et Báthuel : A Dómino egréssus est sermo : non póssumus extra plácitum ejus quidquam áliud loqui tecum.

51. En Rebécca coram te est, tolle eam, et proficíscere, et sit uxor fílii dómini tui, sicut locútus est Dóminus.

52. Quod cum audísset puer Ábraham, prócidens adorávit in terram Dóminum.

53. Prolatísque vasis argénteis, et áureis, ac véstibus, dedit ea Rebéccæ pro múnere : frátribus quoque ejus et matri dona óbtulit.

54. Ínito convívio, vescéntes páriter et bibéntes mansérunt ibi. Surgens autem mane, locútus est puer : Dimítte me, ut vadam ad dóminum meum.

55. Responderúntque fratres ejus et mater : Máneat puélla saltem decem dies apud nos, et póstea proficiscétur.

56. Nolíte, ait, me retinére, quia Dóminus diréxit viam meam : dimíttite me ut pergam ad dóminum meum.

57. Et dixérunt : Vocémus puéllam, et quærámus ipsíus voluntátem.

58. Cumque vocáta venísset, sciscitáti sunt : Vis ire cum hómine isto ? Quæ ait : Vadam.

59. Dimisérunt ergo eam, et nutrícem illíus, servúmque Ábraham, et cómites ejus,

60. imprecántes próspera soróri suæ, atque dicéntes : Soror nostra es, crescas in mille míllia, et possídeat semen tuum portas inimicórum suórum.

61. Ígitur Rebécca et puéllæ illíus, ascénsis cámelis, secútæ sunt virum : qui festínus revertebátur ad dóminum suum.

62. Eo autem témpore deambulábat Ísaac per viam quæ ducit ad púteum, cujus nomen est Vivéntis et vidéntis : habitábat enim in terra austráli :

63. et egréssus fúerat ad meditándum in agro, inclináta jam die : cumque elevásset óculos, vidit cámelos veniéntes procul.

64. Rebécca quoque, conspécto Ísaac, descéndit de cámelo,

65. et ait ad púerum : Quis est ille homo qui venit per agrum in occúrsum nobis ? Dixítque ei : Ipse est dóminus meus. At illa tollens cito pállium, opéruit se.

66. Servus autem cuncta, quæ gésserat, narrávit Ísaac.

67. Qui introdúxit eam in tabernáculum Saræ matris suæ, et accépit eam uxórem : et in tantum diléxit eam, ut dolórem, qui ex morte matris ejus accíderat, temperáret.

