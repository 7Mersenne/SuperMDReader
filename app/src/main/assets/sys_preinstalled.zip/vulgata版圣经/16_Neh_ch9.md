# Liber Nehemi� - Caput 9

1. In die autem vigésimo quarto mensis hujus, convenérunt fílii Israël in jejúnio et in saccis, et humus super eos.

2. Et separátum est semen filiórum Israël ab omni fílio alienígena : et stetérunt, et confitebántur peccáta sua, et iniquitátes patrum suórum.

3. Et consurrexérunt ad standum : et legérunt in volúmine legis Dómini Dei sui, quater in die, et quater confitebántur, et adorábant Dóminum Deum suum.

4. Surrexérunt autem super gradum Levitárum Jósue, et Bani, et Cédmihel, Sabánia, Bonni, Sarébias, Bani, et Chanáni : et clamavérunt voce magna ad Dóminum Deum suum.

5. Et dixérunt Levítæ Jósue, et Cédmihel, Bonni, Hasébnia, Serébia, Odaía, Sébnia, Phatháthia : Súrgite, benedícite Dómino Deo vestro ab ætérno usque in ætérnum : et benedícant nómini glóriæ tuæ excélso in omni benedictióne et laude.

6. Tu ipse, Dómine, solus, tu fecísti cælum, et cælum cælórum, et omnem exércitum eórum : terram, et univérsa quæ in ea sunt : mária, et ómnia quæ in eis sunt : et tu vivíficas ómnia hæc, et exércitus cæli te adórat.

7. Tu ipse, Dómine Deus, qui elegísti Abram, et eduxísti eum de igne Chaldæórum, et posuísti nomen ejus Ábraham :

8. et invenísti cor ejus fidéle coram te, et percussísti cum eo fœdus ut dares ei terram Chananǽi, Hethǽi, et Amorrhǽi, et Pherezǽi, et Jebusǽi, et Gergesǽi, ut dares sémini ejus : et implésti verba tua, quóniam justus es.

9. Et vidísti afflictiónem patrum nostrórum in Ægýpto, clamorémque eórum audísti super mare Rubrum.

10. Et dedísti signa atque porténta in Pharaóne, et in univérsis servis ejus, et in omni pópulo terræ illíus : cognovísti enim quia supérbe égerant contra eos : et fecísti tibi nomen, sicut et in hac die.

11. Et mare divisísti ante eos, et transiérunt per médium maris in sicco : persecutóres autem eórum projecísti in profúndum, quasi lápidem in aquas válidas.

12. Et in colúmna nubis ductor eórum fuísti per diem, et in colúmna ignis per noctem, ut appáreret eis via per quam ingrediebántur.

13. Ad montem quoque Sínai descendísti, et locútus es cum eis de cælo, et dedísti eis judícia recta, et legem veritátis, cæremónias, et præcépta bona :

14. et sábbatum sanctificátum tuum ostendísti eis : et mandáta, et cæremónias, et legem præcepísti eis in manu Móysi servi tui.

15. Panem quoque de cælo dedísti eis in fame eórum, et aquam de petra eduxísti eis sitiéntibus, et dixísti eis ut ingrederéntur et possidérent terram, super quam levásti manum tuam ut tráderes eis.

16. Ipsi vero et patres nostri supérbe égerunt, et induravérunt cervíces suas, et non audiérunt mandáta tua.

17. Et noluérunt audíre, et non sunt recordáti mirabílium tuórum quæ féceras eis. Et induravérunt cervíces suas, et dedérunt caput ut converteréntur ad servitútem suam, quasi per contentiónem. Tu autem, Deus propítius, clemens, et miséricors, longánimis, et multæ miseratiónis, non dereliquísti eos,

18. et quidem cum fecíssent sibi vítulum conflátilem, et dixíssent : Iste est deus tuus, qui edúxit te de Ægýpto : fecerúntque blasphémias magnas :

19. tu autem in misericórdiis tuis multis non dimisísti eos in desérto : colúmna nubis non recéssit ab eis per diem ut dúceret eos in viam, et colúmna ignis per noctem ut osténderet eis iter per quod ingrederéntur.

20. Et spíritum tuum bonum dedísti, qui docéret eos : et manna tuum non prohibuísti ab ore eórum, et aquam dedísti eis in siti.

21. Quadragínta annis pavísti eos in desérto, nihílque eis défuit : vestiménta eórum non inveteravérunt, et pedes eórum non sunt attríti.

22. Et dedísti eis regna, et pópulos, et partítus es eis sortes : et possedérunt terram Sehon, et terram regis Hesébon, et terram Og regis Basan.

23. Et multiplicásti fílios eórum sicut stellas cæli, et adduxísti eos ad terram de qua díxeras pátribus eórum ut ingrederéntur et possidérent.

24. Et venérunt fílii, et possedérunt terram, et humiliásti coram eis habitatóres terræ Chananǽos, et dedísti eos in manu eórum, et reges eórum, et pópulos terræ, ut fácerent eis sicut placébant illis.

25. Cepérunt ítaque urbes munítas et humum pinguem, et possedérunt domos plenas cunctis bonis : cistérnas ab áliis fabricátas, víneas, et olivéta, et ligna pomífera multa : et comedérunt, et saturáti sunt, et impinguáti sunt, et abundavérunt delíciis in bonitáte tua magna.

26. Provocavérunt autem te ad iracúndiam, et recessérunt a te, et projecérunt legem tuam post terga sua : et prophétas tuos occidérunt, qui contestabántur eos ut reverteréntur ad te : fecerúntque blasphémias grandes.

27. Et dedísti eos in manu hóstium suórum, et afflixérunt eos. Et in témpore tribulatiónis suæ clamavérunt ad te, et tu de cælo audísti, et secúndum miseratiónes tuas multas dedísti eis salvatóres, qui salvárent eos de manu hóstium suórum.

28. Cumque requievíssent, revérsi sunt ut fácerent malum in conspéctu tuo, et dereliquísti eos in manu inimicórum suórum, et possedérunt eos. Conversíque sunt, et clamavérunt ad te : tu autem de cælo exaudísti, et liberásti eos in misericórdiis tuis, multis tempóribus.

29. Et contestátus es eos ut reverteréntur ad legem tuam. Ipsi vero supérbe égerunt, et non audiérunt mandáta tua, et in judíciis tuis peccavérunt, quæ fáciet homo, et vivet in eis : et dedérunt húmerum recedéntem, et cervícem suam induravérunt, nec audiérunt.

30. Et protraxísti super eos annos multos, et contestátus es eos in spíritu tuo per manum prophetárum tuórum : et non audiérunt, et tradidísti eos in manu populórum terrárum.

31. In misericórdiis autem tuis plúrimis non fecísti eos in consumptiónem, nec dereliquísti eos : quóniam Deus miseratiónum et clemens es tu.

32. Nunc ítaque Deus noster magne, fortis et terríbilis, custódiens pactum et misericórdiam, ne avértas a fácie tua omnem labórem, qui invénit nos, reges nostros, et príncipes nostros, et sacerdótes nostros, et prophétas nostros, et patres nostros, et omnem pópulum tuum a diébus regis Assur usque in diem hanc.

33. Et tu justus es in ómnibus quæ venérunt super nos : quia veritátem fecísti, nos autem ímpie égimus.

34. Reges nostri, príncipes nostri, sacerdótes nostri et patres nostri non fecérunt legem tuam, et non attendérunt mandáta tua, et testimónia tua quæ testificátus es in eis.

35. Et ipsi in regnis suis, et in bonitáte tua multa quam déderas eis, et in terra latíssima et pingui quam tradíderas in conspéctu eórum, non serviérunt tibi, nec revérsi sunt a stúdiis suis péssimis.

36. Ecce nos ipsi hódie servi sumus : et terra quam dedísti pátribus nostris ut coméderent panem ejus, et quæ bona sunt ejus, et nos ipsi servi sumus in ea.

37. Et fruges ejus multiplicántur régibus quos posuísti super nos propter peccáta nostra : et corpóribus nostris dominántur, et juméntis nostris secúndum voluntátem suam : et in tribulatióne magna sumus.

38. Super ómnibus ergo his nos ipsi percútimus fœdus, et scríbimus : et signant príncipes nostri, Levítæ nostri, et sacerdótes nostri.

