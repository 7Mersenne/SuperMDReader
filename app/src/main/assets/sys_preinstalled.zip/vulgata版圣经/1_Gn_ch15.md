# Liber Genesis - Caput 15

1. His ítaque transáctis, factus est sermo Dómini ad Abram per visiónem dicens : Noli timére, Abram : ego protéctor tuus sum, et merces tua magna nimis.

2. Dixítque Abram : Dómine Deus, quid dabis mihi ? ego vadam absque líberis, et fílius procuratóris domus meæ iste Damáscus Eliézer.

3. Addidítque Abram : Mihi autem non dedísti semen, et ecce vernáculus meus, hæres meus erit.

4. Statímque sermo Dómini factus est ad eum, dicens : Non erit hic hæres tuus, sed qui egrediétur de útero tuo, ipsum habébis hǽredem.

5. Eduxítque eum foras, et ait illi : Súspice cælum, et númera stellas, si potes. Et dixit ei : Sic erit semen tuum.

6. Crédidit Abram Deo, et reputátum est illi ad justítiam.

7. Dixítque ad eum : Ego Dóminus qui edúxi te de Ur Chaldæórum ut darem tibi terram istam, et possidéres eam.

8. At ille ait : Dómine Deus, unde scire possum quod possessúrus sim eam ?

9. Et respóndens Dóminus : Sume, inquit, mihi vaccam triénnem, et capram trimam, et aríetem annórum trium, túrturem quoque et colúmbam.

10. Qui tollens univérsa hæc, divísit ea per médium, et utrásque partes contra se altrínsecus pósuit ; aves autem non divísit.

11. Descenderúntque vólucres super cadávera, et abigébat eas Abram.

12. Cumque sol occúmberet, sopor írruit super Abram, et horror magnus et tenebrósus invásit eum.

13. Dictúmque est ad eum : Scito prænóscens quod peregrínum futúrum sit semen tuum in terra non sua, et subjícient eos servitúti, et afflígent quadringéntis annis.

14. Verúmtamen gentem, cui servitúri sunt, ego judicábo : et post hæc egrediéntur cum magna substántia.

15. Tu autem ibis ad patres tuos in pace, sepúltus in senectúte bona.

16. Generatióne autem quarta reverténtur huc : necdum enim complétæ sunt iniquitátes Amorrhæórum usque ad præsens tempus.

17. Cum ergo occubuísset sol, facta est calígo tenebrósa, et appáruit clíbanus fumans, et lampas ignis tránsiens inter divisiónes illas.

18. In illo die pépigit Dóminus fœdus cum Abram, dicens : Sémini tuo dabo terram hanc a flúvio Ægýpti usque ad flúvium magnum Euphráten,

19. Cinǽos, et Cenezǽos, Cedmonǽos,

20. et Hethǽos, et Pherezǽos, Ráphaim quoque,

21. et Amorrhǽos, et Chananǽos, et Gergesǽos, et Jebusǽos.

