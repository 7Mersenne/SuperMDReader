# Liber Secundus Paralipomenon - Caput 2

1. Décrevit autem Sálomon ædificáre domum nómini Dómini, et palátium sibi.

2. Et numerávit septuagínta míllia virórum portántium húmeris, et octogínta míllia qui cǽderent lápides in móntibus, præpositósque eórum tria míllia sexcéntos.

3. Misit quoque ad Hiram regem Tyri, dicens : Sicut egísti cum David patre meo, et misísti ei ligna cédrina ut ædificáret sibi domum, in qua et habitávit :

4. sic fac mecum ut ædíficem domum nómini Dómini Dei mei, ut cónsecrem eam ad adoléndum incénsum coram illo, et fumigánda arómata, et ad propositiónem panum sempitérnam, et ad holocautomáta mane, et véspere, sábbatis quoque, et neoméniis, et solemnitátibus Dómini Dei nostri in sempitérnum, quæ mandáta sunt Israëli.

5. Domus enim quam ædificáre cúpio, magna est : magnus est enim Deus noster super omnes deos.

6. Quis ergo póterit præválere, ut ædíficet ei dignam domum ? si cælum, et cæli cælórum, cápere eum néqueunt, quantus ego sum, ut possim ædificáre ei domum ? sed ad hoc tantum, ut adoleátur incénsum coram illo.

7. Mitte ergo mihi virum erudítum, qui nóverit operári in auro, et argénto, ære, et ferro, púrpura, cóccino, et hyacíntho : et qui sciat scúlpere cælatúras cum his artifícibus quos mecum hábeo in Judǽa, et Jerúsalem, quos præparávit David pater meus.

8. Sed et ligna cédrina mitte mihi, et arceúthina, et pínea de Líbano : scio enim quod servi tui nóverint cǽdere ligna de Líbano : et erunt servi mei cum servis tuis,

9. ut paréntur mihi ligna plúrima. Domus enim quam cúpio ædificáre, magna est nimis, et ínclyta.

10. Prætérea operáriis qui cæsúri sunt ligna, servis tuis, dabo in cibária trítici coros vigínti míllia, et hórdei coros tótidem, et vini vigínti míllia metrétas, ólei quoque sata vigínti míllia.

11. Dixit autem Hiram rex Tyri per lítteras quas míserat Salomóni : Quia diléxit Dóminus pópulum suum, idcírco te regnáre fecit super eum.

12. Et áddidit, dicens : Benedíctus Dóminus Deus Israël, qui fecit cælum et terram : qui dedit David regi fílium sapiéntem et erudítum et sensátum atque prudéntem, ut ædificáret domum Dómino, et palátium sibi.

13. Misi ergo tibi virum prudéntem et scientíssimum Hiram patrem meum,

14. fílium mulíeris de filiábus Dan, cujus pater fuit Týrius, qui novit operári in auro, et argénto, ære, et ferro, et marmóre, et lignis, in púrpura quoque, et hyacíntho, et bysso, et cóccino : et qui scit cæláre omnem sculptúram, et adinveníre prudénter quodcúmque in ópere necessárium est cum artifícibus tuis, et cum artifícibus dómini mei David patris tui.

15. Tríticum ergo, et hórdeum, et óleum, et vinum, quæ pollícitus es, dómine mi, mitte servis tuis.

16. Nos autem cædémus ligna de Líbano, quot necessária habúeris, et applicábimus ea rátibus per mare in Joppe : tuum autem erit transférre ea in Jerúsalem.

17. Numerávit ígitur Sálomon omnes viros prosélytos qui erant in terra Israël, post dinumeratiónem quam dinumerávit David pater ejus, et invénti sunt centum quinquagínta míllia, et tria míllia sexcénti.

18. Fecítque ex eis septuagínta míllia qui húmeris ónera portárent, et octogínta míllia qui lápides in móntibus cǽderent : tria autem míllia et sexcéntos præpósitos óperum pópuli.

