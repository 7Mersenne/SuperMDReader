# Liber Primus Paralipomenon - Caput 6

1. Fílii Levi : Gerson, Caath, et Merári.

2. Fílii Caath : Amram, Ísaar, Hebron, et Ozíel.

3. Fílii Amram : Áaron, Móyses, et María. Fílii Áaron : Nadab et Abíu, Eleázar, et Ithámar.

4. Eleázar génuit Phínees, et Phínees génuit Abísue.

5. Abísue vero génuit Bocci, et Bocci génuit Ozi.

6. Ozi génuit Zaraíam, et Zaraías génuit Meraíoth.

7. Porro Meraíoth génuit Amáriam, et Amárias génuit Áchitob.

8. Áchitob génuit Sadoc, et Sadoc génuit Achímaas,

9. Achímaas génuit Azaríam, Azarías génuit Johánan,

10. Johánan génuit Azaríam : ipse est qui sacerdótio functus est in domo quam ædificávit Sálomon in Jerúsalem.

11. Génuit autem Azarías Amáriam, et Amárias génuit Áchitob,

12. Áchitob génuit Sadoc, et Sadoc génuit Sellum,

13. Sellum génuit Helcíam, et Helcías génuit Azaríam,

14. Azarías génuit Saraíam, et Saraías génuit Jósedec.

15. Porro Jósedec egréssus est, quando tránstulit Dóminus Judam et Jerúsalem per manus Nabuchodonósor.

16. Fílii ergo Levi : Gersom, Caath, et Merári.

17. Et hæc nómina filiórum Gersom : Lobni, et Sémei.

18. Fílii Caath : Amram, et Ísaar, et Hebron, et Ozíel.

19. Fílii Merári : Móholi et Musi. Hæ autem cognatiónes Levi secúndum famílias eórum.

20. Gersom : Lobni fílius ejus, Jahath fílius ejus, Zamma fílius ejus,

21. Joah fílius ejus, Addo fílius ejus, Zara fílius ejus, Jéthrai fílius ejus.

22. Fílii Caath : Amínadab fílius ejus, Core fílius ejus, Asir fílius ejus,

23. Elcána fílius ejus, Abiásaph fílius ejus, Asir fílius ejus,

24. Thahath fílius ejus, Uríel fílius ejus, Ozías fílius ejus, Saul fílius ejus.

25. Fílii Elcána, Amásai et Áchimoth

26. et Elcána. Fílii Elcána : Sóphai fílius ejus, Nahath fílius ejus,

27. Elíab fílius ejus, Jéroham fílius ejus, Elcána fílius ejus.

28. Fílii Sámuel : primogénitus Vásseni, et Abía.

29. Fílii autem Merári, Móholi : Lobni fílius ejus, Sémei fílius ejus, Oza fílius ejus,

30. Sámmaa fílius ejus, Hággia fílius ejus, Asaía fílius ejus.

31. Isti sunt quos constítuit David super cantóres domus Dómini, ex quo collocáta est arca :

32. et ministrábant coram tabernáculo testimónii, canéntes donec ædificáret Sálomon domum Dómini in Jerúsalem : stabant autem juxta órdinem suum in ministério.

33. Hi vero sunt qui assistébant cum fíliis suis, de fíliis Caath, Hemam cantor fílius Johel, fílii Sámuel,

34. fílii Elcána, fílii Jéroham, fílii Elíel, fílii Thohu,

35. fílii Suph, fílii Elcána, fílii Mahath, fílii Amásai,

36. fílii Elcána, fílii Johel, fílii Azaríæ, fílii Sophóniæ,

37. fílii Thahath, fílii Asir, fílii Abiásaph, fílii Core,

38. fílii Ísaar, fílii Caath, fílii Levi, fílii Israël.

39. Et frater ejus Asaph, qui stabat a dextris ejus, Asaph fílius Barachíæ, fílii Sámaa,

40. fílii Míchaël, fílii Basaíæ, fílii Mélchiæ,

41. fílii Athánai, fílii Zara, fílii Adaía,

42. fílii Ethan, fílii Zamma, fílii Sémei,

43. fílii Jeth, fílii Gersom, fílii Levi.

44. Fílii autem Merári fratres eórum, ad sinístram, Ethan fílius Cusi, fílii Abdi, fílii Maloch,

45. fílii Hasábiæ, fílii Amásiæ, fílii Helcíæ,

46. fílii Amásai, fílii Boni, fílii Somer,

47. fílii Móholi, fílii Musi, fílii Merári, fílii Levi.

48. Fratres quoque eórum Levítæ, qui ordináti sunt in cunctum ministérium tabernáculi domus Dómini.

49. Áaron vero et fílii ejus adolébant incénsum super altáre holocáusti, et super altáre thymiamátis, in omne opus Sancti sanctórum : et ut precaréntur pro Israël juxta ómnia quæ præcéperat Móyses servus Dei.

50. Hi sunt autem fílii Áaron : Eleázar fílius ejus, Phínees fílius ejus, Abísue fílius ejus,

51. Bocci fílius ejus, Ozi fílius ejus, Zaráhia fílius ejus,

52. Meraíoth fílius ejus, Amárias fílius ejus, Áchitob fílius ejus,

53. Sadoc fílius ejus, Achímaas fílius ejus.

54. Et hæc habitácula eórum per vicos atque confínia, filiórum scílicet Áaron, juxta cognatiónes Caathitárum : ipsis enim sorte contígerant.

55. Dedérunt ígitur eis Hebron in terra Juda, et suburbána ejus per circúitum :

56. agros autem civitátis, et villas, Caleb fílio Jephóne.

57. Porro fíliis Áaron dedérunt civitátes ad confugiéndum Hebron, et Lobna, et suburbána ejus,

58. Jether quoque, et Esthémo cum suburbánis suis, sed et Helon, et Dabir cum suburbánis suis,

59. Asan quoque, et Bethsémes, et suburbána eárum.

60. De tribu autem Bénjamin, Gábee et suburbána ejus, et Almath cum suburbánis suis, Anáthoth quoque cum suburbánis suis : omnes civitátes, trédecim, per cognatiónes suas.

61. Fíliis autem Caath resíduis de cognatióne sua dedérunt ex dimídia tribu Manásse in possessiónem urbes decem.

62. Porro fíliis Gersom per cognatiónes suas de tribu Issáchar, et de tribu Aser, et de tribu Nephtháli, et de tribu Manásse in Basan, urbes trédecim.

63. Fíliis autem Merári per cognatiónes suas de tribu Ruben, et de tribu Gad, et de tribu Zábulon, dedérunt sorte civitátes duódecim.

64. Dedérunt quoque fílii Israël Levítis civitátes, et suburbána eárum :

65. dederúntque per sortem, ex tribu filiórum Juda, et ex tribu filiórum Símeon, et ex tribu filiórum Bénjamin urbes has, quas vocavérunt nomínibus suis,

66. et his, qui erant de cognatióne filiórum Caath, fuerúntque civitátes in términis eórum de tribu Éphraim.

67. Dedérunt ergo eis urbes ad confugiéndum, Sichem cum suburbánis suis in monte Éphraim, et Gazer cum suburbánis suis,

68. Jécmaam quoque cum suburbánis suis, et Bethóron simíliter,

69. necnon et Helon cum suburbánis suis, et Gethrémmon in eúmdem modum.

70. Porro ex dimídia tribu Manásse, Aner et suburbána ejus, Bálaam et suburbána ejus : his vidélicet, qui de cognatióne filiórum Caath réliqui erant.

71. Fíliis autem Gersom de cognatióne dimídiæ tribus Manásse, Gaulon in Basan, et suburbána ejus, et Astároth cum suburbánis suis.

72. De tribu Issáchar, Cedes et suburbánis suis, et Dábereth cum suburbánis suis,

73. Ramoth quoque et suburbána ejus, et Anem cum suburbánis suis.

74. De tribu vero Aser : Masal cum suburbánis suis, et Abdon simíliter,

75. Hucac quoque et suburbána ejus, et Rohob cum suburbánis suis.

76. Porro de tribu Nephtháli, Cedes in Galilǽa et suburbána ejus, Hamon cum suburbánis suis, et Cariáthaim et suburbána ejus.

77. Fíliis autem Merári resíduis : de tribu Zábulon, Remmóno et suburbána ejus, et Thabor cum suburbánis sus :

78. trans Jordánem quoque ex advérso Jéricho contra oriéntem Jordánis, de tribu Ruben, Bosor in solitúdine cum suburbánis suis, et Jassa cum suburbánis suis,

79. Cadémoth quoque et suburbána ejus, et Méphaat cum suburbánis suis.

80. Necnon et de tribu Gad, Ramoth in Gálaad et suburbána ejus, et Mánaim cum suburbánis suis,

81. sed et Hesébon cum suburbánis suis, et Jezer cum suburbánis suis.

