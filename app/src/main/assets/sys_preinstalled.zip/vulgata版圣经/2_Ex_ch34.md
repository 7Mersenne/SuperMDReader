# Liber Exodus - Caput 34

1. Ac deínceps : Prǽcide, ait, tibi duas tábulas lapídeas instar priórum, et scribam super eas verba, quæ habuérunt tábulæ quas fregísti.

2. Esto parátus mane, ut ascéndas statim in montem Sínai, stabísque mecum super vérticem montis.

3. Nullus ascéndat tecum, nec videátur quíspiam per totum montem : boves quoque et oves non pascántur e contra.

4. Excídit ergo duas tábulas lapídeas, quales ántea fúerant : et de nocte consúrgens ascéndit in montem Sínai, sicut præcéperat ei Dóminus, portans secum tábulas.

5. Cumque descendísset Dóminus per nubem, stetit Móyses cum eo, ínvocans nomen Dómini.

6. Quo transeúnte coram eo, ait : Dominátor Dómine Deus, miséricors et clemens, pátiens et multæ miseratiónis, ac verax,

7. qui custódis misericórdiam in míllia ; qui aufers iniquitátem, et scélera, atque peccáta, nullúsque apud te per se ínnocens est ; qui reddis iniquitátem patrum fíliis, ac nepótibus in tértiam et quartam progéniem.

8. Festinúsque Móyses, curvátus est pronus in terram, et adórans

9. ait : Si invéni grátiam in conspéctu tuo, Dómine, óbsecro ut gradiáris nobíscum (pópulus enim duræ cervícis est) et áuferas iniquitátes nostras atque peccáta, nosque possídeas.

10. Respóndit Dóminus : Ego iníbo pactum vidéntibus cunctis : signa fáciam quæ numquam visa sunt super terram, nec in ullis géntibus, ut cernat pópulus iste, in cujus es médio, opus Dómini terríbile quod factúrus sum.

11. Obsérva cuncta quæ hódie mando tibi : ego ipse ejíciam ante fáciem tuam Amorrhǽum, et Chananǽum, et Hethǽum, Pherezǽum quoque, et Hevǽum, et Jebusǽum.

12. Cave ne umquam cum habitatóribus terræ illíus jungas amicítias, quæ sint tibi in ruínam :

13. sed aras eórum déstrue, confrínge státuas, lucósque succíde :

14. noli adoráre deum aliénum. Dóminus zelótes nomen ejus ; Deus est æmulátor.

15. Ne íneas pactum cum homínibus illárum regiónum : ne, cum fornicáti fúerint cum diis suis, et adoráverint simulácra eórum, vocet te quíspiam ut cómedas de immolátis.

16. Nec uxórem de filiábus eórum accípies fíliis tuis : ne, postquam ipsæ fúerint fornicátæ, fornicári fáciant et fílios tuos in deos suos.

17. Deos conflátiles non fácies tibi.

18. Solemnitátem azymórum custódies. Septem diébus vésceris ázymis, sicut præcépi tibi, in témpore mensis novórum : mense enim verni témporis egréssus es de Ægýpto.

19. Omne quod áperit vulvam géneris masculíni, meum erit. De cunctis animántibus, tam de bobus, quam de óvibus, meum erit.

20. Primogénitum ásini rédimes ove : sin autem nec prétium pro eo déderis, occidétur. Primogénitum filiórum tuórum rédimes : nec apparébis in conspéctu meo vácuus.

21. Sex diébus operáberis ; die séptimo cessábis aráre et métere.

22. Solemnitátem hebdomadárum fácies tibi in primítiis frugum messis tuæ tritíceæ, et solemnitátem, quando redeúnte anni témpore cuncta condúntur.

23. Tribus tempóribus anni apparébit omne masculínum tuum in conspéctu omnipoténtis Dómini Dei Israël.

24. Cum enim túlero gentes a fácie tua, et dilatávero términos tuos, nullus insidiábitur terræ tuæ, ascendénte te, et apparénte in conspéctu Dómini Dei tui ter in anno.

25. Non immolábis super ferménto sánguinem hóstiæ meæ : neque residébit mane de víctima solemnitátis Phase.

26. Primítias frugum terræ tuæ ófferes in domo Dómini Dei tui. Non coques hædum in lacte matris suæ.

27. Dixítque Dóminus ad Móysen : Scribe tibi verba hæc, quibus et tecum et cum Israël pépigi fœdus.

28. Fuit ergo ibi cum Dómino quadragínta dies et quadragínta noctes : panem non comédit, et aquam non bibit, et scripsit in tábulis verba fóederis decem.

29. Cumque descénderet Móyses de monte Sínai, tenébat duas tábulas testimónii, et ignorábat quod cornúta esset fácies sua ex consórtio sermónis Dómini.

30. Vidéntes autem Áaron et fílii Israël cornútam Móysi fáciem, timuérunt prope accédere.

31. Vocatíque ab eo, revérsi sunt tam Áaron, quam príncipes synagógæ. Et postquam locútus est ad eos,

32. venérunt ad eum étiam omnes fílii Israël : quibus præcépit cuncta quæ audíerat a Dómino in monte Sínai.

33. Impletísque sermónibus, pósuit velámen super fáciem suam.

34. Quod ingréssus ad Dóminum, et loquens cum eo, auferébat donec exíret, et tunc loquebátur ad fílios Israël ómnia quæ sibi fúerant imperáta.

35. Qui vidébant fáciem egrediéntis Móysi esse cornútam, sed operiébat ille rursus fáciem suam, siquándo loquebátur ad eos.

