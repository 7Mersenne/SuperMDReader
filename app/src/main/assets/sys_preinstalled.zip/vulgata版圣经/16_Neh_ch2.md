# Liber Nehemi� - Caput 2

1. Factum est autem in mense Nisan, anno vigésimo Artaxérxis regis : et vinum erat ante eum, et levávi vinum, et dedi regi : et eram quasi lánguidus ante fáciem ejus.

2. Dixítque mihi rex : Quare vultus tuus tristis est, cum te ægrótum non vídeam ? non est hoc frustra, sed malum néscio quod in corde tuo est. Et tímui valde, ac nimis :

3. et dixi regi : Rex, in ætérnum vive : quare non móereat vultus meus, quia cívitas domus sepulchrórum patris mei desérta est, et portæ ejus combústæ sunt igni ?

4. Et ait mihi rex : Pro qua re póstulas ? Et orávi Deum cæli,

5. et dixi ad regem : Si vidétur regi bonum, et si placet servus tuus ante fáciem tuam, ut mittas me in Judǽam ad civitátem sepúlchri patris mei, et ædificábo eam.

6. Dixítque mihi rex, et regína quæ sedébat juxta eum : Usque ad quod tempus erit iter tuum, et quando revertéris ? Et plácuit ante vultum regis, et misit me : et constítui ei tempus.

7. Et dixi regi : Si regi vidétur bonum, epístolas det mihi ad duces regiónis trans flumen, ut tradúcant me, donec véniam in Judǽam :

8. et epístolam ad Asaph custódem saltus regis, ut det mihi ligna, ut tégere possim portas turris domus, et muros civitátis, et domum quam ingréssus fúero. Et dedit mihi rex juxta manum Dei mei bonam mecum.

9. Et veni ad duces regiónis trans flumen, dedíque eis epístolas regis. Míserat autem rex mecum príncipes mílitum, et équites.

10. Et audiérunt Sanabállat Horónites, et Tobías servus Ammánites : et contristáti sunt afflictióne magna, quod venísset homo qui quǽreret prosperitátem filiórum Israël.

11. Et veni Jerúsalem, et eram ibi tribus diébus.

12. Et surréxi nocte ego, et viri pauci mecum, et non indicávi cuíquam quid Deus dedísset in corde meo ut fácerem in Jerúsalem : et juméntum non erat mecum, nisi ánimal cui sedébam.

13. Et egréssus sum per portam vallis nocte, et ante fontem dracónis, et ad portam stércoris, et considerábam murum Jerúsalem dissipátum, et portas ejus consúmptas igni.

14. Et transívi ad portam fontis, et ad aquædúctum regis, et non erat locus juménto cui sedébam ut transíret.

15. Et ascéndi per torréntem nocte, et considerábam murum, et revérsus veni ad portam vallis, et rédii.

16. Magistrátus autem nesciébant quo abiíssem, aut quid ego fácerem : sed et Judǽis, et sacerdótibus, et optimátibus, et magistrátibus, et réliquis qui faciébant opus, usque ad id loci nihil indicáveram.

17. Et dixi eis : Vos nostis afflictiónem in qua sumus : quia Jerúsalem desérta est, et portæ ejus consúmptæ sunt igni : veníte, et ædificémus muros Jerúsalem, et non simus ultra oppróbrium.

18. Et indicávi eis manum Dei mei, quod esset bona mecum, et verba regis quæ locútus esset mihi, et aío : Surgámus, et ædificémus. Et confortátæ sunt manus eórum in bono.

19. Audiérunt autem Sanabállat Horónites, et Tobías servus Ammánites, et Gosem Arabs, et subsannavérunt nos, et despexérunt, dixerúntque : Quæ est hæc res quam fácitis ? numquid contra regem vos rebellátis ?

20. Et réddidi eis sermónem, dixíque ad eos : Deus cæli ipse nos juvat, et nos servi ejus sumus : surgámus et ædificémus : vobis autem non est pars, et justítia, et memória in Jerúsalem.

