# Liber Genesis - Caput 18

1. Appáruit autem ei Dóminus in conválle Mambre sedénti in óstio tabernáculi sui in ipso fervóre diéi.

2. Cumque elevásset óculos, apparuérunt ei tres viri stantes prope eum : quos cum vidísset, cucúrrit in occúrsum eórum de óstio tabernáculi, et adorávit in terram.

3. Et dixit : Dómine, si invéni grátiam in óculis tuis, ne tránseas servum tuum :

4. sed áfferam pauxíllum aquæ, et laváte pedes vestros, et requiéscite sub árbore.

5. Ponámque buccéllam panis, et confortáte cor vestrum : póstea transíbitis : idcírco enim declinástis ad servum vestrum. Qui dixérunt : Fac ut locútus es.

6. Festinávit Ábraham in tabernáculum ad Saram, dixítque ei : Accélera, tria sata símilæ commísce, et fac subcinerícios panes.

7. Ipse vero ad arméntum cucúrrit, et tulit inde vítulum tenérrimum et óptimum, dedítque púero : qui festinávit et coxit illum.

8. Tulit quoque butýrum et lac, et vítulum quem cóxerat, et pósuit coram eis : ipse vero stabat juxta eos sub árbore.

9. Cumque comedíssent, dixérunt ad eum : Ubi est Sara uxor tua ? Ille respóndit : Ecce in tabernáculo est.

10. Cui dixit : Revértens véniam ad te témpore isto, vita cómite, et habébit fílium Sara uxor tua. Quo audíto, Sara risit post óstium tabernáculi.

11. Erant autem ambo senes, provectǽque ætátis, et desíerant Saræ fíeri muliébria.

12. Quæ risit occúlte dicens : Postquam consénui, et dóminus meus vétulus est, voluptáti óperam dabo ?

13. Dixit autem Dóminus ad Ábraham : Quare risit Sara, dicens : Num vere paritúra sum anus ?

14. Numquid Deo quidquam est diffícile ? juxta condíctum revértar ad te hoc eódem témpore, vita cómite, et habébit Sara fílium.

15. Negávit Sara, dicens : Non risi, timóre pertérrita. Dóminus autem : Non est, inquit, ita : sed risísti.

16. Cum ergo surrexíssent inde viri, direxérunt óculos contra Sodómam : et Ábraham simul gradiebátur, dedúcens eos.

17. Dixítque Dóminus : Num celáre pótero Ábraham quæ gestúrus sum :

18. cum futúrus sit in gentem magnam, ac robustíssimam, et benedicéndæ sint in illo omnes natiónes terræ ?

19. Scio enim quod præceptúrus sit fíliis suis, et dómui suæ post se ut custódiant viam Dómini, et fáciant judícium et justítiam : ut addúcat Dóminus propter Ábraham ómnia quæ locútus est ad eum.

20. Dixit ítaque Dóminus : Clamor Sodomórum et Gomórrhæ multiplicátus est, et peccátum eórum aggravátum est nimis.

21. Descéndam, et vidébo utrum clamórem qui venit ad me, ópere compléverint ; an non est ita, ut sciam.

22. Converterúntque se inde, et abiérunt Sodómam : Ábraham vero adhuc stabat coram Dómino.

23. Et appropínquans ait : Numquid perdes justum cum ímpio ?

24. si fúerint quinquagínta justi in civitáte, períbunt simul ? et non parces loco illi propter quinquagínta justos, si fúerint in eo ?

25. Absit a te ut rem hanc fácias, et óccidas justum cum ímpio, fiátque justus sicut ímpius, non est hoc tuum : qui júdicas omnem terram, nequáquam fácies judícium hoc.

26. Dixítque Dóminus ad eum : Si invénero Sodómis quinquagínta justos in médio civitátis, dimíttam omni loco propter eos.

27. Respondénsque Ábraham, ait : Quia semel cœpi, loquar ad Dóminum meum, cum sim pulvis et cinis.

28. Quid si minus quinquagínta justis quinque fúerint ? delébis, propter quadragínta quinque, univérsam urbem ? Et ait : Non delébo, si invénero ibi quadragínta quinque.

29. Rursúmque locútus est ad eum : Sin autem quadragínta ibi invénti fúerint, quid fácies ? Ait : Non percútiam propter quadragínta.

30. Ne quæso, inquit, indígneris, Dómine, si loquar : quid si ibi invénti fúerint trigínta ? Respóndit : Non fáciam, si invénero ibi trigínta.

31. Quia semel, ait, cœpi loquar ad Dóminum meum : quid si ibi invénti fúerint vigínti ? Ait : Non interfíciam propter vigínti.

32. Óbsecro, inquit, ne irascáris, Dómine, si loquar adhuc semel : quid si invénti fúerint ibi decem ? Et dixit : Non delébo propter decem.

33. Abiítque Dóminus, postquam cessávit loqui ad Ábraham : et ille revérsus est in locum suum.

