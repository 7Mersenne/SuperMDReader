# Liber Exodus - Caput 3

1. Móyses autem pascébat oves Jethro sóceri sui sacerdótis Mádian : cumque minásset gregem ad interióra desérti, venit ad montem Dei Horeb.

2. Apparuítque ei Dóminus in flamma ignis de médio rubi : et vidébat quod rubus árderet, et non comburerétur.

3. Dixit ergo Móyses : Vadam, et vidébo visiónem hanc magnam, quare non comburátur rubus.

4. Cernens autem Dóminus quod pérgeret ad vidéndum, vocávit eum de médio rubi, et ait : Móyses, Móyses. Qui respóndit : Adsum.

5. At ille : Ne apprópies, inquit, huc : solve calceaméntum de pédibus tuis : locus enim, in quo stas, terra sancta est.

6. Et ait : Ego sum Deus patris tui, Deus Ábraham, Deus Ísaac et Deus Jacob. Abscóndit Móyses fáciem suam : non enim audébat aspícere contra Deum.

7. Cui ait Dóminus : Vidi afflictiónem pópuli mei in Ægýpto, et clamórem ejus audívi propter durítiam eórum qui præsunt opéribus :

8. et sciens dolórem ejus, descéndi ut líberem eum de mánibus Ægyptiórum, et edúcam de terra illa in terram bonam, et spatiósam, in terram quæ fluit lacte et melle, ad loca Chananǽi et Hethǽi, et Amorrhǽi, et Pherezǽi, et Hevǽi, et Jebusǽi.

9. Clamor ergo filiórum Israël venit ad me : vidíque afflictiónem eórum, qua ab Ægýptiis opprimúntur.

10. Sed veni, et mittam te ad Pharaónem, ut edúcas pópulum meum, fílios Israël, de Ægýpto.

11. Dixítque Móyses ad Deum : Quis sum ego ut vadam ad Pharaónem, et edúcam fílios Israël de Ægýpto ?

12. Qui dixit ei : Ego ero tecum : et hoc habébis signum, quod míserim te : cum edúxeris pópulum meum de Ægýpto, immolábis Deo super montem istum.

13. Ait Móyses ad Deum : Ecce ego vadam ad fílios Israël, et dicam eis : Deus patrum vestrórum misit me ad vos. Si díxerint mihi : Quod est nomen ejus ? quid dicam eis ?

14. Dixit Deus ad Móysen : Ego sum qui sum. Ait : Sic dices fíliis Israël : Qui est, misit me ad vos.

15. Dixítque íterum Deus ad Móysen : Hæc dices fíliis Israël : Dóminus Deus patrum vestrórum, Deus Ábraham, Deus Ísaac et Deus Jacob, misit me ad vos : hoc nomen mihi est in ætérnum, et hoc memoriále meum in generatiónem et generatiónem.

16. Vade, et cóngrega senióres Israël, et dices ad eos : Dóminus Deus patrum vestrórum appáruit mihi, Deus Ábraham, Deus Ísaac et Deus Jacob, dicens : Vísitans visitávi vos : et vidi ómnia quæ accidérunt vobis in Ægýpto.

17. Et dixi ut edúcam vos de afflictióne Ægýpti in terram Chananǽi, et Hethǽi, et Amorrhǽi, et Pherezǽi, et Hevǽi, et Jebusǽi, ad terram fluéntem lacte et melle.

18. Et áudient vocem tuam : ingredierísque tu, et senióres Israël, ad regem Ægýpti, et dices ad eum : Dóminus Deus Hebræórum vocávit nos : íbimus viam trium diérum in solitúdinem, ut immolémus Dómino Deo nostro.

19. Sed ego scio quod non dimíttet vos rex Ægýpti ut eátis nisi per manum válidam.

20. Exténdam enim manum meam, et percútiam Ægýptum in cunctis mirabílibus meis, quæ factúrus sum in médio eórum : post hæc dimíttet vos.

21. Dabóque grátiam pópulo huic coram Ægýptiis : et cum egrediémini, non exíbitis vácui :

22. sed postulábit múlier a vicína sua et ab hóspita sua, vasa argéntea et áurea, ac vestes : ponetísque eas super fílios et fílias vestras, et spoliábitis Ægýptum.

