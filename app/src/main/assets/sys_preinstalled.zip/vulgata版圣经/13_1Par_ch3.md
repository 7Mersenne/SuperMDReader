# Liber Primus Paralipomenon - Caput 3

1. David vero hos hábuit fílios, qui ei nati sunt in Hebron : primogénitum Amnon ex Achínoam Jezrahelítide, secúndum Dániel de Abígail Carmelítide,

2. tértium Absálom fílium Maácha fíliæ Thólmai regis Gessur, quartum Adóniam fílium Aggith,

3. quintum Sapháthiam ex Ábital, sextum Jéthraham de Egla uxóre sua.

4. Sex ergo nati sunt ei in Hebron, ubi regnávit septem annis et sex ménsibus. Trigínta autem et tribus annis regnávit in Jerúsalem.

5. Porro in Jerúsalem nati sunt ei fílii, Símmaa, et Sobab, et Nathan, et Sálomon, quátuor de Bethsábee fília Ámmiel :

6. Jébaar quoque et Elisáma,

7. et Elipháleth, et Noge, et Nepheg, et Jáphia,

8. necnon Elisáma, et Eliáda, et Elípheleth, novem :

9. omnes hi, fílii David absque fíliis concubinárum : habuerúntque sorórem Thamar.

10. Fílius autem Salomónis, Róboam : cujus Abía fílius génuit Asa. De hoc quoque natus est Jósaphat,

11. pater Joram : qui Joram génuit Ochóziam, ex quo ortus est Joas :

12. et hujus Amásias fílius génuit Azaríam. Porro Azaríæ fílius Jóatham

13. procreávit Achaz patrem Ezechíæ, de quo natus est Manásses.

14. Sed et Manásses génuit Amon patrem Josíæ.

15. Fílii autem Josíæ fuérunt : primogénitus Johánan, secúndus Jóakim, tértius Sedécias, quartus Sellum.

16. De Jóakim natus est Jechonías, et Sedécias.

17. Fílii Jechoníæ fuérunt : Asir, Saláthiel,

18. Melchíram, Phadaía, Sennéser, et Jecémia, Sama, et Nadábia.

19. De Phadaía orti sunt Zoróbabel et Sémei. Zoróbabel génuit Mosóllam, Hanániam, et Salómith sorórem eórum :

20. Hasában quoque, et Ohol, et Barachían, et Hasádian, Josabhésed, quinque.

21. Fílius autem Hanániæ, Pháltias pater Jeseíæ, cujus fílius Raphaía : hujus quoque fílius, Arnan, de quo natus est Óbdia, cujus fílius fuit Sechénias.

22. Fílius Sechéniæ, Semeía : cujus fílii Hattus, et Jégaal, et Bária, et Naária, et Saphat, sex número.

23. Fílius Naáriæ, Elioënai, et Ezechías, et Ézricam, tres.

24. Fílii Elioënai, Oduía, et Eliásub, et Pheleía, et Accub, et Johánan, et Dalaía, et Anáni, septem.

