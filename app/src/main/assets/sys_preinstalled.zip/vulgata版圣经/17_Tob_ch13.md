# Liber Tobi� - Caput 13

1. Apériens autem Tobías sénior os suum, benedíxit Dóminum, et dixit : Magnus es, Dómine, in ætérnum, et in ómnia sǽcula regnum tuum :

2. quóniam tu flagéllas, et salvas ; dedúcis ad ínferos, et redúcis : et non est qui effúgiat manum tuam.

3. Confitémini Dómino, fílii Israël, et in conspéctu géntium laudáte eum :

4. quóniam ídeo dispérsit vos inter gentes quæ ignórant eum, ut vos enarrétis mirabília ejus, et faciátis scire eos quia non est álius deus omnípotens præter eum.

5. Ipse castigávit nos propter iniquitátes nostras, et ipse salvábit nos propter misericórdiam suam.

6. Aspícite ergo quæ fecit nobíscum, et cum timóre et tremóre confitémini illi : regémque sæculórum exaltáte in opéribus vestris.

7. Ego autem in terra captivitátis meæ confitébor illi : quóniam osténdit majestátem suam in gentem peccatrícem.

8. Convertímini ítaque peccatóres, et fácite justítiam coram Deo, credéntes quod fáciat vobíscum misericórdiam suam.

9. Ego autem et ánima mea in eo lætábimur.

10. Benedícite Dóminum omnes elécti ejus : ágite dies lætítiæ, et confitémini illi.

11. Jerúsalem cívitas Dei, castigávit te Dóminus in opéribus mánuum tuárum.

12. Confitére Dómino in bonis tuis, et bénedic Deum sæculórum : ut reædíficet in te tabernáculum suum, et révocet ad te omnes captívos, et gáudeas in ómnia sǽcula sæculórum.

13. Luce spléndida fulgébis, et omnes fines terræ adorábunt te.

14. Natiónes ex longínquo ad te vénient, et múnera deferéntes adorábunt in te Dóminum, et terram tuam in sanctificatiónem habébunt :

15. nomen enim magnum invocábunt in te.

16. Maledícti erunt qui contémpserint te, et condemnáti erunt omnes qui blasphemáverint te : benedictíque erunt qui ædificáverint te.

17. Tu autem lætáberis in fíliis tuis, quóniam omnes benedicéntur, et congregabúntur ad Dóminum.

18. Beáti omnes qui díligunt te, et qui gaudent super pace tua.

19. Ánima mea, bénedic Dóminum, quóniam liberávit Jerúsalem civitátem suam a cunctis tribulatiónibus ejus Dóminus Deus noster.

20. Beátus ero si fúerint réliquiæ séminis mei ad vidéndam claritátem Jerúsalem.

21. Portæ Jerúsalem ex sapphíro et smarágdo ædificabúntur, et ex lápide pretióso omnis circúitus murórum ejus.

22. Ex lápide cándido et mundo omnes platéæ ejus sternéntur, et per vicos ejus allelúja cantábitur.

23. Benedíctus Dóminus, qui exaltávit eam, et sit regnum ejus in sǽcula sæculórum super eam. Amen.

