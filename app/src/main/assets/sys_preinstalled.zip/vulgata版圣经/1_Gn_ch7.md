# Liber Genesis - Caput 7

1. Dixítque Dóminus ad eum : Ingrédere tu et omnis domus tua in arcam : te enim vidi justum coram me in generatióne hac.

2. Ex ómnibus animántibus mundis tolle septéna et septéna, másculum et féminam : de animántibus vero immúndis duo et duo, másculum et féminam.

3. Sed et de volatílibus cæli septéna et septéna, másculum et féminam : ut salvétur semen super fáciem univérsæ terræ.

4. Adhuc enim, et post dies septem ego pluam super terram quadragínta diébus et quadragínta nóctibus : et delébo omnem substántiam, quam feci, de superfície terræ.

5. Fecit ergo Noë ómnia quæ mandáverat ei Dóminus.

6. Erátque sexcentórum annórum quando dilúvii aquæ inundavérunt super terram.

7. Et ingréssus est Noë et fílii ejus, uxor ejus et uxóres filiórum ejus cum eo in arcam propter aquas dilúvii.

8. De animántibus quoque mundis et immúndis, et de volúcribus, et ex omni quod movétur super terram,

9. duo et duo ingréssa sunt ad Noë in arcam, másculus et fémina, sicut præcéperat Dóminus Noë.

10. Cumque transíssent septem dies, aquæ dilúvii inundavérunt super terram.

11. Anno sexcentésimo vitæ Noë, mense secúndo, septimodécimo die mensis, rupti sunt omnes fontes abýssi magnæ, et cataráctæ cæli apértæ sunt :

12. et facta est plúvia super terram quadragínta diébus et quadragínta nóctibus.

13. In artículo diéi illíus ingréssus est Noë, et Sem, et Cham, et Japheth fílii ejus ; uxor illíus, et tres uxóres filiórum ejus cum eis in arcam :

14. ipsi et omne ánimal secúndum genus suum, universáque juménta in génere suo, et omne quod movétur super terram in génere suo, cunctúmque volátile secúndum genus suum, univérsæ aves, omnésque vólucres,

15. ingréssæ sunt ad Noë in arcam, bina et bina ex omni carne, in qua erat spíritus vitæ.

16. Et quæ ingréssa sunt, másculus et fémina ex omni carne introiérunt, sicut præcéperat ei Deus : et inclúsit eum Dóminus defóris.

17. Factúmque est dilúvium quadragínta diébus super terram : et multiplicátæ sunt aquæ, et elevavérunt arcam in sublíme a terra.

18. Veheménter enim inundavérunt, et ómnia replevérunt in superfície terræ : porro arca ferebátur super aquas.

19. Et aquæ prævaluérunt nimis super terram : opertíque sunt omnes montes excélsi sub univérso cælo.

20. Quíndecim cúbitis áltior fuit aqua super montes, quos operúerat.

21. Consumptáque est omnis caro quæ movebátur super terram, vólucrum, animántium, bestiárum, omniúmque reptílium, quæ reptant super terram : univérsi hómines,

22. et cuncta, in quibus spiráculum vitæ est in terra, mórtua sunt.

23. Et delévit omnem substántiam quæ erat super terram, ab hómine usque ad pecus, tam réptile quam vólucres cæli : et deléta sunt de terra. Remánsit autem solus Noë, et qui cum eo erant in arca.

24. Obtinuerúntque aquæ terram centum quinquagínta diébus.

