# Liber Tobi� - Caput 11

1. Cumque reverteréntur, pervenérunt ad Charan, quæ est in médio itínere contra Níniven, undécimo die.

2. Dixítque ángelus : Tobía frater, scis quemádmodum reliquísti patrem tuum.

3. Si placet ítaque tibi, præcedámus, et lento gradu sequántur iter nostrum famíliæ, simul cum cónjuge tua, et cum animálibus.

4. Cumque hoc placuísset ut irent, dixit Ráphaël ad Tobíam : Tolle tecum ex felle piscis : erit enim necessárium. Tulit ítaque Tobías ex felle illo, et abiérunt.

5. Anna autem sedébat secus viam quotídie in supercílio montis, unde respícere póterat de longínquo.

6. Et dum ex eódem loco specularétur advéntum ejus, vidit a longe, et íllico agnóvit veniéntem fílium suum : currénsque nuntiávit viro suo, dicens : Ecce venit fílius tuus.

7. Dixítque Ráphaël ad Tobíam : At ubi introíeris domum tuam, statim adóra Dóminum Deum tuum : et grátias agens ei, accéde ad patrem tuum, et osculáre eum.

8. Statímque lini super óculos ejus ex felle isto piscis, quod portas tecum : scias enim quóniam mox aperiéntur óculi ejus, et vidébit pater tuus lumen cæli, et in aspéctu tuo gaudébit.

9. Tunc præcucúrrit canis, qui simul fúerat in via : et quasi núntius advéniens, blandiménto suæ caudæ gaudébat.

10. Et consúrgens cæcus pater ejus, cœpit offéndens pédibus cúrrere : et data manu púero, occúrrit óbviam fílio suo.

11. Et suscípiens osculátus est eum cum uxóre sua, et cœpérunt ambo flere præ gáudio.

12. Cumque adorássent Deum, et grátias egíssent, consedérunt.

13. Tunc sumens Tobías de felle piscis, linívit óculos patris sui.

14. Et sustínuit quasi dimídiam fere horam : et cœpit álbugo ex óculis ejus, quasi membrána ovi, égredi.

15. Quam apprehéndens Tobías, traxit ab óculis ejus : statímque visum recépit.

16. Et glorificábant Deum, ipse vidélicet et uxor ejus, et omnes qui sciébant eum.

17. Dicebátque Tobías : Benedíco te, Dómine Deus Israël, quia tu castigásti me, et tu salvásti me : et ecce ego vídeo Tobíam fílium meum.

18. Ingréssa est étiam post septem dies Sara uxor fílii ejus et omnis família sana, et pécora, et cámeli, et pecúnia multa uxóris ; sed et illa pecúnia, quam recéperat a Gábelo.

19. Et narrávit paréntibus suis ómnia benefícia Dei, quæ fecísset circa eum per hóminem qui eum dúxerat.

20. Venerúntque Áchior et Nabath consobríni Tobíæ gaudéntes ad Tobíam, et congratulántes ei de ómnibus bonis quæ circa illum osténderat Deus.

21. Et per septem dies epulántes, omnes cum gáudio magno gavísi sunt.

