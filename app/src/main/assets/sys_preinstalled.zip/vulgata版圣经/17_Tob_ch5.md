# Liber Tobi� - Caput 5

1. Tunc respóndit Tobías patri suo, et dixit : Ómnia quæcúmque præcepísti mihi fáciam, pater.

2. Quómodo autem pecúniam hanc requíram, ignóro : ille me nescit, et ego eum ignóro : quod signum dabo ei ? sed neque viam per quam pergátur illuc aliquándo cognóvi.

3. Tunc pater suus respóndit illi, et dixit : Chirográphum quidem illíus penes me hábeo : quod dum illi osténderis, statim restítuet.

4. Sed perge nunc, et inquíre tibi áliquem fidélem virum, qui eat tecum salva mercéde sua, ut dum adhuc vivo, recípias eam.

5. Tunc egréssus Tobías, invénit júvenem spléndidum stantem præcínctum, et quasi parátum ad ambulándum.

6. Et ignórans quod ángelus Dei esset, salutávit eum, et dixit : Unde te habémus, bone júvenis ?

7. At ille respóndit : Ex fíliis Israël. Et Tobías dixit ei : Nosti viam quæ ducit in regiónem Medórum ?

8. Cui respóndit : Novi : et ómnia itínera ejus frequénter ambulávi, et mansi apud Gábelum fratrem nostrum, qui morátur in Rages civitáte Medórum, quæ pósita est in monte Ecbatánis.

9. Cui Tobías ait : Sústine me óbsecro, donec hæc ipsa núntiem patri meo.

10. Tunc ingréssus Tobías, indicávit univérsa hæc patri suo. Super quæ admirátus pater, rogávit ut introíret ad eum.

11. Ingréssus ítaque salutávit eum, et dixit : Gáudium tibi sit semper.

12. Et ait Tobías : Quale gáudium mihi erit, qui in ténebris sédeo, et lumen cæli non vídeo ?

13. Cui ait júvenis : Forti ánimo esto : in próximo est ut a Deo cúreris.

14. Dixit ítaque illi Tobías : Numquid póteris perdúcere fílium meum ad Gábelum in Rages civitátem Medórum ? et cum redíeris, restítuam tibi mercédem tuam.

15. Et dixit ei ángelus : Ego ducam, et redúcam eum ad te.

16. Cui Tobías respóndit : Rogo te, índica mihi de qua domo aut de qua tribu es tu.

17. Cui Ráphaël ángelus dixit : Genus quæris mercenárii, an ipsum mercenárium qui cum fílio tuo eat ?

18. sed ne forte sollícitum te reddam, ego sum Azarías Ananíæ magni fílius.

19. Et Tobías respóndit : Ex magno génere es tu. Sed peto ne irascáris quod volúerim cognóscere genus tuum.

20. Dixit autem illi ángelus : Ego sanum ducam, et sanum tibi redúcam fílium tuum.

21. Respóndens autem Tobías, ait : Bene ambulétis, et sit Deus in itínere vestro, et ángelus ejus comitétur vobíscum.

22. Tunc parátis ómnibus quæ erant in via portánda, fecit Tobías vale patri suo et matri suæ, et ambulavérunt ambo simul.

23. Cumque profécti essent, cœpit mater ejus flere, et dícere : Báculum senectútis nostræ tulísti, et transmisísti a nobis.

24. Numquam fuísset ipsa pecúnia, pro qua misísti eum :

25. sufficiébat enim nobis paupértas nostra, ut divítias computarémus hoc, quod videbámus fílium nostrum.

26. Dixítque ei Tobías : Noli flere : salvus pervéniet fílius noster, et salvus revertétur ad nos, et óculi tui vidébunt illum.

27. Credo enim quod ángelus Dei bonus comitétur ei, et bene dispónat ómnia quæ circa eum gerúntur, ita ut cum gáudio revertátur ad nos.

28. Ad hanc vocem cessávit mater ejus flere, et tácuit.

