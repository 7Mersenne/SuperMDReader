# Liber Genesis - Caput 45

1. Non se póterat ultra cohíbere Joseph multis coram astántibus : unde præcépit ut egrederéntur cuncti foras, et nullus interésset aliénus agnitióni mútuæ.

2. Elevavítque vocem cum fletu, quam audiérunt Ægýptii, omnísque domus Pharaónis.

3. Et dixit frátribus suis : Ego sum Joseph : adhuc pater meus vivit ? Non póterant respondére fratres nímio terróre pertérriti.

4. Ad quos ille cleménter : Accédite, inquit, ad me. Et cum accessíssent prope : Ego sum, ait, Joseph, frater vester, quem vendidístis in Ægýptum.

5. Nolíte pavére, neque vobis durum esse videátur quod vendidístis me in his regiónibus : pro salúte enim vestra misit me Deus ante vos in Ægýptum.

6. Biénnium est enim quod cœpit fames esse in terra : et adhuc quinque anni restant, quibus nec arári póterit, nec meti.

7. Præmisítque me Deus ut reservémini super terram, et escas ad vivéndum habére possítis.

8. Non vestro consílio, sed Dei voluntáte huc missus sum : qui fecit me quasi patrem Pharaónis, et dóminum univérsæ domus ejus, ac príncipem in omni terra Ægýpti.

9. Festináte, et ascéndite ad patrem meum, et dicétis ei : Hæc mandat fílius tuus Joseph : Deus fecit me dóminum univérsæ terræ Ægýpti : descénde ad me, ne moréris,

10. et habitábis in terra Gessen : erísque juxta me tu, et fílii tui, et fílii filiórum tuórum, oves tuæ, et arménta tua, et univérsa quæ póssides :

11. ibíque te pascam (ádhuc enim quinque anni resídui sunt famis) ne et tu péreas, et domus tua, et ómnia quæ póssides.

12. En óculi vestri, et óculi fratris mei Bénjamin, vident quod os meum loquátur ad vos.

13. Nuntiáte patri meo univérsam glóriam meam, et cuncta quæ vidístis in Ægýpto : festináte, et addúcite eum ad me.

14. Cumque amplexátus recidísset in collum Bénjamin fratris sui, flevit : illo quoque simíliter flente super collum ejus.

15. Osculatúsque est Joseph omnes fratres suos, et plorávit super síngulos : post quæ ausi sunt loqui ad eum.

16. Auditúmque est, et célebri sermóne vulgátum in aula regis : Venérunt fratres Joseph : et gavísus est Phárao, atque omnis família ejus.

17. Dixítque ad Joseph ut imperáret frátribus suis, dicens : Onerántes juménta, ite in terram Chánaan,

18. et tóllite inde patrem vestrum et cognatiónem, et veníte ad me : et ego dabo vobis ómnia bona Ægýpti, ut comedátis medúllam terræ.

19. Prǽcipe étiam ut tollant plaustra de terra Ægýpti, ad subvectiónem parvulórum suórum ac cónjugum : et dícito : Tóllite patrem vestrum, et properáte quantócius veniéntes.

20. Nec dimittátis quidquam de supelléctili vestra : quia omnes opes Ægýpti vestræ erunt.

21. Fecerúntque fílii Israël ut eis mandátum fúerat. Quibus dedit Joseph plaustra, secúndum Pharaónis impérium, et cibária in itínere.

22. Síngulis quoque proférri jussit binas stolas : Bénjamin vero dedit trecéntos argénteos cum quinque stolis óptimis :

23. tantúmdem pecúniæ et véstium mittens patri suo, addens et ásinos decem, qui subvéherent ex ómnibus divítiis Ægýpti, et tótidem ásinas, tríticum in itínere, panésque portántes.

24. Dimísit ergo fratres suos, et proficiscéntibus ait : Ne irascámini in via.

25. Qui ascendéntes ex Ægýpto, venérunt in terram Chánaan ad patrem suum Jacob.

26. Et nuntiavérunt ei, dicéntes : Joseph fílius tuus vivit : et ipse dominátur in omni terra Ægýpti. Quo audíto Jacob, quasi de gravi somno evígilans, tamen non credébat eis.

27. Illi e contra referébant omnem órdinem rei. Cumque vidísset plaustra et univérsa quæ míserat, revíxit spíritus ejus,

28. et ait : Súfficit mihi si adhuc Joseph fílius meus vivit : vadam, et vidébo illum ántequam móriar.

