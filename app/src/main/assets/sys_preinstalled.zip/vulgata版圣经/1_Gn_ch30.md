# Liber Genesis - Caput 30

1. Cernens autem Rachel quod infecúnda esset, ínvidit soróri suæ, et ait márito suo : Da mihi líberos, alióquin móriar.

2. Cui irátus respóndit Jacob : Num pro Deo ego sum, qui privávit te fructu ventris tui ?

3. At illa : Hábeo, inquit, fámulam Balam : ingrédere ad illam, ut páriat super génua mea, et hábeam ex illa fílios.

4. Dedítque illi Balam in conjúgium : quæ,

5. ingrésso ad se viro, concépit, et péperit fílium.

6. Dixítque Rachel : Judicávit mihi Dóminus, et exaudívit vocem meam, dans mihi fílium, et idcírco appellávit nomen ejus Dan.

7. Rursúmque Bala concípiens, péperit álterum,

8. pro quo ait Rachel : Comparávit me Deus cum soróre mea, et inválui : vocavítque eum Nephtháli.

9. Séntiens Lia quod párere desiísset, Zelpham ancíllam suam márito trádidit.

10. Qua post concéptum edénte fílium,

11. dixit : Felíciter, et idcírco vocávit nomen ejus Gad.

12. Péperit quoque Zelpha álterum.

13. Dixítque Lia : Hoc pro beatitúdine mea : beátam quippe me dicent mulíeres : proptérea appellávit eum Aser.

14. Egréssus autem Ruben témpore messis tritíceæ in agrum, réperit mandragóras, quas matri Liæ détulit. Dixítque Rachel : Da mihi partem de mandragóris fílii tui.

15. Illa respóndit : Parúmne tibi vidétur quod præripúeris máritum mihi, nisi étiam mandragóras fílii mei túleris ? Ait Rachel : Dórmiat tecum hac nocte pro mandragóris fílii tui.

16. Redeuntíque ad vésperam Jacob de agro, egréssa est in occúrsum ejus Lia, et Ad me, inquit, intrábis : quia mercéde condúxi te pro mandragóris fílii mei. Dormivítque cum ea nocte illa.

17. Et exaudívit Deus preces ejus, concepítque et péperit fílium quintum,

18. et ait : Dedit Deus mercédem mihi, quia dedi ancíllam meam viro meo : appellavítque nomen ejus Issáchar.

19. Rursum Lia concípiens, péperit sextum fílium,

20. et ait : Dotávit me Deus dote bona : étiam hac vice mecum erit máritus meus, eo quod genúerim ei sex fílios : et idcírco appellávit nomen ejus Zábulon.

21. Post quem péperit fíliam, nómine Dinam.

22. Recordátus quoque Dóminus Ráchelis, exaudívit eam, et apéruit vulvam ejus.

23. Quæ concépit, et péperit fílium, dicens : Ábstulit Deus oppróbrium meum.

24. Et vocávit nomen ejus Joseph, dicens : Addat mihi Dóminus fílium álterum.

25. Nato autem Joseph, dixit Jacob sócero suo : Dimítte me ut revértar in pátriam, et ad terram meam.

26. Da mihi uxóres, et líberos meos, pro quibus servívi tibi, ut ábeam : tu nosti servitútem qua servívi tibi.

27. Ait illi Laban : Invéniam grátiam in conspéctu tuo, experiménto dídici, quia benedíxerit mihi Deus propter te :

28. constítue mercédem tuam quam dem tibi.

29. At ille respóndit : Tu nosti quómodo servíerim tibi, et quanta in mánibus meis fúerit posséssio tua.

30. Módicum habuísti ántequam venírem ad te, et nunc dives efféctus es : benedixítque tibi Dóminus ad intróitum meum. Justum est ígitur ut aliquándo provídeam étiam dómui meæ.

31. Dixítque Laban : Quid tibi dabo ? At ille ait : Nihil volo : sed si féceris quod póstulo, íterum pascam, et custódiam pécora tua.

32. Gyra omnes greges tuos, et sépara cunctas oves várias, et sparso véllere ; quodcúmque furvum, et maculósum, variúmque fúerit, tam in óvibus quam in capris, erit merces mea.

33. Respondebítque mihi cras justítia mea, quando pláciti tempus advénerit coram te : et ómnia quæ non fúerint vária, et maculósa, et furva, tam in óvibus quam in capris, furti me árguent.

34. Dixítque Laban : Gratum hábeo quod petis.

35. Et separávit in die illa capras, et oves, et hircos, et aríetes vários, atque maculósos : cunctum autem gregem unicolórem, id est albi et nigri vélleris, trádidit in manu filiórum suórum.

36. Et pósuit spátium itíneris trium diérum inter se et génerum, qui pascébat réliquos greges ejus.

37. Tollens ergo Jacob virgas popúleas vírides, et amygdálinas, et ex plátanis, ex parte decorticávit eas : detractísque cortícibus, in his, quæ spoliáta fúerant, candor appáruit : illa vero quæ íntegra fúerant, virídia permansérunt : atque in hunc modum color efféctus est várius.

38. Posuítque eas in canálibus, ubi effundebátur aqua : ut cum veníssent greges ad bibéndum, ante óculos habérent virgas, et in aspéctu eárum concíperent.

39. Factúmque est ut in ipso calóre cóitus, oves intueréntur virgas, et párerent maculósa, et vária, et divérso colóre respérsa.

40. Divisítque gregem Jacob, et pósuit virgas in canálibus ante óculos aríetum : erant autem alba et nigra quæque, Laban ; cétera vero, Jacob, separátis inter se grégibus.

41. Ígitur quando primo témpore ascendebántur oves, ponébat Jacob virgas in canálibus aquárum ante óculos aríetum et óvium, ut in eárum contemplatióne concíperent :

42. quando vero serótina admissúra erat, et concéptus extrémus, non ponébat eas. Factáque sunt ea quæ erant serótina, Laban : et quæ primi témporis, Jacob.

43. Ditatúsque est homo ultra modum, et hábuit greges multos, ancíllas et servos, cámelos et ásinos.

