# Liber Genesis - Caput 17

1. Postquam vero nonagínta et novem annórum esse cóeperat, appáruit ei Dóminus, dixítque ad eum : Ego Deus omnípotens : ámbula coram me, et esto perféctus.

2. Ponámque fœdus meum inter me et te, et multiplicábo te veheménter nimis.

3. Cécidit Abram pronus in fáciem.

4. Dixítque ei Deus : Ego sum, et pactum meum tecum, erísque pater multárum géntium.

5. Nec ultra vocábitur nomen tuum Abram, sed appelláberis Ábraham : quia patrem multárum géntium constítui te.

6. Faciámque te créscere vehementíssime, et ponam te in géntibus, regésque ex te egrediéntur.

7. Et státuam pactum meum inter me et te, et inter semen tuum post te in generatiónibus suis, fóedere sempitérno : ut sim Deus tuus, et séminis tui post te.

8. Dabóque tibi et sémini tuo terram peregrinatiónis tuæ, omnem terram Chánaan in possessiónem ætérnam, eróque Deus eórum.

9. Dixit íterum Deus ad Ábraham : Et tu ergo custódies pactum meum, et semen tuum post te in generatiónibus suis.

10. Hoc est pactum meum quod observábitis inter me et vos, et semen tuum post te : circumcidétur ex vobis omne masculínum :

11. et circumcidétis carnem præpútii vestri, ut sit in signum fóederis inter me et vos.

12. Infans octo diérum circumcidétur in vobis, omne masculínum in generatiónibus vestris : tam vernáculus, quam emptítius circumcidétur, et quicúmque non fúerit de stirpe vestra :

13. erítque pactum meum in carne vestra in fœdus ætérnum.

14. Másculus, cujus præpútii caro circumcísa non fúerit, delébitur ánima illa de pópulo suo : quia pactum meum írritum fecit.

15. Dixit quoque Deus ad Ábraham : Sárai uxórem tuam non vocábis Sárai, sed Saram.

16. Et benedícam ei, et ex illa dabo tibi fílium cui benedictúrus sum : erítque in natiónes, et reges populórum oriéntur ex eo.

17. Cécidit Ábraham in fáciem suam, et risit, dicens in corde suo : Putásne centenário nascétur fílius ? et Sara nonagenária páriet ?

18. Dixítque ad Deum : Útinam Ísmaël vivat coram te.

19. Et ait Deus ad Ábraham : Sara uxor tua páriet tibi fílium, vocabísque nomen ejus Ísaac, et constítuam pactum meum illi in fœdus sempitérnum, et sémini ejus post eum.

20. Super Ísmaël quoque exaudívi te : ecce, benedícam ei, et augébo, et multiplicábo eum valde : duódecim duces generábit, et fáciam illum in gentem magnam.

21. Pactum vero meum státuam ad Ísaac, quem páriet tibi Sara témpore isto in anno áltero.

22. Cumque fínitus esset sermo loquéntis cum eo, ascéndit Deus ab Ábraham.

23. Tulit autem Ábraham Ísmaël fílium suum, et omnes vernáculos domus suæ, universósque quos émerat, cunctos mares ex ómnibus viris domus suæ : et circumcídit carnem præpútii eórum statim in ipsa die, sicut præcéperat ei Deus.

24. Ábraham nonagínta et novem erat annórum quando circumcídit carnem præpútii sui.

25. Et Ísmaël fílius trédecim annos impléverat témpore circumcisiónis suæ.

26. Eádem die circumcísus est Ábraham et Ísmaël fílius ejus :

27. et omnes viri domus illíus, tam vernáculi, quam emptítii et alienígenæ páriter circumcísi sunt.

