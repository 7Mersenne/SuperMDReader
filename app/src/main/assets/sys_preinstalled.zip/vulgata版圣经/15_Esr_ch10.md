# Liber Esdr� - Caput 10

1. Sic ergo oránte Esdra, et imploránte eo et flente, et jacénte ante templum Dei, colléctus est ad eum de Israël cœtus grandis nimis virórum et mulíerum et puerórum, et flevit pópulus fletu multo.

2. Et respóndit Sechénias fílius Jéhiel de fíliis Ælam, et dixit Esdræ : Nos prævaricáti sumus in Deum nostrum, et dúximus uxóres alienígenas de pópulis terræ : et nunc, si est pœniténtia in Israël super hoc,

3. percutiámus fœdus cum Dómino Deo nostro, ut projiciámus univérsas uxóres, et eos qui de his nati sunt, juxta voluntátem Dómini, et eórum qui timent præcéptum Dómini Dei nostri : secúndum legem fiat.

4. Surge, tuum est decérnere, nosque érimus tecum : confortáre, et fac.

5. Surréxit ergo Esdras, et adjurávit príncipes sacerdótum et Levitárum, et omnem Israël, ut fácerent secúndum verbum hoc : et juravérunt.

6. Et surréxit Esdras ante domum Dei, et ábiit ad cubículum Johánan fílii Eliásib, et ingréssus est illuc : panem non comédit, et aquam non bibit : lugébat enim transgressiónem eórum, qui vénerant de captivitáte.

7. Et missa est vox in Juda et in Jerúsalem ómnibus fíliis transmigratiónis, ut congregaréntur in Jerúsalem :

8. et omnis qui non vénerit in tribus diébus juxta consílium príncipum et seniórum, auferétur univérsa substántia ejus, et ipse abjiciétur de cœtu transmigratiónis.

9. Convenérunt ígitur omnes viri Juda et Bénjamin in Jerúsalem tribus diébus : ipse est mensis nonus, vigésimo die mensis : et sedit omnis pópulus in platéa domus Dei, treméntes pro peccáto, et plúviis.

10. Et surréxit Esdras sacérdos, et dixit ad eos : Vos transgréssi estis, et duxístis uxóres alienígenas, ut adderétis super delíctum Israël.

11. Et nunc date confessiónem Dómino Deo patrum vestrórum, et fácite plácitum ejus, et separámini a pópulis terræ, et ab uxóribus alienígenis.

12. Et respóndit univérsa multitúdo, dixítque voce magna : Juxta verbum tuum ad nos, sic fiat.

13. Verúmtamen quia pópulus multus est, et tempus plúviæ, et non sustinémus stare foris, et opus non est diéi uníus vel duórum (veheménter quippe peccávimus in sermóne isto),

14. constituántur príncipes in univérsa multitúdine : et omnes in civitátibus nostris qui duxérunt uxóres alienígenas véniant in tempóribus statútis, et cum his senióres per civitátem et civitátem, et júdices ejus, donec avertátur ira Dei nostri a nobis super peccáto hoc.

15. Ígitur Jónathan fílius Ázahel, et Jaásia fílius Thécue, stetérunt super hoc, et Messóllam et Sebéthai Levítes adjuvérunt eos :

16. fecerúntque sic fílii transmigratiónis. Et abiérunt Esdras sacérdos, et viri príncipes familiárum, in domos patrum suórum, et omnes per nómina sua, et sedérunt in die primo mensis décimi ut quǽrerent rem.

17. Et consummáti sunt omnes viri, qui dúxerant uxóres alienígenas, usque ad diem primam mensis primi.

18. Et invénti sunt de fíliis sacerdótum qui dúxerant uxóres alienígenas. De fíliis Jósue fílii Jósedec, et fratres ejus, Maásia, et Eliézer, et Jarib, et Godólia.

19. Et dedérunt manus suas ut ejícerent uxóres suas, et pro delícto suo aríetem de óvibus offérrent.

20. Et de fíliis Emmer, Hanáni, et Zebédia.

21. Et de fíliis Harim, Maásia, et Elía, et Semeía, et Jéhiel, et Ozías.

22. Et de fíliis Pheshur, Elioënai, Maásia, Ísmaël, Nathánaël, Jozábed, et Elása.

23. Et de fíliis Levitárum, Jozábed, et Sémei, et Celaía, ipse est Cálita, Phataía, Juda, et Eliézer.

24. Et de cantóribus, Eliásib. Et de janitóribus, Sellum, et Telem, et Uri.

25. Et ex Israël, de fíliis Pharos, Remeía, et Jésia, et Mélchia, et Miámin, et Eliézer, et Mélchia, et Bánea.

26. Et de fíliis Ælam, Mathánia, Zacharías, et Jéhiel, et Abdi, et Jérimoth, et Elía.

27. Et de fíliis Zéthua, Elioënai, Eliásib, Mathánia, et Jérimuth, et Zabad, et Azíza.

28. Et de fíliis Bébai, Johánan, Hanánia, Zábbai, Athálai.

29. Et de fíliis Bani, Mosóllam, et Melluch, et Adaía, Jasub, et Saal, et Ramoth.

30. Et de fíliis Phahath Moab, Edna, et Chalal, Banaías, et Maásias, Mathánias, Beséleel, Bénnui, et Manásse.

31. Et de fíliis Herem, Eliézer, Jósue, Mélchias, Semeías, Símeon,

32. Bénjamin, Maloch, Samarías.

33. Et de fíliis Hasom, Mathánai, Mathátha, Zabad, Elíphelet, Jérmai, Manásse, Sémei.

34. De fíliis Bani, Maádi, Amram, et Vel,

35. Báneas, et Badaías, Cheliáu,

36. Vánia, Márimuth, et Eliásib,

37. Mathánias, Mathánai, et Jasi,

38. et Bani, et Bénnui, Sémei,

39. et Sálmias, et Nathan, et Adaías,

40. et Mechnedébai, Sísai, Sárai,

41. Ezrel, et Selemiáu, Seméria,

42. Sellum, Amária, Joseph.

43. De fíliis Nebo, Jéhiel, Matháthias, Zabad, Zábina, Jeddu, et Joël, et Banaía.

44. Omnes hi accéperant uxóres alienígenas, et fuérunt ex eis mulíeres, quæ pepérerant fílios.

