# Liber Genesis - Caput 26

1. Orta autem fame super terram post eam sterilitátem, quæ accíderat in diébus Ábraham, ábiit Ísaac ad Abímelech regem Palæstinórum in Gerára.

2. Apparuítque ei Dóminus, et ait : Ne descéndas in Ægýptum, sed quiésce in terra quam díxero tibi,

3. et peregrináre in ea : eróque tecum, et benedícam tibi : tibi enim et sémini tuo dabo univérsas regiónes has, complens juraméntum quod spopóndi Ábraham patri tuo.

4. Et multiplicábo semen tuum sicut stellas cæli : dabóque pósteris tuis univérsas regiónes has : et benedicéntur in sémine tuo omnes gentes terræ,

5. eo quod obedíerit Ábraham voci meæ, et custodíerit præcépta et mandáta mea, et cæremónias legésque serváverit.

6. Mansit ítaque Ísaac in Geráris.

7. Qui cum interrogarétur a viris loci illíus super uxóre sua, respóndit : Soror mea est : timúerat enim confitéri quod sibi esset sociáta conjúgio, réputans ne forte interfícerent eum propter illíus pulchritúdinem.

8. Cumque pertransíssent dies plúrimi, et ibídem morarétur, prospíciens Abímelech rex Palæstinórum per fenéstram, vidit eum jocántem cum Rebécca uxóre sua.

9. Et accersíto eo, ait : Perspícuum est quod uxor tua sit : cur mentítus es eam sorórem tuam esse ? Respóndit : Tímui ne morérer propter eam.

10. Dixítque Abímelech : Quare imposuísti nobis ? pótuit coíre quíspiam de pópulo cum uxóre tua, et indúxeras super nos grande peccátum. Præcepítque omni pópulo, dicens :

11. Qui tetígerit hóminis hujus uxórem, morte moriétur.

12. Sevit autem Ísaac in terra illa, et invénit in ipso anno céntuplum : benedixítque ei Dóminus.

13. Et locupletátus est homo, et ibat profíciens atque succréscens, donec magnus veheménter efféctus est :

14. hábuit quoque possessiónes óvium et armentórum, et famíliæ plúrimum. Ob hoc invidéntes ei Palǽstini,

15. omnes púteos, quos fóderant servi patris illíus Ábraham, illo témpore obstruxérunt, impléntes humo :

16. in tantum, ut ipse Abímelech díceret ad Ísaac : Recéde a nobis, quóniam poténtior nobis factus es valde.

17. Et ille discédens, ut veníret ad torréntem Geráræ, habitarétque ibi,

18. rursum fodit álios púteos, quos fóderant servi patris sui Ábraham, et quos, illo mórtuo, olim obstrúxerant Philísthiim : appellavítque eos eísdem nomínibus quibus ante pater vocáverat.

19. Foderúntque in torrénte, et reperérunt aquam vivam.

20. Sed et ibi júrgium fuit pastórum Geráræ advérsus pastóres Ísaac, dicéntium : Nostra est aqua, quam ob rem nomen pútei ex eo, quod accíderat, vocávit Calúmniam.

21. Fodérunt autem et álium : et pro illo quoque rixáti sunt, appellavítque eum Inimicítias.

22. Proféctus inde fodit álium púteum, pro quo non contendérunt : ítaque vocávit nomen ejus Latitúdo, dicens : Nunc dilatávit nos Dóminus, et fecit créscere super terram.

23. Ascéndit autem ex illo loco in Bersabée,

24. ubi appáruit ei Dóminus in ipsa nocte, dicens : Ego sum Deus Ábraham patris tui : noli timére, quia ego tecum sum : benedícam tibi, et multiplicábo semen tuum propter servum meum Ábraham.

25. Ítaque ædificávit ibi altáre : et invocáto nómine Dómini, exténdit tabernáculum, præcepítque servis suis ut fóderent púteum.

26. Ad quem locum cum veníssent de Geráris Abímelech, et Ochózath amícus illíus, et Phicol dux mílitum,

27. locútus est eis Ísaac : Quid venístis ad me, hóminem quem odístis, et expulístis a vobis ?

28. Qui respondérunt : Vídimus tecum esse Dóminum, et idcírco nos díximus : Sit juraméntum inter nos, et ineámus fœdus,

29. ut non fácias nobis quidquam mali, sicut et nos nihil tuórum attígimus, nec fécimus quod te lǽderet : sed cum pace dimísimus auctum benedictióne Dómini.

30. Fecit ergo eis convívium, et post cibum et potum

31. surgéntes mane, juravérunt sibi mútuo : dimisítque eos Ísaac pacífice in locum suum.

32. Ecce autem venérunt in ipso die servi Ísaac annuntiántes ei de púteo, quem fóderant, atque dicéntes : Invénimus aquam.

33. Unde appellávit eum Abundántiam : et nomen urbi impósitum est Bersabée, usque in præséntem diem.

34. Ésau vero quadragenárius duxit uxóres, Judith fíliam Béeri Hethǽi, et Basémath fíliam Elon ejúsdem loci :

35. quæ ambæ offénderant ánimum Ísaac et Rebéccæ.

