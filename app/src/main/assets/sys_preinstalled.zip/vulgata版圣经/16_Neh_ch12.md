# Liber Nehemi� - Caput 12

1. Hi sunt autem sacerdótes et Levítæ, qui ascendérunt cum Zoróbabel fílio Saláthiel, et Jósue : Saraía, Jeremías, Esdras,

2. Amária, Melluch, Hattus,

3. Sebénias, Rheum, Mérimuth,

4. Addo, Genthon, Abía,

5. Miámin, Mádia, Belga,

6. Semeía, et Jojárib, Idaía, Sellum, Amoc, Helcías,

7. Idaía. Isti príncipes sacerdótum, et fratres eórum in diébus Jósue.

8. Porro Levítæ, Jésua, Bénnui, Cédmihel, Sarébia, Juda, Mathánias, super hymnos ipsi et fratres eórum :

9. et Becbécia atque Hanni, et fratres eórum, unusquísque in offício suo.

10. Jósue autem génuit Joácim, et Joácim génuit Eliásib, et Eliásib génuit Jojáda,

11. et Jojáda génuit Jónathan, et Jónathan génuit Jéddoa.

12. In diébus autem Joácim erant sacerdótes et príncipes familiárum : Saraíæ, Maraía : Jeremíæ, Hanánia :

13. Esdræ, Mosóllam : Amáriæ, Johánan :

14. Mílicho, Jónathan : Sebéniæ, Joseph :

15. Haram, Edna : Maraíoth, Helci :

16. Adaíæ, Zacharía : Genthon, Mosóllam :

17. Abíæ, Zechri : Miámin et Moádiæ, Phelti :

18. Belgæ, Sámmua : Semaíæ, Jónathan :

19. Jojárib, Mathánai : Jodaíæ, Azzi :

20. Séllai, Célai : Amoc, Heber :

21. Helcíæ, Hasébia : Idaíæ, Nathánaël.

22. Levítæ in diébus Eliásib, et Jojáda, et Johánan, et Jéddoa, scripti príncipes familiárum, et sacerdótes in regno Daríi Persæ.

23. Fílii Levi príncipes familiárum, scripti in libro verbórum diérum, et usque ad dies Jónathan, fílii Eliásib.

24. Et príncipes Levitárum, Hasébia, Serébia, et Jósue fílius Cédmihel : et fratres eórum per vices suas, ut laudárent et confiteréntur juxta præcéptum David viri Dei, et observárent æque per órdinem.

25. Mathánia, et Becbécia, Obédia, Mosóllam, Telmon, Accub, custódes portárum et vestibulórum ante portas.

26. Hi in diébus Joácim fílii Jósue, fílii Jósedec, et in diébus Nehemíæ ducis, et Esdræ sacerdótis scribǽque.

27. In dedicatióne autem muri Jerúsalem, requisiérunt Levítas de ómnibus locis suis ut addúcerent eos in Jerúsalem, et fácerent dedicatiónem et lætítiam in actióne gratiárum, et cántico, et in cýmbalis, psaltériis, et cítharis.

28. Congregáti sunt autem fílii cantórum de campéstribus circa Jerúsalem, et de villis Nethupháthi,

29. et de domo Galgal, et de regiónibus Geba et Azmáveth : quóniam villas ædificavérunt sibi cantóres in circúitu Jerúsalem.

30. Et mundáti sunt sacerdótes et Levítæ, et mundavérunt pópulum, et portas, et murum.

31. Ascéndere autem feci príncipes Juda super murum, et státui duos magnos choros laudántium. Et iérunt ad déxteram super murum ad portam sterquilínii.

32. Et ivit post eos Osaías, et média pars príncipum Juda,

33. et Azarías, Esdras, et Mosóllam, Judas, et Bénjamin, et Semeía, et Jeremías.

34. Et de fíliis sacerdótum in tubis, Zacharías fílius Jónathan, fílius Semeíæ, fílius Mathániæ, fílius Michaíæ, fílius Zechur, fílius Asaph,

35. et fratres ejus Semeía, et Azáreel, Malálai, Galálai, Maái, Nathánaël, et Judas, et Hanáni, in vasis cántici David viri Dei : et Esdras scriba ante eos in porta fontis.

36. Et contra eos ascendérunt in grádibus civitátis David in ascénsu muri super domum David, et usque ad portam aquárum ad oriéntem.

37. Et chorus secúndus grátias referéntium ibat ex advérso, et ego post eum, et média pars pópuli super murum, et super turrim furnórum, et usque ad murum latíssimum,

38. et super portam Éphraim, et super portam antíquam, et super portam píscium et turrim Hanáneel, et turrim Emath, et usque ad portam gregis : et stetérunt in porta custódiæ,

39. steterúntque duo chori laudántium in domo Dei, et ego, et dimídia pars magistrátuum mecum.

40. Et sacerdótes, Eliáchim, Maásia, Miámin, Míchea, Elioënai, Zacharía, Hanánia in tubis,

41. et Maásia, et Semeía, et Eleázar, et Azzi, et Johánan, et Mélchia, et Ælam, et Ezer. Et clare cecinérunt cantóres, et Jezraía præpósitus :

42. et immolavérunt in die illa víctimas magnas, et lætáti sunt : Deus enim lætificáverat eos lætítia magna : sed et uxóres eórum et líberi gavísi sunt, et audíta est lætítia Jerúsalem procul.

43. Recensuérunt quoque in die illa viros super gazophylácia thesáuri ad libámina, et ad primítias, et ad décimas, ut introférrent per eos príncipes civitátis in decóre gratiárum actiónis, sacerdótes et Levítas : quia lætificátus est Juda in sacerdótibus et Levítis adstántibus.

44. Et custodiérunt observatiónem Dei sui, et observatiónem expiatiónis, et cantóres, et janitóres juxta præcéptum David, et Salomónis fílii ejus,

45. quia in diébus David et Asaph ab exórdio erant príncipes constitúti cantórum in cármine laudántium et confiténtium Deo.

46. Et omnis Israël in diébus Zoróbabel et in diébus Nehemíæ, dabant partes cantóribus et janitóribus per dies síngulos, et sanctificábant Levítas, et Levítæ sanctificábant fílios Áaron.

