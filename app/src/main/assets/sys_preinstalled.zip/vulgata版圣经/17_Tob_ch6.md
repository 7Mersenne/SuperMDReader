# Liber Tobi� - Caput 6

1. Proféctus est autem Tobías, et canis secútus est eum, et mansit prima mansióne juxta flúvium Tigris.

2. Et exívit ut laváret pedes suos, et ecce piscis immánis exívit ad devorándum eum.

3. Quem expavéscens Tobías clamávit voce magna, dicens : Dómine, invádit me.

4. Et dixit ei ángelus : Apprehénde bránchiam ejus, et trahe eum ad te. Quod cum fecísset, attráxit eum in siccum, et palpitáre cœpit ante pedes ejus.

5. Tunc dixit ei ángelus : Exéntera hunc piscem, et cor ejus, et fel, et jecur repóne tibi : sunt enim hæc necessária ad medicaménta utíliter.

6. Quod cum fecísset, assávit carnes ejus, et secum tulérunt in via : cétera saliérunt, quæ suffícerent eis, quoúsque pervenírent in Rages civitátem Medórum.

7. Tunc interrogávit Tobías ángelum, et dixit ei : Óbsecro te, Azaría frater, ut dicas mihi quod remédium habébunt ista, quæ de pisce serváre jussísti ?

8. Et respóndens ángelus, dixit ei : Cordis ejus partículam si super carbónes ponas, fumus ejus extrícat omne genus dæmoniórum sive a viro, sive a mulíere, ita ut ultra non accédat ad eos.

9. Et fel valet ad ungéndos óculos in quibus fúerit álbugo, et sanabúntur.

10. Et dixit ei Tobías : Ubi vis ut maneámus ?

11. Respondénsque ángelus, ait : Est hic Raguel nómine, vir propínquus de tribu tua, et hic habet fíliam nómine Saram, sed neque másculum neque féminam ullam habet áliam præter eam.

12. Tibi debétur omnis substántia ejus, et opórtet eam te accípere cónjugem.

13. Pete ergo eam a patre ejus, et dabit tibi eam in uxórem.

14. Tunc respóndit Tobías, et dixit : Áudio quia trádita est septem viris, et mórtui sunt : sed et hoc audívi, quia dæmónium óccidit illos.

15. Tímeo ergo, ne forte et mihi hæc evéniant : et cum sim únicus paréntibus meis, depónam senectútem illórum cum tristítia ad ínferos.

16. Tunc ángelus Ráphaël dixit ei : Audi me, et osténdam tibi qui sunt, quibus præválere potest dæmónium.

17. Hi namque qui conjúgium ita suscípiunt, ut Deum a se et a sua mente exclúdant, et suæ libídini ita vacent sicut equus et mulus quibus non est intelléctus : habet potestátem dæmónium super eos.

18. Tu autem cum accéperis eam, ingréssus cubículum, per tres dies cóntinens esto ab ea, et nihil áliud nisi oratiónibus vacábis cum ea.

19. Ipsa autem nocte, incénso jecóre piscis, fugábitur dæmónium.

20. Secúnda vero nocte in copulatióne sanctórum patriarchárum admítteris.

21. Tértia autem nocte, benedictiónem conséqueris, ut fílii ex vobis procreéntur incólumes.

22. Transácta autem tértia nocte, accípies vírginem cum timóre Dómini, amóre filiórum magis quam libídine ductus, ut in sémine Ábrahæ benedictiónem in fíliis consequáris.

