# Liber Genesis - Caput 33

1. Élevans autem Jacob óculos suos, vidit veniéntem Ésau, et cum eo quadringéntos viros : divisítque fílios Liæ et Rachel, ambarúmque famulárum :

2. et pósuit utrámque ancíllam, et líberos eárum, in princípio : Liam vero, et fílios ejus, in secúndo loco : Rachel autem et Joseph novíssimos.

3. Et ipse progrédiens adorávit pronus in terram sépties, donec appropinquáret frater ejus.

4. Currens ítaque Ésau óbviam fratri suo, amplexátus est eum : stringénsque collum ejus, et ósculans flevit.

5. Levatísque óculis, vidit mulíeres et párvulos eárum, et ait : Quid sibi volunt isti ? et si ad te pértinent ? Respóndit : Párvuli sunt quos donávit mihi Deus servo tuo.

6. Et appropinquántes ancíllæ et fílii eárum, incurváti sunt.

7. Accéssit quoque Lia cum púeris suis : et cum simíliter adorássent, extrémi Joseph et Rachel adoravérunt.

8. Dixítque Ésau : Quænam sunt istæ turmæ quas óbviam hábui ? Respóndit : Ut invenírem grátiam coram dómino meo.

9. At ille ait : Hábeo plúrima, frater mi, sint tua tibi.

10. Dixítque Jacob : Noli ita, óbsecro : sed si invéni grátiam in óculis tuis, áccipe munúsculum de mánibus meis. Sic enim vidi fáciem tuam, quasi víderim vultum Dei : esto mihi propítius,

11. et súscipe benedictiónem quam áttuli tibi, et quam donávit mihi Deus tríbuens ómnia. Vix fratre compellénte, suscípiens,

12. ait : Gradiámur simul, eróque sócius itíneris tui.

13. Dixítque Jacob : Nosti, dómine mi, quod párvulos hábeam téneros, et oves, et boves fœtas mecum : quas si plus in ambulándo fécero laboráre, moriéntur una die cuncti greges.

14. Præcédat dóminus meus ante servum suum : et ego sequar paulátim vestígia ejus, sicut vídero párvulos meos posse, donec véniam ad dóminum meum in Seir.

15. Respóndit Ésau : Oro te, ut de pópulo qui mecum est, saltem sócii remáneant viæ tuæ. Non est, inquit, necésse : hoc uno tantum indígeo, ut invéniam grátiam in conspéctu tuo, dómine mi.

16. Revérsus est ítaque illo die Ésau itínere quo vénerat in Seir.

17. Et Jacob venit in Socoth : ubi ædificáta domo et fixis tentóriis appellávit nomen loci illíus Socoth, id est, Tabernácula.

18. Transivítque in Salem urbem Sichimórum, quæ est in terra Chánaan, postquam revérsus est de Mesopotámia Sýriæ : et habitávit juxta óppidum.

19. Emítque partem agri, in qua fíxerat tabernácula, a fíliis Hemor patris Sichem centum agnis.

20. Et erécto ibi altári, invocávit super illud fortíssimum Deum Israël.

