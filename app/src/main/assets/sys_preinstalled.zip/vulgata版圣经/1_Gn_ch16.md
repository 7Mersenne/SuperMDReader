# Liber Genesis - Caput 16

1. Ígitur Sárai, uxor Abram, non genúerat líberos : sed habens ancíllam ægýptiam nómine Agar,

2. dixit márito suo : Ecce, conclúsit me Dóminus, ne párerem. Ingrédere ad ancíllam meam, si forte saltem ex illa suscípiam fílios. Cumque ille acquiésceret deprecánti,

3. tulit Agar ægýptiam ancíllam suam post annos decem quam habitáre cóeperant in terra Chánaan : et dedit eam viro suo uxórem.

4. Qui ingréssus est ad eam. At illa concepísse se videns, despéxit dóminam suam.

5. Dixítque Sárai ad Abram : Iníque agis contra me : ego dedi ancíllam meam in sinum tuum, quæ videns quod concéperit, despéctui me habet : júdicet Dóminus inter me et te.

6. Cui respóndens Abram : Ecce, ait, ancílla tua in manu tua est, útere ea ut libet. Affligénte ígitur eam Sárai, fugam íniit.

7. Cumque invenísset eam ángelus Dómini juxta fontem aquæ in solitúdine, qui est in via Sur in desérto,

8. dixit ad illam : Agar ancílla Sárai, unde venis ? et quo vadis ? Quæ respóndit : A fácie Sárai dóminæ meæ ego fúgio.

9. Dixítque ei ángelus Dómini : Revertére ad dóminam tuam, et humiliáre sub manu illíus.

10. Et rursum : Multíplicans, inquit, multiplicábo semen tuum, et non numerábitur præ multitúdine.

11. Ac deínceps : Ecce, ait, concepísti, et páries fílium : vocabísque nomen ejus Ísmaël, eo quod audíerit Dóminus afflictiónem tuam.

12. Hic erit ferus homo : manus ejus contra omnes, et manus ómnium contra eum : et e regióne universórum fratrum suórum figet tabernácula.

13. Vocávit autem nomen Dómini qui loquebátur ad eam : Tu Deus qui vidísti me. Dixit enim : Profécto hic vidi posterióra vidéntis me.

14. Proptérea appellávit púteum illum Púteum vivéntis et vidéntis me. Ipse est inter Cades et Barad.

15. Peperítque Agar Abræ fílium : qui vocávit nomen ejus Ísmaël.

16. Octogínta et sex annórum erat Abram quando péperit ei Agar Ismáëlem.

