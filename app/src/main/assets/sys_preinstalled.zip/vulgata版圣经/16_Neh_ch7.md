# Liber Nehemi� - Caput 7

1. Postquam autem ædificátus est murus, et pósui valvas, et recénsui janitóres, et cantóres, et Levítas,

2. præcépi Hanáni fratri meo, et Hanániæ príncipi domus de Jerúsalem (ípse enim quasi vir verax et timens Deum plus céteris videbátur),

3. et dixi eis : Non aperiántur portæ Jerúsalem usque ad calórem solis. Cumque adhuc assísterent, clausæ portæ sunt, et oppilátæ : et pósui custódes de habitatóribus Jerúsalem, síngulos per vices suas, et unumquémque contra domum suam.

4. Cívitas autem erat lata nimis et grandis, et pópulus parvus in médio ejus, et non erant domus ædificátæ.

5. Deus autem dedit in corde meo, et congregávi optimátes, et magistrátus, et vulgus, ut recénserem eos : et invéni librum census eórum qui ascénderant primum, et invéntum est scriptum in eo.

6. Isti fílii provínciæ, qui ascendérunt de captivitáte migrántium, quos transtúlerat Nabuchodonósor rex Babylónis, et revérsi sunt in Jerúsalem et in Judǽam, unusquísque in civitátem suam.

7. Qui venérunt cum Zoróbabel, Jósue, Nehemías, Azarías, Raámias, Nahamáni, Mardochǽus, Belsam, Mesphárath, Begoái, Nahum, Baána. Númerus virórum pópuli Israël :

8. fílii Pharos, duo míllia centum septuagínta duo :

9. fílii Saphátia, trecénti septuagínta duo :

10. fílii Área, sexcénti quinquagínta duo :

11. fílii Phaháthmoab filiórum Jósue et Joab, duo míllia octingénti decem et octo :

12. fílii Ælam, mille ducénti quinquagínta quátuor :

13. fílii Zéthua, octingénti quadragínta quinque :

14. fílii Záchai, septingénti sexagínta :

15. fílii Bánnui, sexcénti quadragínta octo :

16. fílii Bébai, sexcénti vigínti octo :

17. fílii Azgad, duo míllia trecénti vigínti duo :

18. fílii Adónicam, sexcénti sexagínta septem :

19. fílii Béguai, duo míllia sexagínta septem :

20. fílii Adin, sexcénti quinquagínta quinque :

21. fílii Ater, fílii Hezéciæ, nonagínta octo :

22. fílii Hasem, trecénti vigínti octo :

23. fílii Bésai, trecénti vigínti quátuor :

24. fílii Hareph, centum duódecim :

25. fílii Gábaon, nonagínta quinque :

26. fílii Béthlehem et Nétupha, centum octogínta octo.

27. Viri Anáthoth, centum vigínti octo.

28. Viri Betházmoth, quadragínta duo.

29. Viri Cariathiárim, Cephíra, et Beroth, septingénti quadragínta tres.

30. Viri Rama et Geba, sexcénti vigínti unus.

31. Viri Machmas, centum vigínti duo.

32. Viri Bethel et Hai, centum vigínti tres.

33. Viri Nebo altérius, quinquagínta duo.

34. Viri Ælam altérius, mille ducénti quinquagínta quátuor.

35. Fílii Harem, trecénti vigínti.

36. Fílii Jéricho, trecénti quadragínta quinque.

37. Fílii Lod Hadid et Ono, septingénti vigínti unus.

38. Fílii Sénaa, tria míllia nongénti trigínta.

39. Sacerdótes : fílii Idaía in domo Jósue, nongénti septuagínta tres.

40. Fílii Emmer, mille quinquagínta duo.

41. Fílii Phashur, mille ducénti quadragínta septem.

42. Fílii Arem, mille decem et septem. Levítæ :

43. fílii Jósue et Cédmihel filiórum

44. Oduíæ, septuagínta quátuor. Cantóres :

45. fílii Asaph, centum quadragínta octo.

46. Janitóres : fílii Sellum, fílii Ater, fílii Telmon, fílii Accub, fílii Hátita, fílii Sóbai : centum trigínta octo.

47. Nathinǽi : fílii Soha, fílii Hásupha, fílii Tébbaoth,

48. fílii Ceros, fílii Siáa, fílii Phadon, fílii Lebána, fílii Hagába, fílii Sélmai,

49. fílii Hanan, fílii Geddel, fílii Gaher,

50. fílii Raaía, fílii Rasin, fílii Nécoda,

51. fílii Gezem, fílii Aza, fílii Phásea,

52. fílii Bésai, fílii Munim, fílii Nephússim,

53. fílii Bacbuc, fílii Hácupha, fílii Harhur,

54. fílii Besloth, fílii Máhida, fílii Harsa,

55. fílii Bercos, fílii Sísara, fílii Thema,

56. fílii Násia, fílii Hátipha,

57. fílii servórum Salomónis, fílii Sóthai, fílii Sóphereth, fílii Phárida,

58. fílii Jahála, fílii Darcon, fílii Jeddel,

59. fílii Saphátia, fílii Hatil, fílii Phóchereth, qui erat ortus ex Sábaim fílio Amon.

60. Omnes Nathinǽi, et fílii servórum Salomónis, trecénti nonagínta duo.

61. Hi sunt autem qui ascendérunt de Thélmela, Thelhársa, Cherub, Addon, et Emmer : et non potuérunt indicáre domum patrum suórum, et semen suum, utrum ex Israël essent,

62. fílii Dalaía, fílii Tobía, fílii Nécoda, sexcénti quadragínta duo.

63. Et de sacerdótibus, fílii Hábia, fílii Accos, fílii Berzéllai, qui accépit de filiábus Berzéllai Galaáditis uxórem, et vocátus est nómine eórum.

64. Hi quæsiérunt scriptúram suam in censu, et non invenérunt : et ejécti sunt de sacerdótio.

65. Dixítque Athersátha eis ut non manducárent de Sanctis sanctórum, donec staret sacérdos doctus et erudítus.

66. Omnis multitúdo quasi vir unus quadragínta duo míllia trecénti sexagínta,

67. absque servis et ancíllis eórum, qui erant septem míllia trecénti trigínta septem, et inter eos cantóres et cantatríces, ducénti quadragínta quinque.

68. Equi eórum, septingénti trigínta sex : muli eórum, ducénti quadragínta quinque :

69. cámeli eórum, quadringénti trigínta quinque : ásini, sex míllia septingénti vigínti.

70. Nonnúlli autem de princípibus familiárum dedérunt in opus. Athersátha dedit in thesáurum auri drachmas mille, phíalas quinquagínta, túnicas sacerdotáles quingéntas trigínta.

71. Et de princípibus familiárum dedérunt in thesáurum óperis, auri drachmas vigínti míllia, et argénti mnas duo míllia ducéntas.

72. Et quod dedit réliquus pópulus, auri drachmas vigínti míllia, et argénti mnas duo míllia, et túnicas sacerdotáles sexagínta septem.

73. Habitavérunt autem sacerdótes, et Levítæ, et janitóres, et cantóres, et réliquum vulgus, et Nathinǽi, et omnis Israël, in civitátibus suis.

