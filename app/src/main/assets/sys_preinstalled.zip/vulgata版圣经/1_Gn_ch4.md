# Liber Genesis - Caput 4

1. Adam vero cognóvit uxórem suam Hevam, quæ concépit et péperit Cain, dicens : Possédi hóminem per Deum.

2. Rursúmque péperit fratrem ejus Abel. Fuit autem Abel pastor óvium, et Cain agrícola.

3. Factum est autem post multos dies ut offérret Cain de frúctibus terræ múnera Dómino.

4. Abel quoque óbtulit de primogénitis gregis sui, et de adípibus eórum : et respéxit Dóminus ad Abel, et ad múnera ejus.

5. Ad Cain vero, et ad múnera illíus non respéxit : iratúsque est Cain veheménter, et concídit vultus ejus.

6. Dixítque Dóminus ad eum : Quare irátus es ? et cur concídit fácies tua ?

7. nonne si bene égeris, recípies : sin autem male, statim in fóribus peccátum áderit ? sed sub te erit appetítus ejus, et tu domináberis illíus.

8. Dixítque Cain ad Abel fratrem suum : Egrediámur foras. Cumque essent in agro, consurréxit Cain advérsus fratrem suum Abel, et interfécit eum.

9. Et ait Dóminus ad Cain : Ubi est Abel frater tuus ? Qui respóndit : Néscio : num custos fratris mei sum ego ?

10. Dixítque ad eum : Quid fecísti ? vox sánguinis fratris tui clamat ad me de terra.

11. Nunc ígitur maledíctus eris super terram, quæ apéruit os suum, et suscépit sánguinem fratris tui de manu tua.

12. Cum operátus fúeris eam, non dabit tibi fructus suos : vagus et profúgus eris super terram.

13. Dixítque Cain ad Dóminum : Major est iníquitas mea, quam ut véniam mérear.

14. Ecce éjicis me hódie a fácie terræ, et a fácie tua abscóndar, et ero vagus et profúgus in terra : omnis ígitur qui invénerit me, occídet me.

15. Dixítque ei Dóminus : Nequáquam ita fiet : sed omnis qui occíderit Cain, séptuplum puniétur. Posuítque Dóminus Cain signum, ut non interfíceret eum omnis qui invenísset eum.

16. Egressúsque Cain a fácie Dómini, habitávit profúgus in terra ad orientálem plagam Eden.

17. Cognóvit autem Cain uxórem suam, quæ concépit, et péperit Henoch : et ædificávit civitátem, vocavítque nomen ejus ex nómine fílii sui, Henoch.

18. Porro Henoch génuit Irad, et Irad génuit Maviáël, et Maviáël génuit Mathúsaël, et Mathúsaël génuit Lamech.

19. Qui accépit duas uxóres, nomen uni Ada, et nomen álteri Sella.

20. Genuítque Ada Jabel, qui fuit pater habitántium in tentóriis, atque pastórum.

21. Et nomen fratris ejus Jubal : ipse fuit pater canéntium cíthara et órgano.

22. Sella quoque génuit Tubálcain, qui fuit malleátor et faber in cuncta ópera æris et ferri. Soror vero Tubálcain, Noëma.

23. Dixítque Lamech uxóribus suis Adæ et Sellæ : Audíte vocem meam, uxóres Lamech ; auscultáte sermónem meum : quóniam occídi virum in vulnus meum, et adolescéntulum in livórem meum.

24. Séptuplum últio dábitur de Cain : de Lamech vero septuágies sépties.

25. Cognóvit quoque adhuc Adam uxórem suam : et péperit fílium, vocavítque nomen ejus Seth, dicens : Pósuit mihi Deus semen áliud pro Abel, quem óccidit Cain.

26. Sed et Seth natus est fílius, quem vocávit Enos : iste cœpit invocáre nomen Dómini.

