# Liber Genesis - Caput 49

1. Vocávit autem Jacob fílios suos, et ait eis : Congregámini, ut annúntiem quæ ventúra sunt vobis in diébus novíssimis.

2. Congregámini, et audíte, fílii Jacob, audíte Israël patrem vestrum :

3. Ruben, primogénitus meus, tu fortitúdo mea, et princípium dolóris mei ; prior in donis, major in império.

4. Effúsus es sicut aqua, non crescas : quia ascendísti cubíle patris tui, et maculásti stratum ejus.

5. Símeon et Levi fratres vasa iniquitátis bellántia.

6. In consílium eórum non véniat ánima mea, et in cœtu illórum non sit glória mea : quia in furóre suo occidérunt virum, et in voluntáte sua suffodérunt murum.

7. Maledíctus furor eórum, quia pértinax : et indignátio eórum, quia dura : dívidam eos in Jacob, et dispérgam eos in Israël.

8. Juda, te laudábunt fratres tui : manus tua in cervícibus inimicórum tuórum, adorábunt te fílii patris tui.

9. Cátulus leónis Juda : ad prædam, fili mi, ascendísti : requiéscens accubuísti ut leo, et quasi leǽna : quis suscitábit eum ?

10. Non auferétur sceptrum de Juda, et dux de fémore ejus, donec véniat qui mitténdus est, et ipse erit expectátio géntium.

11. Ligans ad víneam pullum suum, et ad vitem, o fili mi, ásinam suam, lavábit in vino stolam suam et in sánguine uvæ pállium suum.

12. Pulchrióres sunt óculi ejus vino, et dentes ejus lacte candidióres.

13. Zábulon in líttore maris habitábit, et in statióne návium pertíngens usque ad Sidónem.

14. Issáchar ásinus fortis accúbans inter términos.

15. Vidit réquiem, quod esset bona et terram, quod óptima : et suppósuit húmerum suum ad portándum, factúsque est tribútis sérviens.

16. Dan judicábit pópulum suum sicut et ália tribus in Israël.

17. Fiat Dan colúber in via, cerástes in sémita, mordens úngulas equi, ut cadat ascénsor ejus retro.

18. Salutáre tuum expectábo, Dómine.

19. Gad, accínctus præliábitur ante eum : et ipse accingétur retrórsum.

20. Aser, pinguis panis ejus, et præbébit delícias régibus.

21. Nephtháli, cervus emíssus, et dans elóquia pulchritúdinis.

22. Fílius accréscens Joseph, fílius accréscens et decórus aspéctu : fíliæ discurrérunt super murum.

23. Sed exasperavérunt eum et jurgáti sunt, inviderúntque illi habéntes jácula.

24. Sedit in forti arcus ejus, et dissolúta sunt víncula brachiórum et mánuum illíus per manus poténtis Jacob : inde pastor egréssus est, lapis Israël.

25. Deus patris tui erit adjútor tuus, et omnípotens benedícet tibi benedictiónibus cæli désuper, benedictiónibus abýssi jacéntis deórsum, benedictiónibus úberum et vulvæ.

26. Benedictiónes patris tui confortátæ sunt benedictiónibus patrum ejus, donec veníret desidérium cóllium æternórum : fiant in cápite Joseph, et in vértice Nazarǽi inter fratres suos.

27. Bénjamin lupus rapax, mane cómedat prædam, et véspere dívidet spólia.

28. Omnes hi in tríbubus Israël duódecim : hæc locútus est eis pater suus, benedixítque síngulis benedictiónibus própriis.

29. Et præcépit eis, dicens : Ego cóngregor ad pópulum meum : sepélite me cum pátribus meis in spelúnca dúplici quæ est in agro Ephron Hethǽi,

30. contra Mambre in terra Chánaan, quam emit Ábraham cum agro ab Ephron Hethǽo in possessiónem sepúlchri.

31. Ibi sepeliérunt eum, et Saram uxórem ejus : ibi sepúltus est Ísaac cum Rebécca cónjuge sua : ibi et Lia cóndita jacet.

32. Finitísque mandátis quibus fílios instruébat, cóllegit pedes suos super léctulum, et óbiit : appositúsque est ad pópulum suum.

