# Liber Esdr� - Caput 1

1. In anno primo Cyri regis Persárum, ut complerétur verbum Dómini ex ore Jeremíæ, suscitávit Dóminus spíritum Cyri regis Persárum : et tradúxit vocem in omni regno suo, étiam per scriptúram, dicens :

2. Hæc dicit Cyrus rex Persárum : Ómnia regna terræ dedit mihi Dóminus Deus cæli, et ipse præcépit mihi ut ædificárem ei domum in Jerúsalem, quæ est in Judǽa.

3. Quis est in vobis de univérso pópulo ejus ? Sit Deus illíus cum ipso. Ascéndat in Jerúsalem, quæ est in Judǽa, et ædíficet domum Dómini Dei Israël : ipse est Deus qui est in Jerúsalem.

4. Et omnes réliqui in cunctis locis ubicúmque hábitant, ádjuvent eum viri de loco suo argénto et auro, et substántia, et pecóribus, excépto quod voluntárie ófferunt templo Dei, quod est in Jerúsalem.

5. Et surrexérunt príncipes patrum de Juda et Bénjamin, et sacerdótes, et Levítæ, et omnis cujus Deus suscitávit spíritum, ut ascénderent ad ædificándum templum Dómini, quod erat in Jerúsalem.

6. Universíque qui erant in circúitu, adjuvérunt manus eórum in vasis argénteis et áureis, in substántia et juméntis, in supelléctili, excéptis his quæ sponte obtúlerant.

7. Rex quoque Cyrus prótulit vasa templi Dómini, quæ túlerat Nabuchodonósor de Jerúsalem, et posúerat ea in templo dei sui.

8. Prótulit autem ea Cyrus rex Persárum per manum Mithridátis fílii Gazábar, et annumerávit ea Sassabásar príncipi Juda.

9. Et hic est númerus eórum : phíalæ áureæ trigínta, phíalæ argénteæ mille, cultri vigínti novem, scyphi áurei trigínta,

10. scyphi argéntei secúndi quadringénti decem, vasa ália mille.

11. Ómnia vasa áurea et argéntea quinque míllia quadringénta : univérsa tulit Sassabásar cum his qui ascendébant de transmigratióne Babylónis in Jerúsalem.

