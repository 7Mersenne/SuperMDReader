# Liber Judith - Caput 13

1. Ut autem sero factum est, festinavérunt servi illíus ad hospítia sua, et conclúsit Vágao óstia cubículi, et ábiit.

2. Erant autem omnes fatigáti a vino,

3. erátque Judith sola in cubículo.

4. Porro Holoférnes jacébat in lecto, nímia ebrietáte sópitus.

5. Dixítque Judith puéllæ suæ ut staret foris ante cubículum, et observáret.

6. Stetítque Judith ante lectum, orans cum lácrimis, et labiórum motu in siléntio,

7. dicens : Confírma me, Dómine Deus Israël, et réspice in hac hora ad ópera mánuum meárum, ut, sicut promisísti, Jerúsalem civitátem tuam érigas : et hoc quod credens per te posse fíeri cogitávi, perfíciam.

8. Et cum hæc dixísset, accéssit ad colúmnam quæ erat ad caput léctuli ejus, et pugiónem ejus, qui in ea ligátus pendébat, exsólvit.

9. Cumque evaginásset illum, apprehéndit comam cápitis ejus, et ait : Confírma me, Dómine Deus, in hac hora.

10. Et percússit bis in cervícem ejus, et abscídit caput ejus, et ábstulit conópeum ejus a colúmnis, et evólvit corpus ejus truncum.

11. Et post pusíllum exívit, et trádidit caput Holoférnis ancíllæ suæ, et jussit ut mítteret illud in peram suam.

12. Et exiérunt duæ, secúndum consuetúdinem suam, quasi ad oratiónem, et transiérunt castra, et gyrántes vallem, venérunt ad portam civitátis.

13. Et dixit Judith a longe custódibus murórum : Aperíte portas, quóniam nobíscum est Deus, qui fecit virtútem in Israël.

14. Et factum est cum audíssent viri vocem ejus, vocavérunt presbýteros civitátis.

15. Et concurrérunt ad eam omnes, a mínimo usque ad máximum : quóniam sperábant eam jam non esse ventúram.

16. Et accendéntes luminária, congyravérunt circa eam univérsi : illa autem ascéndens in eminentiórem locum, jussit fíeri siléntium. Cumque omnes tacuíssent,

17. dixit Judith : Laudáte Dóminum Deum nostrum, qui non deséruit sperántes in se,

18. et in me ancílla sua adimplévit misericórdiam suam, quam promísit dómui Israël : et interfécit in manu mea hostem pópuli sui hac nocte.

19. Et próferens de pera caput Holoférnis, osténdit illis, dicens : Ecce caput Holoférnis príncipis milítiæ Assyriórum, et ecce conópeum illíus, in quo recumbébat in ebrietáte sua, ubi per manum féminæ percússit illum Dóminus Deus noster.

20. Vivit autem ipse Dóminus, quóniam custodívit me ángelus ejus et hinc eúntem, et ibi commorántem, et inde huc reverténtem, et non permísit me Dóminus ancíllam suam coinquinári, sed sine pollutióne peccáti revocávit me vobis gaudéntem in victória sua, in evasióne mea, et in liberatióne vestra.

21. Confitémini illi omnes, quóniam bonus, quóniam in sǽculum misericórdia ejus.

22. Univérsi autem adorántes Dóminum, dixérunt ad eam : Benedíxit te Dóminus in virtúte sua, quia per te ad níhilum redégit inimícos nostros.

23. Porro Ozías princeps pópuli Israël dixit ad eam : Benedícta es tu, fília, a Dómino Deo excélso præ ómnibus muliéribus super terram.

24. Benedíctus Dóminus, qui creávit cælum et terram, qui te diréxit in vúlnera cápitis príncipis inimicórum nostrórum :

25. quia hódie nomen tuum ita magnificávit, ut non recédat laus tua de ore hóminum qui mémores fúerint virtútis Dómini in ætérnum, pro quibus non pepercísti ánimæ tuæ propter angústias et tribulatiónem géneris tui, sed subvenísti ruínæ ante conspéctum Dei nostri.

26. Et dixit omnis pópulus : Fiat, fiat.

27. Porro Áchior vocátus venit, et dixit ei Judith : Deus Israël, cui tu testimónium dedísti quod ulciscátur se de inimícis suis, ipse caput ómnium incredulórum íncidit hac nocte in manu mea.

28. Et ut probes quia ita est, ecce caput Holoférnis, qui in contémptu supérbiæ suæ Deum Israël contémpsit, et tibi intéritum minabátur, dicens : Cum captus fúerit pópulus Israël, gládio perforári præcípiam látera tua.

29. Videns autem Áchior caput Holoférnis, angustiátus præ pavóre cécidit in fáciem suam super terram, et æstuávit ánima ejus.

30. Póstea vero quam resúmpto spíritu recreátus est, prócidit ad pedes ejus, et adorávit eam, et dixit :

31. Benedícta tu a Deo tuo in omni tabernáculo Jacob, quóniam in omni gente quæ audíerit nomen tuum, magnificábitur super te Deus Israël.

