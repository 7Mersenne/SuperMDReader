# Liber Genesis - Caput 31

1. Postquam autem audívit verba filiórum Laban dicéntium : Tulit Jacob ómnia quæ fuérunt patris nostri, et de illíus facultáte ditátus, factus est ínclytus :

2. animadvértit quoque fáciem Laban, quod non esset erga se sicut heri et nudiustértius,

3. máxime dicénte sibi Dómino : Revertére in terram patrum tuórum, et ad generatiónem tuam, eróque tecum.

4. Misit, et vocávit Rachel et Liam in agrum, ubi pascébat greges,

5. dixítque eis : Vídeo fáciem patris vestri quod non sit erga me sicut heri et nudiustértius : Deus autem patris mei fuit mecum.

6. Et ipsæ nostis quod totis víribus meis servíerim patri vestro.

7. Sed et pater vester circumvénit me et mutávit mercédem meam decem vícibus : et tamen non dimísit eum Deus ut nocéret mihi.

8. Si quando dixit : Váriæ erunt mercédes tuæ : pariébant omnes oves vários fœtus ; quando vero e contrário, ait : Alba quæque accípies pro mercéde : omnes greges alba peperérunt.

9. Tulítque Deus substántiam patris vestri, et dedit mihi.

10. Postquam enim concéptus óvium tempus advénerat, levávi óculos meos, et vidi in somnis ascendéntes mares super féminas, vários et maculósos, et diversórum colórum.

11. Dixítque ángelus Dei ad me in somnis : Jacob ? Et ego respóndi : Adsum.

12. Qui ait : Leva óculos tuos, et vide univérsos másculos ascendéntes super féminas, vários, maculósos, atque respérsos. Vidi enim ómnia quæ fecit tibi Laban.

13. Ego sum Deus Bethel, ubi unxísti lápidem, et votum vovísti mihi. Nunc ergo surge, et egrédere de terra hac, revértens in terram nativitátis tuæ.

14. Responderúntque Rachel et Lia : Numquid habémus resídui quidquam in facultátibus et hæreditáte domus patris nostri ?

15. nonne quasi aliénas reputávit nos, et véndidit, comedítque prétium nostrum ?

16. Sed Deus tulit opes patris nostri, et eas trádidit nobis, ac fíliis nostris : unde ómnia quæ præcépit tibi Deus, fac.

17. Surréxit ítaque Jacob, et impósitis líberis ac conjúgibus suis super cámelos, ábiit.

18. Tulítque omnem substántiam suam, et greges, et quidquid in Mesopotámia acquisíerat, pergens ad Ísaac patrem suum in terram Chánaan.

19. Eo témpore íerat Laban ad tondéndas oves, et Rachel furáta est idóla patris sui.

20. Noluítque Jacob confitéri sócero suo quod fúgeret.

21. Cumque abiísset tam ipse quam ómnia quæ juris sui erant, et amne transmísso pérgeret contra montem Gálaad,

22. nuntiátum est Laban die tértio quod fúgeret Jacob.

23. Qui, assúmptis frátribus suis, persecútus est eum diébus septem : et comprehéndit eum in monte Gálaad.

24. Vidítque in somnis dicéntem sibi Deum : Cave ne quidquam áspere loquáris contra Jacob.

25. Jamque Jacob exténderat in monte tabernáculum : cumque ille consecútus fuísset eum cum frátribus suis, in eódem monte Gálaad fixit tentórium.

26. Et dixit ad Jacob : Quare ita egísti, ut clam me abígeres fílias meas quasi captívas gládio ?

27. cur ignoránte me fúgere voluísti, nec indicáre mihi, ut proséquerer te cum gáudio, et cánticis, et týmpanis, et cítharis ?

28. Non es passus ut osculárer fílios meos et fílias : stulte operátus es : et nunc quidem

29. valet manus mea réddere tibi malum : sed Deus patris vestri heri dixit mihi : Cave ne loquáris contra Jacob quidquam dúrius.

30. Esto, ad tuos ire cupiébas, et desidério erat tibi domus patris tui : cur furátus es deos meos ?

31. Respóndit Jacob : Quod ínscio te proféctus sum, tímui ne violénter auférres fílias tuas.

32. Quod autem furti me árguis : apud quemcúmque invéneris deos tuos, necétur coram frátribus nostris : scrutáre, quidquid tuórum apud me invéneris, et aufer. Hæc dicens, ignorábat quod Rachel furáta esset idóla.

33. Ingréssus ítaque Laban tabernáculum Jacob, et Liæ, et utriúsque fámulæ, non invénit. Cumque intrásset tentórium Ráchelis,

34. illa festínans abscóndit idóla subter straménta cámeli, et sedit désuper : scrutantíque omne tentórium, et nihil inveniénti,

35. ait : Ne irascátur dóminus meus quod coram te assúrgere néqueo : quia juxta consuetúdinem feminárum nunc áccidit mihi : sic delúsa sollicitúdo quæréntis est.

36. Tuménsque Jacob, cum júrgio ait : Quam ob culpam meam, et ob quod peccátum meum sic exarsísti post me,

37. et scrutátus es omnem supelléctilem meam ? quid invenísti de cuncta substántia domus tuæ ? pone hic coram frátribus meis, et frátribus tuis, et júdicent inter me et te.

38. Idcírco vigínti annis fui tecum ? oves tuæ et capræ stériles non fuérunt, aríetes gregis tui non comédi :

39. nec captum a béstia osténdi tibi, ego damnum omne reddébam : quidquid furto períbat, a me exigébas :

40. die noctúque æstu urébar, et gelu, fugiebátque somnus ab óculis meis.

41. Sicque per vigínti annos in domo tua servívi tibi, quatuórdecim pro filiábus, et sex pro grégibus tuis : immutásti quoque mercédem meam decem vícibus.

42. Nisi Deus patris mei Ábraham, et timor Ísaac affuísset mihi, fórsitan modo nudum me dimisísses : afflictiónem meam et labórem mánuum meárum respéxit Deus, et árguit te heri.

43. Respóndit ei Laban : Fíliæ meæ et fílii, et greges tui, et ómnia quæ cernis, mea sunt : quid possum fácere fíliis et nepótibus meis ?

44. Veni ergo, et ineámus fœdus, ut sit in testimónium inter me et te.

45. Tulit ítaque Jacob lápidem, et eréxit illum in títulum :

46. dixítque frátribus suis : Afférte lápides. Qui congregántes fecérunt túmulum, comederúntque super eum :

47. quem vocávit Laban Túmulum testis : et Jacob, Acérvum testimónii, utérque juxta proprietátem linguæ suæ.

48. Dixítque Laban : Túmulus iste erit testis inter me et te hódie, et idcírco appellátum est nomen ejus Gálaad, id est, Túmulus testis.

49. Intueátur et júdicet Dóminus inter nos quando recessérimus a nobis,

50. si afflíxeris fílias meas, et si introdúxeris álias uxóres super eas : nullus sermónis nostri testis est absque Deo, qui præsens réspicit.

51. Dixítque rursus ad Jacob : En túmulus hic, et lapis quem eréxi inter me et te,

52. testis erit : túmulus, inquam, iste et lapis sint in testimónium, si aut ego transíero illum pergens ad te, aut tu præteríeris, malum mihi cógitans.

53. Deus Ábraham, et Deus Nachor, júdicet inter nos, Deus patris eórum. Jurávit ergo Jacob per timórem patris sui Ísaac :

54. immolatísque víctimis in monte, vocávit fratres suos ut éderent panem. Qui cum comedíssent, mansérunt ibi :

55. Laban vero de nocte consúrgens, osculátus est fílios, et fílias suas, et benedíxit illis : reversúsque est in locum suum.

