# Liber Exodus - Caput 29

1. Sed et hoc fácies, ut mihi in sacerdótio consecréntur. Tolle vítulum de arménto, et aríetes duos immaculátos,

2. panésque ázymos, et crústulam absque ferménto, quæ conspérsa sit óleo, lagána quoque ázyma óleo lita : de símila tritícea cuncta fácies.

3. Et pósita in canístro ófferes : vítulum autem et duos aríetes.

4. Et Áaron ac fílios ejus applicábis ad óstium tabernáculi testimónii. Cumque láveris patrem cum fíliis suis aqua,

5. índues Áaron vestiméntis suis, id est, línea et túnica, et superhumeráli et rationáli, quod constrínges bálteo.

6. Et pones tiáram in cápite ejus, et láminam sanctam super tiáram,

7. et óleum unctiónis fundes super caput ejus : atque hoc ritu consecrábitur.

8. Fílios quoque illíus applicábis, et índues túnicis líneis, cingésque bálteo,

9. Áaron scílicet et líberos ejus, et impónes eis mitras : erúntque sacerdótes mihi religióne perpétua. Postquam initiáveris manus eórum,

10. applicábis et vítulum coram tabernáculo testimónii. Imponéntque Áaron et fílii ejus manus super caput illíus,

11. et mactábis eum in conspéctu Dómini, juxta óstium tabernáculi testimónii.

12. Sumptúmque de sánguine vítuli, pones super córnua altáris dígito tuo, réliquum autem sánguinem fundes juxta basim ejus.

13. Sumes et ádipem totum qui óperit intestína, et retículum jecóris, ac duos renes, et ádipem qui super eos est, et ófferes incénsum super altáre :

14. carnes vero vítuli et córium et fimum combúres foris extra castra, eo quod pro peccáto sit.

15. Unum quoque aríetem sumes, super cujus caput ponent Áaron et fílii ejus manus.

16. Quem cum mactáveris, tolles de sánguine ejus, et fundes circa altáre.

17. Ipsum autem aríetem secábis in frustra : lotáque intestína ejus ac pedes, pones super concísas carnes, et super caput illíus.

18. Et ófferes totum aríetem in incénsum super altáre : oblátio est Dómino, odor suavíssimus víctimæ Dómini.

19. Tolles quoque aríetem álterum, super cujus caput Áaron et fílii ejus ponent manus.

20. Quem cum immoláveris, sumes de sánguine ejus, et pones super extrémum aurículæ dextræ Áaron et filiórum ejus, et super póllices manus eórum ac pedis dextri, fundésque sánguinem super altáre per circúitum.

21. Cumque túleris de sánguine qui est super altáre, et de óleo unctiónis, aspérges Áaron et vestes ejus, fílios et vestiménta eórum. Consecratísque ipsis et véstibus,

22. tolles ádipem de aríete, et caudam et arvínam, quæ óperit vitália, ac retículum jecóris, et duos renes, atque ádipem, qui super eos est, armúmque dextrum, eo quod sit áries consecratiónis :

23. tortámque panis uníus, crústulam conspérsam óleo, lagánum de canístro azymórum, quod pósitum est in conspéctu Dómini :

24. ponésque ómnia super manus Áaron et filiórum ejus, et sanctificábis eos élevans coram Dómino.

25. Suscipiésque univérsa de mánibus eórum : et incéndes super altáre in holocáustum, odórem suavíssimum in conspéctu Dómini, quia oblátio ejus est.

26. Sumes quoque pectúsculum de aríete, quo initiátus est Áaron, sanctificabísque illud elevátum coram Dómino, et cedet in partem tuam.

27. Sanctificabísque et pectúsculum consecrátum, et armum quem de aríete separásti,

28. quo initiátus est Áaron et fílii ejus, cedéntque in partem Áaron et filiórum ejus jure perpétuo a fíliis Israël : quia primitíva sunt et inítia de víctimis eórum pacíficis quæ ófferunt Dómino.

29. Vestem autem sanctam, qua utétur Áaron, habébunt fílii ejus post eum, ut ungántur in ea, et consecrántur manus eórum.

30. Septem diébus utétur illa qui póntifex pro eo fúerit constitútus de fíliis ejus, et qui ingrediétur tabernáculum testimónii ut minístret in sanctuário.

31. Aríetem autem consecratiónis tolles, et coques carnes ejus in loco sancto :

32. quibus vescétur Áaron et fílii ejus. Panes quoque, qui sunt in canístro, in vestíbulo tabernáculi testimónii cómedent,

33. ut sit placábile sacrifícium, et sanctificéntur offeréntium manus. Alienígena non vescétur ex eis, quia sancti sunt.

34. Quod si remánserit de cárnibus consecrátis, sive de pánibus usque mane, combúres relíquias igni : non comedéntur, quia sanctificáta sunt.

35. Ómnia, quæ præcépi tibi, fácies super Áaron et fíliis ejus. Septem diébus consecrábis manus eórum :

36. et vítulum pro peccáto ófferes per síngulos dies ad expiándum. Mundabísque altáre cum immoláveris expiatiónis hóstiam, et unges illud in sanctificatiónem.

37. Septem diébus expiábis altáre, et sanctificábis, et erit Sanctum sanctórum : omnis, qui tetígerit illud, sanctificábitur.

38. Hoc est quod fácies in altári : agnos annículos duos per síngulos dies júgiter,

39. unum agnum mane, et álterum véspere,

40. décimam partem símilæ conspérsæ óleo tuso, quod hábeat mensúram quartam partem hin, et vinum ad libándum ejúsdem mensúræ in agno uno.

41. Álterum vero agnum ófferes ad vésperam juxta ritum matutínæ oblatiónis, et juxta ea quæ díximus, in odórem suavitátis :

42. sacrifícium est Dómino, oblatióne perpétua in generatiónes vestras, ad óstium tabernáculi testimónii coram Dómino, ubi constítuam ut loquar ad te.

43. Ibíque præcípiam fíliis Israël, et sanctificábitur altáre in glória mea.

44. Sanctificábo et tabernáculum testimónii cum altári, et Áaron cum fíliis suis, ut sacerdótio fungántur mihi.

45. Et habitábo in médio filiórum Israël, eróque eis Deus,

46. et scient quia ego Dóminus Deus eórum, qui edúxi eos de terra Ægýpti, ut manérem inter illos, ego Dóminus Deus ipsórum.

