# Liber Genesis - Caput 23

1. Vixit autem Sara centum vigínti septem annis.

2. Et mórtua est in civitáte Árbee, quæ est Hebron, in terra Chánaan : venítque Ábraham ut plángeret et fleret eam.

3. Cumque surrexísset ab offício fúneris, locútus est ad fílios Heth, dicens :

4. Ádvena sum et peregrínus apud vos : date mihi jus sepúlchri vobíscum, ut sepéliam mórtuum meum.

5. Respondérunt fílii Heth, dicéntes :

6. Audi nos, dómine : princeps Dei es apud nos : in eléctis sepúlchris nostris sépeli mórtuum tuum, nullúsque te prohibére póterit quin in monuménto ejus sepélias mórtuum tuum.

7. Surréxit Ábraham, et adorávit pópulum terræ, fílios vidélicet Heth :

8. dixítque ad eos : Si placet ánimæ vestræ ut sepéliam mórtuum meum, audíte me, et intercédite pro me apud Ephron fílium Seor :

9. ut det mihi spelúncam dúplicem, quam habet in extréma parte agri sui : pecúnia digna tradat eam mihi coram vobis in possessiónem sepúlchri.

10. Habitábat autem Ephron in médio filiórum Heth. Respondítque Ephron ad Ábraham, cunctis audiéntibus qui ingrediebántur portam civitátis illíus, dicens :

11. Nequáquam ita fiat, dómine mi, sed tu magis auscúlta quod loquor. Agrum trado tibi, et spelúncam quæ in eo est, præséntibus fíliis pópuli mei ; sépeli mórtuum tuum.

12. Adorávit Ábraham coram pópulo terræ.

13. Et locútus est ad Ephron circumstánte plebe : Quæso ut áudias me : dabo pecúniam pro agro : súscipe eam, et sic sepéliam mórtuum meum in eo.

14. Respondítque Ephron :

15. Dómine mi, audi me : terra, quam póstulas, quadringéntis siclis argénti valet : istud est prétium inter me et te : sed quantum est hoc ? sépeli mórtuum tuum.

16. Quod cum audísset Ábraham, appéndit pecúniam, quam Ephron postuláverat, audiéntibus fíliis Heth, quadringéntos siclos argénti probátæ monétæ públicæ.

17. Confirmatúsque est ager quondam Ephrónis, in quo erat spelúnca duplex, respíciens Mambre, tam ipse, quam spelúnca, et omnes árbores ejus in cunctis términis ejus per circúitum,

18. Ábrahæ in possessiónem, vidéntibus fíliis Heth, et cunctis qui intrábant portam civitátis illíus.

19. Atque ita sepelívit Ábraham Saram uxórem suam in spelúnca agri dúplici, quæ respiciébat Mambre. Hæc est Hebron in terra Chánaan.

20. Et confirmátus est ager, et antrum quod erat in eo, Ábrahæ in possessiónem monuménti a fíliis Heth.

