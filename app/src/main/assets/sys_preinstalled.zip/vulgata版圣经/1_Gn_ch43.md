# Liber Genesis - Caput 43

1. Ínterim fames omnem terram veheménter premébat.

2. Consumptísque cibis quos ex Ægýpto detúlerant, dixit Jacob ad fílios suos : Revertímini, et émite nobis pauxíllum escárum.

3. Respóndit Judas : Denuntiávit nobis vir ille sub attestatióne jurisjurándi, dicens : Non vidébitis fáciem meam, nisi fratrem vestrum mínimum adduxéritis vobíscum.

4. Si ergo vis eum míttere nobíscum, pergémus páriter, et emémus tibi necessária :

5. sin autem non vis, non íbimus : vir enim, ut sæpe díximus, denuntiávit nobis, dicens : Non vidébitis fáciem meam absque fratre vestro mínimo.

6. Dixit eis Israël : In meam hoc fecístis misériam, ut indicarétis ei et álium habére vos fratrem.

7. At illi respondérunt : Interrogávit nos homo per órdinem nostram progéniem : si pater víveret : si haberémus fratrem : et nos respóndimus ei consequénter juxta id quod fúerat sciscitátus : numquid scire poterámus quod dictúrus esset : Addúcite fratrem vestrum vobíscum ?

8. Judas quoque dixit patri suo : Mitte púerum mecum, ut proficiscámur, et possímus vívere : ne moriámur nos et párvuli nostri.

9. Ego suscípio púerum : de manu mea requíre illum : nisi redúxero, et reddídero eum tibi, ero peccáti reus in te omni témpore.

10. Si non intercessísset dilátio, jam vice alter venissémus.

11. Ígitur Israël pater eórum dixit ad eos : Si sic necésse est, fácite quod vultis : súmite de óptimis terræ frúctibus in vasis vestris, et deférte viro múnera, módicum résinæ, et mellis, et storácis, stactes, et terebínthi, et amygdalárum.

12. Pecúniam quoque dúplicem ferte vobíscum : et illam, quam invenístis in sácculis, reportáte, ne forte erróre factum sit :

13. sed et fratrem vestrum tóllite, et ite ad virum.

14. Deus autem meus omnípotens fáciat vobis eum placábilem : et remíttat vobíscum fratrem vestrum quem tenet, et hunc Bénjamin : ego autem quasi orbátus absque líberis ero.

15. Tulérunt ergo viri múnera, et pecúniam dúplicem, et Bénjamin : descenderúntque in Ægýptum, et stetérunt coram Joseph.

16. Quos cum ille vidísset et Bénjamin simul, præcépit dispensatóri domus suæ, dicens : Íntroduc viros domum, et occíde víctimas, et ínstrue convívium : quóniam mecum sunt comestúri merídie.

17. Fecit ille quod sibi fúerat imperátum, et introdúxit viros domum.

18. Ibíque extérriti, dixérunt mútuo : Propter pecúniam, quam retúlimus prius in saccis nostris, introdúcti sumus : ut devólvat in nos calúmniam, et violénter subjíciat servitúti et nos, et ásinos nostros.

19. Quam ob rem in ipsis fóribus accedéntes ad dispensatórem domus,

20. locúti sunt : Orámus, dómine, ut áudias nos. Jam ante descéndimus ut emerémus escas :

21. quibus emptis, cum venissémus ad diversórium, aperúimus saccos nostros, et invénimus pecúniam in ore saccórum : quam nunc eódem póndere reportávimus.

22. Sed et áliud attúlimus argéntum, ut emámus quæ nobis necessária sunt : non est in nostra consciéntia quis posúerit eam in marsúpiis nostris.

23. At ille respóndit : Pax vobíscum, nolíte timére : Deus vester, et Deus patris vestri, dedit vobis thesáuros in saccis vestris : nam pecúniam, quam dedístis mihi, probátam ego hábeo. Eduxítque ad eos Símeon.

24. Et introdúctis domum, áttulit aquam, et lavérunt pedes suos, dedítque pábulum ásinis eórum.

25. Illi vero parábant múnera, donec ingrederétur Joseph merídie : audíerant enim quod ibi comestúri essent panem.

26. Ígitur ingréssus est Joseph domum suam, obtulerúntque ei múnera, tenéntes in mánibus suis : et adoravérunt proni in terram.

27. At ille, cleménter resalutátis eis, interrogávit eos, dicens : Salvúsne est pater vester senex, de quo dixerátis mihi ? adhuc vivit ?

28. Qui respondérunt : Sospes est servus tuus pater noster, adhuc vivit. Et incurváti, adoravérunt eum.

29. Attóllens autem Joseph óculos, vidit Bénjamin fratrem suum utérinum, et ait : Iste est frater vester párvulus, de quo dixerátis mihi ? Et rursum : Deus, inquit, misereátur tui, fili mi.

30. Festinavítque, quia commóta fúerant víscera ejus super fratre suo, et erumpébant lácrimæ : et intróiens cubículum flevit.

31. Rursúmque lota fácie egréssus, contínuit se, et ait : Pónite panes.

32. Quibus appósitis, seórsum Joseph, et seórsum frátribus, Ægýptiis quoque qui vescebántur simul, seórsum (illícitum est enim Ægýptiis comédere cum Hebrǽis, et profánum putant hujuscémodi convívium)

33. sedérunt coram eo, primogénitus juxta primogénita sua, et mínimus juxta ætátem suam. Et mirabántur nimis,

34. sumptis pártibus quas ab eo accéperant : majórque pars venit Bénjamin, ita ut quinque pártibus excéderet. Biberúntque et inebriáti sunt cum eo.

