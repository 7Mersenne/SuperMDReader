# Liber Genesis - Caput 48

1. His ita transáctis, nuntiátum est Joseph quod ægrotáret pater suus : qui, assúmptis duóbus fíliis Manásse et Éphraim, ire perréxit.

2. Dictúmque est seni : Ecce fílius tuus Joseph venit ad te. Qui confortátus sedit in léctulo.

3. Et ingrésso ad se ait : Deus omnípotens appáruit mihi in Luza, quæ est in terra Chánaan : benedixítque mihi,

4. et ait : Ego te augébo et multiplicábo, et fáciam te in turbas populórum : dabóque tibi terram hanc, et sémini tuo post te in possessiónem sempitérnam.

5. Duo ergo fílii tui, qui nati sunt tibi in terra Ægýpti ántequam huc venírem ad te, mei erunt : Éphraim et Manásses, sicut Ruben et Símeon reputabúntur mihi.

6. Réliquos autem quos genúeris post eos, tui erunt, et nómine fratrum suórum vocabúntur in possessiónibus suis.

7. Mihi enim, quando veniébam de Mesopotámia, mórtua est Rachel in terra Chánaan in ipso itínere, erátque vernum tempus : et ingrediébar Éphratam, et sepelívi eam juxta viam Éphratæ, quæ álio nómine appellátur Béthlehem.

8. Videns autem fílios ejus dixit ad eum : Qui sunt isti ?

9. Respóndit : Fílii mei sunt, quos donávit mihi Deus in hoc loco. Adduc, inquit, eos ad me, ut benedícam illis.

10. Óculi enim Israël caligábant præ nímia senectúte, et clare vidére non póterat. Applicitósque ad se, deosculátus et circumpléxus eos,

11. dixit ad fílium suum : Non sum fraudátus aspéctu tuo : ínsuper osténdit mihi Deus semen tuum.

12. Cumque tulísset eos Joseph de grémio patris, adorávit pronus in terram.

13. Et pósuit Éphraim ad déxteram suam, id est, ad sinístram Israël : Manássen vero in sinístra sua, ad déxteram scílicet patris, applicuítque ambos ad eum.

14. Qui exténdens manum déxteram, pósuit super caput Éphraim minóris fratris : sinístram autem super caput Manásse qui major natu erat, commútans manus.

15. Benedixítque Jacob fíliis Joseph, et ait : Deus, in cujus conspéctu ambulavérunt patres mei Ábraham, et Ísaac ; Deus qui pascit me ab adolescéntia mea usque in præséntem diem :

16. ángelus, qui éruit me de cunctis malis, benedícat púeris istis : et invocétur super eos nomen meum, nómina quoque patrum meórum Ábraham et Ísaac, et crescant in multitúdinem super terram.

17. Videns autem Joseph quod posuísset pater suus déxteram manum super caput Éphraim, gráviter accépit : et apprehénsam manum patris leváre conátus est de cápite Éphraim, et transférre super caput Manásse.

18. Dixítque ad patrem : Non ita convénit, pater : quia hic est primogénitus, pone déxteram tuam super caput ejus.

19. Qui rénuens, ait : Scio, fili mi, scio : et iste quidem erit in pópulos, et multiplicábitur : sed frater ejus minor, major erit illo : et semen illíus crescet in gentes.

20. Benedixítque eis in témpore illo, dicens : In te benedicétur Israël, atque dicétur : Fáciat tibi Deus sicut Éphraim, et sicut Manásse. Constituítque Éphraim ante Manássen.

21. Et ait ad Joseph fílium suum : En ego mórior, et erit Deus vobíscum, reducétque vos ad terram patrum vestrórum.

22. Do tibi partem unam extra fratres tuos, quam tuli de manu Amorrhǽi in gládio et arcu meo.

