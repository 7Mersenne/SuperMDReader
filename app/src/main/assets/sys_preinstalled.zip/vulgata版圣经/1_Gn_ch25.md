# Liber Genesis - Caput 25

1. Ábraham vero áliam duxit uxórem nómine Cetúram :

2. quæ péperit ei Zamran et Jecsan, et Madan, et Mádian, et Jesboc, et Sue.

3. Jecsan quoque génuit Saba et Dadan. Fílii Dadan fuérunt Assúrim, et Latúsim, et Loómin.

4. At vero ex Mádian ortus est Epha, et Opher, et Henoch, et Ábida, et Éldaa : omnes hi fílii Cetúræ.

5. Dedítque Ábraham cuncta quæ posséderat, Ísaac :

6. fíliis autem concubinárum largítus est múnera, et separávit eos ab Ísaac fílio suo, dum adhuc ipse víveret, ad plagam orientálem.

7. Fuérunt autem dies vitæ Ábrahæ, centum septuagínta quinque anni.

8. Et defíciens mórtuus est in senectúte bona, provectǽque ætátis et plenus diérum : congregatúsque est ad pópulum suum.

9. Et sepeliérunt eum Ísaac et Ísmaël fílii sui in spelúnca dúplici, quæ sita est in agro Ephron fílii Seor Hethǽi, e regióne Mambre,

10. quem émerat a fíliis Heth : ibi sepúltus est ipse, et Sara uxor ejus.

11. Et post óbitum illíus benedíxit Deus Ísaac fílio ejus, qui habitábat juxta púteum nómine Vivéntis et vidéntis.

12. Hæ sunt generatiónes Ísmaël fílii Ábrahæ, quem péperit ei Agar Ægýptia, fámula Saræ : et

13. hæc nómina filiórum ejus in vocábulis et generatiónibus suis. Primogénitus Ismáëlis Nabaíoth, deínde Cedar, et Ádbeel, et Mabsam,

14. Masma quoque, et Duma, et Massa,

15. Hadar, et Thema, et Jethur, et Naphis, et Cedma.

16. Isti sunt fílii Ismáëlis : et hæc nómina per castélla et óppida eórum, duódecim príncipes tríbuum suárum.

17. Et facti sunt anni vitæ Ismáëlis centum trigínta septem, deficiénsque mórtuus est, et appósitus ad pópulum suum.

18. Habitávit autem ab Hévila usque Sur, quæ réspicit Ægýptum introëúntibus Assýrios ; coram cunctis frátribus suis óbiit.

19. Hæ quoque sunt generatiónes Ísaac fílii Ábraham : Ábraham génuit Ísaac :

20. qui cum quadragínta esset annórum, duxit uxórem Rebéccam fíliam Bathúelis Syri de Mesopotámia, sorórem Laban.

21. Deprecatúsque est Ísaac Dóminum pro uxóre sua, eo quod esset stérilis : qui exaudívit eum, et dedit concéptum Rebéccæ.

22. Sed collidebántur in útero ejus párvuli ; quæ ait : Si sic mihi futúrum erat, quid necésse fuit concípere ? perrexítque ut consúleret Dóminum.

23. Qui respóndens ait : Duæ gentes sunt in útero tuo, et duo pópuli ex ventre tuo dividéntur, populúsque pópulum superábit, et major sérviet minóri.

24. Jam tempus pariéndi advénerat, et ecce gémini in útero ejus repérti sunt.

25. Qui prior egréssus est, rufus erat, et totus in morem pellis híspidus : vocatúmque est nomen ejus Ésau. Prótinus alter egrédiens, plantam fratris tenébat manu : et idcírco appellávit eum Jacob.

26. Sexagenárius erat Ísaac quando nati sunt ei párvuli.

27. Quibus adúltis, factus est Ésau vir gnarus venándi, et homo agrícola : Jacob autem vir simplex habitábat in tabernáculis.

28. Ísaac amábat Ésau, eo quod de venatiónibus illíus vescerétur : et Rebécca diligébat Jacob.

29. Coxit autem Jacob pulméntum : ad quem cum venísset Ésau de agro lassus,

30. ait : Da mihi de coctióne hac rufa, quia óppido lassus sum. Quam ob causam vocátum est nomen ejus Edom.

31. Cui dixit Jacob : Vende mihi primogénita tua.

32. Ille respóndit : En mórior, quid mihi próderunt primogénita ?

33. Ait Jacob : Jura ergo mihi. Jurávit ei Ésau et véndidit primogénita.

34. Et sic, accépto pane et lentis edúlio, comédit et bibit, et ábiit, parvipéndens quod primogénita vendidísset.

