# Liber Exodus - Caput 23

1. Non suscípies vocem mendácii, nec junges manum tuam ut pro ímpio dicas falsum testimónium.

2. Non séqueris turbam ad faciéndum malum : nec in judício, plurimórum acquiésces senténtiæ, ut a vero dévies.

3. Páuperis quoque non miseréberis in judício.

4. Si occúrreris bovi inimíci tui, aut ásino erránti, reduc ad eum.

5. Si víderis ásinum odiéntis te jácere sub ónere, non pertransíbis, sed sublevábis cum eo.

6. Non declinábis in judícium páuperis.

7. Mendácium fúgies. Insóntem et justum non occídes : quia avérsor ímpium.

8. Nec accípies múnera, quæ étiam excǽcant prudéntes, et subvértunt verba justórum.

9. Peregríno moléstus non eris. Scitis enim advenárum ánimas : quia et ipsi peregríni fuístis in terra Ægýpti.

10. Sex annis seminábis terram tuam, et congregábis fruges ejus :

11. anno autem séptimo dimíttes eam, et requiéscere fácies, ut cómedant páuperes pópuli tui : et quidquid réliquum fúerit, edant béstiæ agri : ita fácies in vínea et in olivéto tuo.

12. Sex diébus operáberis : séptimo die cessábis, ut requiéscat bos et ásinus tuus, et refrigerétur fílius ancíllæ tuæ, et ádvena.

13. Ómnia quæ dixi vobis, custodíte. Et per nomen externórum deórum non jurábitis, neque audiétur ex ore vestro.

14. Tribus vícibus per síngulos annos mihi festa celebrábitis.

15. Solemnitátem azymórum custódies. Septem diébus cómedes ázyma, sicut præcépi tibi, témpore mensis novórum, quando egréssus es de Ægýpto : non apparébis in conspéctu meo vácuus.

16. Et solemnitátem messis primitivórum óperis tui, quæcúmque semináveris in agro : solemnitátem quoque in éxitu anni, quando congregáveris omnes fruges tuas de agro.

17. Ter in anno apparébit omne masculínum tuum coram Dómino Deo tuo.

18. Non immolábis super ferménto sánguinem víctimæ meæ, nec remanébit adeps solemnitátis meæ usque mane.

19. Primítias frugum terræ tuæ déferes in domum Dómini Dei tui. Non coques hædum in lacte matris suæ.

20. Ecce ego mittam ángelum meum, qui præcédat te, et custódiat in via, et introdúcat in locum quem parávi.

21. Obsérva eum, et audi vocem ejus, nec contemnéndum putes : quia non dimíttet cum peccáveris, et est nomen meum in illo.

22. Quod si audíeris vocem ejus, et féceris ómnia quæ loquor, inimícus ero inimícis tuis, et afflígam affligéntes te.

23. Præcedétque te ángelus meus, et introdúcet te ad Amorrhǽum, et Hethǽum, et Pherezǽum, Chananæúmque, et Hevǽum, et Jebusǽum, quos ego cónteram.

24. Non adorábis deos eórum, nec coles eos : non fácies ópera eórum, sed déstrues eos, et confrínges státuas eórum.

25. Servietísque Dómino Deo vestro, ut benedícam pánibus tuis et aquis, et áuferam infirmitátem de médio tui.

26. Non erit infœcúnda, nec stérilis in terra tua : númerum diérum tuórum implébo.

27. Terrórem meum mittam in præcúrsum tuum, et óccidam omnem pópulum, ad quem ingredíeris : cunctorúmque inimicórum tuórum coram te terga vertam :

28. emíttens crabrónes prius, qui fugábunt Hevǽum, et Chananǽum, et Hethǽum, ántequam intróëas.

29. Non ejíciam eos a fácie tua anno uno : ne terra in solitúdinem redigátur, et crescant contra te béstiæ.

30. Paulátim expéllam eos de conspéctu tuo, donec augeáris, et possídeas terram.

31. Ponam autem términos tuos a mari Rubro usque ad mare Palæstinórum, et a desérto usque ad flúvium : tradam in mánibus vestris habitatóres terræ, et ejíciam eos de conspéctu vestro.

32. Non iníbis cum eis fœdus, nec cum diis eórum.

33. Non hábitent in terra tua, ne forte peccáre te fáciant in me, si servíeris diis eórum : quod tibi certe erit in scándalum.

