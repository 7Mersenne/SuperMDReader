# Liber Genesis - Caput 27

1. Sénuit autem Ísaac, et caligavérunt óculi ejus, et vidére non póterat : vocavítque Ésau fílium suum majórem, et dixit ei : Fili mi ? Qui respóndit : Adsum.

2. Cui pater : Vides, inquit, quod senúerim, et ignórem diem mortis meæ.

3. Sume arma tua, pháretram, et arcum, et egrédere foras : cumque venátu áliquid apprehénderis,

4. fac mihi inde pulméntum sicut velle me nosti, et affer ut cómedam : et benedícat tibi ánima mea ántequam móriar.

5. Quod cum audísset Rebécca, et ille abiísset in agrum ut jussiónem patris impléret,

6. dixit fílio suo Jacob : Audívi patrem tuum loquéntem cum Ésau fratre tuo, et dicéntem ei :

7. Affer mihi de venatióne tua, et fac cibos ut cómedam, et benedícam tibi coram Dómino ántequam móriar.

8. Nunc ergo, fili mi, acquiésce consíliis meis :

9. et pergens ad gregem, affer mihi duos hædos óptimos, ut fáciam ex eis escas patri tuo, quibus libénter véscitur :

10. quas cum intúleris, et coméderit, benedícat tibi priúsquam moriátur.

11. Cui ille respóndit : Nosti quod Ésau frater meus homo pilósus sit, et ego lenis :

12. si attrectáverit me pater meus, et sénserit, tímeo ne putet me sibi voluísse illúdere, et indúcam super me maledictiónem pro benedictióne.

13. Ad quem mater : In me sit, ait, ista maledíctio, fili mi : tantum audi vocem meam, et pergens, affer quæ dixi.

14. Ábiit, et áttulit, dedítque matri. Parávit illa cibos, sicut velle nóverat patrem illíus.

15. Et véstibus Ésau valde bonis, quas apud se habébat domi, índuit eum :

16. pelliculásque hædórum circúmdedit mánibus, et colli nuda protéxit :

17. dedítque pulméntum, et panes, quos cóxerat, trádidit.

18. Quibus illátis, dixit : Pater mi ? At ille respóndit : Áudio. Quis es tu, fili mi ?

19. Dixítque Jacob : Ego sum primogénitus tuus Ésau : feci sicut præcepísti mihi : surge, sede, et cómede de venatióne mea, ut benedícat mihi ánima tua.

20. Rursúmque Ísaac ad fílium suum : Quómodo, inquit, tam cito inveníre potuísti, fili mi ? Qui respóndit : Volúntas Dei fuit ut cito occúrreret mihi quod volébam.

21. Dixítque Ísaac : Accéde huc, ut tangam te, fili mi, et probem utrum tu sis fílius meus Ésau, an non.

22. Accéssit ille ad patrem, et palpáto eo, dixit Ísaac : Vox quidem, vox Jacob est : sed manus, manus sunt Ésau.

23. Et non cognóvit eum, quia pilósæ manus similitúdinem majóris exprésserant. Benedícens ergo illi,

24. ait : Tu es fílius meus Ésau ? Respóndit : Ego sum.

25. At ille : Affer mihi, inquit, cibos de venatióne tua, fili mi, ut benedícat tibi ánima mea. Quos cum oblátos comedísset, óbtulit ei étiam vinum. Quo hausto,

26. dixit ad eum : Accéde ad me, et da mihi ósculum, fili mi.

27. Accéssit, et osculátus est eum. Statímque ut sensit vestimentórum illíus fragrántiam, benedícens illi, ait : Ecce odor fílii mei sicut odor agri pleni, cui benedíxit Dóminus.

28. Det tibi Deus de rore cæli et de pinguédine terræ abundántiam fruménti et vini.

29. Et sérviant tibi pópuli, et adórent te tribus : esto dóminus fratrum tuórum, et incurvéntur ante te fílii matris tuæ : qui maledíxerit tibi, sit ille maledíctus, et qui benedíxerit tibi, benedictiónibus repleátur.

30. Vix Ísaac sermónem impléverat, et egrésso Jacob foras, venit Ésau,

31. coctósque de venatióne cibos íntulit patri, dicens : Surge, pater mi, et cómede de venatióne fílii tui, ut benedícat mihi ánima tua.

32. Dixítque illi Ísaac : Quis enim es tu ? Qui respóndit : Ego sum fílius tuus primogénitus Ésau.

33. Expávit Ísaac stupóre veheménti : et ultra quam credi potest admírans, ait : Quis ígitur ille est qui dudum captam venatiónem áttulit mihi, et comédi ex ómnibus priúsquam tu veníres ; benedixíque ei, et erit benedíctus ?

34. Audítis Ésau sermónibus patris, irrúgiit clamóre magno : et consternátus, ait : Bénedic étiam et mihi, pater mi.

35. Qui ait : Venit germánus tuus fraudulénter, et accépit benedictiónem tuam.

36. At ille subjúnxit : Juste vocátum est nomen ejus Jacob : supplantávit enim me en áltera vice : primogénita mea ante tulit, et nunc secúndo surrípuit benedictiónem meam. Rursúmque ad patrem : Numquid non reservásti, ait, et mihi benedictiónem ?

37. Respóndit Ísaac : Dóminum tuum illum constítui, et omnes fratres ejus servitúti illíus subjugávi ; fruménto et vino stabilívi eum : et tibi post hæc, fili mi, ultra quid fáciam ?

38. Cui Ésau : Num unam, inquit, tantum benedictiónem habes, pater ? mihi quoque óbsecro ut benedícas. Cumque ejulátu magno fleret,

39. motus Ísaac, dixit ad eum : In pinguédine terræ, et in rore cæli désuper,

40. erit benedíctio tua. Vives in gládio, et fratri tuo sérvies : tempúsque véniet, cum excútias et solvas jugum ejus de cervícibus tuis.

41. Óderat ergo semper Ésau Jacob pro benedictióne qua benedíxerat ei pater : dixítque in corde suo : Vénient dies luctus patris mei, et óccidam Jacob fratrem meum.

42. Nuntiáta sunt hæc Rebéccæ : quæ mittens et vocans Jacob fílium suum, dixit ad eum : Ecce Ésau frater tuus minátur ut óccidat te.

43. Nunc ergo, fili mi, audi vocem meam, et consúrgens fuge ad Laban fratrem meum in Haran :

44. habitabísque cum eo dies paucos, donec requiéscat furor fratris tui,

45. et cesset indignátio ejus, obliviscatúrque eórum quæ fecísti in eum : póstea mittam, et addúcam te inde huc : cur utróque orbábor fílio in uno die ?

46. Dixítque Rebécca ad Ísaac : Tædet me vitæ meæ propter fílias Heth : si accéperit Jacob uxórem de stirpe hujus terræ, nolo vívere.

