# Liber Tobi� - Caput 14

1. Et consummáti sunt sermónes Tobíæ. Et postquam illuminátus est Tobías, vixit annis quadragínta duóbus, et vidit fílios nepótum suórum.

2. Complétis ítaque annis centum duóbus, sepúltus est honorífice in Nínive.

3. Quinquagínta namque et sex annórum lumen oculórum amísit, sexagenárius vero recépit.

4. Réliquum vero vitæ suæ in gáudio fuit, et cum bono proféctu timóris Dei perréxit in pace.

5. In hora autem mortis suæ vocávit ad se Tobíam fílium suum, et septem júvenes fílios ejus nepótes suos, dixítque eis :

6. Prope erit intéritus Nínive : non enim éxcidit verbum Dómini : et fratres nostri, qui dispérsi sunt a terra Israël, reverténtur ad eam.

7. Omnis autem desérta terra ejus replébitur, et domus Dei, quæ in ea incénsa est, íterum reædificábitur : ibíque reverténtur omnes timéntes Deum,

8. et relínquent gentes idóla sua, et vénient in Jerúsalem, et inhabitábunt in ea :

9. et gaudébunt in ea omnes reges terræ, adorántes regem Israël.

10. Audíte ergo, fílii mei, patrem vestrum : servíte Dómino in veritáte, et inquírite ut faciátis quæ plácita sunt illi :

11. et fíliis vestris mandáte ut fáciant justítias et eleemósynas, ut sint mémores Dei, et benedícant eum in omni témpore in veritáte, et in tota virtúte sua.

12. Nunc ergo fílii, audíte me, et nolíte manére hic : sed quacúmque die sepeliéritis matrem vestram circa me in uno sepúlchro, ex eo dirígite gressus vestros ut exeátis hinc :

13. vídeo enim quia iníquitas ejus finem dabit ei.

14. Factum est autem post óbitum matris suæ, Tobías abscéssit ex Nínive cum uxóre sua, et fíliis, et filiórum fíliis, et revérsus est ad sóceros suos :

15. invenítque eos incólumes in senectúte bona : et curam eórum gessit, et ipse clausit óculos eórum : et omnem hæreditátem domus Ráguelis ipse percépit : vidítque quintam generatiónem, fílios filiórum suórum.

16. Et complétis annis nonagínta novem in timóre Dómini, cum gáudio sepeliérunt eum.

17. Omnis autem cognátio ejus et omnis generátio ejus in bona vita et in sancta conversatióne permánsit, ita ut accépti essent tam Deo quam homínibus, et cunctis habitántibus in terra.

