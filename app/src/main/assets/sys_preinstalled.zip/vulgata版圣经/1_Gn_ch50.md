# Liber Genesis - Caput 50

1. Quod cernens Joseph, ruit super fáciem patris, flens et deósculans eum.

2. Præcepítque servis suis médicis ut aromátibus condírent patrem.

3. Quibus jussa expléntibus, transiérunt quadragínta dies : iste quippe mos erat cadáverum conditórum : flevítque eum Ægýptus septuagínta diébus.

4. Et expléto planctus témpore, locútus est Joseph ad famíliam Pharaónis : Si invéni grátiam in conspéctu vestro, loquímini in áuribus Pharaónis :

5. eo quod pater meus adjuráverit me dicens : En mórior : in sepúlchro meo, quod fodi mihi in terra Chánaan, sepélies me. Ascéndam ígitur, et sepéliam patrem meum, ac revértar.

6. Dixítque ei Phárao : Ascénde, et sépeli patrem tuum sicut adjurátus es.

7. Quo ascendénte, iérunt cum eo omnes senes domus Pharaónis, cunctíque majóres natu terræ Ægýpti :

8. domus Joseph cum frátribus suis, absque párvulis, et grégibus atque arméntis, quæ derelíquerant in terra Gessen.

9. Hábuit quoque in comitátu currus et équites : et facta est turba non módica.

10. Venerúntque ad Áream Atad, quæ sita est trans Jordánem : ubi celebrántes exéquias planctu magno atque veheménti implevérunt septem dies.

11. Quod cum vidíssent habitatóres terræ Chánaan, dixérunt : Planctus magnus est iste Ægýptiis. Et idcírco vocátum est nomen loci illíus, Planctus Ægýpti.

12. Fecérunt ergo fílii Jacob sicut præcéperat eis :

13. et portántes eum in terram Chánaan, sepeliérunt eum in spelúnca dúplici, quam émerat Ábraham cum agro in possessiónem sepúlchri ab Ephron Hethǽo, contra fáciem Mambre.

14. Reversúsque est Joseph in Ægýptum cum frátribus suis, et omni comitátu, sepúlto patre.

15. Quo mórtuo, timéntes fratres ejus, et mútuo colloquéntes : Ne forte memor sit injúriæ quam passus est, et reddat nobis omne malum quod fécimus,

16. mandavérunt ei dicéntes : Pater tuus præcépit nobis ántequam morerétur,

17. ut hæc tibi verbis illíus dicerémus : Óbsecro ut obliviscáris scéleris fratrum tuórum, et peccáti atque malítiæ quam exercuérunt in te : nos quoque orámus ut servis Dei patris tui dimíttas iniquitátem hanc. Quibus audítis flevit Joseph.

18. Venerúntque ad eum fratres sui : et proni adorántes in terram, dixérunt : Servi tui sumus.

19. Quibus ille respóndit : Nolíte timére : num Dei póssumus resístere voluntáti ?

20. Vos cogitástis de me malum : sed Deus vertit illud in bonum, ut exaltáret me, sicut in præsentiárum cérnitis, et salvos fáceret multos pópulos.

21. Nolíte timére : ego pascam vos et párvulos vestros : consolatúsque est eos, et blande ac léniter est locútus.

22. Et habitávit in Ægýpto cum omni domo patris sui : vixítque centum decem annis. Et vidit Éphraim fílios usque ad tértiam generatiónem. Fílii quoque Machir fílii Manásse nati sunt in génibus Joseph.

23. Quibus transáctis, locútus est frátribus suis : Post mortem meam Deus visitábit vos, et ascéndere vos fáciet de terra ista ad terram quam jurávit Ábraham, Ísaac et Jacob.

24. Cumque adjurásset eos atque dixísset : Deus visitábit vos, asportáte ossa mea vobíscum de loco isto :

25. mórtuus est, explétis centum decem vitæ suæ annis. Et cónditus aromátibus, repósitus est in lóculo in Ægýpto.

