# Liber Tobi� - Caput 12

1. Tunc vocávit ad se Tobías fílium suum, dixítque ei : Quid póssumus dare viro isti sancto, qui venit tecum ?

2. Respóndens Tobías, dixit patri suo : Pater, quam mercédem dábimus ei ? aut quid dignum póterit esse benefíciis ejus ?

3. Me duxit et redúxit sanum, pecúniam a Gábelo ipse recépit, uxórem ipse me habére fecit, et dæmónium ab ea ipse compéscuit : gáudium paréntibus ejus fecit, meípsum a devoratióne piscis erípuit, te quoque vidére fecit lumen cæli, et bonis ómnibus per eum repléti sumus. Quid illi ad hæc potérimus dignum dare ?

4. Sed peto te, pater mi, ut roges eum, si forte dignábitur medietátem de ómnibus quæ alláta sunt, sibi assúmere.

5. Et vocántes eum, pater scílicet et fílius, tulérunt eum in partem : et rogáre cœpérunt ut dignarétur dimídiam partem ómnium quæ attúlerant accéptam habére.

6. Tunc dixit eis occúlte : Benedícite Deum cæli, et coram ómnibus vivéntibus confitémini ei, quia fecit vobíscum misericórdiam suam.

7. Étenim sacraméntum regis abscóndere bonum est : ópera autem Dei reveláre et confitéri honoríficum est.

8. Bona est orátio cum jejúnio, et eleemósyna magis quam thesáuros auri recóndere :

9. quóniam eleemósyna a morte líberat, et ipsa est quæ purgat peccáta, et facit inveníre misericórdiam et viam ætérnam.

10. Qui autem fáciunt peccátum et iniquitátem, hostes sunt ánimæ suæ.

11. Manifésto ergo vobis veritátem, et non abscóndam a vobis occúltum sermónem.

12. Quando orábas cum lácrimis, et sepeliébas mórtuos, et derelinquébas prándium tuum, et mórtuos abscondébas per diem in domo tua, et nocte sepeliébas eos, ego óbtuli oratiónem tuam Dómino.

13. Et quia accéptus eras Deo, necésse fuit ut tentátio probáret te.

14. Et nunc misit me Dóminus ut curárem te, et Saram uxórem fílii tui a dæmónio liberárem.

15. Ego enim sum Ráphaël ángelus, unus ex septem qui adstámus ante Dóminum.

16. Cumque hæc audíssent, turbáti sunt, et treméntes cecidérunt super terram in fáciem suam.

17. Dixítque eis ángelus : Pax vobis : nolíte timére.

18. Étenim cum essem vobíscum, per voluntátem Dei eram : ipsum benedícite, et cantáte illi.

19. Vidébar quidem vobíscum manducáre et bíbere : sed ego cibo invisíbili, et potu qui ab homínibus víderi non potest, utor.

20. Tempus est ergo ut revértar ad eum qui me misit : vos autem benedícite Deum, et narráte ómnia mirabília ejus.

21. Et cum hæc dixísset, ab aspéctu eórum ablátus est, et ultra eum vidére non potuérunt.

22. Tunc prostráti per horas tres in fáciem, benedixérunt Deum : et exsurgéntes narravérunt ómnia mirabília ejus.

