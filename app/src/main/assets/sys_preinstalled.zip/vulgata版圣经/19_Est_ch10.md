# Liber Esther - Caput 10

1. Rex vero Assúerus omnem terram et cunctas maris ínsulas fecit tributárias :

2. cujus fortitúdo et impérium, et dígnitas atque sublímitas, qua exaltávit Mardochǽum, scripta sunt in libris Medórum, atque Persárum :

3. et quómodo Mardochǽus judáici géneris secúndus a rege Assúero fúerit, et magnus apud Judǽos, et acceptábilis plebi fratrum suórum, quærens bona pópulo suo, et loquens ea quæ ad pacem séminis sui pertinérent.

4. Dixítque Mardochǽus : A Deo facta sunt ista.

5. Recordátus sum sómnii quod víderam, hæc eádem significántis : nec eórum quidquam írritum fuit.

6. Parvus fons, qui crevit in flúvium, et in lucem solémque convérsus est, et in aquas plúrimas redundávit : Esther est quam rex accépit uxórem, et vóluit esse regínam.

7. Duo autem dracónes : ego sum, et Aman.

8. Gentes, quæ convénerant : hi sunt, qui conáti sunt delére nomen Judæórum.

9. Gens autem mea Israël est, quæ clamávit ad Dóminum, et salvum fecit Dóminus pópulum suum : liberavítque nos ab ómnibus malis, et fecit signa magna atque porténta inter gentes :

10. et duas sortes esse præcépit, unam pópuli Dei, et álteram cunctárum géntium.

11. Venítque utráque sors in statútum ex illo jam témpore diem coram Deo univérsis géntibus :

12. et recordátus est Dóminus pópuli sui, ac misértus est hæreditátis suæ.

13. Et observabúntur dies isti in mense Adar quartadécima et quintadécima die ejúsdem mensis, cum omni stúdio et gáudio, in unum cœtum pópuli congregáti, in cunctas deínceps generatiónes pópuli Israël.

