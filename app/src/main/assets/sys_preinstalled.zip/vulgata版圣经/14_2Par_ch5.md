# Liber Secundus Paralipomenon - Caput 5

1. Íntulit ígitur Sálomon ómnia quæ vóverat David pater suus : argéntum, et aurum, et univérsa vasa pósuit in thesáuris domus Dei.

2. Post quæ congregávit majóres natu Israël, et cunctos príncipes tríbuum, et cápita familiárum de fíliis Israël in Jerúsalem, ut addúcerent arcam fóederis Dómini de civitáte David, quæ est Sion.

3. Venérunt ítaque ad regem omnes viri Israël in die solémni mensis séptimi.

4. Cumque veníssent cuncti seniórum Israël, portavérunt Levítæ arcam,

5. et intulérunt eam, et omnem paratúram tabernáculi. Porro vasa sanctuárii, quæ erant in tabernáculo, portavérunt sacerdótes cum Levítis.

6. Rex autem Sálomon, et univérsus cœtus Israël, et omnes qui fuérunt congregáti ante arcam, immolábant aríetes et boves absque ullo número : tanta enim erat multitúdo victimárum.

7. Et intulérunt sacerdótes arcam fóederis Dómini in locum suum, id est, ad oráculum templi, in Sancta sanctórum subter alas chérubim :

8. ita ut chérubim expánderent alas suas super locum in quo pósita erat arca, et ipsam arcam tégerent cum véctibus suis.

9. Véctium autem quibus portabátur arca, quia páululum longióres erant, cápita parébant ante oráculum : si vero quis páululum fuísset extrínsecus, eos vidére non póterat. Fuit ítaque arca ibi usque in præséntem diem.

10. Nihílque erat áliud in arca, nisi duæ tábulæ quas posúerat Móyses in Horeb, quando legem dedit Dóminus fíliis Israël egrediéntibus ex Ægýpto.

11. Egréssis autem sacerdótibus de sanctuário (ómnes enim sacerdótes qui ibi potúerant inveníri, sanctificáti sunt : nec adhuc in illo témpore vices et ministeriórum ordo inter eos divísus erat),

12. tam Levítæ quam cantóres, id est, et qui sub Asaph erant, et qui sub Eman, et qui sub Ídithun, fílii et fratres eórum vestíti býssinis, cýmbalis, et psaltériis, et cítharis concrepábant, stantes ad orientálem plagam altáris : et cum eis sacerdótes centum vigínti canéntes tubis.

13. Ígitur cunctis páriter, et tubis, et voce, et cýmbalis, et órganis, et divérsi géneris musicórum concinéntibus, et vocem in sublíme tolléntibus, longe sónitus audiebátur, ita ut cum Dóminum laudáre cœpíssent et dícere : Confitémini Dómino quóniam bonus, quóniam in ætérnum misericórdia ejus : implerétur domus Dei nube,

14. nec possent sacerdótes stare et ministráre propter calíginem. Compléverat enim glória Dómini domum Dei.

