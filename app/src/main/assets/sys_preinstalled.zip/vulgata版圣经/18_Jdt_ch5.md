# Liber Judith - Caput 5

1. Nuntiatúmque est Holoférni príncipi milítiæ Assyriórum, quod fílii Israël præparárent se ad resisténdum, ac móntium itínera conclusíssent :

2. et furóre nímio exársit in iracúndia magna, vocavítque omnes príncipes Moab et duces Ammon,

3. et dixit eis : Dícite mihi quis sit pópulus iste, qui montána óbsidet : aut quæ, et quales, et quantæ sint civitátes eórum : quæ étiam sit virtus eórum, aut quæ sit multitúdo eórum, vel quis rex milítiæ illórum :

4. et quare præ ómnibus qui hábitant in oriénte, isti contempsérunt nos, et non exiérunt óbviam nobis ut suscíperent nos cum pace ?

5. Tunc Áchior dux ómnium filiórum Ammon respóndens, ait : Si dignéris audíre, dómine mi, dicam veritátem in conspéctu tuo de pópulo isto qui in montánis hábitat, et non egrediétur verbum falsum ex ore meo.

6. Pópulus iste ex progénie Chaldæórum est.

7. Hic primum in Mesopotámia habitávit, quóniam noluérunt sequi deos patrum suórum, qui erant in terra Chaldæórum.

8. Deseréntes ítaque cæremónias patrum suórum, quæ in multitúdine deórum erant,

9. unum Deum cæli coluérunt, qui et præcépit eis ut exírent inde et habitárent in Charan. Cumque operuísset omnem terram fames, descendérunt in Ægýptum, illícque per quadringéntos annos sic multiplicáti sunt, ut dinumerári eórum non posset exércitus.

10. Cumque graváret eos rex Ægýpti, atque in ædificatiónibus úrbium suárum in luto et látere subjugásset eos, clamavérunt ad Dóminum suum, et percússit totam terram Ægýpti plagis váriis.

11. Cumque ejecíssent eos Ægýptii a se, et cessásset plaga ab eis, et íterum eos vellent cápere, et ad suum servítium revocáre,

12. fugiéntibus his, Deus cæli mare apéruit, ita ut hinc inde aquæ quasi murus solidaréntur, et isti pede sicco fundum maris perambulándo transírent.

13. In quo loco dum innumerábilis exércitus Ægyptiórum eos persequerétur, ita aquis coopértus est, ut non remanéret vel unus, qui factum pósteris nuntiáret.

14. Egréssi vero mare Rubrum, desérta Sina montis occupavérunt, in quibus numquam homo habitáre pótuit, vel fílius hóminis requiévit.

15. Illic fontes amári obdulcáti sunt eis ad bibéndum, et per annos quadragínta annónam de cælo consecúti sunt.

16. Ubicúmque ingréssi sunt sine arcu et sagítta, et absque scuto et gládio, Deus eórum pugnávit pro eis, et vicit.

17. Et non fuit qui insultáret pópulo isti, nisi quando recéssit a cultu Dómini Dei sui.

18. Quotiescúmque autem præter ipsum Deum suum, álterum coluérunt, dati sunt in prædam, et in gládium, et in oppróbrium.

19. Quotiescúmque autem pœnituérunt se recessísse a cultúra Dei sui, dedit eis Deus cæli virtútem resisténdi.

20. Dénique Chananǽum regem, et Jebusǽum, et Pherezǽum, et Hethǽum, et Hevǽum, et Amorrhǽum, et omnes poténtes in Hesébon prostravérunt, et terras eórum et civitátes eórum ipsi possedérunt :

21. et usque dum non peccárent in conspéctu Dei sui, erant cum illis bona : Deus enim illórum odit iniquitátem.

22. Nam et ante hos annos cum recessíssent a via quam déderat illis Deus ut ambulárent in ea, extermináti sunt prǽliis a multis natiónibus, et plúrimi eórum captívi abdúcti sunt in terram non suam.

23. Nuper autem revérsi ad Dóminum Deum suum, ex dispersióne qua dispérsi fúerant, adunáti sunt, et ascendérunt montána hæc ómnia, et íterum póssident Jerúsalem, ubi sunt sancta eórum.

24. Nunc ergo mi dómine, perquíre si est áliqua iníquitas eórum in conspéctu Dei eórum : ascendámus ad illos, quóniam tradens tradet illos Deus eórum tibi, et subjugáti erunt sub jugo poténtiæ tuæ.

25. Si vero non est offénsio pópuli hujus coram Deo suo, non potérimus resístere illis, quóniam Deus eórum deféndet illos : et érimus in oppróbrium univérsæ terræ.

26. Et factum est, cum cessásset loqui Áchior verba hæc, iráti sunt omnes magnátes Holoférnis, et cogitábant interfícere eum, dicéntes ad altérutrum :

27. Quis est iste, qui fílios Israël posse dicat resístere regi Nabuchodonósor et exercítibus ejus, hómines inérmes, et sine virtúte, et sine perítia artis pugnæ ?

28. Ut ergo agnóscat Áchior quóniam fallit nos, ascendámus in montána : et cum capti fúerint poténtes eórum, tunc cum eísdem gládio transverberábitur :

29. ut sciat omnis gens quóniam Nabuchodonósor deus terræ est, et præter ipsum álius non est.

