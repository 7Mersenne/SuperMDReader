# Liber Exodus - Caput 32

1. Videns autem pópulus quod moram fáceret descendéndi de monte Móyses, congregátus advérsus Áaron, dixit : Surge, fac nobis deos, qui nos præcédant : Móysi enim huic viro, qui nos edúxit de terra Ægýpti, ignorámus quid accíderit.

2. Dixítque ad eos Áaron : Tóllite ináures áureas de uxórum, filiorúmque et filiárum vestrárum áuribus, et afférte ad me.

3. Fecítque pópulus quæ jússerat, déferens ináures ad Áaron.

4. Quas cum ille accepísset, formávit ópere fusório, et fecit ex eis vítulum conflátilem : dixerúntque : Hi sunt dii tui Israël, qui te eduxérunt de terra Ægýpti.

5. Quod cum vidísset Áaron, ædificávit altáre coram eo, et præcónis voce clamávit dicens : Cras solémnitas Dómini est.

6. Surgentésque mane, obtulérunt holocáusta, et hóstias pacíficas, et sedit pópulus manducáre, et bíbere, et surrexérunt lúdere.

7. Locútus est autem Dóminus ad Móysen, dicens : Vade, descénde : peccávit pópulus tuus, quem eduxísti de terra Ægýpti.

8. Recessérunt cito de via, quam ostendísti eis : fecerúntque sibi vítulum conflátilem, et adoravérunt, atque immolántes ei hóstias, dixérunt : Isti sunt dii tui Israël, qui te eduxérunt de terra Ægýpti.

9. Rursúmque ait Dóminus ad Móysen : Cerno quod pópulus iste duræ cervícis sit :

10. dimítte me, ut irascátur furor meus contra eos, et déleam eos, faciámque te in gentem magnam.

11. Móyses autem orábat Dóminum Deum suum, dicens : Cur, Dómine, iráscitur furor tuus contra pópulum tuum, quem eduxísti de terra Ægýpti, in fortitúdine magna, et in manu robústa ?

12. Ne quæso dicant Ægýptii : Cállide edúxit eos, ut interfíceret in móntibus, et deléret e terra : quiéscat ira tua, et esto placábilis super nequítia pópuli tui.

13. Recordáre Ábraham, Ísaac, et Israël servórum tuórum, quibus jurásti per temetípsum, dicens : Multiplicábo semen vestrum sicut stellas cæli ; et univérsam terram hanc, de qua locútus sum, dabo sémini vestro, et possidébitis eam semper.

14. Placatúsque est Dóminus ne fáceret malum quod locútus fúerat advérsus pópulum suum.

15. Et revérsus est Móyses de monte, portans duas tábulas testimónii in manu sua, scriptas ex utráque parte,

16. et factas ópere Dei : scriptúra quoque Dei erat sculpta in tábulis.

17. Áudiens autem Jósue tumúltum pópuli vociferántis, dixit ad Móysen : Ululátus pugnæ audítur in castris.

18. Qui respóndit : Non est clamor adhortántium ad pugnam, neque vociferátio compelléntium ad fugam : sed vocem cantántium ego áudio.

19. Cumque appropinquásset ad castra, vidit vítulum, et choros : iratúsque valde, projécit de manu tábulas, et confrégit eas ad radícem montis :

20. arripiénsque vítulum quem fécerant, combússit, et contrívit usque ad púlverem, quem sparsit in aquam, et dedit ex eo potum fíliis Israël.

21. Dixítque ad Áaron : Quid tibi fecit hic pópulus, ut indúceres super eum peccátum máximum ?

22. Cui ille respóndit : Ne indignétur dóminus meus : tu enim nosti pópulum istum, quod pronus sit ad malum :

23. dixérunt mihi : Fac nobis deos, qui nos præcédant : huic enim Móysi, qui nos edúxit de terra Ægýpti, nescímus quid accíderit.

24. Quibus ego dixi : Quis vestrum habet aurum ? Tulérunt, et dedérunt mihi : et projéci illud in ignem, egressúsque est hic vítulus.

25. Videns ergo Móyses pópulum quod esset nudátus (spoliáverat enim eum Áaron propter ignomíniam sordis, et inter hostes nudum constitúerat),

26. et stans in porta castrórum, ait : Si quis est Dómini, jungátur mihi. Congregatíque sunt ad eum omnes fílii Levi :

27. quibus ait : Hæc dicit Dóminus Deus Israël : Ponat vir gládium super femur suum : ite, et rédite de porta usque ad portam per médium castrórum, et óccidat unusquísque fratrem, et amícum, et próximum suum.

28. Fecerúntque fílii Levi juxta sermónem Móysi, ceciderúntque in die illa quasi vigínti tria míllia hóminum.

29. Et ait Móyses : Consecrástis manus vestras hódie Dómino, unusquísque in fílio, et in fratre suo, ut detur vobis benedíctio.

30. Facto autem áltero die, locútus est Móyses ad pópulum : Peccástis peccátum máximum : ascéndam ad Dóminum, si quómodo quívero eum deprecári pro scélere vestro.

31. Reversúsque ad Dóminum, ait : Óbsecro, peccávit pópulus iste peccátum máximum, fecerúntque sibi deos áureos : aut dimítte eis hanc noxam,

32. aut si non facis, dele me de libro tuo quem scripsísti.

33. Cui respóndit Dóminus : Qui peccáverit mihi, delébo eum de libro meo :

34. tu autem vade, et duc pópulum istum quo locútus sum tibi : ángelus meus præcédet te. Ego autem in die ultiónis visitábo et hoc peccátum eórum.

35. Percússit ergo Dóminus pópulum pro reátu vítuli, quem fécerat Áaron.

