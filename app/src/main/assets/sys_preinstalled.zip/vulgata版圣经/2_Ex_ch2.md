# Liber Exodus - Caput 2

1. Egréssus est post hæc vir de domo Levi : et accépit uxórem stirpis suæ.

2. Quæ concépit, et péperit fílium : et videns eum elegántem, abscóndit tribus ménsibus.

3. Cumque jam celáre non posset, sumpsit fiscéllam scírpeam, et linívit eam bitúmine ac pice : posuítque intus infántulum, et expósuit eum in carécto ripæ flúminis,

4. stante procul soróre ejus, et consideránte evéntum rei.

5. Ecce autem descendébat fília Pharaónis ut lavarétur in flúmine : et puéllæ ejus gradiebántur per crepídinem álvei. Quæ cum vidísset fiscéllam in papyrióne, misit unam e famulábus suis : et allátam

6. apériens, cernénsque in ea párvulum vagiéntem, misérta ejus, ait : De infántibus Hebræórum est hic.

7. Cui soror púeri : Vis, inquit, ut vadam, et vocem tibi mulíerem hebrǽam, quæ nutríre possit infántulum ?

8. Respóndit : Vade. Perréxit puélla et vocávit matrem suam.

9. Ad quam locúta fília Pharaónis : Áccipe, ait, púerum istum, et nutri mihi : ego dabo tibi mercédem tuam. Suscépit múlier, et nutrívit púerum : adultúmque trádidit fíliæ Pharaónis.

10. Quem illa adoptávit in locum fílii, vocavítque nomen ejus Móyses, dicens : Quia de aqua tuli eum.

11. In diébus illis postquam créverat Móyses, egréssus est ad fratres suos : vidítque afflictiónem eórum, et virum ægýptium percutiéntem quemdam de Hebrǽis frátribus suis.

12. Cumque circumspexísset huc atque illuc, et nullum adésse vidísset, percússum Ægýptium abscóndit sábulo.

13. Et egréssus die áltero conspéxit duos Hebrǽos rixántes : dixítque ei qui faciébat injúriam : Quare pércutis próximum tuum ?

14. Qui respóndit : Quis te constítuit príncipem et júdicem super nos ? num occídere me tu vis, sicut heri occidísti Ægýptium ? Tímuit Móyses, et ait : Quómodo palam factum est verbum istud ?

15. Audivítque Phárao sermónem hunc, et quærébat occídere Móysen : qui fúgiens de conspéctu ejus, morátus est in terra Mádian, et sedit juxta púteum.

16. Erant autem sacerdóti Mádian septem fíliæ, quæ venérunt ad hauriéndam aquam : et implétis canálibus adaquáre cupiébant greges patris sui.

17. Supervénere pastóres, et ejecérunt eas : surrexítque Móyses, et defénsis puéllis, adaquávit oves eárum.

18. Quæ cum revertíssent ad Raguel patrem suum, dixit ad eas : Cur velócius venístis sólito ?

19. Respondérunt : Vir ægýptius liberávit nos de manu pastórum : ínsuper et hausit aquam nobíscum, potúmque dedit óvibus.

20. At ille : Ubi est ? inquit : quare dimisístis hóminem ? vocáte eum ut cómedat panem.

21. Jurávit ergo Móyses quod habitáret cum eo. Accepítque Sephóram fíliam ejus uxórem :

22. quæ péperit ei fílium, quem vocávit Gersam, dicens : Ádvena fui in terra aliéna. Álterum vero péperit, quem vocávit Eliézer, dicens : Deus enim patris mei adjútor meus erípuit me de manu Pharaónis.

23. Post multum vero témpore mórtuus est rex Ægýpti : et ingemiscéntes fílii Israël, propter ópera vociferáti sunt : ascendítque clamor eórum ad Deum ab opéribus.

24. Et audívit gémitum eórum, ac recordátus est fóederis quod pépigit cum Ábraham, Ísaac et Jacob.

25. Et respéxit Dóminus fílios Israël et cognóvit eos.

