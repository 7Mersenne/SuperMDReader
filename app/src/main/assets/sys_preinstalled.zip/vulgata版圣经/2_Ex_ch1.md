# Liber Exodus - Caput 1

1. Hæc sunt nómina filiórum Israël qui ingréssi sunt in Ægýptum cum Jacob : sínguli cum dómibus suis introiérunt :

2. Ruben, Símeon, Levi, Judas,

3. Issáchar, Zábulon et Bénjamin,

4. Dan et Nephtháli, Gad et Aser.

5. Erant ígitur omnes ánimæ eórum qui egréssi sunt de fémore Jacob, septuagínta : Joseph autem in Ægýpto erat.

6. Quo mórtuo, et univérsis frátribus ejus, omníque cognatióne illa,

7. fílii Israël crevérunt, et quasi germinántes multiplicáti sunt : ac roboráti nimis, implevérunt terram.

8. Surréxit intérea rex novus super Ægýptum, qui ignorábat Joseph.

9. Et ait ad pópulum suum : Ecce, pópulus filiórum Israël multus, et fórtior nobis est.

10. Veníte, sapiénter opprimámus eum, ne forte multiplicétur : et si ingrúerit contra nos bellum, addátur inimícis nostris, expugnatísque nobis egrediátur de terra.

11. Præpósuit ítaque eis magístros óperum, ut afflígerent eos onéribus : ædificaverúntque urbes tabernaculórum Pharaóni, Phithom et Ramésses.

12. Quantóque opprimébant eos, tanto magis multiplicabántur, et crescébant :

13. oderántque fílios Israël Ægýptii, et affligébant illudéntes eis,

14. atque ad amaritúdinem perducébant vitam eórum opéribus duris luti et láteris, omníque famulátu, quo in terræ opéribus premebántur.

15. Dixit autem rex Ægýpti obstetrícibus Hebræórum, quarum una vocabátur Sephóra, áltera Phua,

16. præcípiens eis : Quando obstetricábitis Hebrǽas, et partus tempus advénerit : si másculus fúerit, interfícite eum : si fémina, reserváte.

17. Timuérunt autem obstetríces Deum, et non fecérunt juxta præcéptum regis Ægýpti, sed conservábant mares.

18. Quibus ad se accersítis, rex ait : Quidnam est hoc quod fácere voluístis, ut púeros servarétis ?

19. Quæ respondérunt : Non sunt Hébreæ sicut ægýptiæ mulíeres : ipsæ enim obstetricándi habent sciéntiam, et priúsquam veniámus ad eas, páriunt.

20. Bene ergo fecit Deus obstetrícibus : et crevit pópulus, confortatúsque est nimis.

21. Et quia timuérunt obstetríces Deum, ædificávit eis domos.

22. Præcépit ergo Phárao omni pópulo suo, dicens : Quidquid masculíni sexus natum fúerit, in flumen projícite : quidquid femínini, reserváte.

