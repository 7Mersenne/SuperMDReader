# Liber Primus Paralipomenon - Caput 9

1. Univérsus ergo Israël dinumerátus est, et summa eórum scripta est in libro regum Israël et Juda : translatíque sunt in Babylónem propter delíctum suum.

2. Qui autem habitavérunt primi in possessiónibus et in úrbibus suis : Israël, et sacerdótes, et Levítæ, et Nathinǽi.

3. Commoráti sunt in Jerúsalem de fíliis Juda, et de fíliis Bénjamin, de fíliis quoque Éphraim, et Manásse.

4. Óthei fílius Ámmiud, fílii Amri, fílii Ómrai, fílii Bonni, de fíliis Phares fílii Juda.

5. Et de Silóni : Asaía primogénitus, et fílii ejus.

6. De fíliis autem Zara, Jéhuel, et fratres eórum, sexcénti nonagínta.

7. Porro de fíliis Bénjamin : Salo fílius Mosóllam, fílii Oduía, fílii Asána,

8. et Jobánia fílius Jéroham, et Ela fílius Ozi, fílii Mochóri, et Mosóllam fílius Saphátiæ, fílii Ráhuel, fílii Jebániæ,

9. et fratres eórum per famílias suas, nongénti quinquagínta sex. Omnes hi príncipes cognatiónum per domos patrum suórum.

10. De sacerdótibus autem : Jedaía, Jojárib, et Jachin :

11. Azarías quoque fílius Helcíæ, fílii Mosóllam, fílii Sadoc, fílii Maraíoth, fílii Áchitob, póntifex domus Dei.

12. Porro Adaías fílius Jéroham, fílii Phassur, fílii Mélchiæ, et Maásai fílius Ádiel fílii Jezra, fílii Mosóllam, fílii Mosollámith, fílii Emmer.

13. Fratres quoque eórum príncipes per famílias suas, mille septingénti sexagínta, fortíssimi róbore ad faciéndum opus ministérii in domo Dei.

14. De Levítis autem : Semeía fílius Hassub fílii Ézricam, fílii Hasébia de fíliis Merári.

15. Bacbácar quoque carpentárius, et Galal, et Mathánia fílius Micha, fílii Zechri, fílii Asaph :

16. et Óbdia fílius Semeíæ, fílii Galal, fílii Ídithun : et Barachía fílius Asa, fílii Elcána, qui habitávit in átriis Netopháti.

17. Janitóres autem : Sellum, et Accub, et Telmon, et Áhimam : et frater eórum Sellum princeps,

18. usque ad illud tempus, in porta regis ad oriéntem, observábant per vices suas de fíliis Levi.

19. Sellum vero fílius Core fílii Abiásaph, fílii Core, cum frátribus suis, et domo patris sui, hi sunt Córitæ super ópera ministérii, custódes vestibulórum tabernáculi : et famíliæ eórum per vices castrórum Dómini custodiéntes intróitum.

20. Phínees autem fílius Eleazári erat dux eórum coram Dómino.

21. Porro Zacharías fílius Mosollámia, jánitor portæ tabernáculi testimónii.

22. Omnes hi elécti in ostiários per portas, ducénti duódecim : et descrípti in villis própriis, quos constituérunt David, et Sámuel videns, in fide sua,

23. tam ipsos quam fílios eórum, in óstiis domus Dómini et in tabernáculo vícibus suis.

24. Per quátuor ventos erant ostiárii : id est, ad oriéntem, et ad occidéntem, et ad aquilónem, et ad austrum.

25. Fratres autem eórum in vículis morabántur, et veniébant in sábbatis suis de témpore usque ad tempus.

26. His quátuor Levítis créditus erat omnis númerus janitórum, et erant super éxedras et thesáuros domus Dómini.

27. Per gyrum quoque templi Dómini morabántur in custódiis suis : ut cum tempus fuísset, ipsi mane aperírent fores.

28. De horum génere erant et super vasa ministérii : ad númerum enim et inferebántur vasa, et efferebántur.

29. De ipsis et qui crédita habébant utensília sanctuárii, prǽerant símilæ, et vino, et óleo, et thuri, et aromátibus.

30. Fílii autem sacerdótum unguénta ex aromátibus conficiébant.

31. Et Matháthias Levítes primogénitus Sellum Córitæ, præféctus erat eórum quæ in sartágine frigebántur.

32. Porro de fíliis Caath frátribus eórum, super panes erant propositiónis, ut semper novos per síngula sábbata præparárent.

33. Hi sunt príncipes cantórum per famílias Levitárum, qui in éxedris morabántur, ut die ac nocte júgiter suo ministério deservírent.

34. Cápita Levitárum, per famílias suas príncipes, mansérunt in Jerúsalem.

35. In Gábaon autem commoráti sunt pater Gábaon Jéhiel, et nomen uxóris ejus Maácha.

36. Fílius primogénitus ejus Abdon, et Sur, et Cis, et Baal, et Ner, et Nadab,

37. Gedor quoque, et Áhio, et Zacharías, et Macélloth.

38. Porro Macélloth génuit Sámaan : isti habitavérunt e regióne fratrum suórum in Jerúsalem cum frátribus suis.

39. Ner autem génuit Cis, et Cis génuit Saul, et Saul génuit Jónathan, et Melchísua, et Abinádab, et Ésbaal.

40. Fílius autem Jónathan, Meríbbaal : et Meríbbaal génuit Micha.

41. Porro fílii Micha, Phithon, et Melech, et Tháraa, et Ahaz.

42. Ahaz autem génuit Jara, et Jara génuit Alámath, et Azmoth, et Zamri. Zamri autem génuit Mosa.

43. Mosa vero génuit Bánaa, cujus fílius Raphaía, génuit Elása, de quo ortus est Asel.

44. Porro Asel sex fílios hábuit, his nomínibus : Ézricam, Bocru, Ísmahel, Sária, Óbdia, Hanan : hi sunt fílii Asel.

