# Liber Esther - Caput 7

1. Intrávit ítaque rex et Aman, ut bíberent cum regína.

2. Dixítque ei rex étiam secúnda die, postquam vino incalúerat : Quæ est petítio tua, Esther, ut detur tibi ? et quid vis fíeri ? étiam si dimídiam partem regni mei petíeris, impetrábis.

3. Ad quem illa respóndit : Si invéni grátiam in óculis tuis o rex, et si tibi placet, dona mihi ánimam meam pro qua rogo, et pópulum meum pro quo óbsecro.

4. Tráditi enim sumus ego et pópulus meus, ut conterámur, jugulémur, et pereámus. Atque útinam in servos et fámulas venderémur : esset tolerábile malum, et gemens tacérem : nunc autem hostis noster est, cujus crudélitas redúndat in regem.

5. Respondénsque rex Assúerus, ait : Quis est iste, et cujus poténtiæ, ut hæc áudeat fácere ?

6. Dixítque Esther : Hostis et inimícus noster péssimus iste est Aman. Quod ille áudiens, íllico obstúpuit, vultum regis ac regínæ ferre non sústinens.

7. Rex autem irátus surréxit, et de loco convívii intrávit in hortum arbóribus cónsitum. Aman quoque surréxit ut rogáret Esther regínam pro ánima sua : intelléxit enim a rege sibi parátum malum.

8. Qui cum revérsus esset de horto nemóribus cónsito, et intrásset convívii locum, réperit Aman super léctulum corruísse in quo jacébat Esther, et ait : Étiam regínam vult opprímere, me præsénte, in domo mea. Necdum verbum de ore regis exíerat, et statim operuérunt fáciem ejus.

9. Dixítque Harbóna, unus de eunúchis, qui stabant in ministério regis : En lignum quod paráverat Mardochǽo, qui locútus est pro rege, stat in domo Aman, habens altitúdinis quinquagínta cúbitos. Cui dixit rex : Appéndite eum in eo.

10. Suspénsus est ítaque Aman in patíbulo quod paráverat Mardochǽo : et regis ira quiévit.

