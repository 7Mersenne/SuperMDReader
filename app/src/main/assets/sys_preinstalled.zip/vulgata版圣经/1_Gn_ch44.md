# Liber Genesis - Caput 44

1. Præcépit autem Joseph dispensatóri domus suæ, dicens : Imple saccos eórum fruménto, quantum possunt cápere : et pone pecúniam singulórum in summitáte sacci.

2. Scyphum autem meum argénteum, et prétium quod dedit trítici, pone in ore sacci junióris. Factúmque est ita.

3. Et orto mane, dimíssi sunt cum ásinis suis.

4. Jamque urbem exíerant, et procésserant páululum : tunc Joseph accersíto dispensatóre domus, Surge, inquit, et perséquere viros : et apprehénsis dícito : Quare reddidístis malum pro bono ?

5. scyphus, quem furáti estis, ipse est in quo bibit dóminus meus, et in quo augurári solet : péssimam rem fecístis.

6. Fecit ille ut jússerat : et apprehénsis per órdinem locútus est.

7. Qui respondérunt : Quare sic lóquitur dóminus noster, ut servi tui tantum flagítii commíserint ?

8. pecúniam, quam invénimus in summitáte saccórum, reportávimus ad te de terra Chánaan : et quómodo cónsequens est ut furáti simus de domo dómini tui aurum vel argéntum ?

9. apud quemcúmque fúerit invéntum servórum tuórum quod quæris, moriátur, et nos érimus servi dómini nostri.

10. Qui dixit eis : Fiat juxta vestram senténtiam : apud quemcúmque fúerit invéntum, ipse sit servus meus, vos autem éritis innóxii.

11. Ítaque festináto deponéntes in terram saccos, aperuérunt sínguli.

12. Quos scrutátus, incípiens a majóre usque ad mínimum, invénit scyphum in sacco Bénjamin.

13. At illi, scissis véstibus, oneratísque rursum ásinis, revérsi sunt in óppidum.

14. Primúsque Judas cum frátribus ingréssus est ad Joseph (nécdum enim de loco abíerat) omnésque ante eum páriter in terram corruérunt.

15. Quibus ille ait : Cur sic ágere voluístis ? an ignorátis quod non sit símilis mei in augurándi sciéntia ?

16. Cui Judas : Quid respondébimus, inquit, dómino meo ? vel quid loquémur, aut juste potérimus obténdere ? Deus invénit iniquitátem servórum tuórum : en omnes servi sumus dómini mei, et nos, et apud quem invéntus est scyphus.

17. Respóndit Joseph : Absit a me ut sic agam : qui furátus est scyphum, ipse sit servus meus : vos autem ábite líberi ad patrem vestrum.

18. Accédens autem própius Judas, confidénter ait : Oro, dómine mi, loquátur servus tuus verbum in áuribus tuis, et ne irascáris fámulo tuo : tu es enim post Pharaónem

19. dóminus meus. Interrogásti prius servos tuos : Habétis patrem aut fratrem ?

20. et nos respóndimus tibi dómino meo : Est nobis pater senex, et puer párvulus, qui in senectúte illíus natus est : cujus utérinus frater mórtuus est : et ipsum solum habet mater sua, pater vero tenére díligit eum.

21. Dixistíque servis tuis : Addúcite eum ad me, et ponam óculos meos super illum.

22. Suggéssimus dómino meo : Non potest puer relínquere patrem suum : si enim illum dimíserit, moriétur.

23. Et dixísti servis tuis : Nisi vénerit frater vester mínimus vobíscum, non vidébitis ámplius fáciem meam.

24. Cum ergo ascendissémus ad fámulum tuum patrem nostrum, narrávimus ei ómnia quæ locútus est dóminus meus.

25. Et dixit pater noster : Revertímini, et émite nobis parum trítici.

26. Cui díximus : Ire non póssumus : si frater noster mínimus descénderit nobíscum, proficiscémur simul : alióquin illo absénte, non audémus vidére fáciem viri.

27. Ad quæ ille respóndit : Vos scitis quod duos genúerit mihi uxor mea.

28. Egréssus est unus, et dixístis : Béstia devorávit eum : et hucúsque non compáret.

29. Si tuléritis et istum, et áliquid ei in via contígerit, deducétis canos meos cum mœróre ad ínferos.

30. Ígitur si intrávero ad servum tuum patrem nostrum, et puer defúerit (cum ánima illíus ex hujus ánima péndeat),

31. viderítque eum non esse nobíscum, moriétur, et dedúcent fámuli tui canos ejus cum dolóre ad ínferos.

32. Ego próprie servus tuus sim qui in meam hunc recépi fidem, et spopóndi dicens : Nisi redúxero eum, peccáti reus ero in patrem meum omni témpore.

33. Manébo ítaque servus tuus pro púero in ministério dómini mei, et puer ascéndat cum frátribus suis.

34. Non enim possum redíre ad patrem meum, absénte púero : ne calamitátis, quæ oppressúra est patrem meum, testis assístam.

