# Liber Esdr� - Caput 8

1. Hi sunt ergo príncipes familiárum, et genealógia eórum, qui ascendérunt mecum in regno Artaxérxis regis de Babylóne.

2. De fíliis Phínees, Gersom. De fíliis Ithámar, Dániel. De fíliis David, Hattus.

3. De fíliis Sechéniæ, fíliis Pharos, Zacharías : et cum eo numeráti sunt viri centum quinquagínta.

4. De fíliis Phahath Moab, Elioënai fílius Zárehe, et cum eo ducénti viri.

5. De fíliis Sechéniæ, fílius Ezechíel, et cum eo trecénti viri.

6. De fíliis Adan, Abed fílius Jónathan, et cum eo quinquagínta viri.

7. De fíliis Alam, Isaías fílius Atháliæ, et cum eo septuagínta viri.

8. De fíliis Saphátiæ, Zebédia fílius Míchaël, et cum eo octogínta viri.

9. De fíliis Joab, Obédia fílius Jáhiel, et cum eo ducénti decem et octo viri.

10. De fíliis Selómith, fílius Jósphiæ, et cum eo centum sexagínta viri.

11. De fíliis Bébai, Zacharías fílius Bébai, et cum eo vigínti octo viri.

12. De fíliis Azgad, Johánan fílius Eccétan, et cum eo centum et decem viri.

13. De fíliis Adónicam, qui erant novíssimi : et hæc nómina eórum : Elípheleth, et Jéhiel, et Samaías, et cum eis sexagínta viri.

14. De fílii Begui, Úthai et Zachur, et cum eis septuagínta viri.

15. Congregávi autem eos ad flúvium qui decúrrit ad Aháva, et mánsimus ibi tribus diébus : quæsivíque in pópulo et in sacerdótibus de fíliis Levi, et non invéni ibi.

16. Ítaque misi Eliézer, et Áriel, et Semeíam, et Elnáthan, et Jarib, et álterum Elnáthan, et Nathan, et Zacharíam, et Mosóllam príncipes : et Jojárib, et Elnáthan sapiéntes.

17. Et misi eos ad Eddo, qui est primus in Chásphiæ loco, et pósui in ore eórum verba, quæ loqueréntur ad Eddo, et fratres ejus Nathinǽos in loco Chásphiæ, ut addúcerent nobis minístros domus Dei nostri.

18. Et adduxérunt nobis per manum Dei nostri bonam super nos, virum doctíssimum de fíliis Móholi fílii Levi, fílii Israël, et Sarábiam et fílios ejus et fratres ejus decem et octo,

19. et Hasábiam, et cum eo Isaíam de fíliis Merári, fratrésque ejus, et fílios ejus vigínti :

20. et de Nathinǽis, quos déderat David et príncipes ad ministéria Levitárum, Nathinǽos ducéntos vigínti : omnes hi suis nomínibus vocabántur.

21. Et prædicávi ibi jejúnium juxta flúvium Aháva, ut affligerémur coram Dómino Deo nostro, et peterémus ab eo viam rectam nobis et fíliis nostris, universǽque substántiæ nostræ.

22. Erúbui enim pétere a rege auxílium et équites, qui defénderent nos ab inimíco in via : quia dixerámus regi : Manus Dei nostri est super omnes qui quærunt eum in bonitáte : et impérium ejus, et fortitúdo ejus, et furor, super omnes qui derelínquunt eum.

23. Jejunávimus autem, et rogávimus Deum nostrum per hoc : et evénit nobis próspere.

24. Et separávi de princípibus sacerdótum duódecim, Sarábiam, et Hasábiam, et cum eis de frátribus eórum decem :

25. appendíque eis argéntum et aurum, et vasa consecráta domus Dei nostri, quæ obtúlerat rex et consiliatóres ejus, et príncipes ejus, universúsque Israël eórum qui invénti fúerant :

26. et appéndi in mánibus eórum argénti talénta sexcénta quinquagínta, et vasa argéntea centum, auri centum talénta :

27. et cráteres áureos vigínti, qui habébant sólidos millénos, et vasa æris fulgéntis óptimi duo, pulchra ut aurum.

28. Et dixi eis : Vos sancti Dómini, et vasa sancta, et argéntum et aurum, quod sponte oblátum est Dómino Deo patrum nostrórum :

29. vigiláte et custodíte, donec appendátis coram princípibus sacerdótum, et Levitárum, et dúcibus familiárum Israël in Jerúsalem, in thesáurum domus Dómini.

30. Suscepérunt autem sacerdótes et Levítæ pondus argénti, et auri, et vasórum, ut deférrent Jerúsalem in domum Dei nostri.

31. Promóvimus ergo a flúmine Aháva duodécimo die mensis primi ut pergerémus Jerúsalem : et manus Dei nostri fuit super nos, et liberávit nos de manu inimíci et insidiatóris in via.

32. Et venímus Jerúsalem, et mánsimus ibi tribus diébus.

33. Die autem quarta appénsum est argéntum, et aurum, et vasa in domo Dei nostri per manum Merémoth fílii Uríæ sacerdótis, et cum eo Eleázar fílius Phínees, cumque eis Jozábed fílius Jósue, et Noadaía fílius Bénnoi Levítæ,

34. juxta númerum et pondus ómnium : descriptúmque est omne pondus in témpore illo.

35. Sed et qui vénerant de captivitáte fílii transmigratiónis, obtulérunt holocautomáta Deo Israël, vítulos duódecim pro omni pópulo Israël, aríetes nonagínta sex, agnos septuagínta septem, hircos pro peccáto duódecim : ómnia in holocáustum Dómino.

36. Dedérunt autem edícta regis satrápis qui erant de conspéctu regis, et dúcibus trans flumen, et elevavérunt pópulum et domum Dei.

