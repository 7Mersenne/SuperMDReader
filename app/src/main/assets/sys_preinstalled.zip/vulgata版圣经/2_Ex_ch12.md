# Liber Exodus - Caput 12

1. Dixit quoque Dóminus ad Móysen et Áaron in terra Ægýpti :

2. Mensis iste, vobis princípium ménsium : primus erit in ménsibus anni.

3. Loquímini ad univérsum cœtum filiórum Israël, et dícite eis : Décima die mensis hujus tollat unusquísque agnum per famílias et domos suas.

4. Sin autem minor est númerus ut suffícere possit ad vescéndum agnum, assúmet vicínum suum qui junctus est dómui suæ, juxta númerum animárum quæ suffícere possunt ad esum agni.

5. Erit autem agnus absque mácula, másculus, annículus : juxta quem ritum tollétis et hædum.

6. Et servábitis eum usque ad quartamdécimam diem mensis hujus : immolabítque eum univérsa multitúdo filiórum Israël ad vésperam.

7. Et sument de sánguine ejus, ac ponent super utrúmque postem, et in superlimináribus domórum, in quibus cómedent illum.

8. Et edent carnes nocte illa assas igni, et ázymos panes cum lactúcis agréstibus.

9. Non comedétis ex eo crudum quid, nec coctum aqua, sed tantum assum igni : caput cum pédibus ejus et intestínis vorábitis.

10. Nec remanébit quidquam ex eo usque mane ; si quid resíduum fúerit, igne comburétis.

11. Sic autem comedétis illum : renes vestros accingétis, et calceaménta habébitis in pédibus, tenéntes báculos in mánibus, et comedétis festinánter : est enim Phase (id est, tránsitus) Dómini.

12. Et transíbo per terram Ægýpti nocte illa, percutiámque omne primogénitum in terra Ægýpti ab hómine usque ad pecus : et in cunctis diis Ægýpti fáciam judícia. Ego Dóminus.

13. Erit autem sanguis vobis in signum in ǽdibus in quibus éritis : et vidébo sánguinem, et transíbo vos : nec erit in vobis plaga dispérdens quando percússero terram Ægýpti.

14. Habébitis autem hunc diem in moniméntum : et celebrábitis eam solémnem Dómino in generatiónibus vestris cultu sempitérno.

15. Septem diébus ázyma comedétis : in die primo non erit ferméntum in dómibus vestris : quicúmque coméderit fermentátum, períbit ánima illa de Israël, a primo die usque ad diem séptimum.

16. Dies prima erit sancta atque solémnis, et dies séptima eádem festivitáte venerábilis : nihil óperis faciétis in eis, excéptis his, quæ ad vescéndum pértinent.

17. Et observábitis ázyma : in eádem enim ipsa die edúcam exércitum vestrum de terra Ægýpti, et custodiétis diem istum in generatiónes vestras ritu perpétuo.

18. Primo mense, quartadécima die mensis ad vésperam, comedétis ázyma usque ad diem vigésimam primam ejúsdem mensis ad vésperam.

19. Septem diébus ferméntum non inveniétur in dómibus vestris : qui coméderit fermentátum, períbit ánima ejus de cœtu Israël, tam de ádvenis quam de indígenis terræ.

20. Omne fermentátum non comedétis : in cunctis habitáculis vestris edétis ázyma.

21. Vocávit autem Móyses omnes senióres filiórum Israël, et dixit ad eos : Ite tolléntes ánimal per famílias vestras, et immoláte Phase.

22. Fasciculúmque hyssópi tíngite in sánguine qui est in límine, et aspérgite ex eo superlimináre, et utrúmque postem : nullus vestrum egrediátur óstium domus suæ usque mane.

23. Transíbit enim Dóminus percútiens Ægýptios : cumque víderit sánguinem in superliminári, et in utróque poste, transcéndet óstium domus, et non sinet percussórem íngredi domos vestras et lǽdere.

24. Custódi verbum istud legítimum tibi et fíliis tuis usque in ætérnum.

25. Cumque introiéritis terram, quam Dóminus datúrus est vobis ut pollícitus est, observábitis cæremónias istas.

26. Et cum díxerint vobis fílii vestri : Quæ est ista relígio ?

27. Dicétis eis : Víctima tránsitus Dómini est, quando transívit super domos filiórum Israël in Ægýpto, percútiens Ægýptios, et domos nostras líberans. Incurvatúsque pópulus adorávit.

28. Et egréssi fílii Israël fecérunt sicut præcéperat Dóminus Móysi et Áaron.

29. Factum est autem in noctis médio, percússit Dóminus omne primogénitum in terra Ægýpti, a primogénito Pharaónis, qui in sólio ejus sedébat, usque ad primogénitum captívæ quæ erat in cárcere, et omne primogénitum jumentórum.

30. Surrexítque Phárao nocte, et omnes servi ejus, cunctáque Ægýptus : et ortus est clamor magnus in Ægýpto : neque enim erat domus in qua non jáceret mórtuus.

31. Vocatísque Phárao Móyse et Áaron nocte, ait : Súrgite et egredímini a pópulo meo, vos et fílii Israël : ite, immoláte Dómino sicut dícitis.

32. Oves vestras et arménta assúmite ut petierátis, et abeúntes benedícite mihi.

33. Urgebántque Ægýptii pópulum de terra exíre velóciter, dicéntes : Omnes moriémur.

34. Tulit ígitur pópulus conspérsam farínam ántequam fermentarétur : et ligans in pálliis, pósuit super húmeros suos.

35. Fecerúntque fílii Israël sicut præcéperat Móyses : et petiérunt ab Ægýptiis vasa argéntea et áurea, vestémque plúrimam.

36. Dóminus autem dedit grátiam pópulo coram Ægýptiis ut commodárent eis : et spoliavérunt Ægýptios.

37. Profectíque sunt fílii Israël de Ramésse in Socoth, sexcénta fere míllia péditum virórum, absque párvulis.

38. Sed et vulgus promíscuum innumerábile ascéndit cum eis, oves et arménta et animántia divérsi géneris multa nimis.

39. Coxerúntque farínam, quam dudum de Ægýpto conspérsam túlerant : et fecérunt subcinerícios panes ázymos : neque enim póterant fermentári, cogéntibus exíre Ægýptiis, et nullam fácere sinéntibus moram : nec pulménti quidquam occúrrerat præparáre.

40. Habitátio autem filiórum Israël qua mansérunt in Ægýpto, fuit quadringentórum trigínta annórum.

41. Quibus explétis, eádem die egréssus est omnis exércitus Dómini de terra Ægýpti.

42. Nox ista est observábilis Dómini, quando edúxit eos de terra Ægýpti : hanc observáre debent omnes fílii Israël in generatiónibus suis.

43. Dixítque Dóminus ad Móysen et Áaron : Hæc est relígio Phase : omnis alienígena non cómedet ex eo.

44. Omnis autem servus emptítius circumcidétur, et sic cómedet.

45. Ádvena et mercenárius non edent ex eo.

46. In una domo comedétur, nec efferétis de cárnibus ejus foras, nec os illíus confringétis.

47. Omnis cœtus filiórum Israël fáciet illud.

48. Quod si quis peregrinórum in vestram volúerit transíre colóniam, et fácere Phase Dómini, circumcidétur prius omne masculínum ejus, et tunc rite celebrábit : erítque sicut indígena terræ : si quis autem circumcísus non fúerit, non vescétur ex eo.

49. Eádem lex erit indígenæ et colóno qui peregrinátur apud vos.

50. Fecerúntque omnes fílii Israël sicut præcéperat Dóminus Móysi et Áaron.

51. Et eádem die edúxit Dóminus fílios Israël de terra Ægýpti per turmas suas.

