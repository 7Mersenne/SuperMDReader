# Liber Esther - Caput 5

1. Die autem tértio indúta est Esther regálibus vestiméntis, et stetit in átrio domus régiæ, quod erat intérius, contra basílicam regis : at ille sedébat super sólium suum in consistório palátii contra óstium domus.

2. Cumque vidísset Esther regínam stantem, plácuit óculis ejus, et exténdit contra eam virgam áuream, quam tenébat manu : quæ accédens, osculáta est summitátem virgæ ejus.

3. Dixítque ad eam rex : Quid vis, Esther regína ? quæ est petítio tua ? étiam si dimídiam partem regni petíeris, dábitur tibi.

4. At illa respóndit : Si regi placet, óbsecro ut vénias ad me hódie, et Aman tecum, ad convívium quod parávi.

5. Statímque rex : Vocáte, inquit, cito Aman ut Esther obédiat voluntáti. Venérunt ítaque rex et Aman ad convívium, quod eis regína paráverat.

6. Dixítque ei rex, postquam vinum bíberat abundánter : Quid petis ut detur tibi ? et pro qua re póstulas ? étiam si dimídiam partem regni mei petíeris, impetrábis.

7. Cui respóndit Esther : Petítio mea, et preces sunt istæ :

8. si invéni in conspéctu regis grátiam, et si regi placet ut det mihi quod póstulo, et meam ímpleat petitiónem : véniat rex et Aman ad convívium quod parávi eis, et cras apériam regi voluntátem meam.

9. Egréssus est ítaque illo die Aman lætus et alácer. Cumque vidísset Mardochǽum sedéntem ante fores palátii, et non solum non assurrexísse sibi, sed nec motum quidem de loco sessiónis suæ, indignátus est valde :

10. et dissimuláta ira revérsus in domum suam, convocávit ad se amícos suos, et Zares uxórem suam,

11. et expósuit illis magnitúdinem divitiárum suárum, filiorúmque turbam, et quanta eum glória super omnes príncipes et servos suos rex elevásset.

12. Et post hæc ait : Regína quoque Esther nullum álium vocávit ad convívium cum rege præter me : apud quam étiam cras cum rege pransúrus sum.

13. Et cum hæc ómnia hábeam, nihil me habére puto, quámdiu vídero Mardochǽum Judǽum sedéntem ante fores régias.

14. Responderúntque ei Zares uxor ejus, et céteri amíci : Jube parári excélsam trabem, habéntem altitúdinis quinquagínta cúbitos, et dic mane regi ut appendátur super eam Mardochǽus, et sic ibis cum rege lætus ad convívium. Plácuit ei consílium, et jussit excélsam parári crucem.

