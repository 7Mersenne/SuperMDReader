# Liber Exodus - Caput 31

1. Locutúsque est Dóminus ad Móysen, dicens :

2. Ecce, vocávi ex nómine Beséleel fílium Uri fílii Hur de tribu Juda,

3. et implévi spíritu Dei, sapiéntia, et intelligéntia et sciéntia in omni ópere,

4. ad excogitándum quidquid fabrefíeri potest ex auro, et argénto, et ære,

5. marmóre, et gemmis, et diversitáte lignórum.

6. Dedíque ei sócium Oóliab fílium Achisámech de tribu Dan. Et in corde omnis erudíti pósui sapiéntiam : ut fáciant cuncta quæ præcépi tibi,

7. tabernáculum fóederis, et arcam testimónii, et propitiatórium, quod super eam est, et cuncta vasa tabernáculi,

8. mensámque et vasa ejus, candelábrum puríssimum cum vasis suis, et altáris thymiamátis,

9. et holocáusti, et ómnia vasa eórum, labrum cum basi sua,

10. vestes sanctas in ministério Áaron sacerdóti, et fíliis ejus, ut fungántur offício suo in sacris :

11. óleum unctiónis, et thymiáma arómatum in sanctuário, ómnia quæ præcépi tibi, fácient.

12. Et locútus est Dóminus ad Móysen, dicens :

13. Lóquere fíliis Israël, et dices ad eos : Vidéte ut sábbatum meum custodiátis : quia signum est inter me et vos in generatiónibus vestris : ut sciátis quia ego Dóminus, qui sanctífico vos.

14. Custodíte sábbatum meum, sanctum est enim vobis : qui pollúerit illud, morte moriétur ; qui fécerit in eo opus, períbit ánima illíus de médio pópuli sui.

15. Sex diébus faciétis opus : in die séptimo sábbatum est, réquies sancta Dómino ; omnis qui fécerit opus in hac die, moriétur.

16. Custódiant fílii Israël sábbatum, et célebrent illud in generatiónibus suis. Pactum est sempitérnum

17. inter me et fílios Israël, signúmque perpétuum ; sex enim diébus fecit Dóminus cælum et terram, et in séptimo ab ópere cessávit.

18. Dedítque Dóminus Móysi, complétis hujuscémodi sermónibus in monte Sínai, duas tábulas testimónii lapídeas, scriptas dígito Dei.

