# Liber Esdr� - Caput 4

1. Audiérunt autem hostes Judæ et Bénjamin, quia fílii captivitátis ædificárent templum Dómino Deo Israël :

2. et accedéntes ad Zoróbabel, et ad príncipes patrum, dixérunt eis : Ædificémus vobíscum, quia ita ut vos, quǽrimus Deum vestrum : ecce nos immolávimus víctimas a diébus Asor Haddan regis Assur, qui addúxit nos huc.

3. Et dixit eis Zoróbabel, et Jósue, et réliqui príncipes patrum Israël : Non est vobis et nobis ut ædificémus domum Deo nostro, sed nos ipsi soli ædificábimus Dómino Deo nostro, sicut præcépit nobis Cyrus rex Persárum.

4. Factum est ígitur ut pópulus terræ impedíret manus pópuli Judæ, et turbáret eos in ædificándo.

5. Conduxérunt autem advérsus eos consiliatóres, ut destrúerent consílium eórum ómnibus diébus Cyri regis Persárum, et usque ad regnum Daríi regis Persárum.

6. In regno autem Assúeri, in princípio regni ejus, scripsérunt accusatiónem advérsus habitatóres Judæ et Jerúsalem.

7. Et in diébus Artaxérxis scripsit Béselam, Mithridátes, et Thábeel, et réliqui qui erant in consílio eórum, ad Artaxérxem regem Persárum : epístola autem accusatiónis scripta erat syriáce, et legebátur sermóne syro.

8. Reum Beélteem, et Sámsai scriba, scripsérunt epístolam unam de Jerúsalem Artaxérxi regi, hujuscémodi :

9. Reum Beélteem, et Sámsai scriba, et réliqui consiliatóres eórum, Dinǽi, et Apharsathachǽi, Terphalǽi, Apharsǽi, Erchuǽi, Babylónii, Susanechǽi, Diévi, et Ælamítæ,

10. et céteri de géntibus, quas tránstulit Asenáphar magnus et gloriósus, et habitáre eas fecit in civitátibus Samaríæ, et in réliquis regiónibus trans flumen in pace

11. (hoc est exémplar epístolæ, quam misérunt ad eum), Artaxérxi regi, servi tui, viri qui sunt trans flúvium, salútem dicunt.

12. Notum sit regi quia Judǽi, qui ascendérunt a te ad nos, venérunt in Jerúsalem civitátem rebéllem et péssimam, quam ædíficant exstruéntes muros ejus, et paríetes componéntes.

13. Nunc ígitur notum sit regi, quia si cívitas illa ædificáta fúerit, et muri ejus instauráti, tribútum, et véctigal, et ánnuos réditus non dabunt, et usque ad reges hæc noxa pervéniet.

14. Nos autem mémores salis, quod in palátio comédimus, et quia læsiónes regis vidére nefas dúcimus, idcírco mísimus et nuntiávimus regi,

15. ut recénseas in libris historiárum patrum tuórum, et invénies scriptum in commentáriis : et scies quóniam urbs illa, urbs rebéllis est, et nocens régibus et provínciis, et bella concitántur in ea ex diébus antíquis : quam ob rem et cívitas ipsa destrúcta est.

16. Nuntiámus nos regi, quóniam si cívitas illa ædificáta fúerit, et muri ipsíus instauráti, possessiónem trans flúvium non habébis.

17. Verbum misit rex ad Reum Beélteem, et Sámsai scribam, et ad réliquos, qui erant in consílio eórum habitatóres Samaríæ, et céteris trans flúvium, salútem dicens et pacem.

18. Accusátio, quam misístis ad nos, maniféste lecta est coram me,

19. et a me præcéptum est : et recensuérunt, invenerúntque quóniam cívitas illa a diébus antíquis advérsum reges rebéllat, et seditiónes, et prǽlia concitántur in ea :

20. nam et reges fortíssimi fuérunt in Jerúsalem, qui et domináti sunt omni regióni quæ trans flúvium est : tribútum quoque et véctigal, et réditus accipiébant.

21. Nunc ergo audíte senténtiam : prohibeátis viros illos, ut urbs illa non ædificétur donec si forte a me jussum fúerit.

22. Vidéte ne negligénter hoc impleátis, et paulátim crescat malum contra reges.

23. Ítaque exémplum edícti Artaxérxis regis lectum est coram Reum Beélteem, et Sámsai scriba, et consiliáriis eórum : et abiérunt festíni in Jerúsalem ad Judǽos, et prohibuérunt eos in bráchio et róbore.

24. Tunc intermíssum est opus domus Dómini in Jerúsalem, et non fiébat usque ad annum secúndum regni Daríi regis Persárum.

