# Liber Genesis - Caput 12

1. Dixit autem Dóminus ad Abram : Egrédere de terra tua, et de cognatióne tua, et de domo patris tui, et veni in terram quam monstrábo tibi.

2. Faciámque te in gentem magnam, et benedícam tibi, et magnificábo nomen tuum, erísque benedíctus.

3. Benedícam benedicéntibus tibi, et malédicam maledicéntibus tibi, atque in te benedicéntur univérsæ cognatiónes terræ.

4. Egréssus est ítaque Abram sicut præcéperat ei Dóminus, et ivit cum eo Lot : septuagínta quinque annórum erat Abram cum egrederétur de Haran.

5. Tulítque Sárai uxórem suam, et Lot fílium fratris sui, universámque substántiam quam posséderant, et ánimas quas fécerant in Haran : et egréssi sunt ut irent in terram Chánaan. Cumque veníssent in eam,

6. pertransívit Abram terram usque ad locum Sichem, usque ad convállem illústrem : Chananǽus autem tunc erat in terra.

7. Appáruit autem Dóminus Abram, et dixit ei : Sémini tuo dabo terram hanc. Qui ædificávit ibi altáre Dómino, qui apparúerat ei.

8. Et inde transgrédiens ad montem, qui erat contra oriéntem Bethel, teténdit ibi tabernáculum suum, ab occidénte habens Bethel, et ab oriénte Hai : ædificávit quoque ibi altáre Dómino, et invocávit nomen ejus.

9. Perrexítque Abram vadens, et ultra progrédiens ad merídiem.

10. Facta est autem fames in terra : descendítque Abram in Ægýptum, ut peregrinarétur ibi : prævalúerat enim fames in terra.

11. Cumque prope esset ut ingrederétur Ægýptum, dixit Sárai uxóri suæ : Novi quod pulchra sis múlier :

12. et quod cum víderint te Ægýptii, dictúri sunt : Uxor ipsíus est : et interfícient me, et te reservábunt.

13. Dic ergo, óbsecro te, quod soror mea sis : ut bene sit mihi propter te, et vivat ánima mea ob grátiam tui.

14. Cum ítaque ingréssus esset Abram Ægýptum, vidérunt Ægýptii mulíerem quod esset pulchra nimis.

15. Et nuntiavérunt príncipes Pharaóni, et laudavérunt eam apud illum : et subláta est múlier in domum Pharaónis.

16. Abram vero bene usi sunt propter illam : fuerúntque ei oves et boves et ásini, et servi et fámulæ, et ásinæ et cámeli.

17. Flagellávit autem Dóminus Pharaónem plagis máximis, et domum ejus, propter Sárai uxórem Abram.

18. Vocavítque Phárao Abram, et dixit ei : Quidnam est hoc quod fecísti mihi ? quare non indicásti quod uxor tua esset ?

19. quam ob causam dixísti esse sorórem tuam, ut tóllerem eam mihi in uxórem ? Nunc ígitur ecce conjux tua, áccipe eam, et vade.

20. Præcepítque Phárao super Abram viris : et deduxérunt eum, et uxórem illíus, et ómnia quæ habébat.

