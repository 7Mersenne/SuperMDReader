# Liber Primus Paralipomenon - Caput 7

1. Porro fílii Issáchar : Thola, et Phua, Jasub, et Símeron, quátuor.

2. Fílii Thola : Ozi, et Raphaía, et Jériel, et Jémai, et Jebsem, et Sámuel, príncipes per domos cognatiónum suárum. De stirpe Thola viri fortíssimi numeráti sunt in diébus David, vigínti duo míllia sexcénti.

3. Fílii Ozi : Izráhia, de quo nati sunt Míchaël, et Obádia, et Joël, et Jésia, quinque omnes príncipes.

4. Cumque eis per famílias et pópulos suos, accíncti ad prǽlium, viri fortíssimi, trigínta sex míllia : multas enim habuérunt uxóres, et fílios.

5. Fratres quoque eórum per omnem cognatiónem Issáchar robustíssimi ad pugnándum, octogínta septem míllia numeráti sunt.

6. Fílii Bénjamin : Bela, et Bechor, et Jádihel, tres.

7. Fílii Bela : Esbon, et Ozi, et Ozíel, et Jérimoth, et Úrai, quinque príncipes familiárum, et ad pugnándum robustíssimi : númerus autem eórum, vigínti duo míllia et trigínta quátuor.

8. Porro fílii Bechor : Zamíra, et Joas, et Eliézer, et Elioënai, et Amri, et Jérimoth, et Abía, et Anáthoth, et Almath : omnes hi fílii Bechor.

9. Numeráti sunt autem per famílias suas príncipes cognatiónum suárum ad bella fortíssimi, vigínti míllia et ducénti.

10. Porro fílii Jádihel : Balan. Fílii autem Balan : Jehus, et Bénjamin, et Aod, et Chanána, et Zethan, et Tharsis, et Ahísahar :

11. omnes hi fílii Jádihel, príncipes cognatiónum suárum viri fortíssimi, decem et septem míllia et ducénti ad prǽlium procedéntes.

12. Sepham quoque et Hapham fílii Hir : et Hasim fílii Aher.

13. Fílii autem Nephtháli : Jáziel, et Guni, et Jeser, et Sellum, fílii Bala.

14. Porro fílius Manásse, Ésriel : concubináque ejus Syra péperit Machir patrem Gálaad.

15. Machir autem accépit uxóres fíliis suis Happhim, et Saphan : et hábuit sorórem nómine Maácha : nomen autem secúndi, Sálphaad, natǽque sunt Sálphaad fíliæ.

16. Et péperit Maácha uxor Machir fílium, vocavítque nomen ejus Phares : porro nomen fratris ejus, Sares : et fílii ejus, Ulam, et Recen.

17. Fílius autem Ulam, Badan : hi sunt fílii Gálaad, fílii Machir, fílii Manásse.

18. Soror autem ejus Regína péperit Virum decórum, et Abiézer, et Móhola.

19. Erant autem fílii Sémida, Ahin, et Sechem, et Leci, et Ániam.

20. Fílii autem Éphraim : Suthála, Bared fílius ejus, Thahath fílius ejus, Eláda fílius ejus, Thahath fílius ejus, hujus fílius Zabad,

21. et hujus fílius Súthula, et hujus fílius Ezer et Elad : occidérunt autem eos viri Geth indígenæ, quia descénderant ut inváderent possessiónes eórum.

22. Luxit ígitur Éphraim pater eórum multis diébus, et venérunt fratres ejus ut consolaréntur eum.

23. Ingressúsque est ad uxórem suam : quæ concépit, et péperit fílium, et vocávit nomen ejus Béria, eo quod in malis domus ejus ortus esset :

24. fília autem ejus fuit Sara, quæ ædificávit Bethóron inferiórem et superiórem, et Ozensára.

25. Porro fílius ejus Rapha, et Reseph, et Thale, de quo natus est Thaan,

26. qui génuit Laádan : hujus quoque fílius Ámmiud, qui génuit Elisáma,

27. de quo ortus est Nun, qui hábuit fílium Jósue.

28. Posséssio autem eórum et habitátio, Bethel cum filiábus suis, et contra oriéntem Noran, ad occidentálem plagam Gazer et fíliæ ejus, Sichem quoque cum filiábus suis, usque ad Aza cum filiábus ejus.

29. Juxta fílios quoque Manásse, Bethsan et fílias ejus, Thanach et fílias ejus, Magéddo et fílias ejus, Dor et fílias ejus : in his habitavérunt fílii Joseph, fílii Israël.

30. Fílii Aser : Jemna, et Jésua, et Jéssui, et Bária, et Sara soror eórum.

31. Fílii autem Bária : Heber, et Mélchiel : ipse est pater Bársaith.

32. Heber autem génuit Jephlat, et Somer, et Hotham, et Suáa sorórem eórum.

33. Fílii Jephlat : Phosech, et Chámaal, et Asoth : hi fílii Jephlat.

34. Porro fílii Somer : Ahi, et Róaga, et Haba, et Aram.

35. Fílii autem Helem fratris ejus : Supha, et Jemna, et Selles, et Amal.

36. Fílii Supha : Sue, Harnápher, et Sual, et Beri, et Jamra,

37. Bosor, et Hod, et Samma, et Salúsa, et Jethran, et Bera.

38. Fílii Jether : Jephóne, et Phaspha, et Ara.

39. Fílii autem Olla : Áree, et Hániel, et Résia.

40. Omnes hi fílii Aser, príncipes cognatiónum, elécti atque fortíssimi duces ducum : númerus autem eórum ætátis quæ apta esset ad bellum, vigínti sex míllia.

