# Liber Exodus - Caput 17

1. Ígitur profécta omnis multitúdo filiórum Israël de desérto Sin per mansiónes suas, juxta sermónem Dómini, castrametáti sunt in Ráphidim, ubi non erat aqua ad bibéndum pópulo.

2. Qui jurgátus contra Móysen, ait : Da nobis aquam, ut bibámus. Quibus respóndit Móyses : Quid jurgámini contra me ? cur tentátis Dóminum ?

3. Sitívit ergo ibi pópulus præ aquæ penúria, et murmurávit contra Móysen, dicens : Cur fecísti nos exíre de Ægýpto, ut occíderes nos, et líberos nostros, ac juménta siti ?

4. Clamávit autem Móyses ad Dóminum, dicens : Quid fáciam pópulo huic ? adhuc páululum, et lapidábit me.

5. Et ait Dóminus ad Móysen : Antécede pópulum, et sume tecum de senióribus Israël : et virgam qua percussísti flúvium, tolle in manu tua, et vade.

6. En ego stabo ibi coram te, supra petram Horeb : percutiésque petram, et exíbit ex ea aqua, ut bibat pópulus. Fecit Móyses ita coram senióribus Israël :

7. et vocávit nomen loci illíus, Tentátio, propter júrgium filiórum Israël, et quia tentavérunt Dóminum, dicéntes : Estne Dóminus in nobis, an non ?

8. Venit autem Ámalec, et pugnábat contra Israël in Ráphidim.

9. Dixítque Móyses ad Jósue : Élige viros : et egréssus, pugna contra Ámalec : cras ego stabo in vértice collis, habens virgam Dei in manu mea.

10. Fecit Jósue ut locútus erat Móyses, et pugnávit contra Ámalec : Móyses autem et Áaron et Hur ascendérunt super vérticem collis.

11. Cumque leváret Móyses manus, vincébat Israël : sin autem páululum remisísset, superábat Ámalec.

12. Manus autem Móysi erant graves : suméntes ígitur lápidem, posuérunt subter eum, in quo sedit : Áaron autem et Hur sustentábant manus ejus ex utráque parte. Et factum est ut manus illíus non lassaréntur usque ad occásum solis.

13. Fugavítque Jósue Ámalec, et pópulum ejus in ore gládii.

14. Dixit autem Dóminus ad Móysen : Scribe hoc ob moniméntum in libro, et trade áuribus Jósue : delébo enim memóriam Ámalec sub cælo.

15. Ædificavítque Móyses altáre : et vocávit nomen ejus, Dóminus exaltátio mea, dicens :

16. Quia manus sólii Dómini, et bellum Dómini erit contra Ámalec, a generatióne in generatiónem.

