# Liber Esdr� - Caput 6

1. Tunc Daríus rex præcépit : et recensuérunt in bibliothéca librórum, qui erant repósiti in Babylóne.

2. Et invéntum est in Ecbatánis, quod est castrum in Médena província, vólumen unum : talísque scriptus erat in eo commentárius :

3. Anno primo Cyri regis, Cyrus rex décrevit ut domus Dei ædificarétur, quæ est in Jerúsalem, in loco ubi ímmolent hóstias, et ut ponant fundaménta supportántia altitúdinem cubitórum sexagínta, et latitúdinem cubitórum sexagínta,

4. órdines de lapídibus impólitis tres, et sic órdines de lignis novis : sumptus autem de domo regis dabúntur.

5. Sed et vasa templi Dei áurea et argéntea, quæ Nabuchodonósor túlerat de templo Jerúsalem, et attúlerat ea in Babylónem, reddántur, et referántur in templum in Jerúsalem in locum suum, quæ et pósita sunt in templo Dei.

6. Nunc ergo Thathánai dux regiónis, quæ est trans flumen, Stharbuzánai, et consiliárii vestri Apharsachǽi, qui estis trans flumen, procul recédite ab illis,

7. et dimíttite fíeri templum Dei illud a duce Judæórum, et a senióribus eórum, ut domum Dei illam ædíficent in loco suo.

8. Sed et a me præcéptum est quid opórteat fíeri a presbýteris Judæórum illis ut ædificétur domus Dei, scílicet ut de arca regis, id est, de tribútis quæ dantur de regióne trans flumen, studióse sumptus dentur viris illis, ne impediátur opus.

9. Quod si necésse fúerit, et vítulos, et agnos, et hædos in holocáustum Deo cæli, fruméntum, sal, vinum, et óleum, secúndum ritum sacerdótum, qui sunt in Jerúsalem, detur eis per síngulos dies, ne sit in áliquo querimónia.

10. Et ófferant oblatiónes Deo cæli, oréntque pro vita regis, et filiórum ejus.

11. A me ergo pósitum est decrétum : ut omnis homo qui hanc mutáverit jussiónem, tollátur lignum de domum ipsíus, et erigátur, et configátur in eo, domus autem ejus publicétur.

12. Deus autem, qui habitáre fecit nomen suum ibi, díssipet ómnia regna, et pópulum qui exténderit manum suam ut repúgnet, et díssipet domum Dei illam, quæ est in Jerúsalem. Ego Daríus státui decrétum, quod studióse impléri volo.

13. Ígitur Thathánai dux regiónis trans flumen, et Stharbuzánai, et consiliárii ejus, secúndum quod præcéperat Daríus rex, sic diligénter execúti sunt.

14. Senióres autem Judæórum ædificábant, et prosperabántur juxta prophetíam Aggǽi prophétæ, et Zacharíæ fílii Addo : et ædificavérunt et construxérunt, jubénte Deo Israël, et jubénte Cyro, et Darío, et Artaxérxe régibus Persárum :

15. et complevérunt domum Dei istam, usque ad diem tértium mensis Adar, qui est annus sextus regni Daríi regis.

16. Fecérunt autem fílii Israël sacerdótes et Levítæ, et réliqui filiórum transmigratiónis, dedicatiónem domus Dei in gáudio.

17. Et obtulérunt in dedicatiónem domus Dei, vítulos centum, aríetes ducéntos, agnos quadringéntos, hircos caprárum pro peccáto tótius Israël duódecim, juxta númerum tríbuum Israël.

18. Et statuérunt sacerdótes in ordínibus suis, et Levítas in vícibus suis, super ópera Dei in Jerúsalem, sicut scriptum est in libro Móysi.

19. Fecérunt autem fílii Israël transmigratiónis Pascha, quartadécima die mensis primi.

20. Purificáti enim fúerant sacerdótes et Levítæ quasi unus : omnes mundi ad immolándum Pascha univérsis fíliis transmigratiónis, et frátribus suis sacerdótibus, et sibi.

21. Et comedérunt fílii Israël, qui revérsi fúerant de transmigratióne, et omnes qui se separáverant a coinquinatióne géntium terræ ad eos, ut quǽrerent Dóminum Deum Israël.

22. Et fecérunt solemnitátem azymórum septem diébus in lætítia, quóniam lætificáverat eos Dóminus, et convérterat cor regis Assur ad eos, ut adjuváret manus eórum in ópere domus Dómini Dei Israël.

