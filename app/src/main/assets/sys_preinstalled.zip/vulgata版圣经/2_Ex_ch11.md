# Liber Exodus - Caput 11

1. Et dixit Dóminus ad Móysen : Adhuc una plaga tangam Pharaónem et Ægýptum, et post hæc dimíttet vos, et exíre compéllet.

2. Dices ergo omni plebi ut póstulet vir ab amíco suo, et múlier a vicína sua, vasa argéntea et áurea.

3. Dabit autem Dóminus grátiam pópulo suo coram Ægýptiis. Fuítque Móyses vir magnus valde in terra Ægýpti coram servis Pharaónis et omni pópulo.

4. Et ait : Hæc dicit Dóminus : Média nocte egrédiar in Ægýptum :

5. et moriétur omne primogénitum in terra Ægyptiórum, a primogénito Pharaónis, qui sedet in sólio ejus, usque ad primogénitum ancíllæ quæ est ad molam, et ómnia primogénita jumentórum.

6. Erítque clamor magnus in univérsa terra Ægýpti, qualis nec ante fuit, nec póstea futúrus est.

7. Apud omnes autem fílios Israël non mútiet canis ab hómine usque ad pecus : ut sciátis quanto miráculo dívidat Dóminus Ægýptios et Israël.

8. Descendéntque omnes servi tui isti ad me, et adorábunt me, dicéntes : Egrédere tu, et omnis pópulus qui subjéctus est tibi : post hæc egrediémur.

9. Et exívit a Pharaóne irátus nimis. Dixit autem Dóminus ad Móysen : Non áudiet vos Phárao ut multa signa fiant in terra Ægýpti.

10. Móyses autem et Áaron fecérunt ómnia osténta, quæ scripta sunt, coram Pharaóne. Et indurávit Dóminus cor Pharaónis, nec dimísit fílios Israël de terra sua.

