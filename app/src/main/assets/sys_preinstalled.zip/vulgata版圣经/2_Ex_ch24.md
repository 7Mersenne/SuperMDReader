# Liber Exodus - Caput 24

1. Móysi quoque dixit : Ascénde ad Dóminum tu, et Áaron, Nadab et Abíu, et septuagínta senes ex Israël, et adorábitis procul.

2. Solúsque Móyses ascéndet ad Dóminum, et illi non appropinquábunt : nec pópulus ascéndet cum eo.

3. Venit ergo Móyses et narrávit plebi ómnia verba Dómini, atque judícia : respondítque omnis pópulus una voce : Ómnia verba Dómini, quæ locútus est, faciémus.

4. Scripsit autem Móyses univérsos sermónes Dómini : et mane consúrgens, ædificávit altáre ad radíces montis, et duódecim títulos per duódecim tribus Israël.

5. Misítque júvenes de fíliis Israël, et obtulérunt holocáusta, immolaverúntque víctimas pacíficas Dómino, vítulos.

6. Tulit ítaque Móyses dimídiam partem sánguinis, et misit in cráteras : partem autem resíduam fudit super altáre.

7. Assuménsque vólumen fóederis, legit audiénte pópulo : qui dixérunt : Ómnia quæ locútus est Dóminus, faciémus, et érimus obediéntes.

8. Ille vero sumptum sánguinem respérsit in pópulum, et ait : Hic est sanguis fóederis quod pépigit Dóminus vobíscum super cunctis sermónibus his.

9. Ascenderúntque Móyses et Áaron, Nadab et Abíu, et septuagínta de senióribus Israël :

10. et vidérunt Deum Israël : et sub pédibus ejus quasi opus lápidis sapphírini, et quasi cælum, cum serénum est.

11. Nec super eos qui procul recésserant de fíliis Israël, misit manum suam, viderúntque Deum, et comedérunt, ac bibérunt.

12. Dixit autem Dóminus ad Móysen : Ascénde ad me in montem, et esto ibi : dabóque tibi tábulas lapídeas, et legem, ac mandáta quæ scripsi : ut dóceas eos.

13. Surrexérunt Móyses et Jósue miníster ejus : ascendénsque Móyses in montem Dei,

14. senióribus ait : Expectáte hic donec revertámur ad vos. Habétis Áaron et Hur vobíscum : si quid natum fúerit quæstiónis, referétis ad eos.

15. Cumque ascendísset Móyses, opéruit nubes montem,

16. et habitávit glória Dómini super Sínai, tegens illum nube sex diébus : séptimo autem die vocávit eum de médio calíginis.

17. Erat autem spécies glóriæ Dómini quasi ignis ardens super vérticem montis in conspéctu filiórum Israël.

18. Ingressúsque Móyses médium nébulæ, ascéndit in montem : et fuit ibi quadragínta diébus, et quadragínta nóctibus.

