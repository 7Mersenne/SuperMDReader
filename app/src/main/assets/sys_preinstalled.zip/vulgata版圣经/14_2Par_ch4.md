# Liber Secundus Paralipomenon - Caput 4

1. Fecit quoque altáre ǽneum vigínti cubitórum longitúdinis, et vigínti cubitórum latitúdinis, et decem cubitórum altitúdinis.

2. Mare étiam fúsile decem cúbitis a lábio usque ad lábium, rotúndum per circúitum : quinque cúbitos habébat altitúdinis, et funículus trigínta cubitórum ambiébat gyrum ejus.

3. Similitúdo quoque boum erat subter illud, et decem cúbitis quædam extrínsecus cælatúræ, quasi duóbus vérsibus alvum maris circuíbant. Boves autem erant fúsiles :

4. et ipsum mare super duódecim boves impósitum erat, quorum tres respiciébant ad aquilónem, et álii tres ad occidéntem : porro tres álii merídiem, et tres qui réliqui erant, oriéntem, habéntes mare superpósitum : posterióra autem boum erant intrínsecus sub mari.

5. Porro vástitas ejus habébat mensúram palmi, et lábium illíus erat quasi lábium cálicis, vel repándi lílii : capiebátque tria míllia metrétas.

6. Fecit quoque conchas decem : et pósuit quinque a dextris, et quinque a sinístris, ut lavárent in eis ómnia quæ in holocáustum oblatúri erant : porro in mari sacerdótes lavabántur.

7. Fecit autem et candelábra áurea decem secúndum spéciem qua jussa erant fíeri : et pósuit ea in templo, quinque a dextris, et quinque a sinístris.

8. Necnon et mensas decem : et pósuit eas in templo, quinque a dextris, et quinque a sinístris : phíalas quoque áureas centum.

9. Fecit étiam átrium sacerdótum, et basílicam grandem : et óstia in basílica, quæ texit ære.

10. Porro mare pósuit in látere dextro contra oriéntem ad merídiem.

11. Fecit autem Hiram lebétes, et créagras, et phíalas : et complévit omne opus regis in domo Dei :

12. hoc est, colúmnas duas, et epistýlia, et cápita, et quasi quædam retiácula, quæ cápita tégerent super epistýlia.

13. Malogranáta quoque quadringénta, et retiácula duo ita ut bini órdines malogranatórum síngulis retiáculis jungeréntur, quæ protégerent epistýlia, et cápita columnárum.

14. Bases étiam fecit, et conchas, quas superpósuit básibus :

15. mare unum, boves quoque duódecim sub mari,

16. et lebétes, et créagras, et phíalas. Ómnia vasa fecit Salomóni Hiram pater ejus in domo Dómini ex ære mundíssimo.

17. In regióne Jordánis, fudit ea rex in argillósa terra inter Sochot et Saredátha.

18. Erat autem multitúdo vasórum innumerábilis, ita ut ignorarétur pondus æris.

19. Fecítque Sálomon ómnia vasa domus Dei, et altáre áureum, et mensas, et super eas panes propositiónis :

20. candelábra quoque cum lucérnis suis ut lucérent ante oráculum juxta ritum ex auro puríssimo :

21. et floréntia quædam, et lucérnas, et fórcipes áureos : ómnia de auro mundíssimo facta sunt.

22. Thymiatéria quoque, et thuríbula, et phíalas, et mortaríola ex auro puríssimo. Et óstia cælávit templi interióris, id est, in Sancta sanctórum : et óstia templi forínsecus áurea. Sicque complétum est omne opus quod fecit Sálomon in domo Dómini.

