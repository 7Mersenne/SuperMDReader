# Liber Judith - Caput 2

1. Anno tertiodécimo Nabuchodonósor regis, vigésima et secúnda die mensis primi, factum est verbum in domo Nabuchodonósor regis Assyriórum ut defénderet se.

2. Vocavítque omnes majóres natu, omnésque duces et bellatóres suos, et hábuit cum eis mystérium consílii sui :

3. dixítque cogitatiónem suam in eo esse, ut omnem terram suo subjugáret império.

4. Quod dictum cum placuísset ómnibus, vocávit Nabuchodonósor rex Holoférnem príncipem milítiæ suæ,

5. et dixit ei : Egrédere advérsus omne regnum occidéntis, et contra eos præcípue, qui contempsérunt impérium meum.

6. Non parcet óculus tuus ulli regno, omnémque urbem munítam subjugábis mihi.

7. Tunc Holoférnes vocávit duces et magistrátus virtútis Assyriórum, et dinumerávit viros in expeditiónem sicut præcépit ei rex, centum vigínti míllia péditum pugnatórum, et équitum sagittariórum duódecim míllia.

8. Omnémque expeditiónem suam fecit præíre in multitúdine innumerabílium camelórum, cum his quæ exercítibus suffícerent copióse, boum quoque arménta, gregésque óvium, quorum non erat númerus.

9. Fruméntum ex omni Sýria in transítu suo parári constítuit.

10. Aurum vero et argéntum de domo regis assúmpsit multum nimis.

11. Et proféctus est ipse, et omnis exércitus cum quadrígis, et equítibus, et sagittáriis : qui cooperuérunt fáciem terræ sicut locústæ.

12. Cumque pertransísset fines Assyriórum, venit ad magnos montes Ange, qui sunt a sinístro Cilíciæ : ascendítque ómnia castélla eórum, et obtínuit omnem munitiónem.

13. Éffregit autem civitátem opinatíssimam Melóthi, prædavítque omnes fílios Tharsis et fílios Ísmaël qui erant contra fáciem desérti, et ad austrum terræ Cellon.

14. Et transívit Euphráten, et venit in Mesopotámiam : et fregit omnes civitátes excélsas quæ erant ibi, a torrénte Mambre úsquequo perveniátur ad mare :

15. et occupávit términos ejus, a Cilícia usque ad fines Japheth qui sunt ad austrum.

16. Abduxítque omnes fílios Mádian, et prædávit omnem locupletatiónem eórum, omnésque resisténtes sibi óccidit in ore gládii.

17. Et post hæc descéndit in campos Damásci in diébus messis, et succéndit ómnia sata, omnésque árbores, et víneas fecit íncidi :

18. et cécidit timor illíus super omnes inhabitántes terram.

