# Liber Esther - Caput 9

1. Ígitur duodécimi mensis, quem Adar vocári ante jam díximus, tertiadécima die, quando cunctis Judǽis interféctio parabátur, et hostes eórum inhiábant sánguini, versa vice Judǽi superióres esse cœpérunt, et se de adversáriis vindicáre.

2. Congregatíque sunt per síngulas civitátes, óppida, et loca, ut exténderent manum contra inimícos, et persecutóres suos. Nullúsque ausus est resístere, eo quod omnes pópulos magnitúdinis eórum formído penetrárat.

3. Nam et provinciárum júdices, et duces, et procuratóres, omnísque dígnitas quæ síngulis locis ac opéribus prǽerat, extollébant Judǽos timóre Mardochǽi,

4. quem príncipem esse palátii, et plúrimum posse cognóverant : fama quoque nóminis ejus crescébat quotídie, et per cunctórum ora volitábat.

5. Ítaque percussérunt Judǽi inimícos suos plaga magna, et occidérunt eos, reddéntes eis quod sibi paráverant fácere :

6. in tantum ut étiam in Susan quingéntos viros interfícerent, extra decem fílios Aman Agágitæ hostis Judæórum : quorum ista sunt nómina :

7. Pharsandátha, et Delphon, et Esphátha,

8. et Phorátha, et Adália, et Aridátha,

9. et Phermésta, et Arísai, et Arídai, et Jezátha.

10. Quos cum occidíssent, prædas de substántiis eórum tángere noluérunt.

11. Statímque númerus eórum, qui occísi erant in Susan, ad regem relátus est.

12. Qui dixit regínæ : In urbe Susan interfecérunt Judǽi quingéntos viros, et álios decem fílios Aman : quantam putas eos exercére cædem in univérsis provínciis ? quid ultra póstulas, et quid vis ut fíeri júbeam ?

13. Cui illa respóndit : Si regi placet, detur potéstas Judǽis, ut sicut fecérunt hódie in Susan, sic et cras fáciant, et decem fílii Aman in patíbulis suspendántur.

14. Præcepítque rex ut ita fíeret. Statímque in Susan pepéndit edíctum, et decem fílii Aman suspénsi sunt.

15. Congregátis Judǽis quartadécima die mensis Adar, interfécti sunt in Susan trecénti viri : nec eórum ab illis dirépta substántia est.

16. Sed et per omnes províncias quæ ditióni regis subjacébant, pro animábus suis stetérunt Judǽi, interféctis hóstibus ac persecutóribus suis : in tantum ut septuagínta quinque míllia occisórum impleréntur, et nullus de substántiis eórum quidquam contíngeret.

17. Dies autem tertiusdécimus mensis Adar primus apud omnes interfectiónis fuit, et quartadécima die cǽdere desiérunt. Quem constituérunt esse solémnem, ut in eo omni témpore deínceps vacárent épulis, gáudio, atque convíviis.

18. At hi, qui in urbe Susan cædem exercúerant, tertiodécimo et quartodécimo die ejúsdem mensis in cæde versáti sunt : quintodécimo autem die percútere desiérunt. Et idcírco eúmdem diem constituérunt solémnem epulárum atque lætítiæ.

19. Hi vero Judǽi, qui in óppidis non murátis ac villis morabántur, quartumdécimum diem mensis Adar conviviórum et gáudii decrevérunt, ita ut exúltent in eo, et mittant sibi mútuo partes epulárum et cibórum.

20. Scripsit ítaque Mardochǽus ómnia hæc, et lítteris comprehénsa misit ad Judǽos qui in ómnibus regis provínciis morabántur, tam in vicíno pósitis, quam procul,

21. ut quartamdécimam et quintamdécimam diem mensis Adar pro festis suscíperent, et reverténte semper anno solémni celebrárent honóre :

22. quia in ipsis diébus se ulti sunt Judǽi de inimícis suis, et luctus atque tristítia in hilaritátem gaudiúmque convérsa sunt, esséntque dies isti epulárum atque lætítiæ, et mítterent sibi ínvicem cibórum partes, et paupéribus munúscula largiréntur.

23. Susceperúntque Judǽi in solémnem ritum cuncta quæ eo témpore fácere cóeperant, et quæ Mardochǽus lítteris faciénda mandáverat.

24. Aman enim, fílius Amadáthi stirpis Agag, hostis et adversárius Judæórum, cogitávit contra eos malum, ut occíderet illos atque deléret : et misit phur, quod nostra lingua vértitur in sortem.

25. Et póstea ingréssa est Esther ad regem, óbsecrans ut conátus ejus lítteris regis írriti fíerent, et malum quod contra Judǽos cogitáverat, reverterétur in caput ejus. Dénique et ipsum et fílios ejus affixérunt cruci,

26. atque ex illo témpore dies isti appelláti sunt phurim, id est sórtium : eo quod phur, id est sors, in urnam missa fúerit. Et cuncta quæ gesta sunt, epístolæ, id est, libri hujus volúmine, continéntur :

27. quæque sustinuérunt, et quæ deínceps immutáta sunt, suscepérunt Judǽi super se et semen suum, et super cunctos qui religióni eórum voluérunt copulári, ut nulli líceat duos hos dies absque solemnitáte transígere, quos scriptúra testátur, et certa éxpetunt témpora, annis sibi júgiter succedéntibus.

28. Isti sunt dies, quos nulla umquam delébit oblívio, et per síngulas generatiónes cunctæ in toto orbe provínciæ celebrábunt : nec est ulla cívitas, in qua dies phurim, id est sórtium, non observéntur a Judǽis, et ab eórum progénie, quæ his cæremóniis obligáta est.

29. Scripserúntque Esther regína fília Abíhail, et Mardochǽus Judǽus, étiam secúndam epístolam, ut omni stúdio dies ista solémnis sancirétur in pósterum :

30. et misérunt ad omnes Judǽos qui in centum vigínti septem provínciis regis Assúeri versabántur, ut habérent pacem, et suscíperent veritátem,

31. observántes dies sórtium, et suo témpore cum gáudio celebrárent : sicut constitúerant Mardochǽus et Esther, et illi observánda suscepérunt a se, et a sémine suo, jejúnia, et clamóres, et sórtium dies,

32. et ómnia quæ libri hujus, qui vocátur Esther, história continéntur.

