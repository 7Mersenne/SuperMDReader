# Liber Exodus - Caput 19

1. Mense tértio egressiónis Israël de terra Ægýpti, in die hac venérunt in solitúdinem Sínai.

2. Nam profécti de Ráphidim, et perveniéntes usque in desértum Sínai, castrametáti sunt in eódem loco, ibíque Israël fixit tentória e regióne montis.

3. Móyses autem ascéndit ad Deum : vocavítque eum Dóminus de monte, et ait : Hæc dices dómui Jacob, et annuntiábis fíliis Israël :

4. Vos ipsi vidístis quæ fécerim Ægýptiis, quómodo portáverim vos super alas aquilárum, et assúmpserim mihi.

5. Si ergo audiéritis vocem meam, et custodiéritis pactum meum, éritis mihi in pecúlium de cunctis pópulis : mea est enim omnis terra :

6. et vos éritis mihi in regnum sacerdotále, et gens sancta. Hæc sunt verba quæ lóqueris ad fílios Israël.

7. Venit Móyses : et convocátis majóribus natu pópuli, expósuit omnes sermónes quos mandáverat Dóminus.

8. Respondítque omnis pópulus simul : Cuncta quæ locútus est Dóminus, faciémus. Cumque retulísset Móyses verba pópuli ad Dóminum,

9. ait ei Dóminus : Jam nunc véniam ad te in calígine nubis, ut áudiat me pópulus loquéntem ad te, et credat tibi in perpétuum. Nuntiávit ergo Móyses verba pópuli ad Dóminum.

10. Qui dixit ei : Vade ad pópulum, et sanctífica illos hódie, et cras, lavéntque vestiménta sua.

11. Et sint paráti in diem tértium : in die enim tértia descéndet Dóminus coram omni plebe super montem Sínai.

12. Constituésque términos pópulo per circúitum, et dices ad eos : Cavéte ne ascendátis in montem, nec tangátis fines illíus : omnis qui tetígerit montem, morte moriétur.

13. Manus non tanget eum, sed lapídibus opprimétur, aut confodiétur jáculis : sive juméntum fúerit, sive homo, non vivet : cum cóeperit clángere búccina, tunc ascéndant in montem.

14. Descendítque Móyses de monte ad pópulum, et sanctificávit eum. Cumque lavíssent vestiménta sua,

15. ait ad eos : Estóte paráti in diem tértium, et ne appropinquétis uxóribus vestris.

16. Jamque advénerat tértius dies, et mane inclarúerat : et ecce cœpérunt audíri tonítrua, ac micáre fúlgura, et nubes densíssima operíre montem, clangórque búccinæ veheméntius perstrepébat : et tímuit pópulus qui erat in castris.

17. Cumque eduxísset eos Móyses in occúrsum Dei de loco castrórum, stetérunt ad radíces montis.

18. Totus autem mons Sínai fumábat, eo quod descendísset Dóminus super eum in igne : et ascénderet fumus ex eo quasi de fornáce, erátque omnis mons terríbilis.

19. Et sónitus búccinæ paulátim crescébat in majus, et prolíxius tendebátur : Móyses loquebátur, et Deus respondébat ei.

20. Descendítque Dóminus super montem Sínai in ipso montis vértice, et vocávit Móysen in cacúmen ejus. Quo cum ascendísset,

21. dixit ad eum : Descénde, et contestáre pópulum : ne forte velit transcéndere términos ad vidéndum Dóminum, et péreat ex eis plúrima multitúdo.

22. Sacerdótes quoque qui accédunt ad Dóminum, sanctificéntur, ne percútiat eos.

23. Dixítque Móyses ad Dóminum : Non póterit vulgus ascéndere in montem Sínai : tu enim testificátus es, et jussísti, dicens : Pone términos circa montem, et sanctífica illum.

24. Cui ait Dóminus : Vade, descénde : ascendésque tu, et Áaron tecum : sacerdótes autem et pópulus ne tránseant términos, nec ascéndant ad Dóminum, ne forte interfíciat illos.

25. Descendítque Móyses ad pópulum, et ómnia narrávit eis.

