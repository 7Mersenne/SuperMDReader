# Liber Genesis - Caput 5

1. Hic est liber generatiónis Adam. In die qua creávit Deus hóminem, ad similitúdinem Dei fecit illum.

2. Másculum et féminam creávit eos, et benedíxit illis : et vocávit nomen eórum Adam, in die quo creáti sunt.

3. Vixit autem Adam centum trigínta annis : et génuit ad imáginem et similitúdinem suam, vocavítque nomen ejus Seth.

4. Et facti sunt dies Adam, postquam génuit Seth, octingénti anni : genuítque fílios et fílias.

5. Et factum est omne tempus quod vixit Adam, anni nongénti trigínta, et mórtuus est.

6. Vixit quoque Seth centum quinque annis, et génuit Enos.

7. Vixítque Seth, postquam génuit Enos, octingéntis septem annis, genuítque fílios et fílias.

8. Et facti sunt omnes dies Seth nongentórum duódecim annórum, et mórtuus est.

9. Vixit vero Enos nonagínta annis, et génuit Cáinan.

10. Post cujus ortum vixit octingéntis quíndecim annis, et génuit fílios et fílias.

11. Factíque sunt omnes dies Enos nongénti quinque anni, et mórtuus est.

12. Vixit quoque Cáinan septuagínta annis, et génuit Maláleel.

13. Et vixit Cáinan, postquam génuit Maláleel, octingéntis quadragínta annis, genuítque fílios et fílias.

14. Et facti sunt omnes dies Cáinan nongénti decem anni, et mórtuus est.

15. Vixit autem Maláleel sexagínta quinque annis, et génuit Jared.

16. Et vixit Maláleel, postquam génuit Jared, octingéntis trigínta annis, et génuit fílios et fílias.

17. Et facti sunt omnes dies Maláleel octingénti nonagínta quinque anni, et mórtuus est.

18. Vixítque Jared centum sexagínta duóbus annis, et génuit Henoch.

19. Et vixit Jared, postquam génuit Henoch, octingéntis annis, et génuit fílios et fílias.

20. Et facti sunt omnes dies Jared nongénti sexagínta duo anni, et mórtuus est.

21. Porro Henoch vixit sexagínta quinque annis, et génuit Mathusálam.

22. Et ambulávit Henoch cum Deo : et vixit, postquam génuit Mathusálam, trecéntis annis, et génuit fílios et fílias.

23. Et facti sunt omnes dies Henoch trecénti sexagínta quinque anni.

24. Ambulavítque cum Deo, et non appáruit : quia tulit eum Deus.

25. Vixit quoque Mathusála centum octogínta septem annis, et génuit Lamech.

26. Et vixit Mathusála, postquam génuit Lamech, septingéntis octogínta duóbus annis, et génuit fílios et fílias.

27. Et facti sunt omnes dies Mathusála nongénti sexagínta novem anni, et mórtuus est.

28. Vixit autem Lamech centum octogínta duóbus annis, et génuit fílium :

29. vocavítque nomen ejus Noë, dicens : Iste consolábitur nos ab opéribus et labóribus mánuum nostrárum in terra, cui maledíxit Dóminus.

30. Vixítque Lamech, postquam génuit Noë, quingéntis nonagínta quinque annis, et génuit fílios et fílias.

31. Et facti sunt omnes dies Lamech septingénti septuagínta septem anni, et mórtuus est. Noë vero cum quingentórum esset annórum, génuit Sem, Cham et Japheth.

