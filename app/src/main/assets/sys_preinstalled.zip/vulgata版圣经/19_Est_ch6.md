# Liber Esther - Caput 6

1. Noctem illam duxit rex insómnem, jussítque sibi afférri histórias et annáles priórum témporum. Quæ cum illo præsénte legeréntur,

2. ventum est ad illum locum ubi scriptum erat quómodo nuntiásset Mardochǽus insídias Bagáthan et Thares eunuchórum, regem Assúerum juguláre cupiéntium.

3. Quod cum audísset rex, ait : Quid pro hac fide honóris ac prǽmii Mardochǽus consecútus est ? Dixérunt ei servi illíus ac minístri : Nihil omníno mercédis accépit.

4. Statímque rex : Quis est, inquit, in átrio ? Aman quippe intérius átrium domus régiæ intráverat, ut suggéreret regi, et júberet Mardochǽum áffigi patíbulo, quod ei fúerat præparátum.

5. Respondérunt púeri : Aman stat in átrio. Dixítque rex : Ingrediátur.

6. Cumque esset ingréssus, ait illi : Quid debet fíeri viro, quem rex honoráre desíderat ? Cógitans autem in corde suo Aman, et réputans quod nullum álium rex, nisi se, vellet honoráre,

7. respóndit : Homo, quem rex honoráre cupit,

8. debet índui véstibus régiis, et impóni super equum, qui de sella regis est, et accípere régium diadéma super caput suum :

9. et primus de régiis princípibus ac tyránnis téneat equum ejus, et per platéam civitátis incédens clamet, et dicat : Sic honorábitur, quemcúmque volúerit rex honoráre.

10. Dixítque ei rex : Festína, et sumpta stola et equo, fac, ut locútus es, Mardochǽo Judǽo, qui sedet ante fores palátii. Cave ne quidquam de his, quæ locútus es, prætermíttas.

11. Tulit ítaque Aman stolam et equum, indutúmque Mardochǽum in platéa civitátis, et impósitum equo præcedébat, atque clamábat : Hoc honóre condígnus est, quemcúmque rex volúerit honoráre.

12. Reversúsque est Mardochǽus ad jánuam palátii : et Aman festinávit ire in domum suam, lugens et opérto cápite :

13. narravítque Zares uxóri suæ, et amícis, ómnia quæ eveníssent sibi. Cui respondérunt sapiéntes quos habébat in consílio, et uxor ejus : Si de sémine Judæórum est Mardochǽus, ante quem cádere cœpísti, non póteris ei resístere, sed cades in conspéctu ejus.

14. Adhuc illis loquéntibus, venérunt eunúchi regis, et cito eum ad convívium, quod regína paráverat, pérgere compulérunt.

