# Liber Genesis - Caput 32

1. Jacob quoque ábiit itínere quo cóeperat : fuerúntque ei óbviam ángeli Dei.

2. Quos cum vidísset, ait : Castra Dei sunt hæc : et appellávit nomen loci illíus Mahánaim, id est, Castra.

3. Misit autem et núntios ante se ad Ésau fratrem suum in terram Seir, in regiónem Edom :

4. præcepítque eis, dicens : Sic loquímini dómino meo Ésau : Hæc dicit frater tuus Jacob : Apud Laban peregrinátus sum, et fui usque in præséntem diem.

5. Hábeo boves, et ásinos, et oves, et servos, et ancíllas : mittóque nunc legatiónem ad dóminum meum, ut invéniam grátiam in conspéctu tuo.

6. Reversíque sunt núntii ad Jacob, dicéntes : Venímus ad Ésau fratrem tuum, et ecce próperat tibi in occúrsum cum quadringéntis viris.

7. Tímuit Jacob valde : et pertérritus divísit pópulum qui secum erat, greges quoque et oves, et boves, et cámelos, in duas turmas,

8. dicens : Si vénerit Ésau ad unam turmam, et percússerit eam, ália turma, quæ relícta est, salvábitur.

9. Dixítque Jacob : Deus patris mei Ábraham, et Deus patris mei Ísaac : Dómine qui dixísti mihi : Revertére in terram tuam, et in locum nativitátis tuæ, et benefáciam tibi :

10. minor sum cunctis miseratiónibus tuis, et veritáte tua quam explevísti servo tuo. In báculo meo transívi Jordánem istum : et nunc cum duábus turmis regrédior.

11. Érue me de manu fratris mei Ésau, quia valde eum tímeo : ne forte véniens percútiat matrem cum fíliis.

12. Tu locútus es quod benefáceres mihi, et dilatáres semen meum sicut arénam maris, quæ præ multitúdine numerári non potest.

13. Cumque dormísset ibi nocte illa, separávit de his quæ habébat, múnera Ésau fratri suo,

14. capras ducéntas, hircos vigínti, oves ducéntas, et aríetes vigínti,

15. cámelos fœtas cum pullis suis trigínta, vaccas quadragínta, et tauros vigínti, ásinas vigínti et pullos eárum decem.

16. Et misit per manus servórum suórum síngulos seórsum greges, dixítque púeris suis : Antecédite me, et sit spátium inter gregem et gregem.

17. Et præcépit prióri, dicens : Si óbvium habúeris fratrem meum Ésau, et interrogáverit te : Cujus es ? aut, Quo vadis ? aut, Cujus sunt ista quæ séqueris ?

18. respondébis : Servi tui Jacob, múnera misit dómino meo Ésau, ipse quoque post nos venit.

19. Simíliter dedit mandáta secúndo, et tértio, et cunctis qui sequebántur greges, dicens : Iísdem verbis loquímini ad Ésau cum invenéritis eum.

20. Et addétis : Ipse quoque servus tuus Jacob iter nostrum inséquitur. Dixit enim : Placábo illum munéribus quæ præcédunt, et póstea vidébo illum : fórsitan propitiábitur mihi.

21. Præcessérunt ítaque múnera ante eum, ipse vero mansit nocte illa in castris.

22. Cumque matúre surrexísset, tulit duas uxóres suas, et tótidem fámulas cum úndecim fíliis, et transívit vadum Jaboc.

23. Traductísque ómnibus quæ ad se pertinébant,

24. mansit solus : et ecce vir luctabátur cum eo usque mane.

25. Qui cum vidéret quod eum superáre non posset, tétigit nervum fémoris ejus, et statim emárcuit.

26. Dixítque ad eum : Dimítte me : jam enim ascéndit auróra. Respóndit : Non dimíttam te, nisi benedíxeris mihi.

27. Ait ergo : Quod nomen est tibi ? Respóndit : Jacob.

28. At ille : Nequáquam, inquit, Jacob appellábitur nomen tuum, sed Israël : quóniam si contra Deum fortis fuísti, quanto magis contra hómines prævalébis ?

29. Interrogávit eum Jacob : Dic mihi, quo appelláris nómine ? Respóndit : Cur quæris nomen meum ? Et benedíxit ei in eódem loco.

30. Vocavítque Jacob nomen loci illíus Phánuel, dicens : Vidi Deum fácie ad fáciem, et salva facta est ánima mea.

31. Ortúsque est ei statim sol, postquam transgréssus est Phánuel : ipse vero claudicábat pede.

32. Quam ob causam non cómedunt nervum fílii Israël, qui emárcuit in fémore Jacob, usque in præséntem diem : eo quod tetígerit nervum fémoris ejus, et obstupúerit.

