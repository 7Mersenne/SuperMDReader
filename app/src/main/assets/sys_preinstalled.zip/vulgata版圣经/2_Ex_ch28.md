# Liber Exodus - Caput 28

1. Ápplica quoque ad te Áaron fratrem tuum cum fíliis suis de médio filiórum Israël, ut sacerdótio fungántur mihi : Áaron, Nadab, et Abíu, Eleázar, et Ithámar.

2. Faciésque vestem sanctam Áaron fratri tuo in glóriam et decórem.

3. Et lóqueris cunctis sapiéntibus corde quos replévi spíritu prudéntiæ, ut fáciant vestes Áaron, in quibus sanctificátus minístret mihi.

4. Hæc autem erunt vestiménta quæ fáciet : rationále et superhumerále, túnicam et líneam strictam, cidárim et bálteum. Fácient vestiménta sancta fratri tuo Áaron et fíliis ejus, ut sacerdótio fungántur mihi.

5. Accipiéntque aurum, et hyacínthum, et púrpuram, coccúmque bis tinctum, et byssum.

6. Fácient autem superhumerále de auro et hyacíntho et púrpura, coccóque bis tincto, et bysso retórta, ópere polýmito.

7. Duas oras junctas habébit in utróque látere summitátum, ut in unum rédeant.

8. Ipsa quoque textúra et cuncta óperis variétas erit ex auro et hyacíntho, et púrpura, coccóque bis tincto, et bysso retórta.

9. Sumésque duos lápides onýchinos, et sculpes in eis nómina filiórum Israël :

10. sex nómina in lápide uno, et sex réliqua in áltero, juxta órdinem nativitátis eórum.

11. Ópere sculptóris et cælatúra gemmárii, sculpes eos nomínibus filiórum Israël, inclúsos auro atque circúmdatos :

12. et pones in utróque látere superhumerális, memoriále fíliis Israël. Portabítque Áaron nómina eórum coram Dómino super utrúmque húmerum, ob recordatiónem.

13. Fácies et úncinos ex auro,

14. et duas caténulas ex auro puríssimo sibi ínvicem cohæréntes, quas ínseres úncinis.

15. Rationále quoque judícii fácies ópere polýmito juxta textúram superhumerális, ex auro, hyacíntho, et púrpura, coccóque bis tincto, et bysso retórta.

16. Quadrángulum erit et duplex : mensúram palmi habébit tam in longitúdine quam in latitúdine.

17. Ponésque in eo quátuor órdines lápidum : in primo versu erit lapis sárdius, et topázius, et smarágdus :

18. in secúndo carbúnculus, sapphírus, et jaspis :

19. in tértio ligúrius, achátes, et amethýstus :

20. in quarto chrysólithus, onýchinus, et berýllus. Inclúsi auro erunt per órdines suos.

21. Habebúntque nómina filiórum Israël : duódecim nomínibus cælabúntur, sínguli lápides nomínibus singulórum per duódecim tribus.

22. Fácies in rationáli caténas sibi ínvicem cohæréntes ex auro puríssimo,

23. et duos ánnulos áureos, quos pones in utráque rationális summitáte :

24. catenásque áureas junges ánnulis, qui sunt in margínibus ejus,

25. et ipsárum catenárum extréma duóbus copulábis úncinis in utróque látere superhumerális quod rationále réspicit.

26. Fácies et duos ánnulos áureos, quos pones in summitátibus rationális, in oris, quæ e regióne sunt superhumerális, et posterióra ejus aspíciunt.

27. Necnon et álios duos ánnulos áureos, qui ponéndi sunt in utróque látere superhumerális deórsum, quod réspicit contra fáciem junctúræ inferióris, ut aptári possit cum superhumeráli,

28. et stringátur rationále ánnulis suis cum ánnulis superhumerális vitta hyacínthina, ut máneat junctúra fabrefácta, et a se ínvicem rationále et superhumerále néqueant separári.

29. Portabítque Áaron nómina filiórum Israël in rationáli judícii super pectus suum, quando ingrediétur Sanctuárium, memoriále coram Dómino in ætérnum.

30. Pones autem in rationáli judícii Doctrínam et Veritátem, quæ erunt in péctore Áaron, quando ingrediétur coram Dómino : et gestábit judícium filiórum Israël in péctore suo, in conspéctu Dómini semper.

31. Fácies et túnicam superhumerális totam hyacínthinam,

32. in cujus médio supra erit capítium, et ora per gyrum ejus téxtilis, sicut fíeri solet in extrémis véstium pártibus, ne fácile rumpátur.

33. Deórsum vero, ad pedes ejúsdem túnicæ, per circúitum, quasi mala púnica fácies, ex hyacíntho, et púrpura, et cocco bis tincto, mistis in médio tintinnábulis,

34. ita ut tintinnábulum sit áureum et malum púnicum : rursúmque tintinnábulum áliud áureum et malum púnicum.

35. Et vestiétur ea Áaron in offício ministérii, ut audiátur sónitus quando ingréditur et egréditur sanctuárium in conspéctu Dómini, et non moriátur.

36. Fácies et láminam de auro puríssimo, in qua sculpes ópere cælatóris, Sanctum Dómino.

37. Ligabísque eam vitta hyacínthina, et erit super tiáram,

38. ímminens fronti pontíficis. Portabítque Áaron iniquitátes eórum, quæ obtulérunt et sanctificavérunt fílii Israël, in cunctis munéribus et donáriis suis. Erit autem lámina semper in fronte ejus, ut placátus sit eis Dóminus.

39. Stringésque túnicam bysso, et tiáram býssinam fácies, et bálteum ópere plumárii.

40. Porro fíliis Áaron túnicas líneas parábis et bálteos ac tiáras in glóriam et decórem :

41. vestiésque his ómnibus Áaron fratrem tuum et fílios ejus cum eo. Et cunctórum consecrábis manus, sanctificabísque illos, ut sacerdótio fungántur mihi.

42. Fácies et feminália línea, ut opériant carnem turpitúdinis suæ, a rénibus usque ad fémora :

43. et uténtur eis Áaron et fílii ejus quando ingrediéntur tabernáculum testimónii, vel quando appropínquant ad altáre ut minístrent in sanctuário, ne iniquitátis rei moriántur. Legítimum sempitérnum erit Áaron, et sémini ejus post eum.

