# Liber Genesis - Caput 28

1. Vocávit ítaque Ísaac Jacob, et benedíxit eum, præcepítque ei dicens : Noli accípere cónjugem de génere Chánaan :

2. sed vade, et proficíscere in Mesopotámiam Sýriæ, ad domum Báthuel patris matris tuæ, et áccipe tibi inde uxórem de filiábus Laban avúnculi tui.

3. Deus autem omnípotens benedícat tibi, et créscere te fáciat, atque multíplicet, ut sis in turbas populórum.

4. Et det tibi benedictiónes Ábrahæ, et sémini tuo post te : ut possídeas terram peregrinatiónis tuæ, quam pollícitus est avo tuo.

5. Cumque dimisísset eum Ísaac, proféctus venit in Mesopotámiam Sýriæ ad Laban fílium Báthuel Syri, fratrem Rebéccæ matris suæ.

6. Videns autem Ésau quod benedixísset pater suus Jacob, et misísset eum in Mesopotámiam Sýriæ, ut inde uxórem dúceret ; et quod post benedictiónem præcepísset ei, dicens : Non accípies uxórem de filiábus Chánaan :

7. quodque obédiens Jacob paréntibus suis isset in Sýriam :

8. probans quoque quod non libénter aspíceret fílias Chánaan pater suus :

9. ivit ad Ismáëlem, et duxit uxórem absque iis, quas prius habébat, Máheleth fíliam Ísmaël fílii Ábraham, sorórem Nabaíoth.

10. Ígitur egréssus Jacob de Bersabée, pergébat Haran.

11. Cumque venísset ad quemdam locum, et vellet in eo requiéscere post solis occúbitum, tulit de lapídibus qui jacébant, et suppónens cápiti suo, dormívit in eódem loco.

12. Vidítque in somnis scalam stantem super terram, et cacúmen illíus tangens cælum : ángelos quoque Dei ascendéntes et descendéntes per eam,

13. et Dóminum inníxum scalæ dicéntem sibi : Ego sum Dóminus Deus Ábraham patris tui, et Deus Ísaac : terram, in qua dormis, tibi dabo et sémini tuo.

14. Erítque semen tuum quasi pulvis terræ : dilatáberis ad occidéntem, et oriéntem, et septentriónem, et merídiem : et benedicéntur in te et in sémine tuo cunctæ tribus terræ.

15. Et ero custos tuus quocúmque perréxeris, et redúcam te in terram hanc : nec dimíttam nisi complévero univérsa quæ dixi.

16. Cumque evigilásset Jacob de somno, ait : Vere Dóminus est in loco isto, et ego nesciébam.

17. Pavénsque, Quam terríbilis est, inquit, locus iste ! non est hic áliud nisi domus Dei, et porta cæli.

18. Surgens ergo Jacob mane, tulit lápidem quem supposúerat cápiti suo, et eréxit in títulum, fundens óleum désuper.

19. Appellavítque nomen urbis Bethel, quæ prius Luza vocabátur.

20. Vovit étiam votum, dicens : Si fúerit Deus mecum, et custodíerit me in via, per quam ego ámbulo, et déderit mihi panem ad vescéndum, et vestiméntum ad induéndum,

21. reversúsque fúero próspere ad domum patris mei : erit mihi Dóminus in Deum,

22. et lapis iste, quem eréxi in títulum, vocábitur Domus Dei : cunctorúmque quæ déderis mihi, décimas ófferam tibi.

