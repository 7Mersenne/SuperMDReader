# Liber Judith - Caput 15

1. Cumque omnis exércitus decollátum Holoférnem audísset, fugit mens et consílium ab eis, et solo tremóre et metu agitáti, fugæ præsídium sumunt,

2. ita ut nullus loquerétur cum próximo suo, sed inclináto cápite, relíctis ómnibus, evádere festinábant Hebrǽos, quos armátos super se veníre audiébant, fugiéntes per vias campórum et sémitas cóllium.

3. Vidéntes ítaque fílii Israël fugiéntes, secúti sunt illos. Descenderúntque clangéntes tubis, et ululántes post ipsos.

4. Et quóniam Assýrii non adunáti, in fugam ibant præcípites : fílii autem Israël uno ágmine persequéntes debilitábant omnes quos inveníre potuíssent.

5. Misit ítaque Ozías núntios per omnes civitátes et regiónes Israël.

6. Omnis ítaque régio, omnísque urbs eléctam juventútem armátam misit post eos, et persecúti sunt eos in ore gládii, quoúsque pervenírent ad extremitátem fínium suórum.

7. Relíqui autem qui erant in Bethúlia, ingréssi sunt castra Assyriórum, et prædam quam fugiéntes Assýrii relíquerant, abstulérunt, et onustáti sunt valde.

8. Hi vero qui victóres revérsi sunt ad Bethúliam, ómnia quæ erant illórum attulérunt secum, ita ut non esset númerus in pecóribus et juméntis et univérsis mobílibus eórum, ut a mínimo usque ad máximum omnes dívites fíerent de prædatiónibus eórum.

9. Joácim autem summus póntifex de Jerúsalem venit in Bethúliam cum univérsis presbýteris suis ut vidéret Judith.

10. Quæ cum exísset ad illum, benedixérunt eam omnes una voce, dicéntes : Tu glória Jerúsalem ; tu lætítia Israël ; tu honorificéntia pópuli nostri :

11. quia fecísti viríliter, et confortátum est cor tuum, eo quod castitátem amáveris, et post virum tuum, álterum nescíeris : ídeo et manus Dómini confortávit te, et ídeo eris benedícta in ætérnum.

12. Et dixit omnis pópulus : Fiat, fiat.

13. Per dies autem trigínta, vix collécta sunt spólia Assyriórum a pópulo Israël.

14. Porro autem univérsa quæ Holoférnis peculiária fuísse probáta sunt, dedérunt Judith in auro, et argénto, et véstibus, et gemmis, et omni supelléctili : et trádita sunt ómnia illi a pópulo.

15. Et omnes pópuli gaudébant cum muliéribus, et virgínibus, et juvénibus, in órganis et cítharis.

