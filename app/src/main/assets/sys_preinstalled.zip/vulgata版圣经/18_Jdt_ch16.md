# Liber Judith - Caput 16

1. Tunc cantávit cánticum hoc Dómino Judith, dicens :

2. Incípite Dómino in týmpanis ; cantáte Dómino in cýmbalis ; modulámini illi psalmum novum : exaltáte, et invocáte nomen ejus.

3. Dóminus cónterens bella, Dóminus nomen est illi.

4. Qui pósuit castra sua in médio pópuli sui, ut eríperet nos de manu ómnium inimicórum nostrórum.

5. Venit Assur ex móntibus ab aquilóne in multitúdine fortitúdinis suæ : cujus multitúdo obturávit torréntes, et equi eórum cooperuérunt valles.

6. Dixit se incensúrum fines meos, et júvenes meos occisúrum gládio ; infántes meos dare in prædam, et vírgines in captivitátem.

7. Dóminus autem omnípotens nócuit eum, et trádidit eum in manus féminæ, et confódit eum.

8. Non enim cécidit potens eórum a juvénibus, nec fílii Titan percussérunt eum, nec excélsi gigántes opposuérunt se illi : sed Judith fília Merári in spécie faciéi suæ dissólvit eum.

9. Éxuit enim se vestiménto viduitátis, et índuit se vestiménto lætítiæ in exultatióne filiórum Israël.

10. Unxit fáciem suam unguénto, et colligávit cincínnos suos mitra ; accépit stolam novam ad decipiéndum illum.

11. Sandália ejus rapuérunt óculos ejus ; pulchritúdo ejus captívam fecit ánimam ejus : amputávit pugióne cervícem ejus.

12. Horruérunt Persæ constántiam ejus, et Medi audáciam ejus.

13. Tunc ululavérunt castra Assyriórum, quando apparuérunt húmiles mei, arescéntes in siti.

14. Fílii puellárum compunxérunt eos, et sicut púeros fugiéntes occidérunt eos : periérunt in prǽlio a fácie Dómini Dei mei.

15. Hymnum cantémus Dómino ; hymnum novum cantémus Deo nostro.

16. Adonái Dómine, magnus es tu, et præclárus in virtúte tua : et quem superáre nemo potest.

17. Tibi sérviat omnis creatúra tua, quia dixísti, et facta sunt ; misísti spíritum tuum, et creáta sunt : et non est qui resístat voci tuæ.

18. Montes a fundaméntis movebúntur cum aquis ; petræ, sicut cera, liquéscent ante fáciem tuam.

19. Qui autem timent te, magni erunt apud te per ómnia.

20. Væ genti insurgénti super genus meum : Dóminus enim omnípotens vindicábit in eis ; in die judícii visitábit illos.

21. Dabit enim ignem et vermes in carnes eórum, ut urántur et séntiant usque in sempitérnum.

22. Et factum est post hæc, omnis pópulus post victóriam venit in Jerúsalem adoráre Dóminum : et mox ut purificáti sunt, obtulérunt omnes holocáusta, et vota, et repromissiónes suas.

23. Porro Judith univérsa vasa béllica Holoférnis, quæ dedit illi pópulus, et conópeum quod ipsa sustúlerat de cubíli ipsíus, óbtulit in anáthema obliviónis.

24. Erat autem pópulus jucúndus secúndum fáciem sanctórum : et per tres menses gáudium hujus victóriæ celebrátum est cum Judith.

25. Post dies autem illos, unusquísque rédiit in domum suam : et Judith magna facta est in Bethúlia, et præclárior erat univérsæ terræ Israël.

26. Erat enim virtúti cástitas adjúncta, ita ut non cognósceret virum ómnibus diébus vitæ suæ, ex quo defúnctus est Manásses vir ejus.

27. Erat autem, diébus festis, procédens cum magna glória.

28. Mansit autem in domo viri sui annos centum quinque, et dimísit abram suam líberam : et defúncta est ac sepúlta cum viro suo in Bethúlia.

29. Luxítque illam omnis pópulus diébus septem.

30. In omni autem spátio vitæ ejus non fuit qui perturbáret Israël, et post mortem ejus annis multis.

31. Dies autem victóriæ hujus festivitátis ab Hebrǽis in número sanctórum diérum accípitur, et cólitur a Judǽis ex illo témpore usque in præséntem diem.

