# Liber Primus Paralipomenon - Caput 2

1. Fílii autem Israël : Ruben, Símeon, Levi, Juda, Issáchar, et Zábulon,

2. Dan, Joseph, Bénjamin, Nephtháli, Gad, et Aser.

3. Fílii Juda : Her, Onan, et Sela : hi tres nati sunt ei de fília Sue Chananítide. Fuit autem Her primogénitus Juda malus coram Dómino, et óccidit eum.

4. Thamar autem nurus ejus péperit ei Phares et Zara : omnes ergo fílii Juda, quinque.

5. Fílii autem Phares : Hesron et Hamul.

6. Fílii quoque Zaræ : Zamri, et Ethan, et Eman, Chalchal quoque, et Dara, simul quinque.

7. Fílii Charmi : Achar, qui turbávit Israël, et peccávit in furto anathemátis.

8. Fílii Ethan : Azarías.

9. Fílii autem Hesron qui nati sunt ei : Jerámeel, et Ram, et Calúbi.

10. Porro Ram génuit Amínadab. Amínadab autem génuit Nahásson, príncipem filiórum Juda.

11. Nahásson quoque génuit Salma, de quo ortus est Booz.

12. Booz vero génuit Obed, qui et ipse génuit Ísai.

13. Ísai autem génuit primogénitum Elíab, secúndum Abinádab, tértium Símmaa,

14. quartum Nathánaël, quintum Ráddai,

15. sextum Asom, séptimum David.

16. Quorum soróres fuérunt Sárvia et Abígail. Fílii Sárviæ : Abísai, Joab, et Ásaël, tres.

17. Abígail autem génuit Amása, cujus pater fuit Jether Ismahelítes.

18. Caleb vero fílius Hesron accépit uxórem nómine Azúba, de qua génuit Jérioth : fuerúntque fílii ejus Jaser, et Sobab, et Ardon.

19. Cumque mórtua fuísset Azúba, accépit uxórem Caleb Ephrátha, quæ péperit ei Hur.

20. Porro Hur génuit Uri, et Uri génuit Bezéleel.

21. Post hæc ingréssus est Hesron ad fíliam Machir patris Gálaad, et accépit eam cum esset annórum sexagínta : quæ péperit ei Segub.

22. Sed et Segub génuit Jair, et possédit vigínti tres civitátes in terra Gálaad.

23. Cepítque Gessur et Aram óppida Jair, et Canath, et vículos ejus sexagínta civitátum : omnes isti fílii Machir patris Gálaad.

24. Cum autem mórtuus esset Hesron, ingréssus est Caleb ad Ephrátha. Hábuit quoque Hesron uxórem Abía, quæ péperit ei Assur patrem Thécuæ.

25. Nati sunt autem fílii Jerámeel primogéniti Hesron, Ram primogénitus ejus, et Buna, et Aram, et Asom, et Áchia.

26. Duxit quoque uxórem álteram Jerámeel, nómine Atára, quæ fuit mater Onam.

27. Sed et fílii Ram primogéniti Jerámeel fuérunt Moos, Jamin, et Achar.

28. Onam autem hábuit fílios Sémei et Jada. Fílii autem Sémei : Nadab et Abísur.

29. Nomen vero uxóris Abísur, Abíhail, quæ péperit ei Ahóbban et Molid.

30. Fílii autem Nadab fuérunt Saled et Ápphaim. Mórtuus est autem Saled absque líberis.

31. Fílius vero Ápphaim, Jesi : qui Jesi génuit Sesan. Porro Sesan génuit Ohólai.

32. Fílii autem Jada fratris Sémei : Jether, et Jónathan. Sed et Jether mórtuus est absque líberis.

33. Porro Jónathan génuit Phaleth, et Ziza. Isti fuérunt fílii Jerámeel.

34. Sesan autem non hábuit fílios, sed fílias : et servum ægýptium nómine Jéraa.

35. Dedítque ei fíliam suam uxórem : quæ péperit ei Éthei.

36. Éthei autem génuit Nathan, et Nathan génuit Zabad.

37. Zabad quoque génuit Ophlal, et Ophlal génuit Obed.

38. Obed génuit Jehu, Jehu génuit Azaríam,

39. Azarías génuit Helles, et Helles génuit Elása.

40. Elása génuit Sisámoi, Sisámoi génuit Sellum,

41. Sellum génuit Icámiam, Icámia autem génuit Elisáma.

42. Fílii autem Caleb fratris Jerámeel : Mesa primogénitus ejus ; ipse est pater Ziph : et fílii Marésa patris Hebron.

43. Porro fílii Hebron, Core, et Táphua, et Recem, et Samma.

44. Samma autem génuit Raham, patrem Jércaam, et Recem génuit Sámmai.

45. Fílius Sámmai, Maon : et Maon pater Bethsur.

46. Epha autem concubína Caleb péperit Haran, et Mosa, et Gezez. Porro Haran génuit Gezez.

47. Fílii autem Jaháddai, Regom, et Jóathan, et Gesan, et Phalet, et Epha, et Saaph.

48. Concubína Caleb Maácha, péperit Saber, et Tharána.

49. Génuit autem Saaph pater Mádmena Sue, patrem Máchbena et patrem Gábaa. Fília vero Caleb fuit Achsa.

50. Hi erant fílii Caleb, fílii Hur primogéniti Ephrátha, Sobal pater Cariathiárim.

51. Salma pater Béthlehem, Hariph pater Bethgáder.

52. Fuérunt autem fílii Sobal patris Cariathiárim, qui vidébat dimídium requietiónum.

53. Et de cognatióne Cariathiárim, Jéthrei, et Aphúthei, et Semáthei, et Masérei. Ex his egréssi sunt Saráitæ, et Esthaólitæ.

54. Fílii Salma, Béthlehem, et Netopháthi, corónæ domus Joab, et dimídium requietiónis Sárai :

55. cognatiónes quoque scribárum habitántium in Jabes, canéntes atque resonántes, et in tabernáculis commorántes. Hi sunt Cinǽi, qui venérunt de Calóre patris domus Rechab.

