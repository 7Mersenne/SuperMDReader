# Liber Genesis - Caput 11

1. Erat autem terra lábii uníus, et sermónum eorúmdem.

2. Cumque proficisceréntur de oriénte, invenérunt campum in terra Sénnaar, et habitavérunt in eo.

3. Dixítque alter ad próximum suum : Veníte, faciámus láteres, et coquámus eos igni. Habuerúntque láteres pro saxis, et bitúmen pro cæménto :

4. et dixérunt : Veníte, faciámus nobis civitátem et turrim, cujus culmen pertíngat ad cælum : et celebrémus nomen nostrum ántequam dividámur in univérsas terras.

5. Descéndit autem Dóminus ut vidéret civitátem et turrim, quam ædificábant fílii Adam,

6. et dixit : Ecce, unus est pópulus, et unum lábium ómnibus : cœperúntque hoc fácere, nec desístent a cogitatiónibus suis, donec eas ópere cómpleant.

7. Veníte ígitur, descendámus, et confundámus ibi linguam eórum, ut non áudiat unusquísque vocem próximi sui.

8. Atque ita divísit eos Dóminus ex illo loco in univérsas terras, et cessavérunt ædificáre civitátem.

9. Et idcírco vocátum est nomen ejus Babel, quia ibi confúsum est lábium univérsæ terræ : et inde dispérsit eos Dóminus super fáciem cunctárum regiónum.

10. Hæ sunt generatiónes Sem : Sem erat centum annórum quando génuit Arpháxad, biénnio post dilúvium.

11. Vixítque Sem, postquam génuit Arpháxad, quingéntis annis : et génuit fílios et fílias.

12. Porro Arpháxad vixit trigínta quinque annis, et génuit Sale.

13. Vixítque Arpháxad, postquam génuit Sale, trecéntis tribus annis : et génuit fílios et fílias.

14. Sale quoque vixit trigínta annis, et génuit Heber.

15. Vixítque Sale, postquam génuit Heber, quadringéntis tribus annis : et génuit fílios et fílias.

16. Vixit autem Heber trigínta quátuor annis, et génuit Phaleg.

17. Et vixit Heber postquam génuit Phaleg, quadringéntis trigínta annis : et génuit fílios et fílias.

18. Vixit quoque Phaleg trigínta annis, et génuit Reu.

19. Vixítque Phaleg, postquam génuit Reu, ducéntis novem annis : et génuit fílios et fílias.

20. Vixit autem Reu trigínta duóbus annis, et génuit Sarug.

21. Vixit quoque Reu, postquam génuit Sarug, ducéntis septem annis : et génuit fílios et fílias.

22. Vixit vero Sarug trigínta annis, et génuit Nachor.

23. Vixítque Sarug, postquam génuit Nachor, ducéntis annis : et génuit fílios et fílias.

24. Vixit autem Nachor vigínti novem annis, et génuit Thare.

25. Vixítque Nachor, postquam génuit Thare, centum decem et novem annis : et génuit fílios et fílias.

26. Vixítque Thare septuagínta annis, et génuit Abram, et Nachor, et Aran.

27. Hæ sunt autem generatiónes Thare : Thare génuit Abram, Nachor et Aran. Porro Aran génuit Lot.

28. Mortuúsque est Aran ante Thare patrem suum, in terra nativitátis suæ, in Ur Chaldæórum.

29. Duxérunt autem Abram et Nachor uxóres : nomen uxóris Abram, Sárai : et nomen uxóris Nachor, Melcha fília Aran, patris Melchæ, et patris Jeschæ.

30. Erat autem Sárai stérilis, nec habébat líberos.

31. Tulit ítaque Thare Abram fílium suum, et Lot fílium Aran, fílium fílii sui, et Sárai nurum suam, uxórem Abram fílii sui, et edúxit eos de Ur Chaldæórum, ut irent in terram Chánaan : venerúntque usque Haran, et habitavérunt ibi.

32. Et facti sunt dies Thare ducentórum quinque annórum, et mórtuus est in Haran.

