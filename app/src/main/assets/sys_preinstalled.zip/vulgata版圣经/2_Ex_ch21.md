# Liber Exodus - Caput 21

1. Hæc sunt judícia quæ propónes eis.

2. Si émeris servum hebrǽum, sex annis sérviet tibi : in séptimo egrediétur liber gratis.

3. Cum quali veste intráverit, cum tali éxeat : si habens uxórem, et uxor egrediétur simul.

4. Sin autem dóminus déderit illi uxórem, et pepérerit fílios et fílias : múlier et líberi ejus erunt dómini sui, ipse vero exíbit cum vestítu suo.

5. Quod si díxerit servus : Díligo dóminum meum et uxórem ac líberos ; non egrédiar liber :

6. ófferet eum dóminus diis, et applicábitur ad óstium et postes, perforabítque aurem ejus súbula : et erit ei servus in sǽculum.

7. Si quis vendíderit fíliam suam in fámulam, non egrediétur sicut ancíllæ exíre consuevérunt.

8. Si displicúerit óculis dómini sui cui trádita fúerat, dimíttet eam : pópulo autem aliéno vendéndi non habébit potestátem, si spréverit eam.

9. Sin autem fílio suo despónderit eam, juxta morem filiárum fáciet illi.

10. Quod si álteram ei accéperit, providébit puéllæ núptias, et vestiménta, et prétium pudicítiæ non negábit.

11. Si tria ista non fécerit, egrediétur gratis absque pecúnia.

12. Qui percússerit hóminem volens occídere, morte moriátur.

13. Qui autem non est insidiátus, sed Deus illum trádidit in manus ejus, constítuam tibi locum in quem fúgere débeat.

14. Si quis per indústriam occíderit próximum suum, et per insídias : ab altári meo evélles eum, ut moriátur.

15. Qui percússerit patrem suum aut matrem, morte moriátur.

16. Qui furátus fúerit hóminem, et vendíderit eum, convíctus noxæ, morte moriátur.

17. Qui maledíxerit patri suo, vel matri, morte moriátur.

18. Si rixáti fúerint viri, et percússerit alter próximum suum lápide vel pugno, et ille mórtuus non fúerit, sed jacúerit in léctulo :

19. si surréxerit, et ambuláverit foris super báculum suum, ínnocens erit qui percússerit, ita tamen ut óperas ejus et impénsas in médicos restítuat.

20. Qui percússerit servum suum, vel ancíllam virga, et mórtui fúerint in mánibus ejus, críminis reus erit.

21. Sin autem uno die vel duóbus supervíxerit, non subjacébit pœnæ, quia pecúnia illíus est.

22. Si rixáti fúerint viri, et percússerit quis mulíerem prægnántem, et abortívum quidem fécerit, sed ipsa víxerit : subjacébit damno quantum máritus mulíeris expetíerit, et árbitri judicáverint.

23. Sin autem mors ejus fúerit subsecúta, reddet ánimam pro ánima,

24. óculum pro óculo, dentem pro dente, manum pro manu, pedem pro pede,

25. adustiónem pro adustióne, vulnus pro vúlnere, livórem pro livóre.

26. Si percússerit quíspiam óculum servi sui aut ancíllæ, et luscos eos fécerit, dimíttet eos líberos pro óculo quem éruit.

27. Dentem quoque si excússerit servo vel ancíllæ suæ, simíliter dimíttet eos líberos.

28. Si bos cornu percússerit virum aut mulíerem, et mórtui fúerint, lapídibus obruétur : et non comedéntur carnes ejus, dóminus quoque bovis ínnocens erit.

29. Quod si bos cornupéta fúerit ab heri et nudiustértius, et contestáti sunt dóminum ejus, nec reclúserit eum, occiderítque virum aut mulíerem : et bos lapídibus obruétur, et dóminum ejus occídent.

30. Quod si prétium fúerit ei impósitum, dabit pro ánima sua quidquid fúerit postulátus.

31. Fílium quoque et fíliam si cornu percússerit, símili senténtiæ subjacébit.

32. Si servum ancillámque inváserit, trigínta siclos argénti dómino dabit, bos vero lapídibus opprimétur.

33. Si quis aperúerit cistérnam, et fóderit, et non operúerit eam, ceciderítque bos aut ásinus in eam,

34. reddet dóminus cistérnæ prétium jumentórum : quod autem mórtuum est, ipsíus erit.

35. Si bos aliénus bovem altérius vulneráverit, et ille mórtuus fúerit : vendent bovem vivum, et dívident prétium, cadáver autem mórtui inter se dispértient.

36. Sin autem sciébat quod bos cornupéta esset ab heri et nudiustértius, et non custodívit eum dóminus suus : reddet bovem pro bove, et cadáver íntegrum accípiet.

