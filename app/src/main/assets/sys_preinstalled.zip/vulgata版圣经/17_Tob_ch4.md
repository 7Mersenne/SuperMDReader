# Liber Tobi� - Caput 4

1. Ígitur cum Tobías putáret oratiónem suam exaudíri ut mori potuísset, vocávit ad se Tobíam fílium suum,

2. dixítque ei : Audi, fili mi, verba oris mei, et ea in corde tuo quasi fundaméntum cónstrue.

3. Cum accéperit Deus ánimam meam, corpus meum sépeli : et honórem habébis matri tuæ ómnibus diébus vitæ ejus :

4. memor enim esse debes, quæ et quanta perícula passa sit propter te in útero suo.

5. Cum autem et ipsa compléverit tempus vitæ suæ, sepélias eam circa me.

6. Ómnibus autem diébus vitæ tuæ in mente habéto Deum : et cave ne aliquándo peccáto conséntias, et prætermíttas præcépta Dómini Dei nostri.

7. Ex substántia tua fac eleemósynam, et noli avértere fáciem tuam ab ullo páupere : ita enim fiet ut nec a te avertátur fácies Dómini.

8. Quómodo potúeris, ita esto miséricors.

9. Si multum tibi fúerit, abundánter tríbue : si exíguum tibi fúerit, étiam exíguum libénter impertíri stude.

10. Prǽmium enim bonum tibi thesaurízas in die necessitátis :

11. quóniam eleemósyna ab omni peccáto et a morte líberat, et non patiétur ánimam ire in ténebras.

12. Fidúcia magna erit coram summo Deo, eleemósyna ómnibus faciéntibus eam.

13. Atténde tibi, fili mi, ab omni fornicatióne, et præter uxórem tuam numquam patiáris crimen scire.

14. Supérbiam numquam in tuo sensu aut in tuo verbo dominári permíttas : in ipsa enim inítium sumpsit omnis perdítio.

15. Quicúmque tibi áliquid operátus fúerit, statim ei mercédem restítue, et merces mercenárii tui apud te omníno non remáneat.

16. Quod ab álio óderis fíeri tibi, vide ne tu aliquándo álteri fácias.

17. Panem tuum cum esuriéntibus et egénis cómede, et de vestiméntis tuis nudos tege.

18. Panem tuum et vinum tuum super sepultúram justi constítue, et noli ex eo manducáre et bíbere cum peccatóribus.

19. Consílium semper a sapiénte perquíre.

20. Omni témpore bénedic Deum : et pete ab eo ut vias tuas dírigat, et ómnia consília tua in ipso permáneant.

21. Indíco étiam tibi, fili mi, dedísse me decem talénta argénti, dum adhuc infántulus esses, Gábelo, in Rages civitáte Medórum, et chirográphum ejus apud me hábeo :

22. et ídeo perquíre quómodo ad eum pervénias, et recípias ab eo supra memorátum pondus argénti, et restítuas ei chirográphum suum.

23. Noli timére, fili mi : páuperem quidem vitam gérimus, sed multa bona habébimus si timuérimus Deum, et recessérimus ab omni peccáto, et fecérimus bene.

