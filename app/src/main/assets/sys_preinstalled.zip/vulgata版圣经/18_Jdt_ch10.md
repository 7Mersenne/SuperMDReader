# Liber Judith - Caput 10

1. Factum est autem, cum cessásset clamáre ad Dóminum, surréxit de loco in quo jacúerat prostráta ad Dóminum.

2. Vocavítque abram suam, et descéndens in domum suam, ábstulit a se cilícium, et éxuit se vestiméntis viduitátis suæ,

3. et lavit corpus suum, et unxit se myro óptimo, et discriminávit crinem cápitis sui, et impósuit mitram super caput suum, et índuit se vestiméntis jucunditátis suæ, induítque sandália pédibus suis, assumpsítque dextralíola, et lília, et ináures, et ánnulos, et ómnibus ornaméntis suis ornávit se.

4. Cui étiam Dóminus cóntulit splendórem : quóniam omnis ista composítio non ex libídine, sed ex virtúte pendébat : et ídeo Dóminus hanc in illam pulchritúdinem ampliávit, ut incomparábili decóre ómnium óculis appáreret.

5. Impósuit ítaque abræ suæ ascóperam vini, et vas ólei, et poléntam, et paláthas, et panes, et cáseum, et profécta est.

6. Cumque veníssent ad portam civitátis, invenérunt expectántem Ozíam et presbýteros civitátis.

7. Qui cum vidíssent eam, stupéntes miráti sunt nimis pulchritúdinem ejus.

8. Nihil tamen interrogántes eam, dimisérunt transíre, dicéntes : Deus patrum nostrórum det tibi grátiam, et omne consílium tui cordis sua virtúte corrobóret, ut gloriétur super te Jerúsalem, et sit nomen tuum in número sanctórum et justórum.

9. Et dixérunt hi qui illic erant omnes una voce : Fiat, fiat.

10. Judith vero orans Dóminum, transívit per portas, ipsa et abra ejus.

11. Factum est autem cum descénderet montem, circa ortum diéi, occurrérunt ei exploratóres Assyriórum, et tenuérunt eam, dicéntes : Unde venis ? aut quo vadis ?

12. Quæ respóndit : Fília sum Hebræórum, ídeo ego fugi a fácie eórum, quóniam futúrum agnóvi quod dentur vobis in deprædatiónem, pro eo quod contemnéntes vos, noluérunt ultro trádere seípsos ut invenírent misericórdiam in conspéctu vestro.

13. Hac de causa cogitávi mecum, dicens : Vadam ad fáciem príncipis Holoférnis, ut indícem illi secréta illórum, et osténdam illi quo áditu possit obtinére eos, ita ut non cadat vir unus de exércitu ejus.

14. Et cum audíssent viri illi verba ejus, considerábant fáciem ejus, et erat in óculis eórum stupor, quóniam pulchritúdinem ejus mirabántur nimis.

15. Et dixérunt ad eam : Conservásti ánimam tuam, eo quod tale reperísti consílium, ut descénderes ad dóminum nostrum.

16. Hoc autem scias, quóniam cum stéteris in conspéctu ejus, bene tibi fáciet, et eris gratíssima in corde ejus. Duxerúntque illam ad tabernáculum Holoférnis, annuntiántes eam.

17. Cumque intrásset ante fáciem ejus, statim captus est in suis óculis Holoférnes.

18. Dixerúntque ad eum satéllites ejus : Quis contémnat pópulum Hebræórum, qui tam decóras mulíeres habent, ut non pro his mérito pugnáre contra eos debeámus ?

19. Videns ítaque Judith Holoférnem sedéntem in conópeo, quod erat ex púrpura, et auro, et smarágdo, et lapídibus pretiósis intéxtum,

20. et cum in fáciem ejus intendísset, adorávit eum, prostérnens se super terram. Et elevavérunt eam servi Holoférnis, jubénte dómino suo.

