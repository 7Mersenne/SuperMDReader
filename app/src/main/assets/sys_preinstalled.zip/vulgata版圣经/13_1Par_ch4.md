# Liber Primus Paralipomenon - Caput 4

1. Fílii Juda : Phares, Hesron, et Charmi, et Hur, et Sobal.

2. Raía vero fílius Sobal génuit Jahath, de quo nati sunt Ahúmai, et Laad : hæ cognatiónes Saráthi.

3. Ista quoque stirps Etam : Jézrahel, et Jeséma, et Jedébos. Nomen quoque soróris eórum, Asalelphúni.

4. Phánuel autem pater Gedor, et Ezer pater Hosa : isti sunt fílii Hur primogéniti Ephrátha patris Béthlehem.

5. Assur vero patri Thécuæ erant duæ uxóres, Hálaa et Naára.

6. Péperit autem ei Naára, Oózam, et Hepher, et Themáni, et Ahasthári : isti sunt fílii Naára.

7. Porro fílii Hálaa, Sereth, Ísaar et Ethnan.

8. Cos autem génuit Anob, et Sobóba, et cognatiónem Ahárehel fílii Arum.

9. Fuit autem Jabes ínclytus præ frátribus suis, et mater ejus vocávit nomen illíus Jabes, dicens : Quia péperi eum in dolóre.

10. Invocávit vero Jabes Deum Israël, dicens : Si benedícens benedíxeris mihi, et dilatáveris términos meos, et fúerit manus tua mecum, et féceris me a malítia non ópprimi. Et prǽstitit Deus quæ precátus est.

11. Caleb autem frater Sua génuit Mahir, qui fuit pater Esthon.

12. Porro Esthon génuit Bethrápha, et Phesse, et Tehínna patrem urbis Naas : hi sunt viri Recha.

13. Fílii autem Cenez, Othóniel, et Saraía. Porro fílii Othóniel, Hathath, et Maonáthi.

14. Maonáthi génuit Ophra, Saraía autem génuit Joab patrem Vallis artíficum : ibi quippe artífices erant.

15. Fílii vero Caleb fílii Jephóne, Hir, et Ela, et Naham. Fílii quoque Ela : Cenez.

16. Fílii quoque Jaléleel : Ziph, et Zipha, Thíria, et Ásraël.

17. Et fílii Ezra, Jether, et Mered, et Epher, et Jalon, genuítque Maríam, et Sámmai, et Jesba patrem Esthámo.

18. Uxor quoque ejus Judaía, péperit Jared patrem Gedor, et Heber patrem Socho, et Icúthiel patrem Zánoë : hi autem fílii Béthiæ fíliæ Pharaónis, quam accépit Mered.

19. Et fílii uxóris Odaíæ soróris Naham patris Céila, Garmi, et Esthámo, qui fuit de Macháthi.

20. Fílii quoque Simon, Amnon, et Rinna fílius Hanan, et Thilon. Et fílii Jesi, Zoheth, et Bénzoheth.

21. Fílii Sela, fílii Juda : Her pater Lecha, et Laáda pater Marésa, et cognatiónes domus operántium byssum in domo juraménti.

22. Et qui stare fecit solem, viríque Mendácii, et Secúrus, et Incéndens, qui príncipes fuérunt in Moab, et qui revérsi sunt in Lahem : hæc autem verba vétera.

23. Hi sunt fíguli habitántes in plantatiónibus et in sépibus, apud regem in opéribus ejus : commoratíque sunt ibi.

24. Fílii Símeon : Námuel et Jamin, Jarib, Zara, Saul.

25. Sellum fílius ejus, Mapsam fílius ejus, Masma fílius ejus.

26. Fílii Masma : Hámuel fílius ejus, Zachur fílius ejus, Sémei fílius ejus.

27. Fílii Sémei sédecim, et fíliæ sex : fratres autem ejus non habuérunt fílios multos, et univérsa cognátio non pótuit adæquáre summam filiórum Juda.

28. Habitavérunt autem in Bersabée, et Moláda, et Hasársuhal,

29. et in Bala, et in Asom, et in Tholad,

30. et in Báthuel, et in Horma, et in Síceleg,

31. et in Bethmarcháboth, et in Hasarsúsim, et in Bethbérai, et in Saárim : hæ civitátes eórum usque ad regem David.

32. Villæ quoque eórum : Etam, et Aën, Remmon, et Thochen, et Asan, civitátes quinque.

33. Et univérsi vículi eórum per circúitum civitátum istárum usque ad Baal : hæc est habitátio eórum, et sédium distribútio.

34. Mosóbab quoque et Jemlech, et Josa fílius Amásiæ,

35. et Joël, et Jehu fílius Josábiæ fílii Saraíæ fílii Ásiel,

36. et Elioënai, et Jacóba, et Isuhaía, et Asaía, et Ádiel, et Ísmiel, et Banaía,

37. Ziza quoque fílius Séphei fílii Allon fílii Idaía fílii Semri fílii Samaía.

38. Isti sunt nomináti príncipes in cognatiónibus suis, et in domo affinitátum suárum multiplicáti sunt veheménter.

39. Et profécti sunt ut ingrederéntur in Gador usque ad oriéntem vallis, et ut quǽrerent páscua grégibus suis.

40. Invenerúntque páscuas úberes, et valde bonas, et terram latíssimam et quiétam et fértilem, in qua ante habitáverant de stirpe Cham.

41. Hi ergo venérunt, quos supra descrípsimus nominátim, in diébus Ezechíæ regis Juda : et percussérunt tabernácula eórum, et habitatóres qui invénti fúerant ibi, et delevérunt eos usque in præséntem diem : habitaverúntque pro eis, quóniam ubérrimas páscuas ibídem reperérunt.

42. De fíliis quoque Símeon abiérunt in montem Seir viri quingénti, habéntes príncipes Phálthiam et Naáriam et Raphaíam et Ozíel fílios Jesi :

43. et percussérunt relíquias, quæ evádere potúerant, Amalecitárum, et habitavérunt ibi pro eis usque ad diem hanc.

