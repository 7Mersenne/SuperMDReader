# Liber Secundus Paralipomenon - Caput 8

1. Explétis autem vigínti annis postquam ædificávit Sálomon domum Dómini et domum suam,

2. civitátes quas déderat Hiram Salomóni, ædificávit, et habitáre ibi fecit fílios Israël.

3. Ábiit quoque in Emath Suba, et obtínuit eam.

4. Et ædificávit Pálmyram in desérto, et álias civitátes munitíssimas ædificávit in Emath.

5. Exstruxítque Bethóron superiórem, et Bethóron inferiórem, civitátes murátas habéntes portas et vectes et seras :

6. Bálaath étiam et omnes urbes firmíssimas quæ fuérunt Salomónis, cunctásque urbes quadrigárum, et urbes équitum. Ómnia quæcúmque vóluit Sálomon atque dispósuit, ædificávit in Jerúsalem, et in Líbano, et in univérsa terra potestátis suæ.

7. Omnem pópulum qui derelíctus fúerat de Hethǽis, et Amorrhǽis, et Pherezǽis, et Hevǽis, et Jebusǽis, qui non erant de stirpe Israël,

8. de fíliis eórum, et de pósteris, quos non interfécerant fílii Israël, subjugávit Sálomon in tributários, usque in diem hanc.

9. Porro de fíliis Israël non pósuit ut servírent opéribus regis : ipsi enim erant viri bellatóres, et duces primi, et príncipes quadrigárum et équitum ejus.

10. Omnes autem príncipes exércitus regis Salomónis fuérunt ducénti quinquagínta, qui erudiébant pópulum.

11. Fíliam vero Pharaónis tránstulit de civitáte David in domum quam ædificáverat ei. Dixit enim rex : Non habitábit uxor mea in domo David regis Israël, eo quod sanctificáta sit : quia ingréssa est in eam arca Dómini.

12. Tunc óbtulit Sálomon holocáusta Dómino super altáre Dómini, quod exstrúxerat ante pórticum,

13. ut per síngulos dies offerrétur in eo juxta præcéptum Móysi in sábbatis et in caléndis, et in festis diébus, ter per annum, id est, in solemnitáte azymórum, et in solemnitátem hebdomadárum, et in solemnitáte tabernaculórum.

14. Et constítuit juxta dispositiónem David patris sui offícia sacerdótum in ministériis suis, et Levítas in órdine suo, ut laudárent et ministrárent coram sacerdótibus juxta ritum uniuscujúsque diéi, et janitóres in divisiónibus suis per portam et portam : sic enim præcéperat David homo Dei.

15. Nec prætergréssi sunt de mandátis regis tam sacerdótes quam Levítæ, ex ómnibus quæ præcéperat, et in custódiis thesaurórum.

16. Omnes impénsas præparátas hábuit Sálomon ex eo die quo fundávit domum Dómini usque in diem quo perfécit eam.

17. Tunc ábiit Sálomon in Asiongáber, et in Áilath ad oram maris Rubri, quæ est in terra Edom.

18. Misit autem ei Hiram per manus servórum suórum naves, et nautas gnaros maris, et abiérunt cum servis Salomónis in Ophir, tulerúntque inde quadringénta quinquagínta talénta auri, et attulérunt ad regem Salomónem.

