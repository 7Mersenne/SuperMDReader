# Liber Exodus - Caput 22

1. Si quis furátus fúerit bovem aut ovem, et occíderit vel vendíderit : quinque boves pro uno bove restítuet, et quátuor oves pro una ove.

2. Si effríngens fur domum sive suffódiens fúerit invéntus, et accépto vúlnere mórtuus fúerit, percússor non erit reus sánguinis.

3. Quod si orto sole hoc fécerit, homicídium perpetrávit, et ipse moriétur. Si non habúerit quod pro furto reddat, ipse venundábitur.

4. Si invéntum fúerit apud eum quod furátus est, vivens : sive bos, sive ásinus, sive ovis, duplum restítuet.

5. Si lǽserit quíspiam agrum vel víneam, et dimíserit juméntum suum ut depascátur aliéna : quidquid óptimum habúerit in agro suo, vel in vínea, pro damni æstimatióne restítuet.

6. Si egréssus ignis invénerit spinas, et comprehénderit acérvos frugum, sive stantes ségetes in agris, reddet damnum qui ignem succénderit.

7. Si quis commendáverit amíco pecúniam aut vas in custódiam, et ab eo, qui suscéperat, furto abláta fúerint : si invenítur fur, duplum reddet :

8. si latet fur, dóminus domus applicábitur ad deos, et jurábit quod non exténderit manum in rem próximi sui,

9. ad perpetrándam fraudem, tam in bove quam in ásino, et ove ac vestiménto, et quidquid damnum inférre potest : ad deos utriúsque causa pervéniet, et si illi judicáverint, duplum restítuet próximo suo.

10. Si quis commendáverit próximo suo ásinum, bovem, ovem, et omne juméntum ad custódiam, et mórtuum fúerit, aut debilitátum, vel captum ab hóstibus, nullúsque hoc víderit :

11. jusjurándum erit in médio, quod non exténderit manum ad rem próximi sui : suscipiétque dóminus juraméntum, et ille réddere non cogétur.

12. Quod si furto ablátum fúerit, restítuet damnum dómino ;

13. si coméstum a béstia, déferat ad eum quod occísum est, et non restítuet.

14. Qui a próximo suo quidquam horum mútuo postuláverit, et debilitátum aut mórtuum fúerit dómino non præsénte, réddere compellétur.

15. Quod si impræsentiárum dóminus fúerit, non restítuet, máxime si condúctum vénerat pro mercéde óperis sui.

16. Si sedúxerit quis vírginem necdum desponsátam, dormierítque cum ea : dotábit eam, et habébit eam uxórem.

17. Si pater vírginis dare nolúerit, reddet pecúniam juxta modum dotis, quam vírgines accípere consuevérunt.

18. Maléficos non patíeris vívere.

19. Qui coíerit cum juménto, morte moriátur.

20. Qui ímmolat diis, occidétur, prætérquam Dómino soli.

21. Ádvenam non contristábis, neque afflíges eum : advénæ enim et ipsi fuístis in terra Ægýpti.

22. Víduæ et pupíllo non nocébitis.

23. Si læséritis eos, vociferabúntur ad me, et ego áudiam clamórem eórum :

24. et indignábitur furor meus, percutiámque vos gládio, et erunt uxóres vestræ víduæ, et fílii vestri pupílli.

25. Si pecúniam mútuam déderis pópulo meo páuperi qui hábitat tecum, non urgébis eum quasi exáctor, nec usúris ópprimes.

26. Si pignus a próximo tuo accéperis vestiméntum, ante solis occásum reddes ei.

27. Ipsum enim est solum, quo operítur, induméntum carnis ejus, nec habet áliud in quo dórmiat : si clamáverit ad me, exáudiam eum, quia miséricors sum.

28. Diis non détrahes, et príncipi pópuli tui non maledíces.

29. Décimas tuas et primítias tuas non tardábis réddere : primogénitum filiórum tuórum dabis mihi.

30. De bobus quoque, et óvibus simíliter fácies : septem diébus sit cum matre sua, die octáva reddes illum mihi.

31. Viri sancti éritis mihi : carnem, quæ a béstiis fúerit prægustáta, non comedétis, sed projiciétis cánibus.

