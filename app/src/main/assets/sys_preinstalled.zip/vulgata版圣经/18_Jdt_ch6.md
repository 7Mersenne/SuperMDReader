# Liber Judith - Caput 6

1. Factum est autem cum cessássent loqui, indignátus Holoférnes veheménter, dixit ad Áchior :

2. Quóniam prophetásti nobis, dicens quod gens Israël defendátur a Deo suo, ut osténdam tibi quóniam non est deus nisi Nabuchodonósor,

3. cum percussérimus eos omnes, sicut hóminem unum, tunc et ipse cum illis Assyriórum gládio interíbis, et omnis Israël tecum perditióne dispériet :

4. et probábis quóniam Nabuchodonósor dóminus sit univérsæ terræ : tuncque gládius milítiæ meæ tránsiet per látera tua, et confíxus cades inter vulnerátos Israël, et non respirábis ultra, donec extermíneris cum illis.

5. Porro autem si prophetíam tuam veram exístimas, non concídat vultus tuus : et pallor qui fáciem tuam óbtinet abscédat a te, si verba mea hæc putas impléri non posse.

6. Ut autem nóveris quia simul cum illis hæc experíeris, ecce ex hac hora illórum pópulo sociáberis, ut, dum dignas mei gládii pœnas excéperint, ipse simul ultióni subjáceas.

7. Tunc Holoférnes præcépit servis suis ut comprehénderent Áchior, et perdúcerent eum in Bethúliam, et tráderent eum in manus filiórum Israël.

8. Et accipiéntes eum servi Holoférnis, profécti sunt per campéstria : sed cum appropinquássent ad montána, exiérunt contra eos fundibulárii.

9. Illi autem diverténtes a látere montis, ligavérunt Áchior ad árborem mánibus et pédibus, et sic vinctum réstibus dimisérunt eum, et revérsi sunt ad dóminum suum.

10. Porro fílii Israël descendéntes de Bethúlia, venérunt ad eum : quem solvéntes, duxérunt ad Bethúliam, atque in médium pópuli illum statuéntes, percunctáti sunt quid rerum esset quod illum vinctum Assýrii reliquíssent.

11. In diébus illis erant illic príncipes Ozías fílius Micha de tribu Símeon, et Charmi, qui et Gothóniel.

12. In médio ítaque seniórum, et in conspéctu ómnium, Áchior dixit ómnia quæ locútus ipse fúerat ab Holoférne interrogátus : et quáliter pópulus Holoférnis voluísset propter hoc verbum interfícere eum,

13. et quemádmodum ipse Holoférnes irátus jússerit eum Israëlítis hac de causa tradi, ut dum vícerit fílios Israël, tunc et ipsum Áchior divérsis júbeat interíre supplíciis, propter hoc quod dixísset : Deus cæli defénsor eórum est.

14. Cumque Áchior univérsa hæc exposuísset, omnis pópulus cécidit in fáciem, adorántes Dóminum, et commúni lamentatióne et fletu unánimes preces suas Dómino effudérunt,

15. dicéntes : Dómine Deus cæli et terræ, intuére supérbiam eórum, et réspice ad nostram humilitátem, et fáciem sanctórum tuórum atténde, et osténde quóniam non derelínquis præsuméntes de te : et præsuméntes de se, et de sua virtúte gloriántes, humílias.

16. Fínito ítaque fletu, et per totam diem oratióne populórum compléta, consoláti sunt Áchior,

17. dicéntes : Deus patrum nostrórum, cujus tu virtútem prædicásti, ipse tibi hanc dabit vicissitúdinem, ut eórum magis tu intéritum vídeas.

18. Cum vero Dóminus Deus noster déderit hanc libertátem servis suis, sit et tecum Deus in médio nostri : ut sicut placúerit tibi, ita cum tuis ómnibus convérseris nobíscum.

19. Tunc Ozías, fínito consílio, suscépit eum in domum suam, et fecit ei cœnam magnam.

20. Et vocátis ómnibus presbýteris, simul expléto jejúnio refecérunt.

21. Póstea vero convocátus est omnis pópulus, et per totam noctem intra ecclésiam oravérunt, peténtes auxílium a Deo Israël.

