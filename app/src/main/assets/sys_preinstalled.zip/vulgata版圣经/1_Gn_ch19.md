# Liber Genesis - Caput 19

1. Venerúntque duo ángeli Sodómam véspere, et sedénte Lot in fóribus civitátis. Qui cum vidísset eos, surréxit, et ivit óbviam eis : adoravítque pronus in terram,

2. et dixit : Óbsecro, dómini, declináte in domum púeri vestri, et manéte ibi : laváte pedes vestros, et mane proficiscémini in viam vestram. Qui dixérunt : Mínime, sed in platéa manébimus.

3. Cómpulit illos óppido ut divérterent ad eum : ingressísque domum illíus fecit convívium, et coxit ázyma, et comedérunt.

4. Prius autem quam irent cúbitum, viri civitátis vallavérunt domum a púero usque ad senem, omnis pópulus simul.

5. Vocaverúntque Lot, et dixérunt ei : Ubi sunt viri qui introiérunt ad te nocte ? educ illos huc, ut cognoscámus eos.

6. Egréssus ad eos Lot, post tergum occlúdens óstium, ait :

7. Nolíte, quæso, fratres mei, nolíte malum hoc fácere.

8. Hábeo duas fílias, quæ necdum cognovérunt virum : edúcam eas ad vos, et abutímini eis sicut vobis placúerit, dúmmodo viris istis nihil mali faciátis, quia ingréssi sunt sub umbra cúlminis mei.

9. At illi dixérunt : Recéde illuc. Et rursus : Ingréssus es, ínquiunt, ut ádvena ; numquid ut júdices ? te ergo ipsum magis quam hos affligémus. Vimque faciébant Lot vehementíssime : jamque prope erat ut effríngerent fores.

10. Et ecce misérunt manum viri, et introduxérunt ad se Lot, clauserúntque óstium :

11. et eos, qui foris erant, percussérunt cæcitáte a mínimo usque ad máximum, ita ut óstium inveníre non possent.

12. Dixérunt autem ad Lot : Habes hic quémpiam tuórum ? génerum, aut fílios, aut fílias, omnes, qui tui sunt, educ de urbe hac :

13. delébimus enim locum istum, eo quod incréverit clamor eórum coram Dómino, qui misit nos ut perdámus illos.

14. Egréssus ítaque Lot, locútus est ad géneros suos qui acceptúri erant fílias ejus, et dixit : Súrgite, egredímini de loco isto : quia delébit Dóminus civitátem hanc. Et visus est eis quasi ludens loqui.

15. Cumque esset mane, cogébant eum ángeli, dicéntes : Surge, tolle uxórem tuam, et duas fílias quas habes : ne et tu páriter péreas in scélere civitátis.

16. Dissimulánte illo, apprehendérunt manum ejus, et manum uxóris, ac duárum filiárum ejus, eo quod párceret Dóminus illi.

17. Eduxerúntque eum, et posuérunt extra civitátem : ibíque locúti sunt ad eum, dicéntes : Salva ánimam tuam : noli respícere post tergum, nec stes in omni circa regióne : sed in monte salvum te fac, ne et tu simul péreas.

18. Dixítque Lot ad eos : Quæso, dómine mi,

19. quia invénit servus tuus grátiam coram te, et magnificásti misericórdiam tuam quam fecísti mecum, ut salváres ánimam meam, nec possum in monte salvári, ne forte apprehéndat me malum, et móriar :

20. est cívitas hæc juxta, ad quam possum fúgere, parva, et salvábor in ea : numquid non módica est, et vivet ánima mea ?

21. Dixítque ad eum : Ecce étiam in hoc suscépi preces tuas, ut non subvértam urbem pro qua locútus es.

22. Festína, et salváre ibi : quia non pótero fácere quidquam donec ingrediáris illuc. Idcírco vocátum est nomen urbis illíus Segor.

23. Sol egréssus est super terram, et Lot ingréssus est Segor.

24. Ígitur Dóminus pluit super Sodómam et Gomórrham sulphur et ignem a Dómino de cælo :

25. et subvértit civitátes has, et omnem circa regiónem, univérsos habitatóres úrbium, et cuncta terræ viréntia.

26. Respiciénsque uxor ejus post se, versa est in státuam salis.

27. Ábraham autem consúrgens mane, ubi stéterat prius cum Dómino,

28. intúitus est Sodómam et Gomórrham, et univérsam terram regiónis illíus : vidítque ascendéntem favíllam de terra quasi fornácis fumum.

29. Cum enim subvérteret Deus civitátes regiónis illíus, recordátus Ábrahæ, liberávit Lot de subversióne úrbium in quibus habitáverat.

30. Ascendítque Lot de Segor, et mansit in monte, duæ quoque fíliæ ejus cum eo (timúerat enim manére in Segor) et mansit in spelúnca ipse, et duæ fíliæ ejus cum eo.

31. Dixítque major ad minórem : Pater noster senex est, et nullus virórum remánsit in terra, qui possit íngredi ad nos juxta morem univérsæ terræ.

32. Veni, inebriémus eum vino, dormiamúsque cum eo, ut serváre possímus ex patre nostro semen.

33. Dedérunt ítaque patri suo bíbere vinum nocte illa. Et ingréssa est major, dormivítque cum patre ; at ille non sensit, nec quando accúbuit fília, nec quando surréxit.

34. Áltera quoque die dixit major ad minórem : Ecce dormívi heri cum patre meo, demus ei bíbere vinum étiam hac nocte, et dórmies cum eo, ut salvémus semen de patre nostro.

35. Dedérunt étiam et illa nocte patri suo bíbere vinum, ingressáque minor fília, dormívit cum eo : et ne tunc quidem sensit quando concubúerit, vel quando illa surréxerit.

36. Concepérunt ergo duæ fíliæ Lot de patre suo.

37. Peperítque major fílium, et vocávit nomen ejus Moab : ipse est pater Moabitárum usque in præséntem diem.

38. Minor quoque péperit fílium, et vocávit nomen ejus Ammon, id est, Fílius pópuli mei : ipse est pater Ammonitárum usque hódie.

