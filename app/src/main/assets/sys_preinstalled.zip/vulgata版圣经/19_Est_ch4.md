# Liber Esther - Caput 4

1. Quæ cum audísset Mardochǽus, scidit vestiménta sua, et indútus est sacco, spargens cínerem cápiti : et in platéa médiæ civitátis voce magna clamábat, osténdens amaritúdinem ánimi sui,

2. et hoc ejulátu usque ad fores palátii grádiens. Non enim erat lícitum indútum sacco aulam regis intráre.

3. In ómnibus quoque provínciis, óppidis, ac locis, ad quæ crúdele regis dogma pervénerat, planctus ingens erat apud Judǽos, jejúnium, ululátus, et fletus, sacco et cínere multis pro strato uténtibus.

4. Ingréssæ autem sunt puéllæ Esther et eunúchi, nuntiaverúntque ei. Quod áudiens consternáta est, et vestem misit, ut abláto sacco indúerent eum : quam accípere nóluit.

5. Accitóque Athach eunúcho, quem rex minístrum ei déderat, præcépit ei ut iret ad Mardochǽum, et dísceret ab eo cur hoc fáceret.

6. Egressúsque Athach, ivit ad Mardochǽum stantem in platéa civitátis, ante óstium palátii :

7. qui indicávit ei ómnia quæ accíderant : quómodo Aman promisísset ut in thesáuros regis pro Judæórum nece inférret argéntum.

8. Exémplar quoque edícti, quod pendébat in Susan, dedit ei, ut regínæ osténderet, et móneret eam ut intráret ad regem et deprecarétur eum pro pópulo suo.

9. Regréssus Athach, nuntiávit Esther ómnia quæ Mardochǽus díxerat.

10. Quæ respóndit ei, et jussit ut díceret Mardochǽo :

11. Omnes servi regis, et cunctæ, quæ sub ditióne ejus sunt, norunt provínciæ, quod sive vir, sive múlier non vocátus, intérius átrium regis intráverit, absque ulla cunctatióne statim interficiátur : nisi forte rex áuream virgam ad eum teténderit pro signo cleméntiæ, atque ita possit vívere. Ego ígitur quómodo ad regem intráre pótero, quæ trigínta jam diébus non sum vocáta ad eum ?

12. Quod cum audísset Mardochǽus,

13. rursum mandávit Esther, dicens : Ne putes quod ánimam tuam tantum líberes, quia in domo regis es præ cunctis Judǽis :

14. si enim nunc silúeris, per áliam occasiónem liberabúntur Judǽi : et tu, et domus patris tui, períbitis. Et quis novit utrum idcírco ad regnum véneris, ut in tali témpore paráreris ?

15. Rursúmque Esther hæc Mardochǽo verba mandávit :

16. Vade, et cóngrega omnes Judǽos quos in Susan repéreris, et oráte pro me. Non comedátis et non bibátis tribus diébus et tribus nóctibus : et ego cum ancíllis meis simíliter jejunábo, et tunc ingrédiar ad regem contra legem fáciens, non vocáta, tradénsque me morti et perículo.

17. Ivit ítaque Mardochǽus, et fecit ómnia quæ ei Esther præcéperat.

