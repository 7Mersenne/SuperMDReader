# Liber Esdr� - Caput 7

1. Post hæc autem verba in regno Artaxérxis regis Persárum, Esdras fílius Saraíæ, fílii Azaríæ, fílii Helcíæ,

2. fílii Sellum, fílii Sadoc, fílii Áchitob,

3. fílii Amáriæ, fílii Azaríæ, fílii Maraíoth,

4. fílii Zaráhiæ, fílii Ozi, fílii Bocci,

5. fílii Abísue, fílii Phínees, fílii Eleázar, fílii Áaron sacerdótis ab inítio.

6. Ipse Esdras ascéndit de Babylóne, et ipse scriba velox in lege Móysi, quam Dóminus Deus dedit Israël : et dedit ei rex secúndum manum Dómini Dei ejus super eum, omnem petitiónem ejus.

7. Et ascendérunt de fíliis Israël, et de fíliis sacerdótum, et de fíliis Levitárum, et de cantóribus, et de janitóribus, et de Nathinǽis, in Jerúsalem, anno séptimo Artaxérxis regis.

8. Et venérunt in Jerúsalem mense quinto, ipse est annus séptimus regis.

9. Quia in primo die mensis primi cœpit ascéndere de Babylóne, et in primo die mensis quinti venit in Jerúsalem, juxta manum Dei sui bonam super se.

10. Esdras enim parávit cor suum, ut investigáret legem Dómini, et fáceret et docéret in Israël præcéptum et judícium.

11. Hoc est autem exémplar epístolæ edícti, quod dedit rex Artaxérxes Esdræ sacerdóti, scribæ erudíto in sermónibus et præcéptis Dómini, et cæremóniis ejus in Israël.

12. Artaxérxes rex regum Esdræ sacerdóti scribæ legis Dei cæli doctíssimo, salútem.

13. A me decrétum est, ut cuicúmque placúerit in regno meo de pópulo Israël, et de sacerdótibus ejus, et de Levítis, ire in Jerúsalem, tecum vadat.

14. A fácie enim regis, et septem consiliatórum ejus, missus es, ut vísites Judǽam et Jerúsalem in lege Dei tui, quæ est in manu tua :

15. et ut feras argéntum et aurum quod rex, et consiliatóres ejus, sponte obtulérunt Deo Israël, cujus in Jerúsalem tabernáculum est.

16. Et omne argéntum et aurum quodcúmque invéneris in univérsa província Babylónis, et pópulus offérre volúerit, et de sacerdótibus quæ sponte obtúlerint dómui Dei sui, quæ est in Jerúsalem,

17. líbere áccipe, et studióse eme de hac pecúnia vítulos, aríetes, agnos, et sacrifícia, et libámina eórum, et offer ea super altáre templi Dei vestri, quod est in Jerúsalem.

18. Sed et si quid tibi et frátribus tuis placúerit de réliquo argénto et auro ut faciátis, juxta voluntátem Dei vestri fácite.

19. Vasa quoque, quæ dantur tibi in ministérium domus Dei tui, trade in conspéctu Dei in Jerúsalem.

20. Sed et cétera, quibus opus fúerit in domum Dei tui, quantumcúmque necésse est ut expéndas, dábitur de thesáuro, et de fisco regis,

21. et a me. Ego Artaxérxes rex, státui atque décrevi ómnibus custódibus arcæ públicæ, qui sunt trans flumen, ut quodcúmque petíerit a vobis Esdras sacérdos, scriba legis Dei cæli, absque mora detis,

22. usque ad argénti talénta centum, et usque ad fruménti coros centum, et usque ad vini batos centum, et usque ad batos ólei centum, sal vero absque mensúra.

23. Omne quod ad ritum Dei cæli pértinet, tribuátur diligénter in domo Dei cæli : ne forte irascátur contra regnum regis, et filiórum ejus.

24. Vobis quoque notum fácimus de univérsis sacerdótibus, et Levítis, et cantóribus, et janitóribus, Nathinǽis, et minístris domus Dei hujus, ut véctigal, et tribútum, et annónas non habeátis potestátem imponéndi super eos.

25. Tu autem Esdra, secúndum sapiéntiam Dei tui, quæ est in manu tua, constítue júdices et prǽsides, ut júdicent omni pópulo qui est trans flumen, his vidélicet qui novérunt legem Dei tui : sed et impéritos docéte líbere.

26. Et omnis qui non fécerit legem Dei tui, et legem regis, diligénter, judícium erit de eo sive in mortem, sive in exílium, sive in condemnatiónem substántiæ ejus, vel certe in cárcerem.

27. Benedíctus Dóminus Deus patrum nostrórum, qui dedit hoc in corde regis ut glorificáret domum Dómini quæ est in Jerúsalem,

28. et in me inclinávit misericórdiam suam coram rege et consiliatóribus ejus, et univérsis princípibus regis poténtibus : et ego confortátus manu Dómini Dei mei, quæ erat in me, congregávi de Israël príncipes qui ascénderent mecum.

