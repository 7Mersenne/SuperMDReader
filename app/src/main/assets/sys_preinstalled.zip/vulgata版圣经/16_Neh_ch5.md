# Liber Nehemi� - Caput 5

1. Et factus est clamor pópuli et uxórum ejus magnus advérsus fratres suos Judǽos.

2. Et erant qui dícerent : Fílii nostri et fíliæ nostræ multæ sunt nimis : accipiámus pro prétio eórum fruméntum, et comedámus, et vivámus.

3. Et erant qui dícerent : Agros nostros, et víneas, et domus nostras opponámus, et accipiámus fruméntum in fame.

4. Et álii dicébant : Mútuo sumámus pecúnias in tribúta regis, demúsque agros nostros et víneas :

5. et nunc sicut carnes fratrum nostrórum, sic carnes nostræ sunt : et sicut fílii eórum, ita et fílii nostri : ecce nos subjugámus fílios nostros et fílias nostras in servitútem, et de filiábus nostris sunt fámulæ, nec habémus unde possint rédimi : et agros nostros et víneas nostras álii póssident.

6. Et irátus sum nimis cum audíssem clamórem eórum secúndum verba hæc :

7. cogitavítque cor meum mecum, et increpávi optimátes et magistrátus, et dixi eis : Usurásne sínguli a frátribus vestris exígitis ? Et congregávi advérsum eos conciónem magnam,

8. et dixi eis : Nos, ut scitis, redémimus fratres nostros Judǽos, qui vénditi fúerant géntibus secúndum possibilitátem nostram : et vos ígitur vendétis fratres vestros, et redimémus eos ? Et siluérunt, nec invenérunt quid respondérent.

9. Dixíque ad eos : Non est bona res quam fácitis : quare non in timóre Dei nostri ambulástis, ne exprobrétur nobis a géntibus inimícis nostris ?

10. Et ego, et fratres mei, et púeri mei commodávimus plúrimis pecúniam et fruméntum. Non repetámus in commúne istud : æs aliénum concedámus quod debétur nobis.

11. Réddite eis hódie agros suos, et víneas suas, et olivéta sua, et domos suas : quin pótius et centésimum pecúniæ, fruménti, vini et ólei, quam exígere solétis ab eis, date pro illis.

12. Et dixérunt : Reddémus, et ab eis nihil quærémus : sicque faciémus ut lóqueris. Et vocávi sacerdótes, et adjurávi eos ut fácerent juxta quod díxeram.

13. Ínsuper excússi sinum meum, et dixi : Sic excútiat Deus omnem virum qui non compléverit verbum istud, de domo sua, et de labóribus suis : sic excutiátur, et vácuus fiat. Et dixit univérsa multitúdo : Amen : et laudavérunt Deum. Fecit ergo pópulus sicut erat dictum.

14. A die autem illa, qua præcéperat rex mihi ut essem dux in terra Juda, ab anno vigésimo usque ad annum trigésimum secúndum Artaxérxis regis per annos duódecim, ego et fratres mei annónas quæ dúcibus debebántur non comédimus.

15. Duces autem primi, qui fúerant ante me, gravavérunt pópulum, et accepérunt ab eis in pane, et vino, et pecúnia, quotídie siclos quadragínta : sed et minístri eórum depressérunt pópulum. Ego autem non feci ita propter timórem Dei :

16. quin pótius in ópere muri ædificávi, et agrum non emi, et omnes púeri mei congregáti ad opus erant.

17. Judǽi quoque et magistrátus centum quinquagínta viri, et qui veniébant ad nos de géntibus quæ in circúitu nostro sunt, in mensa mea erant.

18. Parabátur autem mihi per dies síngulos bos unus, aríetes sex elécti, excéptis volatílibus, et inter dies decem vina divérsa, et ália multa tribuébam : ínsuper et annónas ducátus mei non quæsívi : valde enim attenuátus erat pópulus.

19. Meménto mei, Deus meus, in bonum, secúndum ómnia quæ feci pópulo huic.

