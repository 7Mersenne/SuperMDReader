# Liber Genesis - Caput 41

1. Post duos annos vidit Phárao sómnium. Putábat se stare super flúvium,

2. de quo ascendébant septem boves, pulchræ et crassæ nimis : et pascebántur in locis palústribus.

3. Áliæ quoque septem emergébant de flúmine, fœdæ confectǽque mácie : et pascebántur in ipsa amnis ripa in locis viréntibus :

4. devoraverúntque eas, quarum mira spécies et habitúdo córporum erat. Expergefáctus Phárao,

5. rursum dormívit, et vidit álterum sómnium : septem spicæ pullulábant in culmo uno plenæ atque formósæ :

6. áliæ quoque tótidem spicæ ténues, et percússæ urédine oriebántur,

7. devorántes ómnium priórum pulchritúdinem. Evígilans Phárao post quiétem,

8. et facto mane, pavóre pertérritus, misit ad omnes conjectóres Ægýpti, cunctósque sapiéntes, et accersítis narrávit sómnium, nec erat qui interpretarétur.

9. Tunc demum reminíscens pincernárum magíster, ait : Confíteor peccátum meum :

10. irátus rex servis suis, me et magístrum pistórum retrúdi jussit in cárcerem príncipis mílitum :

11. ubi una nocte utérque vídimus sómnium prǽsagum futurórum.

12. Erat ibi puer hebrǽus, ejúsdem ducis mílitum fámulus : cui narrántes sómnia,

13. audívimus quidquid póstea rei probávit evéntus ; ego enim rédditus sum offício meo, et ille suspénsus est in cruce.

14. Prótinus ad regis impérium edúctum de cárcere Joseph totondérunt : ac veste mutáta obtulérunt ei.

15. Cui ille ait : Vidi sómnia, nec est qui edísserat : quæ audívi te sapientíssime conjícere.

16. Respóndit Joseph : Absque me Deus respondébit próspera Pharaóni.

17. Narrávit ergo Phárao quod víderat : Putábam me stare super ripam flúminis,

18. et septem boves de amne conscéndere, pulchras nimis, et obésis cárnibus : quæ in pastu palúdis virécta carpébant.

19. Et ecce, has sequebántur áliæ septem boves, in tantum defórmes et maciléntæ, ut numquam tales in terra Ægýpti víderim :

20. quæ, devorátis et consúmptis prióribus,

21. nullum saturitátis dédere vestígium : sed símili mácie et squalóre torpébant. Evígilans, rursus sopóre depréssus,

22. vidi sómnium. Septem spicæ pullulábant in culmo uno plenæ atque pulchérrimæ.

23. Áliæ quoque septem ténues et percússæ urédine, oriebántur e stípula :

24. quæ priórum pulchritúdinem devoravérunt. Narrávi conjectóribus sómnium, et nemo est qui edísserat.

25. Respóndit Joseph : Sómnium regis unum est : quæ factúrus est Deus, osténdit Pharaóni.

26. Septem boves pulchræ, et septem spicæ plenæ, septem ubertátis anni sunt : eamdémque vim sómnii comprehéndunt.

27. Septem quoque boves ténues atque maciléntæ, quæ ascendérunt post eas, et septem spicæ ténues, et vento urénte percússæ, septem anni ventúræ sunt famis.

28. Qui hoc órdine complebúntur :

29. ecce septem anni vénient fertilitátis magnæ in univérsa terra Ægýpti,

30. quos sequéntur septem anni álii tantæ sterilitátis, ut oblivióni tradátur cuncta retro abundántia : consumptúra est enim fames omnem terram,

31. et ubertátis magnitúdinem perditúra est inópiæ magnitúdo.

32. Quod autem vidísti secúndo ad eámdem rem pértinens sómnium : firmitátis indícium est, eo quod fiat sermo Dei, et velócius impleátur.

33. Nunc ergo provídeat rex virum sapiéntem et indústrium, et præfíciat eum terræ Ægýpti :

34. qui constítuat præpósitos per cunctas regiónes : et quintam partem frúctuum per septem annos fertilitátis,

35. qui jam nunc futúri sunt, cóngreget in hórrea : et omne fruméntum sub Pharaónis potestáte condátur, servetúrque in úrbibus.

36. Et præparétur futúræ septem annórum fami, quæ oppressúra est Ægýptum, et non consumétur terra inópia.

37. Plácuit Pharaóni consílium et cunctis minístris ejus :

38. locutúsque est ad eos : Num inveníre potérimus talem virum, qui spíritu Dei plenus sit ?

39. Dixit ergo ad Joseph : Quia osténdit tibi Deus ómnia quæ locútus es, numquid sapientiórem et consímilem tui inveníre pótero ?

40. Tu eris super domum meam, et ad tui oris impérium cunctus pópulus obédiet : uno tantum regni sólio te præcédam.

41. Dixítque rursus Phárao ad Joseph : Ecce, constítui te super univérsam terram Ægýpti.

42. Tulítque ánnulum de manu sua, et dedit eum in manu ejus : vestivítque eum stola býssina, et collo torquem áuream circumpósuit.

43. Fecítque eum ascéndere super currum suum secúndum, clamánte præcóne, ut omnes coram eo genu flécterent, et præpósitum esse scirent univérsæ terræ Ægýpti.

44. Dixit quoque rex ad Joseph : Ego sum Phárao : absque tuo império non movébit quisquam manum aut pedem in omni terra Ægýpti.

45. Vertítque nomen ejus, et vocávit eum, lingua ægyptiáca, Salvatórem mundi. Dedítque illi uxórem Áseneth fíliam Putipháre sacerdótis Heliopóleos. Egréssus est ítaque Joseph ad terram Ægýpti

46. (trigínta autem annórum erat quando stetit in conspéctu regis Pharaónis), et circuívit omnes regiónes Ægýpti.

47. Venítque fertílitas septem annórum : et in manípulos redáctæ ségetes congregátæ sunt in hórrea Ægýpti.

48. Omnis étiam frugum abundántia in síngulis úrbibus cóndita est.

49. Tantáque fuit abundántia trítici, ut arénæ maris coæquarétur, et cópia mensúram excéderet.

50. Nati sunt autem Joseph fílii duo ántequam veníret fames : quos péperit ei Áseneth fília Putipháre sacerdótis Heliopóleos.

51. Vocavítque nomen primogéniti Manásses, dicens : Oblivísci me fecit Deus ómnium labórum meórum, et domus patris mei.

52. Nomen quoque secúndi appellávit Éphraim, dicens : Créscere me fecit Deus in terra paupertátis meæ.

53. Ígitur transáctis septem ubertátis annis, qui fúerant in Ægýpto,

54. cœpérunt veníre septem anni inópiæ, quos prædíxerat Joseph : et in univérso orbe fames præváluit, in cuncta autem terra Ægýpti panis erat.

55. Qua esuriénte, clamávit pópulus ad Pharaónem, aliménta petens. Quibus ille respóndit : Ite ad Joseph : et quidquid ipse vobis díxerit, fácite.

56. Crescébat autem quotídie fames in omni terra : aperuítque Joseph univérsa hórrea, et vendébat Ægýptiis : nam et illos opprésserat fames.

57. Omnésque provínciæ veniébant in Ægýptum, ut émerent escas, et malum inópiæ temperárent.

