# Liber Esther - Caput 16

1. Rex magnus Artaxérxes ab Índia usque Æthiópiam, centum vigínti septem provinciárum dúcibus ac princípibus qui nostræ jussióni obédiunt, salútem dicit.

2. Multi bonitáte príncipum et honóre, qui in eos collátus est, abúsi sunt in supérbiam :

3. et non solum subjéctos régibus nitúntur opprímere, sed datam sibi glóriam non feréntes, in ipsos qui dedérunt, moliúntur insídias.

4. Nec conténti sunt grátias non ágere benefíciis, et humanitátis in se jura violáre, sed Dei quoque cuncta cernéntis arbitrántur se posse fúgere senténtiam.

5. Et in tantum vesániæ prorupérunt, ut eos qui crédita sibi offícia diligénter obsérvant, et ita cuncta agunt ut ómnium laude digni sint, mendaciórum cunículis conéntur subvértere,

6. dum aures príncipum símplices, et ex sua natúra álios æstimántes, cállida fraude decípiunt.

7. Quæ res et ex vetéribus probátur históriis, et ex his quæ gerúntur quotídie, quómodo malis quorúmdam suggestiónibus regum stúdia depravéntur.

8. Unde providéndum est paci ómnium provinciárum.

9. Nec putáre debétis, si divérsa jubeámus, ex ánimi nostri veníre levitáte, sed pro qualitáte et necessitáte témporum, ut reipúblicæ poscit utílitas, ferre senténtiam.

10. Et ut maniféstius quod dícimus intelligátis, Aman fílius Amadáthi, et ánimo et gente Mácedo, alienúsque a Persárum sánguine, et pietátem nostram sua crudelitáte commáculans, peregrínus a nobis suscéptus est :

11. et tantam in se expértus humanitátem, ut pater noster vocarétur, et adorarétur ab ómnibus post regem secúndus :

12. qui in tantum arrogántiæ tumórem sublátus est, ut regno priváre nos niterétur et spíritu.

13. Nam Mardochǽum, cujus fide et benefíciis vívimus, et consórtem regni nostri Esther cum omni gente sua, novis quibúsdam atque ináuditis máchinis expetívit in mortem :

14. hoc cógitans ut illis interféctis, insidiarétur nostræ solitúdini, et regnum Persárum transférret in Macedónas.

15. Nos autem a péssimo mortálium Judǽos neci destinátos, in nulla pénitus culpa repérimus, sed e contrário justis uténtes légibus,

16. et fílios altíssimi et máximi sempérque vivéntis Dei, cujus benefício et pátribus nostris et nobis regnum est tráditum, et usque hódie custodítur.

17. Unde eas lítteras, quas sub nómine nostro ille diréxerat, sciátis esse írritas.

18. Pro quo scélere ante portas hujus urbis, id est, Susan, et ipse qui machinátus est, et omnis cognátio ejus pendet in patíbulis : non nobis, sed Deo reddénte ei quod méruit.

19. Hoc autem edíctum, quod nunc míttimus, in cunctis úrbibus proponátur, ut líceat Judǽis uti légibus suis.

20. Quibus debétis esse adminículo, ut eos qui se ad necem eórum paráverant, possint interfícere tertiadécima die mensis duodécimi, qui vocátur Adar.

21. Hanc enim diem, Deus omnípotens, mœróris et luctus, eis vertit in gáudium.

22. Unde et vos inter céteros festos dies, hanc habetóte diem, et celebráte eam cum omni lætítia, ut et in pósterum cognoscátur,

23. omnes qui fidéliter Persis obédiunt, dignam pro fide recípere mercédem ; qui autem insidiántur regno eórum, períre pro scélere.

24. Omnis autem província et cívitas quæ nolúerit solemnitátis hujus esse párticeps, gládio et igne péreat, et sic deleátur, ut non solum homínibus, sed étiam béstiis ínvia sit in sempitérnum, pro exémplo contémptus et inobediéntiæ.

