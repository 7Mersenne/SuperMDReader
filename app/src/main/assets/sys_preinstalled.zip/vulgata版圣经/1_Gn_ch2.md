# Liber Genesis - Caput 2

1. Ígitur perfécti sunt cæli et terra, et omnis ornátus eórum.

2. Complevítque Deus die séptimo opus suum quod fécerat : et requiévit die séptimo ab univérso ópere quod patrárat.

3. Et benedíxit diéi séptimo, et sanctificávit illum, quia in ipso cessáverat ab omni ópere suo quod creávit Deus ut fáceret.

4. Istæ sunt generatiónes cæli et terræ, quando creáta sunt, in die quo fecit Dóminus Deus cælum et terram,

5. et omne virgúltum agri ántequam orirétur in terra, omnémque herbam regiónis priúsquam germináret : non enim plúerat Dóminus Deus super terram, et homo non erat qui operarétur terram :

6. sed fons ascendébat e terra, írrigans univérsam superfíciem terræ.

7. Formávit ígitur Dóminus Deus hóminem de limo terræ, et inspirávit in fáciem ejus spiráculum vitæ, et factus est homo in ánimam vivéntem.

8. Plantáverat autem Dóminus Deus paradísum voluptátis a princípio, in quo pósuit hóminem quem formáverat.

9. Produxítque Dóminus Deus de humo omne lignum pulchrum visu, et ad vescéndum suáve lignum étiam vitæ in médio paradísi, lignúmque sciéntiæ boni et mali.

10. Et flúvius egrediebátur de loco voluptátis ad irrigándum paradísum, qui inde divíditur in quátuor cápita.

11. Nomen uni Phison : ipse est qui círcuit omnem terram Hévilath, ubi náscitur aurum :

12. et aurum terræ illíus óptimum est ; ibi invenítur bdéllium, et lapis onýchinus.

13. Et nomen flúvii secúndi Gehon ; ipse est qui circúmit omnem terram Æthiópiæ.

14. Nomen vero flúminis tértii, Tigris : ipse vadit contra Assýrios. Flúvius autem quartus, ipse est Euphrátes.

15. Tulit ergo Dóminus Deus hóminem, et pósuit eum in paradíso voluptátis, ut operarétur, et custodíret illum :

16. præcepítque ei, dicens : Ex omni ligno paradísi cómede ;

17. de ligno autem sciéntiæ boni et mali ne cómedas : in quocúmque enim die coméderis ex eo, morte moriéris.

18. Dixit quoque Dóminus Deus : Non est bonum esse hóminem solum : faciámus ei adjutórium símile sibi.

19. Formátis ígitur Dóminus Deus de humo cunctis animántibus terræ, et univérsis volatílibus cæli, addúxit ea ad Adam, ut vidéret quid vocáret ea : omne enim quod vocávit Adam ánimæ vivéntis, ipsum est nomen ejus.

20. Appellavítque Adam nomínibus suis cuncta animántia, et univérsa volatília cæli, et omnes béstias terræ : Adæ vero non inveniebátur adjútor símilis ejus.

21. Immísit ergo Dóminus Deus sopórem in Adam : cumque obdormísset, tulit unam de costis ejus, et replévit carnem pro ea.

22. Et ædificávit Dóminus Deus costam, quam túlerat de Adam, in mulíerem : et addúxit eam ad Adam.

23. Dixítque Adam : Hoc nunc os ex óssibus meis, et caro de carne mea : hæc vocábitur Vírago, quóniam de viro sumpta est.

24. Quam ob rem relínquet homo patrem suum, et matrem, et adhærébit uxóri suæ : et erunt duo in carne una.

25. Erat autem utérque nudus, Adam scílicet et uxor ejus : et non erubescébant.

