# Liber Esther - Caput 15

1. Et mandávit ei (haud dúbium quin esset Mardochǽus) ut ingrederétur ad regem, et rogáret pro pópulo suo et pro pátria sua.

2. Memoráre, inquit, diérum humilitátis tuæ, quómodo nutríta sis in manu mea, quia Aman secúndus a rege locútus est contra nos in mortem :

3. et tu ínvoca Dóminum, et lóquere regi pro nobis, et líbera nos de morte.

4. Die autem tértio depósuit vestiménta ornátus sui, et circúmdata est glória sua.

5. Cumque régio fúlgeret hábitu, et invocásset ómnium rectórem et salvatórem Deum, assúmpsit duas fámulas,

6. et super unam quidem innitebátur, quasi præ delíciis et nímia teneritúdine corpus suum ferre non sústinens :

7. áltera autem famulárum sequebátur dóminam, defluéntia in humum induménta susténtans.

8. Ipsa autem róseo colóre vultum perfúsa, et gratis ac niténtibus óculis, tristem celábat ánimum, et nímio timóre contráctum.

9. Ingréssa ígitur cuncta per órdinem óstia, stetit contra regem, ubi ille residébat super sólium regni sui, indútus véstibus régiis, auróque fulgens, et pretiósis lapídibus : erátque terríbilis aspéctu.

10. Cumque elevásset fáciem, et ardéntibus óculis furórem péctoris indicásset, regína córruit, et in pallórem colóre mutáto, lassum super ancíllulam reclinávit caput.

11. Convertítque Deus spíritum regis in mansuetúdinem, et festínus ac métuens exilívit de sólio, et susténtans eam ulnis suis donec redíret ad se, his verbis blandiebátur :

12. Quid habes, Esther ? ego sum frater tuus : noli metúere.

13. Non moriéris : non enim pro te, sed pro ómnibus hæc lex constitúta est.

14. Accéde ígitur, et tange sceptrum.

15. Cumque illa retíceret, tulit áuream virgam, et pósuit super collum ejus, et osculátus est eam, et ait : Cur mihi non lóqueris ?

16. Quæ respóndit : Vidi te, dómine, quasi ángelum Dei, et conturbátum est cor meum præ timóre glóriæ tuæ.

17. Valde enim mirábilis es, dómine, et fácies tua plena est gratiárum.

18. Cumque loquerétur, rursus córruit, et pene exanimáta est.

19. Rex autem turbabátur, et omnes minístri ejus consolabántur eam.

