# Liber Genesis - Caput 38

1. Eódem témpore, descéndens Judas a frátribus suis, divértit ad virum Odollámitem, nómine Hiram.

2. Vidítque ibi fíliam hóminis Chananǽi, vocábulo Sue : et accépta uxóre, ingréssus est ad eam.

3. Quæ concépit, et péperit fílium, et vocávit nomen ejus Her.

4. Rursúmque concépto fœtu, natum fílium vocávit Onan.

5. Tértium quoque péperit : quem appellávit Sela ; quo nato, párere ultra cessávit.

6. Dedit autem Judas uxórem primogénito suo Her, nómine Thamar.

7. Fuit quoque Her primogénitus Judæ nequam in conspéctu Dómini : et ab eo occísus est.

8. Dixit ergo Judas ad Onan fílium suum : Ingrédere uxórem fratris tui, et sociáre illi, ut súscites semen fratri tuo.

9. Ille sciens non sibi nasci fílios, intróiens ad uxórem fratris sui, semen fundébat in terram, ne líberi fratris nómine nasceréntur.

10. Et idcírco percússit eum Dóminus, quod rem detestábilem fáceret.

11. Quam ob rem dixit Judas Thamar núrui suæ : Esto vídua in domo patris tui, donec crescat Sela fílius meus : timébat enim ne et ipse morerétur, sicut fratres ejus. Quæ ábiit, et habitávit in domo patris sui.

12. Evolútis autem multis diébus, mórtua est fília Sue uxor Judæ : qui, post luctum consolatióne suscépta, ascendébat ad tonsóres óvium suárum, ipse et Hiras opílio gregis Odollámites, in Thamnas.

13. Nuntiatúmque est Thamar quod socer illíus ascénderet in Thamnas ad tondéndas oves.

14. Quæ, depósitis viduitátis véstibus, assúmpsit therístrum : et mutáto hábitu, sedit in bívio itíneris, quod ducit Thamnam : eo quod crevísset Sela, et non eum accepísset máritum.

15. Quam cum vidísset Judas, suspicátus est esse meretrícem : operúerat enim vultum suum, ne agnoscerétur.

16. Ingrediénsque ad eam, ait : Dimítte me ut coëam tecum : nesciébat enim quod nurus sua esset. Qua respondénte : Quid dabis mihi ut fruáris concúbitu meo ?

17. dixit : Mittam tibi hædum de grégibus. Rursúmque illa dicénte : Pátiar quod vis, si déderis mihi arrhabónem, donec mittas quod pollíceris.

18. Ait Judas : Quid tibi vis pro arrhabóne dari ? Respóndit : Ánnulum tuum, et armíllam, et báculum quem manu tenes. Ad unum ígitur cóitum múlier concépit,

19. et surgens ábiit : depositóque hábitu quem súmpserat, indúta est viduitátis véstibus.

20. Misit autem Judas hædum per pastórem suum Odollámitem, ut recíperet pignus quod déderat mulíeri : qui cum non invenísset eam,

21. interrogávit hómines loci illíus : Ubi est múlier quæ sedébat in bívio ? Respondéntibus cunctis : Non fuit in loco ista méretrix.

22. Revérsus est ad Judam, et dixit ei : Non invéni eam : sed et hómines loci illíus dixérunt mihi, numquam sedísse ibi scortum.

23. Ait Judas : Hábeat sibi, certe mendácii argúere nos non potest, ego misi hædum quem promíseram : et tu non invenísti eam.

24. Ecce autem post tres menses nuntiavérunt Judæ, dicéntes : Fornicáta est Thamar nurus tua, et vidétur úterus illíus intuméscere. Dixítque Judas : Prodúcite eam ut comburátur.

25. Quæ cum ducerétur ad pœnam, misit ad sócerum suum, dicens : De viro, cujus hæc sunt, concépi : cognósce cujus sit ánnulus, et armílla, et báculus.

26. Qui, ágnitis munéribus, ait : Jústior me est : quia non trádidi eam Sela fílio meo. Attámen ultra non cognóvit eam.

27. Instánte autem partu, apparuérunt gémini in útero : atque in ipsa effusióne infántium unus prótulit manum, in qua óbstetrix ligávit cóccinum, dicens :

28. Iste egrediétur prior.

29. Illo vero retrahénte manum, egréssus est alter : dixítque múlier : Quare divísa est propter te macéria ? et ob hanc causam, vocávit nomen ejus Phares.

30. Póstea egréssus est frater ejus, in cujus manu erat cóccinum : quem appellávit Zara.

