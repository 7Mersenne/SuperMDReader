# Liber Esther - Caput 14

1. Esther quoque regína confúgit ad Dóminum, pavens perículum quod imminébat.

2. Cumque deposuísset vestes régias, flétibus et lúctui apta induménta suscépit, et pro unguéntis váriis, cínere et stércore implévit caput, et corpus suum humiliávit jejúniis : omniáque loca, in quibus ántea lætári consuéverat, crínium laceratióne complévit.

3. Et deprecabátur Dóminum Deum Israël, dicens : Dómine mi, qui rex noster es solus, ádjuva me solitáriam, et cujus præter te nullus est auxiliátor álius.

4. Perículum meum in mánibus meis est.

5. Audívi a patre meo quod tu, Dómine, tulísses Israël de cunctis géntibus, et patres nostros ex ómnibus retro majóribus suis, ut possidéres hæreditátem sempitérnam, fecistíque eis sicut locútus es.

6. Peccávimus in conspéctu tuo, et idcírco tradidísti nos in manus inimicórum nostrórum :

7. colúimus enim deos eórum. Justus es Dómine :

8. et nunc non eis súfficit, quod duríssima nos ópprimunt servitúte, sed robur mánuum suárum, idolórum poténtiæ deputántes,

9. volunt tua mutáre promíssa, et delére hæreditátem tuam, et cláudere ora laudántium te, atque extínguere glóriam templi et altáris tui,

10. ut apériant ora géntium, et laudent idolórum fortitúdinem, et prædícent carnálem regem in sempitérnum.

11. Ne tradas, Dómine, sceptrum tuum his, qui non sunt, ne rídeant ad ruínam nostram : sed convérte consílium eórum super eos, et eum qui in nos cœpit sævíre, dispérde.

12. Meménto, Dómine, et osténde te nobis in témpore tribulatiónis nostræ, et da mihi fidúciam, Dómine rex deórum, et univérsæ potestátis :

13. tríbue sermónem compósitum in ore meo in conspéctu leónis, et transfer cor illíus in ódium hostis nostri, ut et ipse péreat, et céteri qui ei conséntiunt.

14. Nos autem líbera manu tua, et ádjuva me, nullum áliud auxílium habéntem nisi te, Dómine, qui habes ómnium sciéntiam,

15. et nosti quia óderim glóriam iniquórum, et detéster cubíle incircumcisórum, et omnis alienígenæ.

16. Tu scis necessitátem meam, quod abóminer signum supérbiæ et glóriæ meæ, quod est super caput meum in diébus ostentatiónis meæ, et detéster illud quasi pannum menstruátæ, et non portem in diébus siléntii mei,

17. et quod non coméderim in mensa Aman, nec mihi placúerit convívium regis, et non bíberim vinum libáminum :

18. et numquam lætáta sit ancílla tua, ex quo huc transláta sum usque in præséntem diem, nisi in te, Dómine Deus Ábraham.

19. Deus fortis super omnes, exáudi vocem eórum qui nullam áliam spem habent, et líbera nos de manu iniquórum, et érue me a timóre meo.

