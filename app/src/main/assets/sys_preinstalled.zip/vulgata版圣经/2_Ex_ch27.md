# Liber Exodus - Caput 27

1. Fácies et altáre de lignis setim, quod habébit quinque cúbitus in longitúdine, et tótidem in latitúdine, id est, quadrum, et tres cúbitos in altitúdine.

2. Córnua autem per quátuor ángulos ex ipso erunt : et opéries illud ære.

3. Faciésque in usus ejus lebétes ad suscipiéndos cíneres, et fórcipes atque fuscínulas, et ígnium receptácula ; ómnia vasa ex ære fabricábis.

4. Craticulámque in modum retis ǽneam : per cujus quátuor ángulos erunt quátuor ánnuli ǽnei.

5. Quos pones subter árulam altáris : erítque cratícula usque ad altáris médium.

6. Fácies et vectes altáris de lignis setim duos, quos opéries láminis ǽneis :

7. et indúces per círculos, erúntque ex utróque látere altáris ad portándum.

8. Non sólidum, sed ináne et cavum intrínsecus fácies illud, sicut tibi in monte monstrátum est.

9. Fácies et átrium tabernáculi, in cujus austráli plaga contra merídiem erunt tentória de bysso retórta : centum cúbitos unum latus tenébit in longitúdine.

10. Et colúmnas vigínti cum básibus tótidem ǽneis, quæ cápita cum cælatúris suis habébunt argéntea.

11. Simíliter et in látere aquilónis per longum erunt tentória centum cubitórum, colúmnæ vigínti, et bases ǽneæ ejúsdem númeri, et cápita eárum cum cælatúris suis argéntea.

12. In latitúdine vero átrii, quod réspicit ad occidéntem, erunt tentória per quinquagínta cúbitos, et colúmnæ decem, basésque tótidem.

13. In ea quoque átrii latitúdine, quæ réspicit ad oriéntem, quinquagínta cúbiti erunt.

14. In quibus quíndecim cubitórum tentória láteri uno deputabúntur, columnǽque tres et bases tótidem :

15. et in látere áltero erunt tentória cúbitos obtinéntia quíndecim, colúmnæ tres, et bases tótidem.

16. In intróitu vero átrii fiet tentórium cubitórum vigínti ex hyacíntho et púrpura, coccóque bis tincto, et bysso retórta, ópere plumárii : colúmnas habébit quátuor, cum básibus tótidem.

17. Omnes colúmnæ átrii per circúitum vestítæ erunt argénteis láminis, capítibus argénteis, et básibus ǽneis.

18. In longitúdine occupábit átrium cúbitos centum, in latitúdine quinquagínta, altitúdo quinque cubitórum erit : fiétque de bysso retórta, et habébit bases ǽneas.

19. Cuncta vasa tabernáculi in omnes usus et cæremónias, tam paxíllos ejus quam átrii, ex ære fácies.

20. Prǽcipe fíliis Israël ut áfferant tibi óleum de arbóribus olivárum puríssimum, pilóque contúsum, ut árdeat lucérna semper

21. in tabernáculo testimónii, extra velum quod oppánsum est testimónio. Et collocábunt eam Áaron et fílii ejus, ut usque mane lúceat coram Dómino. Perpétuus erit cultus per successiónes eórum a fíliis Israël.

