# Liber Primus Paralipomenon - Caput 8

1. Bénjamin autem génuit Bale primogénitum suum, Asbel secúndum, Ahára tértium,

2. Nóhaa quartum, et Rapha quintum.

3. Fuerúntque fílii Bale : Addar, et Gera, et Abíud,

4. Abísue quoque et Náaman, et Áhoë,

5. sed et Gera, et Séphuphan, et Huram.

6. Hi sunt fílii Ahod, príncipes cognatiónum habitántium in Gábaa, qui transláti sunt in Mánahath.

7. Náaman autem, et Áchia, et Gera, ipse tránstulit eos, et génuit Osa, et Áhiud.

8. Porro Saháraim génuit in regióne Moab, postquam dimísit Husim et Bara uxóres suas.

9. Génuit autem de Hodes uxóre sua Jobab, et Sébia, et Mosa, et Molchom,

10. Jehus quoque, et Séchia, et Marma : hi sunt fílii ejus príncipes in famíliis suis.

11. Mehúsim vero génuit Ábitob et Élphaal.

12. Porro fílii Élphaal : Heber, et Mísaam, et Samad : hic ædificávit Ono, et Lod, et fílias ejus.

13. Bária autem et Sama príncipes cognatiónum habitántium in Ajálon : hi fugavérunt habitatóres Geth.

14. Et Áhio, et Sesac, et Jérimoth,

15. et Zabádia, et Arod, et Heder,

16. Míchaël quoque, et Jespha, et Joha fílii Bária.

17. Et Zabádia, et Mosóllam, et Hezéci, et Heber,

18. et Jesamári, et Jézlia, et Jobab fílii Élphaal,

19. et Jacim, et Zechri, et Zabdi,

20. et Elioënai, et Seléthai, et Elíel,

21. et Adaía, et Baraía, et Samárath, fílii Sémei.

22. Et Jespham, et Heber, et Elíel,

23. et Abdon, et Zechri, et Hanan,

24. et Hanánia, et Ælam, et Anathóthia,

25. et Jephdaía, et Phánuel, fílii Sesac.

26. Et Samsári, et Sohória, et Othólia,

27. et Jérsia, et Elía, et Zechri, fílii Jéroham.

28. Hi patriárchæ, et cognatiónum príncipes, qui habitavérunt in Jerúsalem.

29. In Gábaon autem habitavérunt Abigábaon, et nomen uxóris ejus Maácha :

30. filiúsque ejus primogénitus Abdon, et Sur, et Cis, et Baal, et Nadab,

31. Gedor quoque, et Áhio, et Zacher, et Macélloth :

32. et Macélloth génuit Sámaa : habitaverúntque ex advérso fratrum suórum in Jerúsalem cum frátribus suis.

33. Ner autem génuit Cis, et Cis génuit Saul. Porro Saul génuit Jónathan, et Melchísua, et Abinádab, et Ésbaal.

34. Fílius autem Jónathan, Meríbbaal : et Meríbbaal génuit Micha.

35. Fílii Micha, Phithon, et Melech, et Tháraa, et Ahaz.

36. Et Ahaz génuit Joáda, et Joáda génuit Alámath, et Azmoth, et Zamri : porro Zamri génuit Mosa,

37. et Mosa génuit Bánaa, cujus fílius fuit Rapha, de quo ortus est Elása, qui génuit Asel.

38. Porro Asel sex fílii fuérunt his nomínibus : Ézricam, Bocru, Ísmahel, Sária, Óbdia, et Hanan : omnes hi fílii Asel.

39. Fílii autem Esec fratris ejus, Ulam primogénitus, et Jehus secúndus, et Eliphálet tértius.

40. Fuerúntque fílii Ulam viri robustíssimi, et magno róbore tendéntes arcum : et multos habéntes fílios ac nepótes, usque ad centum quinquagínta. Omnes hi fílii Bénjamin.

