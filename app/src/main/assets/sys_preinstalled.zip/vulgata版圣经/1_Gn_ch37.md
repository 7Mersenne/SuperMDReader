# Liber Genesis - Caput 37

1. Habitávit autem Jacob in terra Chánaan, in qua pater suus peregrinátus est.

2. Et hæ sunt generatiónes ejus : Joseph cum sédecim esset annórum, pascébat gregem cum frátribus suis adhuc puer : et erat cum fíliis Balæ et Zelphæ uxórum patris sui : accusavítque fratres suos apud patrem crímine péssimo.

3. Israël autem diligébat Joseph super omnes fílios suos, eo quod in senectúte genuísset eum : fecítque ei túnicam polýmitam.

4. Vidéntes autem fratres ejus quod a patre plus cunctis fíliis amarétur, óderant eum, nec póterant ei quidquam pacífice loqui.

5. Áccidit quoque ut visum sómnium reférret frátribus suis : quæ causa majóris ódii seminárium fuit.

6. Dixítque ad eos : Audíte sómnium meum quod vidi :

7. putábam nos ligáre manípulos in agro : et quasi consúrgere manípulum meum, et stare, vestrósque manípulos circumstántes adoráre manípulum meum.

8. Respondérunt fratres ejus : Numquid rex noster eris ? aut subjiciémur ditióni tuæ ? Hæc ergo causa somniórum atque sermónum, invídiæ et ódii fómitem ministrávit.

9. Áliud quoque vidit sómnium, quod narrans frátribus, ait : Vidi per sómnium, quasi solem, et lunam, et stellas úndecim adoráre me.

10. Quod cum patri suo, et frátribus retulísset, increpávit eum pater suus, et dixit : Quid sibi vult hoc sómnium quod vidísti ? num ego et mater tua, et fratres tui adorábimus te super terram ?

11. Invidébant ei ígitur fratres sui : pater vero rem tácitus considerábat.

12. Cumque fratres illíus in pascéndis grégibus patris moraréntur in Sichem,

13. dixit ad eum Israël : Fratres tui pascunt oves in Síchimis : veni, mittam te ad eos. Quo respondénte,

14. Præsto sum, ait ei : Vade, et vide si cuncta próspera sint erga fratres tuos, et pécora : et renúntia mihi quid agátur. Missus de valle Hebron, venit in Sichem :

15. invenítque eum vir errántem in agro, et interrogávit quid quǽreret.

16. At ille respóndit : Fratres meos quæro : índica mihi ubi pascant greges.

17. Dixítque ei vir : Recessérunt de loco isto : audívi autem eos dicéntes : Eámus in Dóthain. Perréxit ergo Joseph post fratres suos, et invénit eos in Dóthain.

18. Qui cum vidíssent eum procul, ántequam accéderet ad eos, cogitavérunt illum occídere :

19. et mútuo loquebántur : Ecce somniátor venit :

20. veníte, occidámus eum, et mittámus in cistérnam véterem : dicemúsque : Fera péssima devorávit eum : et tunc apparébit quid illi prosint sómnia sua.

21. Áudiens autem hoc Ruben, nitebátur liberáre eum de mánibus eórum, et dicébat :

22. Non interficiátis ánimam ejus, nec effundátis sánguinem : sed projícite eum in cistérnam hanc, quæ est in solitúdine, manúsque vestras serváte innóxias : hoc autem dicébat, volens erípere eum de mánibus eórum, et réddere patri suo.

23. Conféstim ígitur ut pervénit ad fratres suos, nudavérunt eum túnica talári et polýmita :

24. miserúntque eum in cistérnam véterem, quæ non habébat aquam.

25. Et sedéntes ut coméderent panem, vidérunt Ismaëlitas viatóres veníre de Gálaad, et cámelos eórum portántes arómata, et résinam, et stacten in Ægýptum.

26. Dixit ergo Judas frátribus suis : Quid nobis prodest si occidérimus fratrem nostrum, et celavérimus sánguinem ipsíus ?

27. mélius est ut venundétur Ismaëlitis, et manus nostræ non polluántur : frater enim et caro nostra est. Acquievérunt fratres sermónibus illíus.

28. Et prætereúntibus Madiánitis negotiatóribus, extrahéntes eum de cistérna, vendidérunt eum Ismaëlitis, vigínti argénteis : qui duxérunt eum in Ægýptum.

29. Reversúsque Ruben ad cistérnam, non invénit púerum :

30. et scissis véstibus pergens ad fratres suos, ait : Puer non compáret, et ego quo ibo ?

31. Tulérunt autem túnicam ejus, et in sánguine hædi, quem occíderant, tinxérunt :

32. mitténtes qui ferrent ad patrem, et dícerent : Hanc invénimus : vide utrum túnica fílii tui sit, an non.

33. Quam cum agnovísset pater, ait : Túnica fílii mei est : fera péssima comédit eum, béstia devorávit Joseph.

34. Scissísque véstibus, indútus est cilício, lugens fílium suum multo témpore.

35. Congregátis autem cunctis líberis ejus ut lenírent dolórem patris, nóluit consolatiónem accípere, sed ait : Descéndam ad fílium meum lugens in inférnum. Et illo perseveránte in fletu,

36. Madiánitæ vendidérunt Joseph in Ægýpto Putiphári eunúcho Pharaónis, magístro mílitum.

