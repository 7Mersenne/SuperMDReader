# Liber Genesis - Caput 22

1. Quæ postquam gesta sunt, tentávit Deus Ábraham, et dixit ad eum : Ábraham, Ábraham. At ille respóndit : Adsum.

2. Ait illi : Tolle fílium tuum unigénitum, quem díligis, Ísaac, et vade in terram visiónis, atque ibi ófferes eum in holocáustum super unum móntium quem monstrávero tibi.

3. Ígitur Ábraham de nocte consúrgens, stravit ásinum suum, ducens secum duos júvenes, et Ísaac fílium suum : cumque concidísset ligna in holocáustum, ábiit ad locum quem præcéperat ei Deus.

4. Die autem tértio, elevátis óculis, vidit locum procul :

5. dixítque ad púeros suos : Expectáte hic cum ásino : ego et puer illuc usque properántes, postquam adoravérimus, revertémur ad vos.

6. Tulit quoque ligna holocáusti, et impósuit super Ísaac fílium suum : ipse vero portábat in mánibus ignem et gládium. Cumque duo pérgerent simul,

7. dixit Ísaac patri suo : Pater mi. At ille respóndit : Quid vis, fili ? Ecce, inquit, ignis et ligna : ubi est víctima holocáusti ?

8. Dixit autem Ábraham : Deus providébit sibi víctimam holocáusti, fili mi. Pergébant ergo páriter.

9. Et venérunt ad locum quem osténderat ei Deus, in quo ædificávit altáre, et désuper ligna compósuit ; cumque alligásset Ísaac fílium suum, pósuit eum in altáre super struem lignórum.

10. Extendítque manum, et arrípuit gládium, ut immoláret fílium suum.

11. Et ecce ángelus Dómini de cælo clamávit, dicens : Ábraham, Ábraham. Qui respóndit : Adsum.

12. Dixítque ei : Non exténdas manum tuam super púerum, neque fácias illi quidquam : nunc cognóvi quod times Deum, et non pepercísti unigénito fílio tuo propter me.

13. Levávit Ábraham óculos suos, vidítque post tergum aríetem inter vepres hæréntem córnibus, quem assúmens óbtulit holocáustum pro fílio.

14. Appellavítque nomen loci illíus, Dóminus videt. Unde usque hódie dícitur : In monte Dóminus vidébit.

15. Vocávit autem ángelus Dómini Ábraham secúndo de cælo, dicens :

16. Per memetípsum jurávi, dicit Dóminus : quia fecísti hanc rem, et non pepercísti fílio tuo unigénito propter me :

17. benedícam tibi, et multiplicábo semen tuum sicut stellas cæli, et velut arénam quæ est in líttore maris : possidébit semen tuum portas inimicórum suórum,

18. et benedicéntur in sémine tuo omnes gentes terræ, quia obedísti voci meæ.

19. Revérsus est Ábraham ad púeros suos, abierúntque Bersabée simul, et habitávit ibi.

20. His ita gestis, nuntiátum est Ábrahæ quod Melcha quoque genuísset fílios Nachor fratri suo :

21. Hus primogénitum, et Buz fratrem ejus, et Cámuel patrem Syrórum,

22. et Cased, et Ázau, Pheldas quoque et Jedlaph,

23. ac Báthuel, de quo nata est Rebécca : octo istos génuit Melcha, Nachor fratri Ábrahæ.

24. Concubína vero illíus, nómine Roma, péperit Tábee, et Gaham, et Thahas, et Maácha.

