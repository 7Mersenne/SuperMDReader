# Liber Genesis - Caput 1

1. In princípio creávit Deus cælum et terram.

2. Terra autem erat inánis et vácua, et ténebræ erant super fáciem abýssi : et spíritus Dei ferebátur super aquas.

3. Dixítque Deus : Fiat lux. Et facta est lux.

4. Et vidit Deus lucem quod esset bona : et divísit lucem a ténebris.

5. Appellavítque lucem Diem, et ténebras Noctem : factúmque est véspere et mane, dies unus.

6. Dixit quoque Deus : Fiat firmaméntum in médio aquárum : et dívidat aquas ab aquis.

7. Et fecit Deus firmaméntum, divisítque aquas, quæ erant sub firmaménto, ab his, quæ erant super firmaméntum. Et factum est ita.

8. Vocavítque Deus firmaméntum, Cælum : et factum est véspere et mane, dies secúndus.

9. Dixit vero Deus : Congregéntur aquæ, quæ sub cælo sunt, in locum unum : et appáreat árida. Et factum est ita.

10. Et vocávit Deus áridam Terram, congregationésque aquárum appellávit Mária. Et vidit Deus quod esset bonum.

11. Et ait : Gérminet terra herbam viréntem, et faciéntem semen, et lignum pomíferum fáciens fructum juxta genus suum, cujus semen in semetípso sit super terram. Et factum est ita.

12. Et prótulit terra herbam viréntem, et faciéntem semen juxta genus suum, lignúmque fáciens fructum, et habens unumquódque seméntem secúndum spéciem suam. Et vidit Deus quod esset bonum.

13. Et factum est véspere et mane, dies tértius.

14. Dixit autem Deus : Fiant luminária in firmaménto cæli, et dívidant diem ac noctem, et sint in signa et témpora, et dies et annos :

15. ut lúceant in firmaménto cæli, et illúminent terram. Et factum est ita.

16. Fecítque Deus duo luminária magna : lumináre majus, ut præésset diéi : et lumináre minus, ut præésset nocti : et stellas.

17. Et pósuit eas in firmaménto cæli, ut lucérent super terram,

18. et præéssent diéi ac nocti, et divíderent lucem ac ténebras. Et vidit Deus quod esset bonum.

19. Et factum est véspere et mane, dies quartus.

20. Dixit étiam Deus : Prodúcant aquæ réptile ánimæ vivéntis, et volátile super terram sub firmaménto cæli.

21. Creavítque Deus cete grándia, et omnem ánimam vivéntem atque motábilem, quam prodúxerant aquæ in spécies suas, et omne volátile secúndum genus suum. Et vidit Deus quod esset bonum.

22. Benedixítque eis, dicens : Créscite, et multiplicámini, et repléte aquas maris : avésque multiplicéntur super terram.

23. Et factum est véspere et mane, dies quintus.

24. Dixit quoque Deus : Prodúcat terra ánimam vivéntem in génere suo, juménta, et reptília, et béstias terræ secúndum spécies suas. Factúmque est ita.

25. Et fecit Deus béstias terræ juxta spécies suas, et juménta, et omne réptile terræ in génere suo. Et vidit Deus quod esset bonum,

26. et ait : Faciámus hóminem ad imáginem et similitúdinem nostram : et præsit píscibus maris, et volatílibus cæli, et béstiis, universǽque terræ, omníque réptili, quod movétur in terra.

27. Et creávit Deus hóminem ad imáginem suam : ad imáginem Dei creávit illum, másculum et féminam creávit eos.

28. Benedixítque illis Deus, et ait : Créscite et multiplicámini, et repléte terram, et subjícite eam, et dominámini píscibus maris, et volatílibus cæli, et univérsis animántibus, quæ movéntur super terram.

29. Dixítque Deus : Ecce dedi vobis omnem herbam afferéntem semen super terram, et univérsa ligna quæ habent in semetípsis seméntem géneris sui, ut sint vobis in escam :

30. et cunctis animántibus terræ, omníque vólucri cæli, et univérsis quæ movéntur in terra, et in quibus est ánima vivens, ut hábeant ad vescéndum. Et factum est ita.

31. Vidítque Deus cuncta quæ fécerat, et erant valde bona. Et factum est véspere et mane, dies sextus.

