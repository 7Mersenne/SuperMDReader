# Liber Esther - Caput 11

1. Anno quarto regnántibus Ptolemǽo et Cleopátra, attulérunt Dosithǽus, qui se sacerdótem et Levítici géneris ferébat, et Ptolemǽus fílius ejus, hanc epístolam phurim, quam dixérunt interpretátum esse Lysimáchum Ptolemǽi fílium in Jerúsalem.

2. Anno secúndo, regnánte Artaxérxe máximo, prima die mensis Nisan, vidit sómnium Mardochǽus fílius Jaíri, fílii Sémei, fílii Cis, de tribu Bénjamin :

3. homo Judǽus, qui habitábat in urbe Susis, vir magnus, et inter primos aulæ régiæ.

4. Erat autem de eo número captivórum, quos transtúlerat Nabuchodonósor rex Babylónis de Jerúsalem cum Jechonía rege Juda.

5. Et hoc ejus sómnium fuit : apparuérunt voces, et tumúltus, et tonítrua, et terræmótus, et conturbátio super terram :

6. et ecce duo dracónes magni, paratíque contra se in prǽlium.

7. Ad quorum clamórem cunctæ concitátæ sunt natiónes, ut pugnárent contra gentem justórum.

8. Fuítque dies illa tenebrárum et discríminis, tribulatiónis et angústiæ, et ingens formído super terram.

9. Conturbatáque est gens justórum timéntium mala sua, et præparáta ad mortem.

10. Clamaverúntque ad Deum : et illis vociferántibus, fons parvus creávit in flúvium máximum, et in aquas plúrimas redundávit.

11. Lux et sol ortus est, et húmiles exaltáti sunt, et devoravérunt ínclytos.

12. Quod cum vidísset Mardochǽus, et surrexísset de strato, cogitábat quid Deus fácere vellet : et fixum habébat in ánimo, scire cúpiens quid significáret sómnium.

