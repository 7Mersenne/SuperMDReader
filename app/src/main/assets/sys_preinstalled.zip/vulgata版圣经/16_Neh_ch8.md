# Liber Nehemi� - Caput 8

1. Et vénerat mensis séptimus : fílii autem Israël erant in civitátibus suis. Congregatúsque est omnis pópulus quasi vir unus ad platéam quæ est ante portam aquárum : et dixérunt Esdræ scribæ ut afférret librum legis Móysi, quam præcéperat Dóminus Israëli.

2. Áttulit ergo Esdras sacérdos legem coram multitúdine virórum et mulíerum, cunctísque qui póterant intellígere, in die prima mensis séptimi.

3. Et legit in eo apérte in platéa quæ erat ante portam aquárum, de mane usque ad médiam diem, in conspéctu virórum et mulíerum, et sapiéntium : et aures omnis pópuli erant eréctæ ad librum.

4. Stetit autem Esdras scriba super gradum lígneum, quem fécerat ad loquéndum : et stetérunt juxta eum Matháthias, et Semeía, et Ánia, et Uría, et Helcía, et Maásia, ad déxteram ejus : et ad sinístram, Phadaía, Mísaël, et Mélchia, et Hasum, et Hasbadána, Zacharía, et Mosóllam.

5. Et apéruit Esdras librum coram omni pópulo : super univérsum quippe pópulum eminébat : et cum aperuísset eum, stetit omnis pópulus.

6. Et benedíxit Esdras Dómino Deo magno : et respóndit omnis pópulus : Amen, amen, élevans manus suas : et incurváti sunt, et adoravérunt Deum proni in terram.

7. Porro Jósue, et Bani, et Serébia, Jamin, Accub, Sépthai, Ódia, Maásia, Célita, Azarías, Jozábed, Hanan, Phalaía, Levítæ, siléntium faciébant in pópulo ad audiéndam legem : pópulus autem stabat in gradu suo.

8. Et legérunt in libro legis Dei distíncte, et apérte ad intelligéndum : et intellexérunt cum legerétur.

9. Dixit autem Nehemías (ípse est Athersátha) et Esdras sacérdos et scriba, et Levítæ interpretántes univérso pópulo : Dies sanctificátus est Dómino Deo nostro : nolíte lugére, et nolíte flere. Flebat enim omnis pópulus cum audíret verba legis.

10. Et dixit eis : Ite, comédite pínguia, et bíbite mulsum, et míttite partes his qui non præparavérunt sibi, quia sanctus dies Dómini est : et nolíte contristári : gáudium étenim Dómini est fortitúdo nostra.

11. Levítæ autem siléntium faciébant in omni pópulo, dicéntes : Tacéte, quia dies sanctus est, et nolíte dolére.

12. Ábiit ítaque omnis pópulus ut coméderet, et bíberet, et mítteret partes, et fáceret lætítiam magnam : quia intelléxerant verba quæ docúerat eos.

13. Et in die secúndo congregáti sunt príncipes familiárum univérsi pópuli, sacerdótes et Levítæ, ad Esdram scribam, ut interpretarétur eis verba legis.

14. Et invenérunt scriptum in lege præcepísse Dóminum in manu Móysi ut hábitent fílii Israël in tabernáculis in die solémni, mense séptimo :

15. et ut prædícent, et divúlgent vocem in univérsis úrbibus suis, et in Jerúsalem, dicéntes : Egredímini in montem, et afférte frondes olívæ, et frondes ligni pulchérrimi, frondes myrti, et ramos palmárum, et frondes ligni nemorósi, ut fiant tabernácula, sicut scriptum est.

16. Et egréssus est pópulus, et attulérunt. Fecerúntque sibi tabernácula unusquísque in domáte suo : et in átriis suis, et in átriis domus Dei, et in platéa portæ aquárum, et in platéa portæ Éphraim.

17. Fecit ergo univérsa ecclésia eórum qui redíerant de captivitáte, tabernácula, et habitavérunt in tabernáculis : non enim fécerant a diébus Jósue fílii Nun táliter fílii Israël usque ad diem illum. Et fuit lætítia magna nimis.

18. Legit autem in libro legis Dei per dies síngulos, a die primo usque ad diem novíssimum. Et fecérunt solemnitátem septem diébus, et in die octávo colléctam juxta ritum.

