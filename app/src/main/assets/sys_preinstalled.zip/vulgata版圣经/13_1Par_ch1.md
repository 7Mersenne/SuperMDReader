# Liber Primus Paralipomenon - Caput 1

1. Adam, Seth, Enos,

2. Cáinan, Maláleel, Jared,

3. Henoch, Mathusále, Lamech,

4. Noë, Sem, Cham, et Japtheth.

5. Fílii Japheth : Gomer, et Magog, et Mádai, et Javan, Thubal, Mosoch, Thiras.

6. Porro fílii Gomer : Áscenez, et Riphath, et Thogórma.

7. Fílii autem Javan : Elísa et Tharsis, Cethim et Dodánim.

8. Fílii Cham : Chus, et Mésraim, et Phut, et Chánaan.

9. Fílii autem Chus : Saba, et Hévila, Sabátha, et Regma, et Sabathácha. Porro fílii Regma : Saba, et Dadan.

10. Chus autem génuit Nemrod : iste cœpit esse potens in terra.

11. Mésraim vero génuit Ludim, et Anámim, et Laábim, et Néphtuim,

12. Phetrúsim quoque, et Cásluim : de quibus egréssi sunt Philísthiim, et Caphtórim.

13. Chánaan vero génuit Sidónem primogénitum suum, Hethǽum quoque,

14. et Jebusǽum, et Amorrhǽum, et Gergesǽum,

15. Hevæúmque et Aracǽum, et Sinǽum.

16. Arádium quoque, et Samarǽum, et Hamathǽum.

17. Fílii Sem : Ælam, et Assur, et Arpháxad, et Lud, et Aram, et Hus, et Hul, et Gether, et Mosoch.

18. Arpháxad autem génuit Sale, qui et ipse génuit Heber.

19. Porro Heber nati sunt duo fílii : nomen uni Phaleg, quia in diébus ejus divísa est terra ; et nomen fratris ejus Jectan.

20. Jectan autem génuit Élmodad, et Saleph, et Asármoth, et Jare,

21. Adóram quoque, et Huzal, et Decla,

22. Hebal étiam, et Abímaël, et Saba, necnon

23. et Ophir, et Hévila, et Jobab : omnes isti fílii Jectan.

24. Sem, Arpháxad, Sale,

25. Heber, Phaleg, Rágau,

26. Serug, Nachor, Thare,

27. Abram : iste est Ábraham.

28. Fílii autem Ábraham, Ísaac et Ísmahel.

29. Et hæ generatiónes eórum. Primogénitus Ismáhelis, Nabaíoth, et Cedar, et Ádbeel, et Mabsam,

30. et Masma, et Duma, Massa, Hadad, et Thema,

31. Jetur, Naphis, Cedma : hi sunt fílii Ismáhelis.

32. Fílii autem Cetúræ concubínæ Ábraham, quos génuit : Zamran, Jecsan, Madan, Mádian, Jesboc, et Sue. Porro fílii Jecsan : Saba, et Dadan. Fílii autem Dadan : Assúrim, et Latússim, et Laómim.

33. Fílii autem Mádian : Epha, et Epher, et Henoch, et Ábida, et Éldaa : omnes hi fílii Cetúræ.

34. Génuit autem Ábraham Ísaac : cujus fuérunt fílii Ésau, et Israël.

35. Fílii Ésau : Éliphaz, Ráhuel, Jehus, Íhelom, et Core.

36. Fílii Éliphaz : Theman, Omar, Sephi, Gathan, Cenez, Thamna, Ámalec.

37. Fílii Ráhuel : Nahath, Zara, Samma, Meza.

38. Fílii Seir : Lotan, Sobal, Sébeon, Ana, Dison, Eser, Disan.

39. Fílii Lotan : Hori, Homam. Soror autem Lotan fuit Thamna.

40. Fílii Sobal : Álian, et Mánahath, et Ebal, Sephi et Onam. Fílii Sébeon : Aja et Ana. Fílii Ana : Dison.

41. Fílii Dison : Hamram, et Heséban, et Jethran, et Charan.

42. Fílii Eser : Bálaan, et Zavan, et Jacan. Fílii Disan : Hus et Aran.

43. Isti sunt reges qui imperavérunt in terra Edom, ántequam esset rex super fílios Israël. Bale fílius Beor : et nomen civitátis ejus, Denába.

44. Mórtuus est autem Bale, et regnávit pro eo Jobab fílius Zare de Bosra.

45. Cumque et Jobab fuísset mórtuus, regnávit pro eo Husam de terra Themanórum.

46. Óbiit quoque et Husam, et regnávit pro eo Adad fílius Badad, qui percússit Mádian in terra Moab : et nomen civitátis ejus Avith.

47. Cumque et Adad fuísset mórtuus, regnávit pro eo Semla de Masréca.

48. Sed et Semla mórtuus est, et regnávit pro eo Saul de Rohóboth, quæ juxta amnem sita est.

49. Mórtuo quoque Saul, regnávit pro eo Balánan fílius Achóbor.

50. Sed et hic mórtuus est, et regnávit pro eo Adad : cujus urbis nomen fuit Phau, et appelláta est uxor ejus Meetábel fília Matred fíliæ Mézaab.

51. Adad autem mórtuo, duces pro régibus in Edom esse cœpérunt : dux Thamna, dux Alva, dux Jetheth,

52. dux Oolibáma, dux Ela, dux Phinon,

53. dux Cenez, dux Theman, dux Mabsar,

54. dux Mágdiel, dux Hiram : hi duces Edom.

