# Liber Esdr� - Caput 5

1. Prophetavérunt autem Aggǽus prophéta, et Zacharías fílius Addo, prophetántes ad Judǽos qui erant in Judǽa et Jerúsalem, in nómine Dei Israël.

2. Tunc surrexérunt Zoróbabel fílius Saláthiel, et Jósue fílius Jósedec, et cœpérunt ædificáre templum Dei in Jerúsalem, et cum eis prophétæ Dei adjuvántes eos.

3. In ipso autem témpore venit ad eos Thathánai, qui erat dux trans flumen, et Stharbuzánai, et consiliárii eórum : sicque dixérunt eis : Quis dedit vobis consílium ut domum hanc ædificarétis, et muros ejus instaurarétis ?

4. Ad quod respóndimus eis, quæ essent nómina hóminum auctórum ædificatiónis illíus.

5. Óculus autem Dei eórum factus est super senes Judæórum, et non potuérunt inhíbere eos. Placuítque ut res ad Daríum referrétur, et tunc satisfácerent advérsus accusatiónem illam.

6. Exémplar epístolæ, quam misit Thathánai dux regiónis trans flumen, et Stharbuzánai, et consiliatóres ejus Arphasachǽi, qui erant trans flumen, ad Daríum regem.

7. Sermo, quem míserant ei, sic scriptus erat : Darío regi pax omnis.

8. Notum sit regi, isse nos ad Judǽam provínciam, ad domum Dei magni, quæ ædificátur lápide impólito, et ligna ponúntur in pariétibus : opúsque illud diligénter exstrúitur, et crescit in mánibus eórum.

9. Interrogávimus ergo senes illos, et ita díximus eis : Quis dedit vobis potestátem ut domum hanc ædificarétis, et muros hos instaurarétis ?

10. Sed et nómina eórum quæsívimus ab eis, ut nuntiarémus tibi : scripsimúsque nómina eórum virórum, qui sunt príncipes in eis.

11. Hujuscémodi autem sermónem respondérunt nobis dicéntes : Nos sumus servi Dei cæli et terræ, et ædificámus templum, quod erat exstrúctum ante hos annos multos, quodque rex Israël magnus ædificáverat, et exstrúxerat.

12. Postquam autem ad iracúndiam provocavérunt patres nostri Deum cæli, trádidit eos in manus Nabuchodonósor regis Babylónis Chaldǽi, domum quoque hanc destrúxit, et pópulum ejus tránstulit in Babylónem.

13. Anno autem primo Cyri regis Babylónis, Cyrus rex propósuit edíctum ut domus Dei hæc ædificarétur.

14. Nam et vasa templi Dei áurea et argéntea, quæ Nabuchodonósor túlerat de templo, quod erat in Jerúsalem, et asportáverat ea in templum Babylónis, prótulit Cyrus rex de templo Babylónis, et data sunt Sassabásar vocábulo, quem et príncipem constítuit,

15. dixítque ei : Hæc vasa tolle, et vade, et pone ea in templo, quod est in Jerúsalem, et domus Dei ædificétur in loco suo.

16. Tunc ítaque Sassabásar ille venit et pósuit fundaménta templi Dei in Jerúsalem, et ex eo témpore usque nunc ædificátur, et necdum complétum est.

17. Nunc ergo si vidétur regi bonum, recénseat in bibliothéca regis, quæ est in Babylóne, utrúmnam a Cyro rege jussum fúerit ut ædificarétur domus Dei in Jerúsalem, et voluntátem regis super hac re mittat ad nos.

