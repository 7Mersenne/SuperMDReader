# Liber Nehemi� - Caput 11

1. Habitavérunt autem príncipes pópuli in Jerúsalem : réliqua vero plebs misit sortem, ut tóllerent unam partem de decem qui habitatúri essent in Jerúsalem civitáte sancta, novem vero partes in civitátibus.

2. Benedíxit autem pópulus ómnibus viris qui se sponte obtúlerant ut habitárent in Jerúsalem.

3. Hi sunt ítaque príncipes provínciæ qui habitavérunt in Jerúsalem, et in civitátibus Juda. Habitávit autem unusquísque in possessióne sua, in úrbibus suis, Israël, sacerdótes, Levítæ, Nathinǽi, et fílii servórum Salomónis.

4. Et in Jerúsalem habitavérunt de fíliis Juda, et de fíliis Bénjamin : de fíliis Juda, Athaías fílius Áziam, fílii Zacharíæ, fílii Amáriæ, fílii Saphátiæ, fílii Meláleel : de fíliis Phares,

5. Maásia fílius Baruch, fílius Cholhóza, fílius Házia, fílius Adaía, fílius Jojárib, fílius Zacharíæ, fílius Silónitis :

6. omnes hi fílii Phares, qui habitavérunt in Jerúsalem, quadringénti sexagínta octo viri fortes.

7. Hi sunt autem fílii Bénjamin : Sellum fílius Mosóllam, fílius Joëd, fílius Phadaía, fílius Colaía, fílius Másia, fílius Étheel, fílius Isaía,

8. et post eum Gébbai, Séllai, nongénti vigínti octo,

9. et Joël fílius Zechri præpósitus eórum, et Judas fílius Sénua super civitátem secúndus.

10. Et de sacerdótibus, Idaía fílius Joárib, Jachin,

11. Saraía fílius Helcíæ, fílius Mosóllam, fílius Sadoc, fílius Meraíoth, fílius Áchitob princeps domus Dei,

12. et fratres eórum faciéntes ópera templi : octingénti vigínti duo. Et Adaía fílius Jéroham, fílius Phelélia, fílius Amsi, fílius Zacharíæ, fílius Pheshur, fílius Mélchiæ,

13. et fratres ejus príncipes patrum : ducénti quadragínta duo. Et Amássai fílius Ázreel, fílius Aházi, fílius Mosollámoth, fílius Emmer,

14. et fratres eórum poténtes nimis : centum vigínti octo, et præpósitus eórum Zábdiel fílius poténtium.

15. Et de Levítis, Semeía fílius Hasub, fílius Azáricam, fílius Hasábia, fílius Boni,

16. et Sabáthai et Jozábed, super ómnia ópera quæ erant forínsecus in domo Dei, a princípibus Levitárum.

17. Et Mathánia fílius Micha, fílius Zebédei, fílius Asaph, princeps ad laudándum et ad confiténdum in oratióne, et Becbécia secúndus de frátribus ejus, et Abda fílius Sámua, fílius Galal, fílius Ídithun :

18. omnes Levítæ in civitáte sancta ducénti octogínta quátuor.

19. Et janitóres, Accub, Telmon, et fratres eórum, qui custodiébant óstia : centum septuagínta duo.

20. Et réliqui ex Israël sacerdótes et Levítæ in univérsis civitátibus Juda, unusquísque in possessióne sua.

21. Et Nathinǽi, qui habitábant in Ophel, et Siáha, et Gaspha de Nathinǽis.

22. Et epíscopus Levitárum in Jerúsalem, Azzi fílius Bani, fílius Hasábiæ, fílius Mathániæ, fílius Michæ. De fíliis Asaph, cantóres in ministério domus Dei.

23. Præcéptum quippe regis super eos erat, et ordo in cantóribus per dies síngulos,

24. et Phatháhia fílius Mesezébel, de fíliis Zara fílii Juda in manu regis, juxta omne verbum pópuli,

25. et in dómibus per omnes regiónes eórum. De fíliis Juda habitavérunt in Cariathárbe et in filiábus ejus : et in Dibon, et in filiábus ejus : et in Cábseel, et in vículis ejus :

26. et in Jésue, et in Moláda, et in Bethpháleth,

27. et in Hasérsual, et in Bersabée, et in filiábus ejus,

28. et in Síceleg, et in Mochóna, et in filiábus ejus,

29. et in Remmon, et in Sáraa, et in Jérimuth,

30. Zánoa, Odóllam, et in villis eárum, Lachis et regiónibus ejus, et Azéca, et filiábus ejus. Et mansérunt in Bersabée usque ad vallem Ennom.

31. Fílii autem Bénjamin, a Geba, Mechmas, et Hai, et Bethel, et filiábus ejus

32. Anáthoth, Nob, Ananía,

33. Asor, Rama, Géthaim,

34. Hadid, Séboim, et Nebállat, Lod,

35. et Ono valle artíficum.

36. Et de Levítis portiónes Judæ et Bénjamin.

