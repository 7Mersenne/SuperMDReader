# Liber Judith - Caput 4

1. Tunc audiéntes hæc fílii Israël qui habitábant in terra Juda, timuérunt valde a fácie ejus.

2. Tremor et horror invásit sensus eórum, ne hoc fáceret Jerúsalem et templo Dómini, quod fécerat céteris civitátibus et templis eárum.

3. Et misérunt in omnem Samaríam per circúitum usque Jéricho, et præoccupavérunt omnes vértices móntium :

4. et muris circumdedérunt vicos suos, et congregavérunt fruménta in præparatiónem pugnæ.

5. Sacérdos étiam Eliáchim scripsit ad univérsos qui erant contra Ésdrelon, quæ est contra fáciem campi magni juxta Dóthain, et univérsos per quos viæ tránsitus esse póterat,

6. ut obtinérent ascénsus móntium, per quos via esse póterat ad Jerúsalem, et illic custodírent ubi angústum iter esse póterat inter montes.

7. Et fecérunt fílii Israël secúndum quod constitúerat eis sacérdos Dómini Eliáchim.

8. Et clamávit omnis pópulus ad Dóminum instántia magna, et humiliavérunt ánimas suas in jejúniis et oratiónibus, ipsi et mulíeres eórum.

9. Et induérunt se sacerdótes cilíciis, et infántes prostravérunt contra fáciem templi Dómini, et altáre Dómini operuérunt cilício :

10. et clamavérunt ad Dóminum Deum Israël unanímiter ne daréntur in prædam infántes eórum, et uxóres eórum in divisiónem, et civitátes eórum in extermínium, et sancta eórum in pollutiónem, et fíerent oppróbrium géntibus.

11. Tunc Eliáchim sacérdos Dómini magnus circuívit omnem Israël, allocutúsque est eos,

12. dicens : Scitóte quóniam exáudiet Dóminus preces vestras, si manéntes permanséritis in jejúniis et oratiónibus in conspéctu Dómini.

13. Mémores estóte Móysi servi Dómini, qui Ámalec confidéntem in virtúte sua, et in poténtia sua, et in exércitu suo, et in clýpeis suis, et in cúrribus suis, et in equítibus suis, non ferro pugnándo, sed précibus sanctis orándo dejécit :

14. sic erunt univérsi hostes Israël, si perseveravéritis in hoc ópere quod cœpístis.

15. Ad hanc ígitur exhortatiónem ejus deprecántes Dóminum, permanébant in conspéctu Dómini,

16. ita ut étiam hi qui offerébant Dómino holocáusta, præcíncti cilíciis offérrent sacrifícia Dómino, et erat cinis super cápita eórum.

17. Et ex toto corde suo omnes orábant Deum, ut visitáret pópulum suum Israël.

