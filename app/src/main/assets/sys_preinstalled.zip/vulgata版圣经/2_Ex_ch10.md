# Liber Exodus - Caput 10

1. Et dixit Dóminus ad Móysen : Ingrédere ad Pharaónem : ego enim indurávi cor ejus, et servórum illíus, ut fáciam signa mea hæc in eo :

2. et narres in áuribus fílii tui, et nepótum tuórum, quóties contríverim Ægýptios, et signa mea fécerim in eis : et sciátis quia ego Dóminus.

3. Introiérunt ergo Móyses et Áaron ad Pharaónem, et dixérunt ei : Hæc dicit Dóminus Deus Hebræórum : Úsquequo non vis súbjici mihi ? dimítte pópulum meum, ut sacríficet mihi.

4. Sin autem resístis, et non vis dimíttere eum : ecce ego indúcam cras locústam in fines tuos :

5. quæ opériat superfíciem terræ, ne quidquam ejus appáreat, sed comedátur quod resíduum fúerit grándini : corródet enim ómnia ligna quæ gérminant in agris.

6. Et implébunt domos tuas, et servórum tuórum, et ómnium Ægyptiórum, quantam non vidérunt patres tui, et avi, ex quo orti sunt super terram, usque in præséntem diem. Avertítque se, et egréssus est a Pharaóne.

7. Dixérunt autem servi Pharaónis ad eum : Úsquequo patiémur hoc scándalum ? dimítte hómines, ut sacríficent Dómino Deo suo ; nonne vides quod períerit Ægýptus ?

8. Revocaverúntque Móysen et Áaron ad Pharaónem : qui dixit eis : Ite, sacrificáte Dómino Deo vestro : quinam sunt qui itúri sunt ?

9. Ait Móyses : Cum párvulis nostris, et senióribus pergémus, cum fíliis et filiábus, cum óvibus et arméntis : est enim solémnitas Dómini Dei nostri.

10. Et respóndit Phárao : Sic Dóminus sit vobíscum, quómodo ego dimíttam vos, et párvulos vestros, cui dúbium est quod péssime cogitétis ?

11. non fiet ita, sed ite tantum viri, et sacrificáte Dómino : hoc enim et ipsi petístis. Statímque ejécti sunt de conspéctu Pharaónis.

12. Dixit autem Dóminus ad Móysen : Exténde manum tuam super terram Ægýpti ad locústam, ut ascéndat super eam, et dévoret omnem herbam quæ resídua fúerit grándini.

13. Et exténdit Móyses virgam super terram Ægýpti : et Dóminus indúxit ventum uréntem tota die illa et nocte : et mane facto, ventus urens levávit locústas.

14. Quæ ascendérunt super univérsam terram Ægýpti : et sedérunt in cunctis fínibus Ægyptiórum innumerábiles, quales ante illud tempus non fúerant, nec póstea futúræ sunt.

15. Operuerúntque univérsam superfíciem terræ, vastántes ómnia. Devoráta est ígitur herba terræ, et quidquid pomórum in arbóribus fuit, quæ grando dimíserat : nihílque omníno virens relíctum est in lignis et in herbis terræ, in cuncta Ægýpto.

16. Quam ob rem festínus Phárao vocávit Móysen et Áaron, et dixit eis : Peccávi in Dóminum Deum vestrum, et in vos.

17. Sed nunc dimíttite peccátum mihi étiam hac vice, et rogáte Dóminum Deum vestrum, ut áuferat a me mortem istam.

18. Egressúsque Móyses de conspéctu Pharaónis, orávit Dóminum.

19. Qui flare fecit ventum ab occidénte vehementíssimum, et arréptam locústam projécit in mare Rubrum : non remánsit ne una quidem in cunctis fínibus Ægýpti.

20. Et indurávit Dóminus cor Pharaónis, nec dimísit fílios Israël.

21. Dixit autem Dóminus ad Móysen : Exténde manum tuam in cælum : et sint ténebræ super terram Ægýpti tam densæ, ut palpári queant.

22. Extendítque Móyses manum in cælum : et factæ sunt ténebræ horríbiles in univérsa terra Ægýpti tribus diébus.

23. Nemo vidit fratrem suum, nec movit se de loco in quo erat : ubicúmque autem habitábant fílii Israël, lux erat.

24. Vocavítque Phárao Móysen et Áaron, et dixit eis : Ite, sacrificáte Dómino : oves tantum vestræ et arménta remáneant, párvuli vestri eant vobíscum.

25. Ait Móyses : Hóstias quoque et holocáusta dabis nobis, quæ offerámus Dómino Deo nostro.

26. Cuncti greges pergent nobíscum ; non remanébit ex eis úngula : quæ necessária sunt in cultum Dómini Dei nostri : præsértim cum ignorémus quid débeat immolári, donec ad ipsum locum perveniámus.

27. Indurávit autem Dóminus cor Pharaónis, et nóluit dimíttere eos.

28. Dixítque Phárao ad Móysen : Recéde a me, et cave ne ultra vídeas fáciem meam : quocúmque die apparúeris mihi, moriéris.

29. Respóndit Móyses : Ita fiet ut locútus es : non vidébo ultra fáciem tuam.

