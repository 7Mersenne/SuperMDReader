# Liber Genesis - Caput 29

1. Proféctus ergo Jacob venit in terram orientálem.

2. Et vidit púteum in agro, tres quoque greges óvium accubántes juxta eum : nam ex illo adaquabántur pécora, et os ejus grandi lápide claudebátur.

3. Morísque erat ut cunctis óvibus congregátis devólverent lápidem, et reféctis grégibus rursum super os pútei pónerent.

4. Dixítque ad pastóres : Fratres, unde estis ? Qui respondérunt : De Haran.

5. Quos intérrogans, Numquid, ait, nostis Laban fílium Nachor ? Dixérunt : Nóvimus.

6. Sanúsne est ? inquit. Valet, ínquiunt : et ecce Rachel fília ejus venit cum grege suo.

7. Dixítque Jacob : Adhuc multum diéi súperest, nec est tempus ut reducántur ad caulas greges : date ante potum óvibus, et sic eas ad pastum redúcite.

8. Qui respondérunt : Non póssumus, donec ómnia pécora congregéntur, et amoveámus lápidem de ore pútei, ut adaquémus greges.

9. Adhuc loquebántur, et ecce Rachel veniébat cum óvibus patris sui : nam gregem ipsa pascébat.

10. Quam cum vidísset Jacob, et sciret consobrínam suam, ovésque Laban avúnculi sui, amóvit lápidem quo púteus claudebátur.

11. Et adaquáto grege, osculátus est eam : et eleváta voce flevit,

12. et indicávit ei quod frater esset patris sui, et fílius Rebéccæ : at illa festínans nuntiávit patri suo.

13. Qui cum audísset venísse Jacob fílium soróris suæ, cucúrrit óbviam ei : complexúsque eum, et in óscula ruens, duxit in domum suam. Audítis autem causis itíneris,

14. respóndit : Os meum es, et caro mea. Et postquam impléti sunt dies mensis uníus,

15. dixit ei : Num quia frater meus es, gratis sérvies mihi ? dic quid mercédis accípias.

16. Habébat vero duas fílias : nomen majóris Lia, minor vero appellabátur Rachel.

17. Sed Lia lippis erat óculis : Rachel decóra fácie, et venústo aspéctu.

18. Quam díligens Jacob, ait : Sérviam tibi pro Rachel fília tua minóre, septem annis.

19. Respóndit Laban : Mélius est ut tibi eam dem quam álteri viro : mane apud me.

20. Servívit ergo Jacob pro Rachel septem annis : et videbántur illi pauci dies præ amóris magnitúdine.

21. Dixítque ad Laban : Da mihi uxórem meam : quia jam tempus implétum est, ut ingrédiar ad illam.

22. Qui vocátis multis amicórum turbis ad convívium, fecit núptias.

23. Et véspere Liam fíliam suam introdúxit ad eum,

24. dans ancíllam fíliæ, Zelpham nómine. Ad quam cum ex more Jacob fuísset ingréssus, facto mane vidit Liam :

25. et dixit ad sócerum suum : Quid est quod fácere voluísti ? nonne pro Rachel servívi tibi ? quare imposuísti mihi ?

26. Respóndit Laban : Non est in loco nostro consuetúdinis, ut minóres ante tradámus ad núptias.

27. Imple hebdómadam diérum hujus cópulæ : et hanc quoque dabo tibi pro ópere quo servitúrus es mihi septem annis áliis.

28. Acquiévit plácito : et hebdómada transácta, Rachel duxit uxórem :

29. cui pater servam Balam tradíderat.

30. Tandémque pótitus optátis núptiis, amórem sequéntis prióri prǽtulit, sérviens apud eum septem annis áliis.

31. Videns autem Dóminus quod despíceret Liam, apéruit vulvam ejus, soróre stérili permanénte.

32. Quæ concéptum génuit fílium, vocavítque nomen ejus Ruben, dicens : Vidit Dóminus humilitátem meam : nunc amábit me vir meus.

33. Rursúmque concépit et péperit fílium, et ait : Quóniam audívit me Dóminus habéri contémptui, dedit étiam istum mihi ; vocavítque nomen ejus Símeon.

34. Concepítque tértio, et génuit álium fílium : dixítque : Nunc quoque copulábitur mihi máritus meus : eo quod pepérerim ei tres fílios : et idcírco appellávit nomen ejus Levi.

35. Quarto concépit, et péperit fílium, et ait : Modo confitébor Dómino, et ob hoc vocávit eum Judam : cessavítque párere.

