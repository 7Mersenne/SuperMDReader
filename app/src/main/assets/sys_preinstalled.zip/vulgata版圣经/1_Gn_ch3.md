# Liber Genesis - Caput 3

1. Sed et serpens erat callídior cunctis animántibus terræ quæ fécerat Dóminus Deus. Qui dixit ad mulíerem : Cur præcépit vobis Deus ut non comederétis de omni ligno paradísi ?

2. Cui respóndit múlier : De fructu lignórum, quæ sunt in paradíso, véscimur :

3. de fructu vero ligni quod est in médio paradísi, præcépit nobis Deus ne comederémus, et ne tangerémus illud, ne forte moriámur.

4. Dixit autem serpens ad mulíerem : Nequáquam morte moriémini.

5. Scit enim Deus quod in quocúmque die comedéritis ex eo, aperiéntur óculi vestri, et éritis sicut dii, sciéntes bonum et malum.

6. Vidit ígitur múlier quod bonum esset lignum ad vescéndum, et pulchrum óculis, aspectúque delectábile : et tulit de fructu illíus, et comédit : dedítque viro suo, qui comédit.

7. Et apérti sunt óculi ambórum ; cumque cognovíssent se esse nudos, consuérunt fólia ficus, et fecérunt sibi perizomáta.

8. Et cum audíssent vocem Dómini Dei deambulántis in paradíso ad auram post merídiem, abscóndit se Adam et uxor ejus a fácie Dómini Dei in médio ligni paradísi.

9. Vocavítque Dóminus Deus Adam, et dixit ei : Ubi es ?

10. Qui ait : Vocem tuam audívi in paradíso, et tímui, eo quod nudus essem, et abscóndi me.

11. Cui dixit : Quis enim indicávit tibi quod nudus esses, nisi quod ex ligno de quo præcéperam tibi ne coméderes, comedísti ?

12. Dixítque Adam : Múlier, quam dedísti mihi sóciam, dedit mihi de ligno, et comédi.

13. Et dixit Dóminus Deus ad mulíerem : Quare hoc fecísti ? Quæ respóndit : Serpens decépit me, et comédi.

14. Et ait Dóminus Deus ad serpéntem : Quia fecísti hoc, maledíctus es inter ómnia animántia, et béstias terræ : super pectus tuum gradiéris, et terram cómedes cunctis diébus vitæ tuæ.

15. Inimicítias ponam inter te et mulíerem, et semen tuum et semen illíus : ipsa cónteret caput tuum, et tu insidiáberis calcáneo ejus.

16. Mulíeri quoque dixit : Multiplicábo ærúmnas tuas, et concéptus tuos : in dolóre páries fílios, et sub viri potestáte eris, et ipse dominábitur tui.

17. Adæ vero dixit : Quia audísti vocem uxóris tuæ, et comedísti de ligno, ex quo præcéperam tibi ne coméderes, maledícta terra in ópere tuo : in labóribus cómedes ex ea cunctis diébus vitæ tuæ.

18. Spinas et tríbulos germinábit tibi, et cómedes herbam terræ.

19. In sudóre vultus tui vésceris pane, donec revertáris in terram de qua sumptus es : quia pulvis es et in púlverem revertéris.

20. Et vocávit Adam nomen uxóris suæ, Heva : eo quod mater esset cunctórum vivéntium.

21. Fecit quoque Dóminus Deus Adæ et uxóri ejus túnicas pellíceas, et índuit eos :

22. et ait : Ecce Adam quasi unus ex nobis factus est, sciens bonum et malum : nunc ergo ne forte mittat manum suam, et sumat étiam de ligno vitæ, et cómedat, et vivat in ætérnum.

23. Et emísit eum Dóminus Deus de paradíso voluptátis, ut operarétur terram de qua sumptus est.

24. Ejecítque Adam : et collocávit ante paradísum voluptátis chérubim, et flámmeum gládium, atque versátilem, ad custodiéndam viam ligni vitæ.

