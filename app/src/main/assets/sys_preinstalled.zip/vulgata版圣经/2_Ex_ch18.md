# Liber Exodus - Caput 18

1. Cumque audísset Jethro, sacérdos Mádian, cognátus Móysi, ómnia quæ fécerat Deus Móysi, et Israëli pópulo suo, et quod eduxísset Dóminus Israël de Ægýpto,

2. tulit Sephóram uxórem Móysi quam remíserat,

3. et duos fílios ejus : quorum unus vocabátur Gersam, dicénte patre : Ádvena fui in terra aliéna ;

4. alter vero Eliézer : Deus enim, ait, patris mei adjútor meus, et éruit me de gládio Pharaónis.

5. Venit ergo Jethro cognátus Móysi, et fílii ejus, et uxor ejus ad Móysen in desértum, ubi erat castrametátus juxta montem Dei.

6. Et mandávit Móysi, dicens : Ego Jethro cognátus tuus vénio ad te, et uxor tua, et duo fílii cum ea.

7. Qui egréssus in occúrsum cognáti sui, adorávit, et osculátus est eum : salutaverúntque se mútuo verbis pacíficis. Cumque intrásset tabernáculum,

8. narrávit Móyses cognáto suo cuncta quæ fécerat Dóminus Pharaóni et Ægýptiis propter Israël : universúmque labórem, qui accidísset eis in itínere, et quod liberáverat eos Dóminus.

9. Lætatúsque est Jethro super ómnibus bonis, quæ fécerat Dóminus Israëli, eo quod eruísset eum de manu Ægyptiórum.

10. Et ait : Benedíctus Dóminus, qui liberávit vos de manu Ægyptiórum, et de manu Pharaónis ; qui éruit pópulum suum de manu Ægýpti.

11. Nunc cognóvi, quia magnus Dóminus super omnes deos : eo quod supérbe égerint contra illos.

12. Óbtulit ergo Jethro cognátus Móysi holocáusta et hóstias Deo : venerúntque Áaron et omnes senióres Israël, ut coméderent panem cum eo coram Deo.

13. Áltera autem die sedit Móyses ut judicáret pópulum, qui assistébat Móysi a mane usque ad vésperam.

14. Quod cum vidísset cognátus ejus, ómnia scílicet quæ agébat in pópulo, ait : Quid est hoc quod facis in plebe ? cur solus sedes, et omnis pópulus præstolátur de mane usque ad vésperam ?

15. Cui respóndit Móyses : Venit ad me pópulus quærens senténtiam Dei :

16. cumque accíderit eis áliqua disceptátio, véniunt ad me ut júdicem inter eos, et osténdam præcépta Dei, et leges ejus.

17. At ille : Non bonam, inquit, rem facis.

18. Stulto labóre consúmeris et tu, et pópulus iste qui tecum est : ultra vires tuas est negótium ; solus illud non póteris sustinére.

19. Sed audi verba mea atque consília, et erit Deus tecum. Esto tu pópulo in his quæ ad Deum pértinent, ut réferas quæ dicúntur ad eum :

20. ostendásque pópulo cæremónias et ritum coléndi, viámque per quam íngredi débeant, et opus quod fácere débeant.

21. Próvide autem de omni plebe viros poténtes, et timéntes Deum, in quibus sit véritas, et qui óderint avarítiam, et constítue ex eis tribúnos, et centuriónes, et quinquagenários, et decános,

22. qui júdicent pópulum omni témpore : quidquid autem majus fúerit, réferant ad te, et ipsi minóra tantúmmodo júdicent : leviúsque sit tibi, partíto in álios ónere.

23. Si hoc féceris, implébis impérium Dei, et præcépta ejus póteris sustentáre : et omnis hic pópulus revertétur ad loca sua cum pace.

24. Quibus audítis, Móyses fecit ómnia quæ ille suggésserat.

25. Et eléctis viris strénuis de cuncto Israël, constítuit eos príncipes pópuli, tribúnos, et centuriónes, et quinquagenários, et decános.

26. Qui judicábant plebem omni témpore : quidquid autem grávius erat, referébant ad eum, facilióra tantúmmodo judicántes.

27. Dimisítque cognátum suum : qui revérsus ábiit in terram suam.

