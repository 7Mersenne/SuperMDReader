# Liber Nehemi� - Caput 4

1. Factum est autem, cum audísset Sanabállat quod ædificarémus murum, irátus est valde : et motus nimis subsannávit Judǽos,

2. et dixit coram frátribus suis, et frequéntia Samaritanórum : Quid Judǽi fáciunt imbecílles ? num dimíttent eos gentes ? num sacrificábunt, et complébunt in una die ? numquid ædificáre póterunt lápides de acérvis púlveris, qui combústi sunt ?

3. Sed et Tobías Ammánites, próximus ejus, ait : Ædíficent : si ascénderit vulpes, transíliet murum eórum lapídeum.

4. Audi, Deus noster, quia facti sumus despéctui : convérte oppróbrium super caput eórum, et da eos in despectiónem in terra captivitátis.

5. Ne opérias iniquitátem eórum, et peccátum eórum coram fácie tua non deleátur, quia irrisérunt ædificántes.

6. Ítaque ædificávimus murum, et conjúnximus totum usque ad partem dimídiam : et provocátum est cor pópuli ad operándum.

7. Factum est autem, cum audísset Sanabállat, et Tobías, et Árabes, et Ammánitæ, et Azótii, quod obdúcta esset cicátrix muri Jerúsalem, et quod cœpíssent interrúpta conclúdi, iráti sunt nimis.

8. Et congregáti sunt omnes páriter ut venírent, et pugnárent contra Jerúsalem, et moliréntur insídias.

9. Et orávimus Deum nostrum, et posúimus custódes super murum die ac nocte contra eos.

10. Dixit autem Judas : Debilitáta est fortitúdo portántis, et humus nímia est, et nos non potérimus ædificáre murum.

11. Et dixérunt hostes nostri : Nésciant, et ignórent donec veniámus in médium eórum, et interficiámus eos, et cessáre faciámus opus.

12. Factum est autem veniéntibus Judǽis qui habitábant juxta eos, et dicéntibus nobis per decem vices, ex ómnibus locis quibus vénerant ad nos,

13. státui in loco post murum per circúitum pópulum in órdinem cum gládiis suis, et lánceis, et arcúbus.

14. Et perspéxi atque surréxi : et aío ad optimátes et magistrátus, et ad réliquam partem vulgi : Nolíte timére a fácie eórum : Dómini magni et terríbilis mementóte, et pugnáte pro frátribus vestris, fíliis vestris, et filiábus vestris, et uxóribus vestris, et dómibus vestris.

15. Factum est autem, cum audíssent inimíci nostri nuntiátum esse nobis, dissipávit Deus consílium eórum. Et revérsi sumus omnes ad muros, unusquísque ad opus suum.

16. Et factum est a die illa, média pars júvenum eórum faciébat opus, et média paráta erat ad bellum : et lánceæ, et scuta, et arcus, et lorícæ, et príncipes post eos in omni domo Juda.

17. Ædificántium in muro, et portántium ónera, et imponéntium : una manu sua faciébat opus, et áltera tenébat gládium :

18. ædificéntium enim unusquísque gládio erat accínctus renes. Et ædificábant, et clangébant búccina juxta me.

19. Et dixi ad optimátes, et ad magistrátus, et ad réliquam partem vulgi : Opus grande est et latum, et nos separáti sumus in muro procul alter ab áltero :

20. in loco quocúmque audiéritis clangórem tubæ, illuc concúrrite ad nos : Deus noster pugnábit pro nobis.

21. Et nos ipsi faciámus opus, et média pars nostrum téneat lánceas ab ascénsu auróræ donec egrediántur astra.

22. In témpore quoque illo dixi pópulo : Unusquísque cum púero suo máneat in médio Jerúsalem, et sint nobis vices per noctem et diem ad operándum.

23. Ego autem et fratres mei, et púeri mei, et custódes, qui erant post me, non deponebámus vestiménta nostra : unusquísque tantum nudabátur ad baptísmum.

