# Liber Judith - Caput 8

1. Et factum est cum audísset hæc verba Judith vídua, quæ erat fília Merári fílii Idox fílii Joseph fílii Ozíæ fílii Élai fílii Jamnor fílii Gédeon fílii Ráphaim fílii Áchitob fílii Mélchiæ fílii Enan fílii Nathániæ fílii Saláthiel fílii Símeon fílii Ruben,

2. et vir ejus fuit Manásses, qui mórtuus est in diébus messis hordeáceæ :

3. instábat enim super alligántes manípulos in campo, et venit æstus super caput ejus, et mórtuus est in Bethúlia civitáte sua, et sepúltus est illic cum pátribus suis.

4. Erat autem Judith relícta ejus vídua jam annis tribus et ménsibus sex.

5. Et in superióribus domus suæ fecit sibi secrétum cubículum, in quo cum puéllis suis clausa morabátur,

6. et habens super lumbos suos cilícium, jejunábat ómnibus diébus vitæ suæ, præter sábbata et neoménias et festa domus Israël.

7. Erat autem elegánti aspéctu nimis, cui vir suus relíquerat divítias multas, et famíliam copiósam, ac possessiónes arméntis boum, et grégibus óvium plenas.

8. Et erat hæc in ómnibus famosíssima, quóniam timébat Dóminum valde, nec erat qui loquerétur de illa verbum malum.

9. Hæc ítaque cum audísset quóniam Ozías promisísset quod transácto quinto die tráderet civitátem, misit ad presbýteros Chabri et Charmi.

10. Et venérunt ad illam, et dixit illis : Quod est hoc verbum, in quo consénsit Ozías, ut tradat civitátem Assýriis si intra quinque dies non vénerit vobis adjutórium ?

11. et qui estis vos, qui tentátis Dóminum ?

12. non est iste sermo qui misericórdiam próvocet, sed pótius qui iram éxcitet, et furórem accéndat.

13. Posuístis vos tempus miseratiónis Dómini, et in arbítrium vestrum, diem constituístis ei.

14. Sed quia pátiens Dóminus est, in hoc ipso pœniteámus, et indulgéntiam ejus fusis lácrimis postulémus :

15. non enim quasi homo sic Deus comminábitur, neque sicut fílius hóminis ad iracúndiam inflammábitur.

16. Et ídeo humiliémus illi ánimas nostras, et in spíritu constitúti humiliáto, serviéntes illi

17. dicámus flentes Dómino, ut secúndum voluntátem suam sic fáciat nobíscum misericórdiam suam : ut sicut conturbátum est cor nostrum in supérbia eórum, ita étiam de nostra humilitáte gloriémur :

18. quóniam non sumus secúti peccáta patrum nostrórum, qui dereliquérunt Deum suum, et adoravérunt deos aliénos,

19. pro quo scélere dati sunt in gládium, et in rapínam, et in confusiónem inimícis suis : nos autem álterum deum nescímus præter ipsum.

20. Expectémus húmiles consolatiónem ejus, et exquíret sánguinem nostrum de afflictiónibus inimicórum nostrórum, et humiliábit omnes gentes, quæcúmque insúrgunt contra nos, et fáciet illas sine honóre Dóminus Deus noster.

21. Et nunc fratres, quóniam vos estis presbýteri in pópulo Dei, et ex vobis pendet ánima illórum, ad elóquium vestrum corda eórum erígite, ut mémores sint quia tentáti sunt patres nostri, ut probaréntur si vere cólerent Deum suum.

22. Mémores esse debent quómodo pater noster Ábraham tentátus est, et per multas tribulatiónes probátus, Dei amícus efféctus est.

23. Sic Ísaac, sic Jacob, sic Móyses, et omnes qui placuérunt Deo, per multas tribulatiónes transiérunt fidéles.

24. Illi autem qui tentatiónes non suscepérunt cum timóre Dómini, et impatiéntiam suam et impropérium murmuratiónis suæ contra Dóminum protulérunt,

25. extermináti sunt ab exterminatóre, et a serpéntibus periérunt.

26. Et nos ergo non ulciscámur nos pro his quæ pátimur,

27. sed reputántes peccátis nostris hæc ipsa supplícia minóra esse flagélla Dómini, quibus quasi servi corrípimur ad emendatiónem, et non ad perditiónem nostram evenísse credámus.

28. Et dixérunt illi Ozías et presbýteri : Ómnia quæ locúta es, vera sunt, et non est in sermónibus tuis ulla reprehénsio.

29. Nunc ergo ora pro nobis, quóniam múlier sancta es, et timens Deum.

30. Et dixit illis Judith : Sicut quod pótui loqui, Dei esse cognoscítis,

31. ita quod fácere dispósui, probáte si ex Deo est, et oráte ut firmum fáciat Deus consílium meum.

32. Stábitis vos ad portam nocte ista, et ego éxeam cum abra mea : et oráte, ut sicut dixístis, in diébus quinque respíciat Dóminus pópulum suum Israël.

33. Vos autem nolo ut scrutémini actum meum, et usque dum renúntiem vobis, nihil áliud fiat, nisi orátio pro me ad Dóminum Deum nostrum.

34. Et dixit ad eam Ozías princeps Juda : Vade in pace, et Dóminus sit tecum in ultiónem inimicórum nostrórum. Et reverténtes abiérunt.

