# Liber Secundus Paralipomenon - Caput 7

1. Cumque complésset Sálomon fundens preces, ignis descéndit de cælo, et devorávit holocáusta et víctimas : et majéstas Dómini implévit domum.

2. Nec póterant sacerdótes íngredi templum Dómini, eo quod implésset majéstas Dómini templum Dómini.

3. Sed et omnes fílii Israël vidébant descendéntem ignem, et glóriam Dómini super domum : et corruéntes proni in terram super paviméntum stratum lápide, adoravérunt, et laudavérunt Dóminum, quóniam bonus, quóniam in sǽculum misericórdia ejus.

4. Rex autem et omnis pópulus immolábant víctimas coram Dómino.

5. Mactávit ígitur rex Sálomon hóstias, boum vigínti duo míllia, aríetum centum vigínti míllia : et dedicávit domum Dei rex, et univérsus pópulus.

6. Sacerdótes autem stabant in offíciis suis, et Levítæ in órganis cárminum Dómini, quæ fecit David rex ad laudándum Dóminum : Quóniam in ætérnum misericórdia ejus, hymnos David canéntes per manus suas : porro sacerdótes canébant tubis ante eos, cunctúsque Israël stabat.

7. Sanctificávit quoque Sálomon médium átrii ante templum Dómini : obtúlerat enim ibi holocáusta et ádipes pacificórum : quia altáre ǽneum quod fécerat, non póterat sustinére holocáusta et sacrifícia et ádipes.

8. Fecit ergo Sálomon solemnitátem in témpore illo septem diébus, et omnis Israël cum eo, ecclésia magna valde, ab intróitu Emath usque ad torréntem Ægýpti.

9. Fecítque die octávo colléctam, eo quod dedicásset altáre septem diébus, et solemnitátem celebrásset diébus septem.

10. Ígitur in die vigésimo tértio mensis séptimi, dimísit pópulos ad tabernácula sua, lætántes atque gaudéntes super bono quod fécerat Dóminus Davídi, et Salomóni, et Israëli pópulo suo.

11. Complevítque Sálomon domum Dómini, et domum regis, et ómnia quæ disposúerat in corde suo ut fáceret in domo Dómini, et in domo sua, et prosperátus est.

12. Appáruit autem ei Dóminus nocte, et ait : Audívi oratiónem tuam, et elégi locum istum mihi in domum sacrifícii.

13. Si cláusero cælum, et plúvia non flúxerit, et mandávero et præcépero locústæ ut dévoret terram, et mísero pestiléntiam in pópulum meum :

14. convérsus autem pópulus meus, super quos invocátum est nomen meum, deprecátus me fúerit, et exquisíerit fáciem meam, et égerit pœniténtiam a viis suis péssimis : et ego exáudiam de cælo, et propítius ero peccátis eórum, et sanábo terram eórum.

15. Óculi quoque mei erunt apérti, et aures meæ eréctæ ad oratiónem ejus, qui in loco isto oráverit.

16. Elégi enim, et sanctificávi locum istum, ut sit nomen meum ibi in sempitérnum, et permáneant óculi mei et cor meum ibi cunctis diébus.

17. Tu quoque si ambuláveris coram me, sicut ambuláverit David pater tuus, et féceris juxta ómnia quæ præcépi tibi, et justítias meas judiciáque serváveris :

18. suscitábo thronum regni tui, sicut pollícitus sum David patri tuo, dicens : Non auferétur de stirpe tua vir qui sit princeps in Israël.

19. Si autem avérsi fuéritis, et dereliquéritis justítias meas, et præcépta mea quæ propósui vobis, et abeúntes serviéritis diis aliénis, et adoravéritis eos,

20. evéllam vos de terra mea quam dedi vobis : et domum hanc, quam sanctificávi nómini meo, projíciam a fácie mea, et tradam eam in parábolam, et in exémplum cunctis pópulis.

21. Et domus ista erit in provérbium univérsis transeúntibus, et dicent stupéntes : Quare fecit Dóminus sic terræ huic, et dómui huic ?

22. Respondebúntque : Quia dereliquérunt Dóminum Deum patrum suórum, qui edúxit eos de terra Ægýpti, et apprehendérunt deos aliénos, et adoravérunt eos, et coluérunt : idcírco venérunt super eos univérsa hæc mala.

