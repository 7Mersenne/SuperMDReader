# Liber Exodus - Caput 25

1. Locutúsque est Dóminus ad Móysen, dicens :

2. Lóquere fíliis Israël, ut tollant mihi primítias : ab omni hómine qui ófferet ultróneus, accipiétis eas.

3. Hæc sunt autem quæ accípere debeátis : aurum, et argéntum, et æs,

4. hyacínthum et púrpuram, coccúmque bis tinctum, et byssum, pilos caprárum,

5. et pelles aríetum rubricátas, pellésque jánthinas, et ligna setim :

6. óleum ad luminária concinnánda : arómata in unguéntum, et thymiamáta boni odóris :

7. lápides onýchinos, et gemmas ad ornándum ephod, ac rationále.

8. Faciéntque mihi sanctuárium, et habitábo in médio eórum :

9. juxta omnem similitúdinem tabernáculi quod osténdam tibi, et ómnium vasórum in cultum ejus. Sicque faciétis illud :

10. arcam de lignis setim compíngite, cujus longitúdo hábeat duos et semis cúbitos : latitúdo, cúbitum et dimídium : altitúdo, cúbitum simíliter ac semíssem.

11. Et deaurábis eam auro mundíssimo intus et foris : faciésque supra, corónam áuream per circúitum :

12. et quátuor círculos áureos, quos pones per quátuor arcæ ángulos : duo círculi sint in látere uno, et duo in áltero.

13. Fácies quoque vectes de lignis setim, et opéries eos auro.

14. Inducésque per círculos qui sunt in arcæ latéribus, ut portétur in eis :

15. qui semper erunt in círculis, nec umquam extrahéntur ab eis.

16. Ponésque in arca testificatiónem quam dabo tibi.

17. Fácies et propitiatórium de auro mundíssimo : duos cúbitos et dimídium tenébit longitúdo ejus, et cúbitum ac semíssem latitúdo.

18. Duos quoque chérubim áureos et prodúctiles fácies, ex utráque parte oráculi.

19. Cherub unus sit in látere uno, et alter in áltero.

20. Utrúmque latus propitiatórii tegant expandéntes alas, et operiéntes oráculum, respiciántque se mútuo versis vúltibus in propitiatórium quo operiénda est arca,

21. in qua pones testimónium quod dabo tibi.

22. Inde præcípiam, et loquar ad te supra propitiatórium, ac de médio duórum chérubim, qui erunt super arcam testimónii, cuncta quæ mandábo per te fíliis Israël.

23. Fácies et mensam de lignis setim, habéntem duos cúbitos longitúdinis, et in latitúdine cúbitum, et in altitúdine cúbitum et semíssem.

24. Et inaurábis eam auro puríssimo : faciésque illi lábium áureum per circúitum,

25. et ipsi lábio corónam interrásilem altam quátuor dígitis : et super illam, álteram corónam auréolam.

26. Quátuor quoque círculos áureos præparábis, et pones eis in quátuor ángulis ejúsdem mensæ per síngulos pedes.

27. Subter corónam erunt círculi áurei, ut mittántur vectes per eos, et possit mensa portári.

28. Ipsos quoque vectes fácies de lignis setim, et circúmdabis auro ad subvehéndam mensam.

29. Parábis et acetábula, ac phíalas, thuríbula, et cyáthos, in quibus offerénda sunt libámina, ex auro puríssimo.

30. Et pones super mensam panes propositiónis in conspéctu meo semper.

31. Fácies et candelábrum dúctile de auro mundíssimo, hástile ejus, et cálamos, scyphos, et sphǽrulas, ac lília ex ipso procedéntia.

32. Sex cálami egrediéntur de latéribus, tres ex uno látere, et tres ex áltero.

33. Tres scyphi quasi in nucis modum per cálamos síngulos, sphæruláque simul, et lílium : et tres simíliter scyphi instar nucis in cálamo áltero, sphæruláque simul et lílium. Hoc erit opus sex calamórum, qui producéndi sunt de hástili :

34. in ipso autem candelábro erunt quátuor scyphi in nucis modum, sphærulǽque per síngulos, et lília.

35. Sphǽrulæ sub duóbus cálamis per tria loca, qui simul sex fiunt procedéntes de hástili uno.

36. Et sphǽrulæ ígitur et cálami ex ipso erunt, univérsa ductília de auro puríssimo.

37. Fácies et lucérnas septem, et pones eas super candelábrum, ut lúceant ex advérso.

38. Emunctória quoque, et ubi quæ emúncta sunt extinguántur, fiant de auro puríssimo.

39. Omne pondus candelábri cum univérsis vasis suis habébit taléntum auri puríssimi.

40. Ínspice, et fac secúndum exémplar quod tibi in monte monstrátum est.

