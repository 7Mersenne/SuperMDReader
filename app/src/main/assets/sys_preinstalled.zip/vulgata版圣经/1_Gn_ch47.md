# Liber Genesis - Caput 47

1. Ingréssus ergo Joseph nuntiávit Pharaóni, dicens : Pater meus et fratres, oves eórum et arménta, et cuncta quæ póssident, venérunt de terra Chánaan : et ecce consístunt in terra Gessen.

2. Extrémos quoque fratrum suórum quinque viros constítuit coram rege :

3. quos ille interrogávit : Quid habétis óperis ? Respondérunt : Pastóres óvium sumus servi tui, et nos et patres nostri.

4. Ad peregrinándum in terra tua venímus : quóniam non est herba grégibus servórum tuórum, ingravescénte fame in terra Chánaan : petimúsque ut esse nos júbeas servos tuos in terra Gessen.

5. Dixit ítaque rex ad Joseph : Pater tuus et fratres tui venérunt ad te.

6. Terra Ægýpti in conspéctu tuo est : in óptimo loco fac eos habitáre, et trade eis terram Gessen. Quod si nosti in eis esse viros indústrios, constítue illos magístros pécorum meórum.

7. Post hæc introdúxit Joseph patrem suum ad regem, et státuit eum coram eo : qui benedícens illi,

8. et interrogátus ab eo : Quot sunt dies annórum vitæ tuæ ?

9. respóndit : Dies peregrinatiónis meæ centum trigínta annórum sunt, parvi et mali, et non pervenérunt usque ad dies patrum meórum quibus peregrináti sunt.

10. Et benedícto rege, egréssus est foras.

11. Joseph vero patri et frátribus suis dedit possessiónem in Ægýpto in óptimo terræ loco, Ramésses, ut præcéperat Phárao.

12. Et alébat eos, omnémque domum patris sui, præbens cibária síngulis.

13. In toto enim orbe panis déerat, et opprésserat fames terram, máxime Ægýpti et Chánaan.

14. E quibus omnem pecúniam congregávit pro venditióne fruménti, et íntulit eam in ærárium regis.

15. Cumque defecísset emptóribus prétium, venit cuncta Ægýptus ad Joseph, dicens : Da nobis panes : quare mórimur coram te, deficiénte pecúnia ?

16. Quibus ille respóndit : Addúcite pécora vestra, et dabo vobis pro eis cibos, si prétium non habétis.

17. Quæ cum adduxíssent, dedit eis aliménta pro equis, et óvibus, et bobus, et ásinis : sustentavítque eos illo anno pro commutatióne pécorum.

18. Venérunt quoque anno secúndo, et dixérunt ei : Non celábimus dóminum nostrum quod deficiénte pecúnia, pécora simul defecérunt : nec clam te est, quod absque corpóribus et terra nihil habeámus.

19. Cur ergo moriémur te vidénte ? et nos et terra nostra tui érimus : eme nos in servitútem régiam, et præbe sémina, ne pereúnte cultóre redigátur terra in solitúdinem.

20. Emit ígitur Joseph omnem terram Ægýpti, vendéntibus síngulis possessiónes suas præ magnitúdine famis. Subjecítque eam Pharaóni,

21. et cunctos pópulos ejus a novíssimis términis Ægýpti usque ad extrémos fines ejus,

22. præter terram sacerdótum, quæ a rege trádita fúerat eis : quibus et statúta cibária ex hórreis públicis præbebántur, et idcírco non sunt compúlsi véndere possessiónes suas.

23. Dixit ergo Joseph ad pópulos : En ut cérnitis, et vos et terram vestram Phárao póssidet : accípite sémina, et sérite agros,

24. ut fruges habére possítis. Quintam partem regi dábitis : quátuor réliquas permítto vobis in seméntem, et in cibum famíliis et líberis vestris.

25. Qui respondérunt : Salus nostra in manu tua est : respíciat nos tantum dóminus noster, et læti serviémus regi.

26. Ex eo témpore usque in præséntem diem, in univérsa terra Ægýpti régibus quinta pars sólvitur, et factum est quasi in legem, absque terra sacerdotáli, quæ líbera ab hac conditióne fuit.

27. Habitávit ergo Israël in Ægýpto, id est, in terra Gessen, et possédit eam : auctúsque est, et multiplicátus nimis.

28. Et vixit in ea decem et septem annis : factíque sunt omnes dies vitæ illíus, centum quadragínta septem annórum.

29. Cumque appropinquáre cérneret diem mortis suæ, vocávit fílium suum Joseph, et dixit ad eum : Si invéni grátiam in conspéctu tuo, pone manum tuam sub fémore meo : et fácies mihi misericórdiam et veritátem, ut non sepélias me in Ægýpto :

30. sed dórmiam cum pátribus meis, et áuferas me de terra hac, condásque in sepúlchro majórum meórum. Cui respóndit Joseph : Ego fáciam quod jussísti.

31. Et ille : Jura ergo, inquit, mihi. Quo juránte, adorávit Israël Deum, convérsus ad léctuli caput.

