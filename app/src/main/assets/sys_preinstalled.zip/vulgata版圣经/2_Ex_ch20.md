# Liber Exodus - Caput 20

1. Locutúsque est Dóminus cunctos sermónes hos :

2. Ego sum Dóminus Deus tuus, qui edúxi te de terra Ægýpti, de domo servitútis.

3. Non habébis deos aliénos coram me.

4. Non fácies tibi scúlptile, neque omnem similitúdinem quæ est in cælo désuper, et quæ in terra deórsum, nec eórum quæ sunt in aquis sub terra.

5. Non adorábis ea, neque coles : ego sum Dóminus Deus tuus fortis, zelótes, vísitans iniquitátem patrum in fílios, in tértiam et quartam generatiónem eórum qui odérunt me :

6. et fáciens misericórdiam in míllia his qui díligunt me, et custódiunt præcépta mea.

7. Non assúmes nomen Dómini Dei tui in vanum : nec enim habébit insóntem Dóminus eum qui assúmpserit nomen Dómini Dei sui frustra.

8. Meménto ut diem sábbati sanctífices.

9. Sex diébus operáberis, et fácies ómnia ópera tua.

10. Séptimo autem die sábbatum Dómini Dei tui est : non fácies omne opus in eo, tu, et fílius tuus et fília tua, servus tuus et ancílla tua, juméntum tuum, et ádvena qui est intra portas tuas.

11. Sex enim diébus fecit Dóminus cælum et terram, et mare, et ómnia quæ in eis sunt, et requiévit in die séptimo : idcírco benedíxit Dóminus diéi sábbati, et sanctificávit eum.

12. Honóra patrem tuum et matrem tuam, ut sis longǽvus super terram, quam Dóminus Deus tuus dabit tibi.

13. Non occídes.

14. Non mœcháberis.

15. Non furtum fácies.

16. Non lóqueris contra próximum tuum falsum testimónium.

17. Non concupísces domum próximi tui, nec desiderábis uxórem ejus, non servum, non ancíllam, non bovem, non ásinum, nec ómnia quæ illíus sunt.

18. Cunctus autem pópulus vidébat voces et lámpades, et sónitum búccinæ, montémque fumántem : et pertérriti ac pavóre concússi, stetérunt procul,

19. dicéntes Móysi : Lóquere tu nobis, et audiémus : non loquátur nobis Dóminus, ne forte moriámur.

20. Et ait Móyses ad pópulum : Nolíte timére : ut enim probáret vos venit Deus, et ut terror illíus esset in vobis, et non peccarétis.

21. Stetítque pópulus de longe. Móyses autem accéssit ad calíginem in qua erat Deus.

22. Dixit prætérea Dóminus ad Móysen : Hæc dices fíliis Israël : Vos vidístis quod de cælo locútus sim vobis.

23. Non faciétis deos argénteos, nec deos áureos faciétis vobis.

24. Altáre de terra faciétis mihi, et offerétis super eo holocáusta et pacífica vestra, oves vestras et boves in omni loco in quo memória fúerit nóminis mei : véniam ad te, et benedícam tibi.

25. Quod si altáre lapídeum féceris mihi, non ædificábis illud de sectis lapídibus : si enim leváveris cultrum super eo, polluétur.

26. Non ascéndes per gradus ad altáre meum, ne revelétur turpitúdo tua.

