# Liber Tobi� - Caput 8

1. Postquam vero cœnavérunt, introduxérunt júvenem ad eam.

2. Recordátus ítaque Tobías sermónum ángeli, prótulit de cassídili suo partem jecóris, posuítque eam super carbónes vivos.

3. Tunc Ráphaël ángelus apprehéndit dæmónium, et religávit illud in desérto superióris Ægýpti.

4. Tunc hortátus est vírginem Tobías, dixítque ei : Sara, exsúrge, et deprecémur Deum hódie, et cras, et secúndum cras : quia his tribus nóctibus Deo júngimur ; tértia autem transácta nocte, in nostro érimus conjúgio.

5. Fílii quippe sanctórum sumus, et non póssumus ita conjúngi sicut gentes quæ ignórant Deum.

6. Surgéntes autem páriter, instánter orábant ambo simul, ut sánitas darétur eis.

7. Dixítque Tobías : Dómine Deus patrum nostrórum, benedícant te cæli et terræ, maréque et fontes, et flúmina, et omnes creatúræ tuæ quæ in eis sunt.

8. Tu fecísti Adam de limo terræ, dedistíque ei adjutórium Hevam.

9. Et nunc Dómine, tu scis quia non luxúriæ causa accípio sorórem meam cónjugem, sed sola posteritátis dilectióne, in qua benedicátur nomen tuum in sǽcula sæculórum.

10. Dixit quoque Sara : Miserére nobis Dómine, miserére nobis, et consenescámus ambo páriter sani.

11. Et factum est circa pullórum cantum, accersíri jussit Raguel servos suos, et abiérunt cum eo páriter ut fóderent sepúlchrum.

12. Dicébat enim : Ne forte símili modo evénerit ei, quo et céteris illis septem viris qui sunt ingréssi ad eam.

13. Cumque parássent fossam, revérsus Raguel ad uxórem suam, dixit ei :

14. Mitte unam de ancíllis tuis, et vídeat si mórtuus est, ut sepéliam eum ántequam illucéscat dies.

15. At illa misit unam ex ancíllis suis. Quæ ingréssa cubículum, réperit eos salvos et incólumes, secum páriter dormiéntes.

16. Et revérsa nuntiávit bonum núntium : et benedixérunt Dóminum, Raguel vidélicet et Anna uxor ejus,

17. et dixérunt : Benedícimus te, Dómine Deus Israël, quia non cóntigit quemádmodum putabámus.

18. Fecísti enim nobíscum misericórdiam tuam, et exclusísti a nobis inimícum persequéntem nos.

19. Misértus es autem duóbus únicis. Fac eos, Dómine, plénius benedícere te, et sacrifícium tibi laudis tuæ et suæ sanitátis offérre, ut cognóscat univérsitas géntium quia tu es Deus solus in univérsa terra.

20. Statímque præcépit servis suis Raguel ut replérent fossam quam fécerant priúsquam elucésceret.

21. Uxóri autem suæ dixit ut instrúeret convívium, et præparáret ómnia quæ in cibos erant iter agéntibus necessária.

22. Duas quoque pingues vaccas, et quátuor aríetes, occídi fecit, et parári épulas ómnibus vicínis suis, cunctísque amícis.

23. Et adjurávit Raguel Tobíam ut duas hebdómadas morarétur apud se.

24. De ómnibus autem quæ possidébat Raguel, dimídiam partem dedit Tobíæ, et fecit scriptúram, ut pars dimídia quæ supérerat, post óbitum eórum Tobíæ domínio deveníret.

