# Liber Exodus - Caput 16

1. Profectíque sunt de Elim, et venit omnis multitúdo filiórum Israël in desértum Sin, quod est inter Elim et Sínai, quintodécimo die mensis secúndi, postquam egréssi sunt de terra Ægýpti.

2. Et murmurávit omnis congregátio filiórum Israël contra Móysen et Áaron in solitúdine.

3. Dixerúntque fílii Israël ad eos : Útinam mórtui essémus per manum Dómini in terra Ægýpti, quando sedebámus super ollas cárnium, et comedebámus panem in saturitáte : cur eduxístis nos in desértum istud, ut occiderétis omnem multitúdinem fame ?

4. Dixit autem Dóminus ad Móysen : Ecce ego pluam vobis panes de cælo : egrediátur pópulus, et cólligat quæ suffíciunt per síngulos dies : ut tentem eum utrum ámbulet in lege mea, an non.

5. Die autem sexto parent quod ínferant : et sit duplum quam collígere solébant per síngulos dies.

6. Dixerúntque Móyses et Áaron ad omnes fílios Israël : Véspere sciétis quod Dóminus edúxerit vos de terra Ægýpti,

7. et mane vidébitis glóriam Dómini : audívit enim murmur vestrum contra Dóminum : nos vero quid sumus, quia mussitástis contra nos ?

8. Et ait Móyses : Dabit vobis Dóminus véspere carnes édere, et mane panes in saturitáte : eo quod audíerit murmuratiónes vestras quibus murmuráti estis contra eum : nos enim quid sumus ? nec contra nos est murmur vestrum, sed contra Dóminum.

9. Dixit quoque Móyses ad Áaron : Dic univérsæ congregatióni filiórum Israël : Accédite coram Dómino : audívit enim murmur vestrum.

10. Cumque loquerétur Áaron ad omnem cœtum filiórum Israël, respexérunt ad solitúdinem : et ecce glória Dómini appáruit in nube.

11. Locútus est autem Dóminus ad Móysen, dicens :

12. Audívi murmuratiónes filiórum Israël. Lóquere ad eos : Véspere comedétis carnes, et mane saturabímini pánibus : scietísque quod ego sum Dóminus Deus vester.

13. Factum est ergo véspere, et ascéndens cotúrnix, coopéruit castra : mane quoque ros jácuit per circúitum castrórum.

14. Cumque operuísset superfíciem terræ, appáruit in solitúdine minútum, et quasi pilo tusum in similitúdinem pruínæ super terram.

15. Quod cum vidíssent fílii Israël, dixérunt ad ínvicem : Manhu ? quod signíficat : Quid est hoc ? ignorábant enim quid esset. Quibus ait Móyses : Iste est panis quem Dóminus dedit vobis ad vescéndum.

16. Hic est sermo, quem præcépit Dóminus : Cólligat unusquísque ex eo quantum súfficit ad vescéndum : gomor per síngula cápita, juxta númerum animárum vestrárum quæ hábitant in tabernáculo sic tollétis.

17. Fecerúntque ita fílii Israël : et collegérunt, álius plus, álius minus.

18. Et mensi sunt ad mensúram gomor : nec qui plus collégerat, hábuit ámplius : nec qui minus paráverat, réperit minus : sed sínguli juxta id quod édere póterant, congregavérunt.

19. Dixítque Móyses ad eos : Nullus relínquat ex eo in mane.

20. Qui non audiérunt eum, sed dimisérunt quidam ex eis usque mane, et scátere cœpit vérmibus, atque compútruit : et irátus est contra eos Móyses.

21. Colligébant autem mane sínguli, quantum suffícere póterat ad vescéndum : cumque incaluísset sol, liquefiébat.

22. In die autem sexta collegérunt cibos dúplices, id est, duo gomor per síngulos hómines : venérunt autem omnes príncipes multitúdinis, et narravérunt Móysi.

23. Qui ait eis : Hoc est quod locútus est Dóminus : Réquies sábbati sanctificáta est Dómino cras : quodcúmque operándum est, fácite, et quæ coquénda sunt cóquite : quidquid autem réliquum fúerit, repónite usque in mane.

24. Fecerúntque ita ut præcéperat Móyses, et non compútruit, neque vermis invéntus est in eo.

25. Dixítque Móyses : Comédite illud hódie, quia sábbatum est Dómini : non inveniétur hódie in agro.

26. Sex diébus collígite : in die autem séptimo sábbatum est Dómini, idcírco non inveniétur.

27. Venítque séptima dies : et egréssi de pópulo ut collígerent, non invenérunt.

28. Dixit autem Dóminus ad Móysen : Úsquequo non vultis custodíre mandáta mea et legem meam ?

29. vidéte quod Dóminus déderit vobis sábbatum, et propter hoc die sexta tríbuit vobis cibos dúplices : máneat unusquísque apud semetípsum ; nullus egrediátur de loco suo die séptimo.

30. Et sabbatizávit pópulus die séptimo.

31. Appellavítque domus Israël nomen ejus Man : quod erat quasi semen coriándri album, gustúsque ejus quasi símilæ cum melle.

32. Dixit autem Móyses : Iste est sermo, quem præcépit Dóminus : Imple gomor ex eo, et custodiátur in futúras retro generatiónes : ut nóverint panem, quo álui vos in solitúdine, quando edúcti estis de terra Ægýpti.

33. Dixítque Móyses ad Áaron : Sume vas unum, et mitte ibi man, quantum potest cápere gomor, et repóne coram Dómino ad servándum in generatiónes vestras,

34. sicut præcépit Dóminus Móysi. Posuítque illud Áaron in tabernáculo reservándum.

35. Fílii autem Israël comedérunt man quadragínta annis, donec venírent in terram habitábilem : hoc cibo áliti sunt, úsquequo tángerent fines terræ Chánaan.

36. Gomor autem décima pars est ephi.

