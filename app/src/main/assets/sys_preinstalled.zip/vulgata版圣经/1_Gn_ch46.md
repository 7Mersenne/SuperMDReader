# Liber Genesis - Caput 46

1. Profectúsque Israël cum ómnibus quæ habébat, venit ad Púteum juraménti : et mactátis ibi víctimis Deo patris sui Ísaac,

2. audívit eum per visiónem noctis vocántem se, et dicéntem sibi : Jacob, Jacob. Cui respóndit : Ecce adsum.

3. Ait illi Deus : Ego sum fortíssimus Deus patris tui : noli timére, descénde in Ægýptum, quia in gentem magnam fáciam te ibi.

4. Ego descéndam tecum illuc, et ego inde addúcam te reverténtem : Joseph quoque ponet manus suas super óculos tuos.

5. Surréxit autem Jacob a Púteo juraménti : tulerúntque eum fílii cum párvulis et uxóribus suis in plaustris quæ míserat Phárao ad portándum senem,

6. et ómnia quæ posséderat in terra Chánaan : venítque in Ægýptum cum omni sémine suo,

7. fílii ejus, et nepótes, fíliæ, et cuncta simul progénies.

8. Hæc sunt autem nómina filiórum Israël, qui ingréssi sunt in Ægýptum, ipse cum líberis suis. Primogénitus Ruben.

9. Fílii Ruben : Henoch et Phallu et Hesron et Charmi.

10. Fílii Símeon : Jámuel et Jamin et Ahod, et Jachin et Sohar, et Saul fílius Chanaanítidis.

11. Fílii Levi : Gerson et Caath et Merári.

12. Fílii Juda : Her et Onan et Sela et Phares et Zara ; mórtui sunt autem Her et Onan in terra Chánaan. Natíque sunt fílii Phares : Hesron et Hamul.

13. Fílii Issáchar : Thola et Phua et Job et Semron.

14. Fílii Zábulon : Sared et Elon et Jáhelel.

15. Hi fílii Liæ quos génuit in Mesopotámia Sýriæ cum Dina fília sua : omnes ánimæ filiórum ejus et filiárum, trigínta tres.

16. Fílii Gad : Séphion et Haggi et Suni et Esébon et Heri et Árodi et Áreli.

17. Fílii Aser : Jamne et Jésua et Jéssui et Béria, Sara quoque soror eórum. Fílii Béria : Heber et Mélchiel.

18. Hi fílii Zelphæ, quam dedit Laban Liæ fíliæ suæ : et hos génuit Jacob sédecim ánimas.

19. Fílii Rachel uxóris Jacob : Joseph et Bénjamin.

20. Natíque sunt Joseph fílii in terra Ægýpti, quos génuit ei Áseneth fília Putipháre sacerdótis Heliopóleos : Manásses et Éphraim.

21. Fílii Bénjamin : Bela et Bechor et Asbel et Gera et Náaman et Echi et Ros et Mophim et Ophim et Ared.

22. Hi fílii Rachel quos génuit Jacob : omnes ánimæ, quatuórdecim.

23. Fílii Dan : Husim.

24. Fílii Nephtháli : Jásiel et Guni et Jeser et Sallem.

25. Hi fílii Balæ, quam dedit Laban Rácheli fíliæ suæ : et hos génuit Jacob : omnes ánimæ, septem.

26. Cunctæ ánimæ, quæ ingréssæ sunt cum Jacob in Ægýptum, et egréssæ sunt de fémore illíus, absque uxóribus filiórum ejus, sexagínta sex.

27. Fílii autem Joseph, qui nati sunt ei in terra Ægýpti, ánimæ duæ. Omnes ánimæ domus Jacob, quæ ingréssæ sunt in Ægýptum, fúere septuagínta.

28. Misit autem Judam ante se ad Joseph, ut nuntiáret ei, et occúrreret in Gessen.

29. Quo cum pervenísset, juncto Joseph curro suo, ascéndit óbviam patri suo ad eúmdem locum : vidénsque eum, írruit super collum ejus, et inter ampléxus flevit.

30. Dixítque pater ad Joseph : Jam lætus móriar, quia vidi fáciem tuam, et supérstitem te relínquo.

31. At ille locútus est ad fratres suos, et ad omnem domum patris sui : Ascéndam, et nuntiábo Pharaóni, dicámque ei : Fratres mei, et domus patris mei, qui erant in terra Chánaan, venérunt ad me :

32. et sunt viri pastóres óvium, curámque habent alendórum gregum : pécora sua, et arménta, et ómnia quæ habére potuérunt, adduxérunt secum.

33. Cumque vocáverit vos, et díxerit : Quod est opus vestrum ?

34. respondébitis : Viri pastóres sumus servi tui, ab infántia nostra usque in præsens, et nos et patres nostri. Hæc autem dicétis, ut habitáre possítis in terra Gessen : quia detestántur Ægýptii omnes pastóres óvium.

