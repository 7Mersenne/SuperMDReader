# Liber Genesis - Caput 21

1. Visitávit autem Dóminus Saram, sicut promíserat : et implévit quæ locútus est.

2. Concepítque et péperit fílium in senectúte sua, témpore quo prædíxerat ei Deus.

3. Vocavítque Ábraham nomen fílii sui, quem génuit ei Sara, Ísaac :

4. et circumcídit eum octávo die, sicut præcéperat ei Deus,

5. cum centum esset annórum : hac quippe ætáte patris, natus est Ísaac.

6. Dixítque Sara : Risum fecit mihi Deus : quicúmque audíerit, corridébit mihi.

7. Rursúmque ait : Quis auditúrus créderet Ábraham quod Sara lactáret fílium, quem péperit ei jam seni ?

8. Crevit ígitur puer, et ablactátus est : fecítque Ábraham grande convívium in die ablactatiónis ejus.

9. Cumque vidísset Sara fílium Agar Ægýptiæ ludéntem cum Ísaac fílio suo, dixit ad Ábraham :

10. Éjice ancíllam hanc, et fílium ejus : non enim erit hæres fílius ancíllæ cum fílio meo Ísaac.

11. Dure accépit hoc Ábraham pro fílio suo.

12. Cui dixit Deus : Non tibi videátur ásperum super púero, et super ancílla tua : ómnia quæ díxerit tibi Sara, audi vocem ejus : quia in Ísaac vocábitur tibi semen.

13. Sed et fílium ancíllæ fáciam in gentem magnam, quia semen tuum est.

14. Surréxit ítaque Ábraham mane, et tollens panem et utrem aquæ, impósuit scápulæ ejus, tradidítque púerum, et dimísit eam. Quæ cum abiísset, errábat in solitúdine Bersabée.

15. Cumque consúmpta esset aqua in utre, abjécit púerum subter unam árborum, quæ ibi erant.

16. Et ábiit, sedítque e regióne procul quantum potest arcus jácere : dixit enim : Non vidébo moriéntem púerum : et sedens contra, levávit vocem suam et flevit.

17. Exaudívit autem Deus vocem púeri : vocavítque ángelus Dei Agar de cælo, dicens : Quid agis Agar ? noli timére : exaudívit enim Deus vocem púeri de loco in quo est.

18. Surge, tolle púerum, et tene manum illíus : quia in gentem magnam fáciam eum.

19. Aperuítque óculos ejus Deus : quæ videns púteum aquæ, ábiit, et implévit utrem, dedítque púero bíbere.

20. Et fuit cum eo : qui crevit, et morátus est in solitúdine, factúsque est júvenis sagittárius.

21. Habitavítque in desérto Pharan, et accépit illi mater sua uxórem de terra Ægýpti.

22. Eódem témpore dixit Abímelech, et Phicol princeps exércitus ejus, ad Ábraham : Deus tecum est in univérsis quæ agis.

23. Jura ergo per Deum, ne nóceas mihi, et pósteris meis, stirpíque meæ : sed juxta misericórdiam, quam feci tibi, fácies mihi, et terræ in qua versátus es ádvena.

24. Dixítque Ábraham : Ego jurábo.

25. Et increpávit Abímelech propter púteum aquæ quem vi abstulérunt servi ejus.

26. Respondítque Abímelech : Nescívi quis fécerit hanc rem : sed et tu non indicásti mihi, et ego non audívi præter hódie.

27. Tulit ítaque Ábraham oves et boves, et dedit Abímelech : percusserúntque ambo fœdus.

28. Et státuit Ábraham septem agnas gregis seórsum.

29. Cui dixit Abímelech : Quid sibi volunt septem agnæ istæ, quas stare fecísti seórsum ?

30. At ille : Septem, inquit, agnas accípies de manu mea : ut sint mihi in testimónium, quóniam ego fodi púteum istum.

31. Idcírco vocátus est locus ille Bersabée : quia ibi utérque jurávit.

32. Et iniérunt fœdus pro púteo juraménti.

33. Surréxit autem Abímelech, et Phicol princeps exércitus ejus, reversíque sunt in terram Palæstinórum. Ábraham vero plantávit nemus in Bersabée, et invocávit ibi nomen Dómini Dei ætérni.

34. Et fuit colónus terræ Palæstinórum diébus multis.

