# Liber Esdr� - Caput 2

1. Hi sunt autem provínciæ fílii, qui ascendérunt de captivitáte, quam transtúlerat Nabuchodonósor rex Babylónis in Babylónem, et revérsi sunt in Jerúsalem et Judam, unusquísque in civitátem suam.

2. Qui venérunt cum Zoróbabel, Jósue, Nehemía, Saraía, Rahelaía, Mardóchai, Belsan, Mesphar, Béguai, Rehum, Baána. Númerus virórum pópuli Israël :

3. fílii Pharos duo míllia centum septuagínta duo.

4. Fílii Sephátia, trecénti septuagínta duo.

5. Fílii Área, septingénti septuagínta quinque.

6. Fílii Phahath Moab, filiórum Jósue : Joab, duo míllia octingénti duódecim.

7. Fílii Ælam, mille ducénti quinquagínta quátuor.

8. Fílii Zéthua, nongénti quadragínta quinque.

9. Fílii Záchai, septingénti sexagínta.

10. Fílii Bani, sexcénti quadragínta duo.

11. Fílii Bébai, sexcénti vigínti tres.

12. Fílii Azgad, mille ducénti vigínti duo.

13. Fílii Adónicam, sexcénti sexagínta sex.

14. Fílii Béguai, duo míllia quinquagínta sex.

15. Fílii Adin, quadringénti quinquagínta quátuor.

16. Fílii Ather, qui erant ex Ezechía, nonagínta octo.

17. Fílii Bésai, trecénti vigínti tres.

18. Fílii Jora, centum duódecim.

19. Fílii Hasum, ducénti vigínti tres.

20. Fílii Gebbar, nonagínta quinque.

21. Fílii Béthlehem, centum vigínti tres.

22. Viri Nétupha, quinquagínta sex.

23. Viri Anáthoth, centum vigínti octo.

24. Fílii Azmáveth, quadragínta duo.

25. Fílii Cariathiárim, Cephíra et Beroth, septingénti quadragínta tres.

26. Fílii Rama et Gábaa, sexcénti vigínti unus.

27. Viri Machmas, centum vigínti duo.

28. Viri Bethel et Hai, ducénti vigínti tres.

29. Fílii Nebo, quinquagínta duo.

30. Fílii Megbis, centum quinquagínta sex.

31. Fílii Ælam altérius, mille ducénti quinquagínta quátuor.

32. Fílii Harim, trecénti vigínti.

33. Fílii Lod Hadid, et Ono, septingénti vigínti quinque.

34. Fílii Jéricho, trecénti quadragínta quinque.

35. Fílii Sénaa, tria míllia sexcénti trigínta.

36. Sacerdótes : fílii Jadaía in domo Jósue, nongénti septuagínta tres.

37. Fílii Emmer, mille quinquagínta duo.

38. Fílii Pheshur, mille ducénti quadragínta septem.

39. Fílii Harim, mille decem et septem.

40. Levítæ : fílii Jósue et Cédmihel filiórum Odóviæ, septuagínta quátuor.

41. Cantóres : fílii Asaph, centum vigínti octo.

42. Fílii janitórum : fílii Sellum, fílii Ater, fílii Telmon, fílii Accub, fílii Hátitha, fílii Sóbai : univérsi centum trigínta novem.

43. Nathinǽi : fílii Siha, fílii Hásupha, fílii Tábbaoth,

44. fílii Ceros, fílii Siáa, fílii Phadon,

45. fílii Lebána, fílii Hagába, fílii Accub,

46. fílii Hagab, fílii Sémlai, fílii Hanan,

47. fílii Gaddel, fílii Gaher, fílii Raaía,

48. fílii Rasin, fílii Nécoda, fílii Gazam,

49. fílii Aza, fílii Phásea, fílii Bésee,

50. fílii Ásena, fílii Munim, fílii Nephúsim,

51. fílii Bacbuc, fílii Hácupha, fílii Harhur,

52. fílii Besluth, fílii Máhida, fílii Harsa,

53. fílii Bercos, fílii Sísara, fílii Thema,

54. fílii Násia, fílii Hátipha,

55. fílii servórum Salomónis, fílii Sótai, fílii Sóphereth, fílii Pharúda,

56. fílii Jala, fílii Dercon, fílii Geddel,

57. fílii Saphátia, fílii Hatil, fílii Phóchereth, qui erant de Asébaim, fílii Ami :

58. omnes Nathinǽi, et fílii servórum Salomónis, trecénti nonagínta duo.

59. Et hi qui ascendérunt de Thelmála, Thelhársa, Cherub, et Adon, et Emer : et non potuérunt indicáre domum patrum suórum et semen suum, utrum ex Israël essent.

60. Fílii Dalaía, fílii Tobía, fílii Nécoda, sexcénti quinquagínta duo.

61. Et de fíliis sacerdótum : fílii Hóbia, fílii Accos, fílii Berzéllai, qui accépit de filiábus Berzéllai Galaáditis, uxórem, et vocátus est nómine eórum :

62. hi quæsiérunt scriptúram genealógiæ suæ, et non invenérunt, et ejécti sunt de sacerdótio.

63. Et dixit Athersátha eis ut non coméderent de Sancto sanctórum, donec súrgeret sacérdos doctus atque perféctus.

64. Omnis multitúdo quasi unus, quadragínta duo míllia trecénti sexagínta :

65. excéptis servis eórum, et ancíllis, qui erant septem míllia trecénti trigínta septem : et in ipsis cantóres atque cantatríces ducénti.

66. Equi eórum septingénti trigínta sex, muli eórum, ducénti quadragínta quinque,

67. cámeli eórum, quadringénti trigínta quinque, ásini eórum, sex míllia septingénti vigínti.

68. Et de princípibus patrum, cum ingrederéntur templum Dómini, quod est in Jerúsalem, sponte obtulérunt in domum Dei ad exstruéndam eam in loco suo.

69. Secúndum vires suas dedérunt impénsas óperis, auri sólidos sexagínta míllia et mille, argénti mnas quinque míllia, et vestes sacerdotáles centum.

70. Habitavérunt ergo sacerdótes, et Levítæ, et de pópulo, et cantóres, et janitóres, et Nathinǽi, in úrbibus suis, universúsque Israël in civitátibus suis.

