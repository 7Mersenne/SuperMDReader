# Liber Nehemi� - Caput 10

1. Signatóres autem fuérunt Nehemías, Athersátha fílius Hachélai, et Sedécias,

2. Saraías, Azarías, Jeremías,

3. Pheshur, Amárias, Mélchias,

4. Hattus, Sebénia, Melluch,

5. Harem, Mérimuth, Óbdias,

6. Dániel, Genthon, Baruch,

7. Mosóllam, Abía, Miámin,

8. Maázia, Bélgai, Semeía : hi sacerdótes.

9. Porro Levítæ, Jósue fílius Azániæ, Bénnui de fíliis Henádad, Cédmihel,

10. et fratres eórum, Sebénia, Odaía, Célita, Phalaía, Hanan,

11. Micha, Rohob, Hasébia,

12. Zachur, Serébia, Sabánia,

13. Odaía, Bani, Báninu.

14. Cápita pópuli, Pharos, Phaháthmoab, Ælam, Zethu, Bani,

15. Bonni, Azgad, Bébai,

16. Adónia, Begoái, Adin,

17. Ater, Hezécia, Azur,

18. Odaía, Hasum, Bésai,

19. Hareph, Anáthoth, Nébai,

20. Mégphias, Mosóllam, Hazir,

21. Mesizábel, Sadoc, Jéddua,

22. Phéltia, Hanan, Anaía,

23. Ósee, Hanánia, Hasub,

24. Álohes, Phálea, Sobec,

25. Rehum, Hasébna, Maásia,

26. Echaía, Hanan, Anan,

27. Melluch, Haran, Baána.

28. Et réliqui de pópulo, sacerdótes, Levítæ, janitóres, et cantóres, Nathinǽi, et omnes qui se separavérunt de pópulis terrárum ad legem Dei, uxóres eórum, fílii eórum, et fíliæ eórum,

29. omnes qui póterant sápere spondéntes pro frátribus suis, optimátes eórum, et qui veniébant ad pollicéndum et jurándum ut ambulárent in lege Dei, quam déderat in manu Móysi servi Dei : ut fácerent et custodírent univérsa mandáta Dómini Dei nostri, et judícia ejus et cæremónias ejus :

30. et ut non darémus fílias nostras pópulo terræ, et fílias eórum non acciperémus fíliis nostris.

31. Pópuli quoque terræ, qui impórtant venália, et ómnia ad usum, per diem sábbati ut vendant, non accipiémus ab eis in sábbato et in die sanctificáto. Et dimittémus annum séptimum, et exactiónem univérsæ manus.

32. Et statuémus super nos præcépta, ut demus tértiam partem sicli per annum ad opus domus Dei nostri,

33. ad panes propositiónis, et ad sacrifícium sempitérnum, et in holocáustum sempitérnum in sábbatis, in caléndis, in solemnitátibus, et in sanctificátis, et pro peccáto : ut exorétur pro Israël, et in omnem usum domus Dei nostri.

34. Sortes ergo mísimus super oblatiónem lignórum inter sacerdótes, et Levítas, et pópulum, ut inferréntur in domum Dei nostri per domos patrum nostrórum, per témpora, a tempóribus anni usque ad annum : ut árderent super altáre Dómini Dei nostri, sicut scriptum est in lege Móysi :

35. et ut afferrémus primogénita terræ nostræ, et primitíva univérsi fructus omnis ligni, ab anno in annum, in domo Dómini :

36. et primitíva filiórum nostrórum et pécorum nostrórum, sicut scriptum est in lege, et primitíva boum nostrórum et óvium nostrárum, ut offerréntur in domo Dei nostri, sacerdótibus qui minístrant in domo Dei nostri :

37. et primítias cibórum nostrórum, et libáminum nostrórum, et poma omnis ligni, vindémiæ quoque et ólei, afferémus sacerdótibus ad gazophylácium Dei nostri, et décimam partem terræ nostræ Levítis. Ipsi Levítæ décimas accípient ex ómnibus civitátibus óperum nostrórum.

38. Erit autem sacérdos fílius Áaron cum Levítis in décimis Levitárum, et Levítæ ófferent décimam partem décimæ suæ in domo Dei nostri ad gazophylácium in domum thesáuri.

39. Ad gazophylácium enim deportábunt fílii Israël, et fílii Levi, primítias fruménti, vini, et ólei : et ibi erunt vasa sanctificáta, et sacerdótes, et cantóres, et janitóres, et minístri : et non dimittémus domum Dei nostri.

