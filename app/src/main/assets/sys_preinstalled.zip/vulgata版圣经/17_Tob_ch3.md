# Liber Tobi� - Caput 3

1. Tunc Tobías ingémuit, et cœpit oráre cum lácrimis,

2. dicens : Justus es, Dómine, et ómnia judícia tua justa sunt, et omnes viæ tuæ, misericórdia, et véritas, et judícium.

3. Et nunc Dómine, memor esto mei, et ne vindíctam sumas de peccátis meis, neque reminiscáris delícta mea, vel paréntum meórum.

4. Quóniam non obedívimus præcéptis tuis, ídeo tráditi sumus in direptiónem, et captivitátem, et mortem, et in fábulam, et in impropérium ómnibus natiónibus in quibus dispersísti nos.

5. Et nunc Dómine, magna judícia tua, quia non égimus secúndum præcépta tua, et non ambulávimus sincériter coram te.

6. Et nunc Dómine, secúndum voluntátem tuam fac mecum, et prǽcipe in pace récipi spíritum meum : éxpedit enim mihi mori magis quam vívere.

7. Eádem ítaque die, cóntigit ut Sara fília Ráguelis in Rages civitáte Medórum et ipsa audíret impropérium ab una ex ancíllis patris sui,

8. quóniam trádita fúerat septem viris, et dæmónium nómine Asmodǽus occíderat eos, mox ut ingréssi fuíssent ad eam.

9. Ergo cum pro culpa sua increpáret puéllam, respóndit ei, dicens : Ámplius ex te non videámus fílium aut fíliam super terram, interféctrix virórum tuórum.

10. Numquid et occídere me vis, sicut jam occidísti septem viros ? Ad hanc vocem perréxit in supérius cubículum domus suæ : et tribus diébus, et tribus nóctibus non manducávit, neque bibit :

11. sed in oratióne persístens cum lácrimis deprecabátur Deum, ut ab isto impropério liberáret eam.

12. Factum est autem die tértia, dum compléret oratiónem, benedícens Dóminum

13. dixit : Benedíctum est nomen tuum, Deus patrum nostrórum : qui cum irátus fúeris, misericórdiam fácies, et in témpore tribulatiónis peccáta dimíttis his qui ínvocant te.

14. Ad te, Dómine, fáciem meam convérto ; ad te óculos meos dírigo.

15. Peto, Dómine, ut de vínculo impropérii hujus absólvas me, aut certe désuper terram erípias me.

16. Tu scis, Dómine, quia numquam concupívi virum, et mundam servávi ánimam meam ab omni concupiscéntia.

17. Numquam cum ludéntibus míscui me, neque cum his qui in levitáte ámbulant, partícipem me prǽbui.

18. Virum autem cum timóre tuo, non cum libídine mea, consénsi suscípere.

19. Et, aut ego indígna fui illis, aut illi fórsitan me non fuérunt digni, quia fórsitan viro álii conservásti me.

20. Non est enim in hóminis potestáte consílium tuum.

21. Hoc autem pro certo habet omnis qui te colit : quod vita ejus, si in probatióne fúerit, coronábitur ; si autem in tribulatióne fúerit, liberábitur ; et si in correptióne fúerit, ad misericórdiam tuam veníre licébit.

22. Non enim delectáris in perditiónibus nostris : quia post tempestátem tranquíllum facis, et post lacrimatiónem et fletum, exultatiónem infúndis.

23. Sit nomen tuum, Deus Israël, benedíctum in sǽcula.

24. In illo témpore exaudítæ sunt preces ambórum in conspéctu glóriæ summi Dei :

25. et missus est ángelus Dómini sanctus Ráphaël ut curáret eos ambos, quorum uno témpore sunt oratiónes in conspéctu Dómini recitátæ.

