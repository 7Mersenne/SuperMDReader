# Liber Esdr� - Caput 9

1. Postquam autem hæc compléta sunt, accessérunt ad me príncipes, dicéntes : Non est separátus pópulus Israël, sacerdótes et Levítæ, a pópulis terrárum et abominatiónibus eórum : Chananǽi vidélicet, et Hethǽi, et Pherezǽi, et Jebusǽi, et Ammonitárum, et Moabitárum, et Ægyptiórum, et Amorrhæórum :

2. tulérunt enim de filiábus eórum sibi et fíliis suis, et commiscuérunt semen sanctum cum pópulis terrárum : manus étiam príncipum et magistrátuum fuit in transgressióne hac prima.

3. Cumque audíssem sermónem istum, scidi pállium meum et túnicam, et evélli capíllos cápitis mei et barbæ, et sedi mœrens.

4. Convenérunt autem ad me omnes qui timébant verbum Dei Israël, pro transgressióne eórum qui de captivitáte vénerant, et ego sedébam tristis usque ad sacrifícium vespertínum :

5. et in sacrifício vespertíno, surréxi de afflictióne mea, et scisso pállio et túnica, curvávi génua mea, et expándi manus meas ad Dóminum Deum meum.

6. Et dixi : Deus meus, confúndor et erubésco leváre fáciem meam ad te : quóniam iniquitátes nostræ multiplicátæ sunt super caput nostrum, et delícta nostra crevérunt usque ad cælum,

7. a diébus patrum nostrórum : sed et nos ipsi peccávimus gráviter usque ad diem hanc, et in iniquitátibus nostris tráditi sumus ipsi, et reges nostri, et sacerdótes nostri, in manum regum terrárum, et in gládium, et in captivitátem, et in rapínam, et in confusiónem vultus, sicut et die hac.

8. Et nunc quasi parum et ad moméntum facta est deprecátio nostra apud Dóminum Deum nostrum, ut dimitteréntur nobis réliquiæ, et darétur nobis paxíllus in loco sancto ejus, et illumináret óculos nostros Deus noster, et daret nobis vitam módicam in servitúte nostra :

9. quia servi sumus, et in servitúte nostra non derelíquit nos Deus noster, sed inclinávit super nos misericórdiam coram rege Persárum, ut daret nobis vitam, et sublimáret domum Dei nostri, et exstrúeret solitúdines ejus, et daret nobis sepem in Juda et Jerúsalem.

10. Et nunc quid dicémus, Deus noster, post hæc ? Quia derelíquimus mandáta tua,

11. quæ præcepísti in manu servórum tuórum prophetárum, dicens : Terra, ad quam vos ingredímini ut possideátis eam, terra immúnda est juxta immundítiam populórum, ceterarúmque terrárum, abominatiónibus eórum qui replevérunt eam ab ore usque ad os in coinquinatióne sua.

12. Nunc ergo fílias vestras ne detis fíliis eórum, et fílias eórum ne accipiátis fíliis vestris, et non quærátis pacem eórum et prosperitátem eórum usque in ætérnum : ut confortémini, et comedátis quæ bona sunt terræ, et hǽredes habeátis fílios vestros usque in sǽculum.

13. Et post ómnia quæ venérunt super nos in opéribus nostris péssimis, et in delícto nostro magno, quia tu, Deus noster, liberásti nos de iniquitáte nostra, et dedísti nobis salútem sicut est hódie,

14. ut non converterémur, et írrita facerémus mandáta tua, neque matrimónia jungerémus cum pópulis abominatiónum istárum. Numquid irátus es nobis usque ad consummatiónem, ne dimítteres nobis relíquias ad salútem ?

15. Dómine Deus Israël, justus es tu : quóniam derelícti sumus, qui salvarémur sicut die hac. Ecce coram te sumus in delícto nostro : non enim stari potest coram te super hoc.

