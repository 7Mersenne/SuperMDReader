# Liber Genesis - Caput 42

1. Áudiens autem Jacob quod aliménta venderéntur in Ægýpto, dixit fíliis suis : Quare neglígitis ?

2. audívi quod tríticum venundétur in Ægýpto : descendíte, et émite nobis necessária, ut possímus vívere, et non consumámur inópia.

3. Descendéntes ígitur fratres Joseph decem, ut émerent fruménta in Ægýpto,

4. Bénjamin domi reténto a Jacob, qui díxerat frátribus ejus : Ne forte in itínere quidquam patiátur mali :

5. ingréssi sunt terram Ægýpti cum áliis qui pergébant ad eméndum. Erat autem fames in terra Chánaan.

6. Et Joseph erat princeps in terra Ægýpti, atque ad ejus nutum fruménta pópulis vendebántur. Cumque adorássent eum fratres sui,

7. et agnovísset eos, quasi ad aliénos dúrius loquebátur, intérrogans eos : Unde venístis ? Qui respondérunt : De terra Chánaan, ut emámus víctui necessária.

8. Et tamen fratres ipse cognóscens, non est cógnitus ab eis.

9. Recordatúsque somniórum, quæ aliquándo víderat, ait ad eos : Exploratóres estis : ut videátis infirmióra terræ venístis.

10. Qui dixérunt : Non est ita, dómine, sed servi tui venérunt ut émerent cibos.

11. Omnes fílii uníus viri sumus : pacífici venímus, nec quidquam fámuli tui machinántur mali.

12. Quibus ille respóndit : Áliter est : immúnita terræ hujus consideráre venístis.

13. At illi : Duódecim, ínquiunt, servi tui, fratres sumus, fílii viri uníus in terra Chánaan : mínimus cum patre nostro est, álius non est super.

14. Hoc est, ait, quod locútus sum : exploratóres estis.

15. Jam nunc experiméntum vestri cápiam : per salútem Pharaónis non egrediémini hinc, donec véniat frater vester mínimus.

16. Míttite ex vobis unum, et addúcat eum : vos autem éritis in vínculis, donec probéntur quæ dixístis utrum vera an falsa sint : alióquin per salútem Pharaónis exploratóres estis.

17. Trádidit ergo illos custódiæ tribus diébus.

18. Die autem tértio edúctis de cárcere, ait : Fácite quæ dixi, et vivétis : Deum enim tímeo.

19. Si pacífici estis, frater vester unus ligétur in cárcere : vos autem ábite, et ferte fruménta quæ emístis, in domos vestras,

20. et fratrem vestrum mínimum ad me addúcite, ut possim vestros probáre sermónes, et non moriámini. Fecérunt ut díxerat,

21. et locúti sunt ad ínvicem : Mérito hæc pátimur, quia peccávimus in fratrem nostrum, vidéntes angústiam ánimæ illíus, dum deprecarétur nos, et non audívimus : idcírco venit super nos ista tribulátio.

22. E quibus unus Ruben, ait : Numquid non dixi vobis : Nolíte peccáre in púerum : et non audístis me ? en sanguis ejus exquíritur.

23. Nesciébant autem quod intellígeret Joseph, eo quod per interprétem loquerétur ad eos.

24. Avertítque se parúmper, et flevit : et revérsus locútus est ad eos.

25. Tollénsque Símeon, et ligans illis præséntibus, jussit minístris ut implérent eórum saccos trítico, et repónerent pecúnias singulórum in sácculis suis, datis supra cibáriis in viam : qui fecérunt ita.

26. At illi portántes fruménta in ásinis suis, profécti sunt.

27. Apertóque unus sacco, ut daret juménto pábulum in diversório, contemplátus pecúniam in ore sácculi,

28. dixit frátribus suis : Réddita est mihi pecúnia, en habétur in sacco. Et obstupefácti, turbatíque, mútuo dixérunt : Quidnam est hoc quod fecit nobis Deus ?

29. Venerúntque ad Jacob patrem suum in terram Chánaan, et narravérunt ei ómnia quæ accidíssent sibi, dicéntes :

30. Locútus est nobis dóminus terræ dure, et putávit nos exploratóres esse provínciæ.

31. Cui respóndimus : Pacífici sumus, nec ullas mólimur insídias.

32. Duódecim fratres uno patre géniti sumus : unus non est super, mínimus cum patre nostro est in terra Chánaan.

33. Qui ait nobis : Sic probábo quod pacífici sitis : fratrem vestrum unum dimíttite apud me, et cibária dómibus vestris necessária súmite, et ábite,

34. fratrémque vestrum mínimum addúcite ad me, ut sciam quod non sitis exploratóres : et istum, qui tenétur in vínculis, recípere possítis : ac deínceps quæ vultis, eméndi habeátis licéntiam.

35. His dictis, cum fruménta effúnderent, sínguli reperérunt in ore saccórum ligátas pecúnias, exterritísque simul ómnibus,

36. dixit pater Jacob : Absque líberis me esse fecístis : Joseph non est super, Símeon tenétur in vínculis, et Bénjamin auferétis : in me hæc ómnia mala recidérunt.

37. Cui respóndit Ruben : Duos fílios meos intérfice, si non redúxero illum tibi : trade illum in manu mea, et ego eum tibi restítuam.

38. At ille : Non descéndet, inquit, fílius meus vobíscum : frater ejus mórtuus est, et ipse solus remánsit : si quid ei advérsi accíderit in terra ad quam pérgitis, deducétis canos meos cum dolóre ad ínferos.

