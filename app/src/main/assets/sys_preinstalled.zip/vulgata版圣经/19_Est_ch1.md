# Liber Esther - Caput 1

1. In diébus Assúeri, qui regnávit ab Índia usque Æthiópiam super centum vigínti septem províncias,

2. quando sedit in sólio regni sui, Susan cívitas regni ejus exórdium fuit.

3. Tértio ígitur anno impérii sui fecit grande convívium cunctis princípibus et púeris suis, fortíssimis Persárum, et Medórum ínclytis, et præféctis provinciárum coram se,

4. ut osténderet divítias glóriæ regni sui, ac magnitúdinem atque jactántiam poténtiæ suæ, multo témpore, centum vidélicet et octogínta diébus.

5. Cumque impleréntur dies convívii, invitávit omnem pópulum, qui invéntus est in Susan, a máximo usque ad mínimum : et jussit septem diébus convívium præparári in vestíbulo horti, et nemóris quod régio cultu et manu cónsitum erat.

6. Et pendébant ex omni parte tentória ǽrii colóris et carbásini ac hyacínthini, sustentáta fúnibus býssinis atque purpúreis, qui ebúrneis círculis insérti erant, et colúmnis marmóreis fulciebántur. Léctuli quoque áurei et argéntei, super paviméntum smarágdino et pário stratum lápide, dispósiti erant : quod mira varietáte pictúra decorábat.

7. Bibébant autem qui invitáti erant áureis póculis, et áliis atque áliis vasis cibi inferebántur. Vinum quoque, ut magnificéntia régia dignum erat, abúndans, et præcípuum ponebátur.

8. Nec erat qui noléntes cógeret ad bibéndum, sed sicut rex statúerat, præpónens mensis síngulos de princípibus suis ut súmeret unusquísque quod vellet.

9. Vasthi quoque regína fecit convívium feminárum in palátio, ubi rex Assúerus manére consuéverat.

10. Ítaque die séptimo, cum rex esset hilárior, et post nímiam potatiónem incaluísset mero, præcépit Maumam, et Bazátha, et Harbóna, et Bagátha, et Abgátha, et Zethar, et Charchas, septem eunúchis qui in conspéctu ejus ministrábant,

11. ut introdúcerent regínam Vasthi coram rege, pósito super caput ejus diadémate, ut osténderet cunctis pópulis et princípibus pulchritúdinem illíus : erat enim pulchra valde.

12. Quæ rénuit, et ad regis impérium quod per eunúchos mandáverat, veníre contémpsit. Unde irátus rex, et nímio furóre succénsus,

13. interrogávit sapiéntes, qui ex more régio semper ei áderant, et illórum faciébat cuncta consílio, sciéntium leges, ac jura majórum

14. (erant autem primi et próximi, Chársena, et Sethar, et Admátha, et Tharsis, et Mares, et Marsána, et Mámuchan, septem duces Persárum, atque Medórum, qui vidébant fáciem regis, et primi post eum resídere sóliti erant) :

15. cui senténtiæ Vasthi regína subjacéret, quæ Assúeri regis impérium, quod per eunúchos mandáverat, fácere noluísset.

16. Respondítque Mámuchan, audiénte rege atque princípibus : Non solum regem læsit regína Vasthi, sed et omnes pópulos et príncipes qui sunt in cunctis provínciis regis Assúeri.

17. Egrediétur enim sermo regínæ ad omnes mulíeres, ut contémnant viros suos, et dicant : Rex Assúerus jussit ut regína Vasthi intráret ad eum, et illa nóluit.

18. Atque hoc exémplo omnes príncipum cónjuges Persárum atque Medórum parvipéndent impéria maritórum : unde regis justa est indignátio.

19. Si tibi placet, egrediátur edíctum a fácie tua, et scribátur juxta legem Persárum atque Medórum, quam præteríri illícitum est, ut nequáquam ultra Vasthi ingrediátur ad regem, sed regnum illíus áltera, quæ mélior est illa, accípiat.

20. Et hoc in omne (quod latíssimum est) provinciárum tuárum divulgétur impérium, et cunctæ uxóres, tam majórum quam minórum, déferant máritis suis honórem.

21. Plácuit consílium ejus regi et princípibus : fecítque rex juxta consílium Mámuchan,

22. et misit epístolas ad univérsas províncias regni sui, ut quæque gens audíre et légere póterat, divérsis linguis et lítteris, esse viros príncipes ac majóres in dómibus suis : et hoc per cunctos pópulos divulgári.

