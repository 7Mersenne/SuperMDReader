# Liber Esther - Caput 2

1. His ita gestis, postquam regis Assúeri indignátio deferbúerat, recordátus est Vasthi, et quæ fecísset, vel quæ passa esset :

2. dixerúntque púeri regis ac minístri ejus : Quærántur regi puéllæ vírgines ac speciósæ,

3. et mittántur qui consíderent per univérsas províncias puéllas speciósas et vírgines : et addúcant eas ad civitátem Susan, et tradant eas in domum feminárum sub manu Égei eunúchi, qui est præpósitus et custos mulíerum regiárum : et accípiant mundum mulíebrem, et cétera ad usus necessária.

4. Et quæcúmque inter omnes óculis regis placúerit, ipsa regnet pro Vasthi. Plácuit sermo regi : et ita, ut suggésserant, jussit fíeri.

5. Erat vir Judǽus in Susan civitáte, vocábulo Mardochǽus fílius Jair, fílii Sémei, fílii Cis, de stirpe Jémini,

6. qui translátus fúerat de Jerúsalem eo témpore quo Jechoníam regem Juda Nabuchodonósor rex Babylónis transtúlerat,

7. qui fuit nutrítius fíliæ fratris sui Edíssæ, quæ áltero nómine vocabátur Esther, et utrúmque paréntem amíserat : pulchra nimis, et decóra fácie. Mortuísque patre ejus ac matre, Mardochǽus sibi eam adoptávit in fíliam.

8. Cumque percrebruísset regis impérium, et juxta mandátum illíus multæ pulchræ vírgines adduceréntur Susan, et Égeo traderéntur eunúcho, Esther quoque inter céteras puéllas ei trádita est, ut servarétur in número feminárum.

9. Quæ plácuit ei, et invénit grátiam in conspéctu illíus. Et præcépit eunúcho, ut acceleráret mundum mulíebrem, et tráderet ei partes suas, et septem puéllas speciosíssimas de domo regis, et tam ipsam quam pedisséquas ejus ornáret atque excóleret.

10. Quæ nóluit indicáre ei pópulum et pátriam suam : Mardochǽus enim præcéperat ei, ut de hac re omníno retíceret :

11. qui deambulábat quotídie ante vestíbulum domus, in qua eléctæ vírgines servabántur, curam agens salútis Esther, et scire volens quid ei accíderet.

12. Cum autem venísset tempus singulárum per órdinem puellárum ut intrárent ad regem, explétis ómnibus quæ ad cultum mulíebrem pertinébant, mensis duodécimus vertebátur : ita dumtáxat, ut sex ménsibus óleo ungeréntur mýrrhino, et áliis sex quibúsdam pigméntis et aromátibus uteréntur.

13. Ingredientésque ad regem, quidquid postulássent ad ornátum pértinens, accipiébant : et ut eis placúerat, compósitæ de triclínio feminárum ad regis cubículum transíbant.

14. Et quæ intráverat véspere, egrediebátur mane, atque inde in secúndas ædes deducebátur, quæ sub manu Susagázi eunúchi erant, qui concubínis regis præsidébat : nec habébat potestátem ad regem ultra redeúndi, nisi voluísset rex, et eam veníre jussísset ex nómine.

15. Evolúto autem témpore per órdinem, instábat dies quo Esther fília Abíhail fratris Mardochǽi, quam sibi adoptáverat in fíliam, déberet intráre ad regem. Quæ non quæsívit mulíebrem cultum, sed quæcúmque vóluit Égeus eunúchus custos vírginum, hæc ei ad ornátum dedit. Erat enim formósa valde, et incredíbili pulchritúdine : ómnium óculis gratiósa et amábilis videbátur.

16. Ducta est ítaque ad cubículum regis Assúeri mense décimo, qui vocátur Tebeth, séptimo anno regni ejus.

17. Et adamávit eam rex plus quam omnes mulíeres, habuítque grátiam et misericórdiam coram eo super omnes mulíeres : et pósuit diadéma regni in cápite ejus, fecítque eam regnáre in loco Vasthi.

18. Et jussit convívium præparári permagníficum cunctis princípibus et servis suis pro conjunctióne et núptiis Esther. Et dedit réquiem univérsis provínciis, ac dona largítus est juxta magnificéntiam principálem.

19. Cumque secúndo quæreréntur vírgines et congregaréntur, Mardochǽus manébat ad jánuam regis :

20. necdum prodíderat Esther pátriam et pópulum suum, juxta mandátum ejus. Quidquid enim ille præcipiébat, observábat Esther : et ita cuncta faciébat ut eo témpore sólita erat, quo eam párvulam nutriébat.

21. Eo ígitur témpore, quo Mardochǽus ad regis jánuam morabátur, iráti sunt Bagáthan et Thares duo eunúchi regis, qui janitóres erant, et in primo palátii límine præsidébant : voluerúntque insúrgere in regem, et occídere eum.

22. Quod Mardochǽum non látuit, statímque nuntiávit regínæ Esther : et illa regi ex nómine Mardochǽi, qui ad se rem detúlerat.

23. Quǽsitum est, et invéntum : et appénsus est utérque eórum in patíbulo. Mandatúmque est históriis, et annálibus tráditum coram rege.

