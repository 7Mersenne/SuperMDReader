# Liber Judith - Caput 12

1. Tunc jussit eam introíre ubi repósiti erant thesáuri ejus, et jussit illic manére eam, et constítuit quid darétur illi de convívio suo.

2. Cui respóndit Judith, et dixit : Nunc non pótero manducáre ex his quæ mihi prǽcipis tríbui, ne véniat super me offénsio : ex his autem quæ mihi détuli, manducábo.

3. Cui Holoférnes ait : Si defécerint tibi ista, quæ tecum detulísti, quid faciémus tibi ?

4. Et dixit Judith : Vivit ánima tua, dómine meus, quóniam non expéndet ómnia hæc ancílla tua, donec fáciat Deus in manu mea hæc quæ cogitávi. Et induxérunt illam servi ejus in tabernáculum quod præcéperat.

5. Et pétiit dum introíret, ut darétur ei cópia nocte et ante lucem egrediéndi foras ad oratiónem, et deprecándi Dóminum.

6. Et præcépit cubiculáriis suis ut sicut placéret illi, exíret et introíret ad adorándum Deum suum per tríduum :

7. et exíbat nóctibus in vallem Bethúliæ, et baptizábat se in fonte aquæ.

8. Et ut ascendébat, orábat Dóminum Deum Israël ut dirígeret viam ejus ad liberatiónem pópuli sui.

9. Et intróiens, munda manébat in tabernáculo usque dum accíperet escam suam in véspere.

10. Et factum est, in quarto die Holoférnes fecit cœnam servis suis, et dixit ad Vágao eunúchum suum : Vade, et suáde Hebrǽam illam ut sponte conséntiat habitáre mecum.

11. Fœdum est enim apud Assýrios, si fémina irrídeat virum agéndo ut immúnis ab eo tránseat.

12. Tunc introívit Vágao ad Judith, et dixit : Non vereátur bona puélla introíre ad dóminum meum, ut honorificétur ante fáciem ejus, ut mandúcet cum eo, et bibat vinum in jucunditáte.

13. Cui Judith respóndit : Quæ ego sum, ut contradícam dómino meo ?

14. omne quod erit ante óculos ejus bonum et óptimum, fáciam. Quidquid autem illi placúerit, hoc mihi erit óptimum ómnibus diébus vitæ meæ.

15. Et surréxit, et ornávit se vestiménto suo, et ingréssa stetit ante fáciem ejus.

16. Cor autem Holoférnes concússum est : erat enim ardens in concupiscéntia ejus.

17. Et dixit ad eam Holoférnes : Bibe nunc, et accúmbe in jucunditáte, quóniam invenísti grátiam coram me.

18. Et dixit Judith : Bibam, dómine, quóniam magnificáta est ánima mea hódie præ ómnibus diébus meis.

19. Et accépit, et manducávit et bibit coram ipso ea quæ paráverat illi ancílla ejus.

20. Et jucúndus factus est Holoférnes ad eam, bibítque vinum multum nimis, quantum numquam bíberat in vita sua.

