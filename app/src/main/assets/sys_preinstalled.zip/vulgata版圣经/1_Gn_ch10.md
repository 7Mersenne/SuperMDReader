# Liber Genesis - Caput 10

1. Hæ sunt generatiónes filiórum Noë, Sem, Cham et Japheth : natíque sunt eis fílii post dilúvium.

2. Fílii Japheth : Gomer, et Magog, et Mádai, et Javan, et Thubal, et Mosoch, et Thiras.

3. Porro fílii Gomer : Áscenez et Riphath et Thogórma.

4. Fílii autem Javan : Elísa et Tharsis, Cetthim et Dodánim.

5. Ab his divísæ sunt ínsulæ géntium in regiónibus suis, unusquísque secúndum linguam suam et famílias suas in natiónibus suis.

6. Fílii autem Cham : Chus, et Mésraim, et Phuth, et Chánaan.

7. Fílii Chus : Saba, et Hévila, et Sabátha, et Regma, et Sabatácha. Fílii Regma : Saba et Dadan.

8. Porro Chus génuit Nemrod : ipse cœpit esse potens in terra,

9. et erat robústus venátor coram Dómino. Ob hoc exívit provérbium : Quasi Nemrod robústus venátor coram Dómino.

10. Fuit autem princípium regni ejus Bábylon, et Arach et Achad, et Chalánne, in terra Sénnaar.

11. De terra illa egréssus est Assur, et ædificávit Níniven, et platéas civitátis, et Chale.

12. Resen quoque inter Níniven et Chale : hæc est cívitas magna.

13. At vero Mésraim génuit Ludim, et Anámim et Laábim, Néphthuim,

14. et Phetrúsim, et Chásluim : de quibus egréssi sunt Philísthiim et Caphtórim.

15. Chánaan autem génuit Sidónem primogénitum suum. Hethǽum,

16. et Jebusǽum, et Amorrhǽum, Gergesǽum,

17. Hevǽum, et Aracǽum : Sinǽum,

18. et Arádium, Samarǽum, et Amathǽum : et post hæc dissemináti sunt pópuli Chananæórum.

19. Factíque sunt términi Chánaan veniéntibus a Sidóne Geráram usque Gazam, donec ingrediáris Sodómam et Gomórrham, et Adámam, et Séboim usque Lesa.

20. Hi sunt fílii Cham in cognatiónibus, et linguis, et generatiónibus, terrísque et géntibus suis.

21. De Sem quoque nati sunt, patre ómnium filiórum Heber, fratre Japheth majóre.

22. Fílii Sem : Ælam, et Assur, et Arpháxad, et Lud, et Aram.

23. Fílii Aram : Us, et Hul, et Gether, et Mes.

24. At vero Arpháxad génuit Sale, de quo ortus est Heber.

25. Natíque sunt Heber fílii duo : nomen uni Phaleg, eo quod in diébus ejus divísa sit terra : et nomen fratris ejus Jectan.

26. Qui Jectan génuit Élmodad, et Saleph, et Asármoth, Jare,

27. et Adúram, et Uzal, et Decla,

28. et Ebal, et Abímaël, Saba,

29. et Ophir, et Hévila, et Jobab : omnes isti, fílii Jectan.

30. Et facta est habitátio eórum de Messa pergéntibus usque Sephar montem orientálem.

31. Isti fílii Sem secúndum cognatiónes, et linguas, et regiónes in géntibus suis.

32. Hæ famíliæ Noë juxta pópulos et natiónes suas. Ab his divísæ sunt gentes in terra post dilúvium.

