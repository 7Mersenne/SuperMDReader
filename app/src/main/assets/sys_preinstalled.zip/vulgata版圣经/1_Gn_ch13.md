# Liber Genesis - Caput 13

1. Ascéndit ergo Abram de Ægýpto, ipse et uxor ejus, et ómnia quæ habébat, et Lot cum eo, ad austrálem plagam.

2. Erat autem dives valde in possessióne auri et argénti.

3. Reversúsque est per iter, quo vénerat, a merídie in Bethel, usque ad locum ubi prius fíxerat tabernáculum inter Bethel et Hai,

4. in loco altáris quod fécerat prius : et invocávit ibi nomen Dómini.

5. Sed et Lot qui erat cum Abram, fuérunt greges óvium, et arménta, et tabernácula.

6. Nec póterat eos cápere terra, ut habitárent simul : erat quippe substántia eórum multa, et nequíbant habitáre commúniter.

7. Unde et facta est rixa inter pastóres gregum Abram et Lot. Eo autem témpore Chananǽus et Pherezǽus habitábant in terra illa.

8. Dixit ergo Abram ad Lot : Ne quæso sit júrgium inter me et te, et inter pastóres meos et pastóres tuos : fratres enim sumus.

9. Ecce univérsa terra coram te est : recéde a me, óbsecro : si ad sinístram íeris, ego déxteram tenébo : si tu déxteram elégeris, ego ad sinístram pergam.

10. Elevátis ítaque Lot óculis, vidit omnem circa regiónem Jordánis, quæ univérsa irrigabátur ántequam subvérteret Dóminus Sodómam et Gomórrham, sicut paradísus Dómini, et sicut Ægýptus veniéntibus in Segor.

11. Elegítque sibi Lot regiónem circa Jordánem, et recéssit ab oriénte : divisíque sunt altérutrum a fratre suo.

12. Abram habitávit in terra Chánaan ; Lot vero morátus est in óppidis, quæ erant circa Jordánem, et habitávit in Sodómis.

13. Hómines autem Sodómitæ péssimi erant, et peccatóres coram Dómino nimis.

14. Dixítque Dóminus ad Abram, postquam divísus est ab eo Lot : Leva óculos tuos et vide a loco, in quo nunc es, ad aquilónem et merídiem, ad oriéntem et occidéntem.

15. Omnem terram, quam cónspicis, tibi dabo, et sémini tuo usque in sempitérnum.

16. Faciámque semen tuum sicut púlverem terræ : si quis potest hóminum numeráre púlverem terræ, semen quoque tuum numeráre póterit.

17. Surge, et perámbula terram in longitúdine et in latitúdine sua : quia tibi datúrus sum eam.

18. Movens ígitur tabernáculum suum Abram, venit, et habitávit juxta convállem Mambre, quæ est in Hebron : ædificavítque ibi altáre Dómino.

