# Liber Judith - Caput 9

1. Quibus ascendéntibus, Judith ingréssa est oratórium suum : et índuens se cilício, pósuit cínerem super caput suum : et prostérnens se Dómino, clamábat ad Dóminum, dicens :

2. Dómine Deus patris mei Símeon, qui dedísti illi gládium in defensiónem alienigenárum, qui violatóres extitérunt in coinquinatióne sua, et denudavérunt femur vírginis in confusiónem :

3. et dedísti mulíeres illórum in prædam, et fílias illórum in captivitátem : et omnem prædam in divisiónem servis tuis, qui zelavérunt zelum tuum : subvéni, quæso te, Dómine Deus meus, mihi víduæ.

4. Tu enim fecísti prióra, et illa post illa cogitásti : et hoc factum est quod ipse voluísti.

5. Omnes enim viæ tuæ parátæ sunt, et tua judícia in tua providéntia posuísti.

6. Réspice castra Assyriórum nunc, sicut tunc castra Ægyptiórum vidére dignátus es, quando post servos tuos armáti currébant, confidéntes in quadrígis, et in equitátu suo, et in multitúdine bellatórum.

7. Sed aspexísti super castra eórum, et ténebræ fatigavérunt eos.

8. Ténuit pedes eórum abýssus, et aquæ operuérunt eos.

9. Sic fiant et isti, Dómine, qui confídunt in multitúdine sua, et in cúrribus suis, et in contis, et in scutis, et in sagíttis suis, et in lánceis gloriántur,

10. et nésciunt quia tu ipse es Deus noster, qui cónteris bella ab inítio, et Dóminus nomen est tibi.

11. Érige bráchium tuum sicut ab inítio, et allíde virtútem illórum in virtúte tua : cadat virtus eórum in iracúndia tua, qui promíttunt se violáre sancta tua, et pollúere tabernáculum nóminis tui, et dejícere gládio suo cornu altáris tui.

12. Fac, Dómine, ut gládio próprio ejus supérbia amputétur :

13. capiátur láqueo oculórum suórum in me, et percúties eum ex lábiis caritátis meæ.

14. Da mihi in ánimo constántiam ut contémnam illum, et virtútem, ut evértam illum.

15. Erit enim hoc memoriále nóminis tui, cum manus féminæ dejécerit eum.

16. Non enim in multitúdine est virtus tua, Dómine, neque in equórum víribus volúntas tua est, nec supérbi ab inítio placuérunt tibi : sed humílium et mansuetórum semper tibi plácuit deprecátio.

17. Deus cælórum, creátor aquárum, et Dóminus tótius creatúræ, exáudi me míseram deprecántem, et de tua misericórdia præsuméntem.

18. Meménto, Dómine, testaménti tui, et da verbum in ore meo, et in corde meo consílium corrobóra, ut domus tua in sanctificatióne tua permáneat :

19. et omnes gentes agnóscant quia tu es Deus, et non est álius præter te.

