# Liber Tobi� - Caput 2

1. Post hæc vero, cum esset dies festus Dómini, et factum esset prándium bonum in domo Tobíæ,

2. dixit fílio suo : Vade, et adduc áliquos de tribu nostra, timéntes Deum, ut epuléntur nobíscum.

3. Cumque abiísset, revérsus nuntiávit ei unum ex fíliis Israël jugulátum jácere in platéa. Statímque exíliens de accúbitu suo, relínquens prándium, jejúnus pervénit ad corpus :

4. tollénsque illud portávit ad domum suam occúlte, ut dum sol occubuísset, caute sepelíret eum.

5. Cumque occultásset corpus, manducávit panem cum luctu et tremóre,

6. mémorans illum sermónem, quem dixit Dóminus per Amos prophétam : Dies festi vestri converténtur in lamentatiónem et luctum.

7. Cum vero sol occubuísset, ábiit, et sepelívit eum.

8. Arguébant autem eum omnes próximi ejus, dicéntes : Jam hujus rei causa intérfici jussus es, et vix effugísti mortis impérium, et íterum sépelis mórtuos ?

9. Sed Tobías plus timens Deum quam regem, rapiébat córpora occisórum, et occultábat in domo sua, et médiis nóctibus sepeliébat ea.

10. Cóntigit autem ut quadam die fatigátus a sepultúra, véniens in domum suam, jactásset se juxta paríetem, et obdormísset,

11. et ex nido hirúndinum dormiénti illi cálida stércora incíderent super óculos ejus, fierétque cæcus.

12. Hanc autem tentatiónem ídeo permísit Dóminus eveníre illi, ut pósteris darétur exémplum patiéntiæ ejus, sicut et sancti Job.

13. Nam cum ab infántia sua semper Deum timúerit, et mandáta ejus custodíerit, non est contristátus contra Deum quod plaga cæcitátis evénerit ei,

14. sed immóbilis in Dei timóre permánsit, agens grátias Deo ómnibus diébus vitæ suæ.

15. Nam sicut beáto Job insultábant reges, ita isti paréntes et cognáti ejus irridébant vitam ejus, dicéntes :

16. Ubi est spes tua, pro qua eleemósynas et sepultúras faciébas ?

17. Tobías vero increpábat eos, dicens : Nolíte ita loqui :

18. quóniam fílii sanctórum sumus, et vitam illam expectámus, quam Deus datúrus est his qui fidem suam numquam mutant ab eo.

19. Anna vero uxor ejus ibat ad opus téxtrinum quotídie, et de labóre mánuum suárum victum quem cónsequi póterat, deferébat.

20. Unde factum est ut hædum caprárum accípiens detulísset domi :

21. cujus cum vocem balántis vir ejus audísset, dixit : Vidéte, ne forte furtívus sit : réddite eum dóminis suis, quia non licet nobis aut édere ex furto áliquid, aut contíngere.

22. Ad hæc uxor ejus iráta respóndit : Maniféste vana facta est spes tua, et eleemósynæ tuæ modo apparuérunt.

23. Atque his et áliis hujuscémodi verbis exprobrábat ei.

