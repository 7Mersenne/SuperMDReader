# Liber Nehemi� - Caput 13

1. In die autem illo, lectum est in volúmine Móysi, audiénte pópulo : et invéntum est scriptum in eo, quod non débeant introíre Ammónites et Moábites in ecclésiam Dei usque in ætérnum :

2. eo quod non occúrrerint fíliis Israël cum pane et aqua, et condúxerint advérsum eos Bálaam ad maledicéndum eis : et convértit Deus noster maledictiónem in benedictiónem.

3. Factum est autem, cum audíssent legem, separavérunt omnem alienígenam ab Israël.

4. Et super hoc erat Eliásib sacérdos, qui fúerat præpósitus in gazophylácio domus Dei nostri, et próximus Tobíæ.

5. Fecit ergo sibi gazophylácium grande, et ibi erant ante eum reponéntes múnera, et thus, et vasa, et décimam fruménti, vini, et ólei, partes Levitárum, et cantórum, et janitórum, et primítias sacerdotáles.

6. In ómnibus autem his non fui in Jerúsalem, quia anno trigésimo secúndo Artaxérxis regis Babylónis veni ad regem, et in fine diérum rogávi regem.

7. Et veni in Jerúsalem, et intelléxi malum quod fécerat Eliásib Tobíæ, ut fáceret ei thesáurum in vestíbulis domus Dei.

8. Et malum mihi visum est valde. Et projéci vasa domus Tobíæ foras de gazophylácio :

9. præcepíque et emundavérunt gazophylácia : et rétuli ibi vasa domus Dei, sacrifícium, et thus.

10. Et cognóvi quod partes Levitárum non fuíssent datæ, et fugísset unusquísque in regiónem suam de Levítis, et cantóribus, et de his qui ministrábant :

11. et egi causam advérsus magistrátus, et dixi : Quare derelíquimus domum Dei ? et congregávi eos, et feci stare in statiónibus suis.

12. Et omnis Juda apportábat décimam fruménti, vini, et ólei, in hórrea.

13. Et constitúimus super hórrea Selémiam sacerdótem, et Sadoc scribam, et Phadaíam de Levítis, et juxta eos Hanan fílium Zachur, fílium Mathániæ : quóniam fidéles comprobáti sunt, et ipsis créditæ sunt partes fratrum suórum.

14. Meménto mei, Deus meus, pro hoc, et ne déleas miseratiónes meas quas feci in domo Dei mei, et in cæremóniis ejus.

15. In diébus illis vidi in Juda calcántes torculária in sábbato, portántes acérvos, et onerántes super ásinos vinum, et uvas, et ficus, et omne onus, et inferéntes in Jerúsalem, die sábbati. Et contestátus sum ut in die qua véndere licéret, vénderent.

16. Et Týrii habitavérunt in ea, inferéntes pisces, et ómnia venália : et vendébant in sábbatis fíliis Juda in Jerúsalem.

17. Et objurgávi optimátes Juda, et dixi eis : Quæ est hæc res mala quam vos fácitis, et profanátis diem sábbati ?

18. numquid non hæc fecérunt patres nostri, et addúxit Deus noster super nos omne malum hoc, et super civitátem hanc ? et vos ádditis iracúndiam super Israël violándo sábbatum.

19. Factum est autem, cum quievíssent portæ Jerúsalem in die sábbati, dixi : et clausérunt jánuas, et præcépi ut non aperírent eas usque post sábbatum : et de púeris meis constítui super portas, ut nullus inférret onus in die sábbati.

20. Et mansérunt negotiatóres, et vendéntes univérsa venália, foris Jerúsalem semel et bis.

21. Et contestátus sum eos, et dixi eis : Quare manétis ex advérso muri ? si secúndo hoc fecéritis, manum mittam in vos. Ítaque ex témpore illo non venérunt in sábbato.

22. Dixi quoque Levítis ut mundaréntur, et venírent ad custodiéndas portas, et sanctificándam diem sábbati : et pro hoc ergo meménto mei, Deus meus, et parce mihi secúndum multitúdinem miseratiónum tuárum.

23. Sed et in diébus illis vidi Judǽos ducéntes uxóres Azótidas, Ammonítidas, et Moabítidas.

24. Et fílii eórum ex média parte loquebántur azótice, et nesciébant loqui judáice, et loquebántur juxta linguam pópuli et pópuli.

25. Et objurgávi eos, et maledíxi. Et cécidi ex eis viros, et decalvávi eos, et adjurávi in Deo ut non darent fílias suas fíliis eórum, et non accíperent de filiábus eórum fíliis suis et sibimetípsis, dicens :

26. Numquid non in hujuscémodi re peccávit Sálomon rex Israël ? et certe in géntibus multis non erat rex símilis ei, et diléctus Deo suo erat, et pósuit eum Deus regem super omnem Israël : et ipsum ergo duxérunt ad peccátum mulíeres alienígenæ.

27. Numquid et nos inobediéntes faciémus omne malum grande hoc ut prævaricémur in Deo nostro, et ducámus uxóres peregrínas ?

28. De fíliis autem Jojáda fílii Eliásib sacerdótis magni, gener erat Sanabállat Horónites, quem fugávi a me.

29. Recordáre, Dómine Deus meus, advérsum eos qui pólluunt sacerdótium, jusque sacerdotále et Levíticum.

30. Ígitur mundávi eos ab ómnibus alienígenis, et constítui órdines sacerdótum et Levitárum, unumquémque in ministério suo :

31. et in oblatióne lignórum in tempóribus constitútis, et in primitívis : meménto mei, Deus meus, in bonum. Amen.

