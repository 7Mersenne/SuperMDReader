# Liber Exodus - Caput 15

1. Tunc cécinit Móyses et fílii Israël carmen hoc Dómino, et dixérunt : Cantémus Dómino : glorióse enim magnificátus est, equum et ascensórem dejécit in mare.

2. Fortitúdo mea, et laus mea Dóminus, et factus est mihi in salútem : iste Deus meus, et glorificábo eum : Deus patris mei, et exaltábo eum.

3. Dóminus quasi vir pugnátor, Omnípotens nomen ejus,

4. currus Pharaónis et exércitum ejus projécit in mare : elécti príncipes ejus submérsi sunt in mari Rubro.

5. Abýssi operuérunt eos ; descendérunt in profúndum quasi lapis.

6. Déxtera tua, Dómine, magnificáta est in fortitúdine : déxtera tua, Dómine, percússit inimícum.

7. Et in multitúdine glóriæ tuæ deposuísti adversários tuos : misísti iram tuam, quæ devorávit eos sicut stípulam.

8. Et in spíritu furóris tui congregátæ sunt aquæ : stetit unda fluens, congregáta sunt abýssi in médio mari.

9. Dixit inimícus : Pérsequar et comprehéndam, dívidam spólia, implébitur ánima mea : evaginábo gládium meum, interfíciet eos manus mea.

10. Flavit spíritus tuus, et opéruit eos mare : submérsi sunt quasi plumbum in aquis veheméntibus.

11. Quis símilis tui in fórtibus, Dómine ? quis símilis tui, magníficus in sanctitáte, terríbilis atque laudábilis, fáciens mirabília ?

12. Extendísti manum tuam, et devorávit eos terra.

13. Dux fuísti in misericórdia tua pópulo quem redemísti : et portásti eum in fortitúdine tua, ad habitáculum sanctum tuum.

14. Ascendérunt pópuli, et iráti sunt : dolóres obtinuérunt habitatóres Philísthiim.

15. Tunc conturbáti sunt príncipes Edom, robústos Moab obtínuit tremor : obriguérunt omnes habitatóres Chánaan.

16. Írruat super eos formído et pavor, in magnitúdine bráchii tui : fiant immóbiles quasi lapis, donec pertránseat pópulus tuus, Dómine, donec pertránseat pópulus tuus iste, quem possedísti.

17. Introdúces eos, et plantábis in monte hæreditátis tuæ, firmíssimo habitáculo tuo quod operátus es, Dómine : sanctuárium tuum, Dómine, quod firmavérunt manus tuæ.

18. Dóminus regnábit in ætérnum et ultra.

19. Ingréssus est enim eques Phárao cum cúrribus et equítibus ejus in mare : et redúxit super eos Dóminus aquas maris : fílii autem Israël ambulavérunt per siccum in médio ejus.

20. Sumpsit ergo María prophetíssa, soror Áaron, týmpanum in manu sua : egressǽque sunt omnes mulíeres post eam cum týmpanis et choris,

21. quibus præcinébat, dicens : Cantémus Dómino, glorióse enim magnificátus est : equum et ascensórem ejus dejécit in mare.

22. Tulit autem Móyses Israël de mari Rubro, et egréssi sunt in desértum Sur : ambulaverúntque tribus diébus per solitúdinem, et non inveniébant aquam.

23. Et venérunt in Mara, nec póterant bíbere aquas de Mara, eo quod essent amáræ : unde et cóngruum loco nomen impósuit, vocans illum Mara, id est, amaritúdinem.

24. Et murmurávit pópulus contra Móysen, dicens : Quid bibémus ?

25. At ille clamávit ad Dóminum, qui osténdit ei lignum : quod cum misísset in aquas, in dulcédinem versæ sunt : ibi constítuit ei præcépta, atque judícia, et ibi tentávit eum,

26. dicens : Si audíeris vocem Dómini Dei tui, et quod rectum est coram eo féceris, et obedíeris mandátis ejus, custodierísque ómnia præcépta illíus, cunctum languórem, quem pósui in Ægýpto, non indúcam super te : ego enim Dóminus sanátor tuus.

27. Venérunt autem in Elim fílii Israël, ubi erant duódecim fontes aquárum, et septuagínta palmæ : et castrametáti sunt juxta aquas.

