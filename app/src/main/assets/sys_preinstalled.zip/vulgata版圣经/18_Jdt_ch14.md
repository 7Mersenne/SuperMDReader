# Liber Judith - Caput 14

1. Dixit autem Judith ad omnem pópulum : Audíte me, fratres : suspéndite caput hoc super muros nostros :

2. et erit, cum exíerit sol, accípiat unusquísque arma sua, et exíte cum ímpetu, non ut descendátis deórsum, sed quasi ímpetum faciéntes.

3. Tunc exploratóres necésse erit ut fúgiant ad príncipem suum excitándum ad pugnam.

4. Cumque duces eórum cucúrrerint ad tabernáculum Holoférnis, et invénerint eum truncum in suo sánguine volutátum, décidet super eos timor.

5. Cumque cognovéritis fúgere eos, ite post illos secúri, quóniam Dóminus cónteret eos sub pédibus vestris.

6. Tunc Áchior, videns virtútem quam fecit Deus Israël, relícto gentilitátis ritu, crédidit Deo, et circumcídit carnem præpútii sui, et appósitus est ad pópulum Israël, et omnis succéssio géneris ejus usque in hodiérnum diem.

7. Mox autem ut ortus est dies, suspendérunt super muros caput Holoférnis, accepítque unusquísque vir arma sua, et egréssi sunt cum grandi strépitu et ululátu.

8. Quod vidéntes exploratóres, ad tabernáculum Holoférnis cucurrérunt.

9. Porro hi qui in tabernáculo erant, veniéntes, et ante ingréssum cubículi perstrepéntes, excitándi grátia, inquietúdinem arte moliebántur, ut non ab excitántibus, sed a sonántibus Holoférnes evigiláret.

10. Nullus enim audébat cubículum virtútis Assyriórum pulsándo aut intrándo aperíre.

11. Sed cum veníssent ejus duces ac tribúni, et univérsi majóres exércitus regis Assyriórum, dixérunt cubiculáriis :

12. Intráte, et excitáte illum, quóniam egréssi mures de cavérnis suis, ausi sunt provocáre nos ad prǽlium.

13. Tunc ingréssus Vágao cubículum ejus, stetit ante cortínam, et plausum fecit mánibus suis : suspicabátur enim illum cum Judith dormíre.

14. Sed cum nullum motum jacéntis sensu áurium cáperet, accéssit próximans ad cortínam, et élevans eam, vidénsque cadáver absque cápite Holoférnis in suo sánguine tabefáctum jácere super terram, exclamávit voce magna cum fletu, et scidit vestiménta sua.

15. Et ingréssus tabernáculum Judith, non invénit eam, et exíliit foras ad pópulum,

16. et dixit : Una múlier hebrǽa fecit confusiónem in domo regis Nabuchodonósor : ecce enim Holoférnes jacet in terra, et caput ejus non est in illo.

17. Quod cum audíssent príncipes virtútis Assyriórum, scidérunt omnes vestiménta sua, et intolerábilis timor et tremor cécidit super eos, et turbáti sunt ánimi eórum valde.

18. Et factus est clamor incomparábilis in médio castrórum eórum.

