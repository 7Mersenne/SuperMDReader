# Liber Genesis - Caput 35

1. Intérea locútus est Deus ad Jacob : Surge, et ascénde Bethel, et hábita ibi, facque altáre Deo qui appáruit tibi quando fugiébas Ésau fratrem tuum.

2. Jacob vero convocáta omni domo sua, ait : Abjícite deos aliénos qui in médio vestri sunt, et mundámini, ac mutáte vestiménta vestra.

3. Súrgite, et ascendámus in Bethel, ut faciámus ibi altáre Deo : qui exaudívit me in die tribulatiónis meæ, et sócius fuit itíneris mei.

4. Dedérunt ergo ei omnes deos aliénos quos habébant, et ináures quæ erant in áuribus eórum : at ille ínfodit ea subter terebínthum, quæ est post urbem Sichem.

5. Cumque profécti essent, terror Dei invásit omnes per circúitum civitátes, et non sunt ausi pérsequi recedéntes.

6. Venit ígitur Jacob Luzam, quæ est in terra Chánaan, cognoménto Bethel : ipse et omnis pópulus cum eo.

7. Ædificavítque ibi altáre, et appellávit nomen loci illíus, Domus Dei : ibi enim appáruit ei Deus cum fúgeret fratrem suum.

8. Eódem témpore mórtua est Debóra nutrix Rebéccæ, et sepúlta est ad radíces Bethel subter quercum : vocatúmque est nomen loci illíus, Quercus fletus.

9. Appáruit autem íterum Deus Jacob postquam revérsus est de Mesopotámia Sýriæ, benedixítque ei

10. dicens : Non vocáberis ultra Jacob, sed Israël erit nomen tuum. Et appellávit eum Israël,

11. dixítque ei : Ego Deus omnípotens : cresce, et multiplicáre : gentes et pópuli natiónum ex te erunt, reges de lumbis tuis egrediéntur,

12. terrámque quam dedi Ábraham et Ísaac, dabo tibi et sémini tuo post te.

13. Et recéssit ab eo.

14. Ille vero eréxit títulum lapídeum in loco quo locútus fúerat ei Deus : libans super eum libámina, et effúndens óleum :

15. vocánsque nomen loci illíus Bethel.

16. Egréssus autem inde, venit verno témpore ad terram quæ ducit Éphratam : in qua cum parturíret Rachel,

17. ob difficultátem partus periclitári cœpit. Dixítque ei óbstetrix : Noli timére, quia et hunc habébis fílium.

18. Egrediénte autem ánima præ dolóre, et imminénte jam morte, vocávit nomen fílii sui Benómi, id est, Fílius dolóris mei : pater vero appellávit eum Bénjamin, id est, Fílius dextræ.

19. Mórtua est ergo Rachel, et sepúlta est in via quæ ducit Éphratam, hæc est Béthlehem.

20. Erexítque Jacob títulum super sepúlchrum ejus : hic est títulus monuménti Rachel, usque in præséntem diem.

21. Egréssus inde, fixit tabernáculum trans Turrem gregis.

22. Cumque habitáret in illa regióne, ábiit Ruben, et dormívit cum Bala concubína patris sui : quod illum mínime látuit. Erant autem fílii Jacob duódecim.

23. Fílii Liæ : primogénitus Ruben, et Símeon, et Levi, et Judas, et Issáchar, et Zábulon.

24. Fílii Rachel : Joseph et Bénjamin.

25. Fílii Balæ ancíllæ Ráchelis : Dan et Nephtháli.

26. Fílii Zelphæ ancíllæ Liæ : Gad et Aser : hi sunt fílii Jacob, qui nati sunt ei in Mesopotámia Sýriæ.

27. Venit étiam ad Ísaac patrem suum in Mambre, civitátem Árbee, hæc est Hebron, in qua peregrinátus est Ábraham et Ísaac.

28. Et compléti sunt dies Ísaac centum octogínta annórum.

29. Consumptúsque ætáte mórtuus est : et appósitus est pópulo suo senex et plenus diérum : et sepeliérunt eum Ésau et Jacob fílii sui.

