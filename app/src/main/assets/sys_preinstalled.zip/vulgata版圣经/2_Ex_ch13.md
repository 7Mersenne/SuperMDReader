# Liber Exodus - Caput 13

1. Locutúsque est Dóminus ad Móysen, dicens :

2. Sanctífica mihi omne primogénitum quod áperit vulvam in fíliis Israël, tam de homínibus quam de juméntis : mea sunt enim ómnia.

3. Et ait Móyses ad pópulum : Mementóte diéi hujus in qua egréssi estis de Ægýpto et de domo servitútis, quóniam in manu forti edúxit vos Dóminus de loco isto : ut non comedátis fermentátum panem.

4. Hódie egredímini mense novárum frugum.

5. Cumque introdúxerit te Dóminus in terram Chananǽi, et Hethǽi, et Amorrhǽi, et Hevǽi, et Jebusǽi, quam jurávit pátribus tuis ut daret tibi, terram fluéntem lacte et melle, celebrábis hunc morem sacrórum mense isto.

6. Septem diébus vésceris ázymis : et in die séptimo erit solémnitas Dómini.

7. Ázyma comedétis septem diébus : non apparébit apud te áliquid fermentátum, nec in cunctis fínibus tuis.

8. Narrabísque fílio tuo in die illo, dicens : Hoc est quod fecit mihi Dóminus quando egréssus sum de Ægýpto.

9. Et erit quasi signum in manu tua, et quasi moniméntum ante óculos tuos : et ut lex Dómini semper sit in ore tuo, in manu enim forti edúxit te Dóminus de Ægýpto.

10. Custódies hujuscémodi cultum statúto témpore a diébus in dies.

11. Cumque introdúxerit te Dóminus in terram Chananǽi, sicut jurávit tibi et pátribus tuis, et déderit tibi eam :

12. separábis omne quod áperit vulvam Dómino, et quod primitívum est in pecóribus tuis : quidquid habúeris masculíni sexus, consecrábis Dómino.

13. Primogénitum ásini mutábis ove : quod si non redémeris, interfícies. Omne autem primogénitum hóminis de fíliis tuis, prétio rédimes.

14. Cumque interrogáverit te fílius tuus cras, dicens : Quid est hoc ? respondébis ei : In manu forti edúxit nos Dóminus de terra Ægýpti, de domo servitútis.

15. Nam cum indurátus esset Phárao, et nollet nos dimíttere, óccidit Dóminus omne primogénitum in terra Ægýpti, a primogénito hóminis usque ad primogénitum jumentórum : idcírco ímmolo Dómino omne quod áperit vulvam masculíni sexus, et ómnia primogénita filiórum meórum rédimo.

16. Erit ígitur quasi signum in manu tua, et quasi appénsum quid, ob recordatiónem, inter óculos tuos : eo quod in manu forti edúxit nos Dóminus de Ægýpto.

17. Ígitur cum emisísset Phárao pópulum, non eos duxit Deus per viam terræ Philísthiim quæ vicína est : réputans ne forte pœníteret eum, si vidísset advérsum se bella consúrgere, et reverterétur in Ægýptum.

18. Sed circumdúxit per viam desérti, quæ est juxta mare Rubrum : et armáti ascendérunt fílii Israël de terra Ægýpti.

19. Tulit quoque Móyses ossa Joseph secum : eo quod adjurásset fílios Israël, dicens : Visitábit vos Deus ; efférte ossa mea hinc vobíscum.

20. Profectíque de Socoth castrametáti sunt in Etham, in extrémis fínibus solitúdinis.

21. Dóminus autem præcedébat eos ad ostendéndam viam per diem in colúmna nubis, et per noctem in colúmna ignis : ut dux esset itíneris utróque témpore.

22. Numquam défuit colúmna nubis per diem, nec colúmna ignis per noctem, coram pópulo.

