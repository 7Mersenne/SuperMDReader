# Liber Judith - Caput 3

1. Tunc misérunt legátos suos universárum úrbium ac provinciárum reges ac príncipes, Sýriæ scílicet Mesopotámiæ, et Sýriæ Sobal, et Líbyæ, atque Cilíciæ : qui veniéntes ad Holoférnem, dixérunt :

2. Désinat indignátio tua circa nos : mélius est enim ut vivéntes serviámus Nabuchodonósor regi magno, et súbditi simus tibi, quam moriéntes cum intéritu nostro ipsi servitútis nostræ damna patiámur.

3. Omnis cívitas nostra, omnísque posséssio, omnes montes, et colles, et campi, et arménta boum, gregésque óvium, et caprárum, equorúmque et camelórum, et univérsæ facultátes nostræ atque famíliæ, in conspéctu tuo sunt :

4. sint ómnia nostra sub lege tua.

5. Nos, et fílii nostri, servi tui sumus.

6. Veni nobis pacíficus dóminus, et útere servítio nostro, sicut placúerit tibi.

7. Tunc descéndit de móntibus cum equítibus in virtúte magna, et obtínuit omnem civitátem, et omnem inhabitántem terram.

8. De univérsis autem úrbibus assúmpsit sibi auxiliários viros fortes, et eléctos ad bellum.

9. Tantúsque metus provínciis illis incúbuit, ut universárum úrbium habitatóres príncipes et honoráti simul cum pópulis exírent óbviam veniénti,

10. excipiéntes eum cum corónis et lampádibus, ducéntes choros in týmpanis et tíbiis.

11. Nec ista tamen faciéntes, ferocitátem ejus péctoris mitigáre potuérunt :

12. nam et civitátes eórum destrúxit, et lucos eórum excídit.

13. Præcéperat enim illi Nabuchodonósor rex, ut omnes deos terræ extermináret, vidélicet ut ipse solus dicerétur deus ab his natiónibus quæ potuíssent Holoférnis poténtia subjugári.

14. Pertránsiens autem Sýriam Sobal, et omnem Apámeam, omnémque Mesopotámiam, venit ad Idumǽos in terram Gábaa,

15. accepítque civitátes eórum, et sedit ibi per trigínta dies, in quibus diébus adunári præcépit univérsum exércitum virtútis suæ.

