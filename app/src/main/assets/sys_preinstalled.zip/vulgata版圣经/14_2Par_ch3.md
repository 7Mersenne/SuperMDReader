# Liber Secundus Paralipomenon - Caput 3

1. Et cœpit Sálomon ædificáre domum Dómini in Jerúsalem in monte Mória, qui demonstrátus fúerat David patri ejus, in loco quem paráverat David in área Ornan Jebusǽi.

2. Cœpit autem ædificáre mense secúndo, anno quarto regni sui.

3. Et hæc sunt fundaménta quæ jecit Sálomon, ut ædificáret domum Dei : longitúdinis cúbitos in mensúra prima sexagínta, latitúdinis cúbitos vigínti.

4. Pórticum vero ante frontem, quæ tendebátur in longum juxta mensúram latitúdinis domus, cubitórum vigínti : porro altitúdo centum vigínti cubitórum erat : et deaurávit eam intrínsecus auro mundíssimo.

5. Domum quoque majórem texit tábulis lígneis abiégnis, et láminas auri obrízi affíxit per totum : sculpsítque in ea palmas, et quasi caténulas se ínvicem complecténtes.

6. Stravit quoque paviméntum templi pretiosíssimo marmóre, decóre multo.

7. Porro aurum erat probatíssimum, de cujus láminis texit domum, et trabes ejus, et postes, et paríetes, et óstia : et cælávit chérubim in pariétibus.

8. Fecit quoque domum Sancti sanctórum : longitúdinem juxta latitúdinem domus cubitórum vigínti : et latitúdinem simíliter vigínti cubitórum : et láminis áureis texit eam, quasi taléntis sexcéntis.

9. Sed et clavos fecit áureos, ita ut sínguli clavi siclos quinquagénos appénderent : cœnácula quoque texit auro.

10. Fecit étiam in domo Sancti sanctórum chérubim duos, ópere statuário : et texit eos auro.

11. Alæ chérubim vigínti cúbitis extendebántur, ita ut una ala habéret cúbitos quinque et tángeret paríetem domus : et áltera quinque cúbitos habens, alam tángeret altérius cherub.

12. Simíliter cherub altérius ala, quinque habébat cúbitos, et tangébat paríetem : et ala ejus áltera quinque cubitórum, alam cherub altérius contingébat.

13. Ígitur alæ utriúsque chérubim expánsæ erant et extendebántur per cúbitos vigínti : ipsi autem stabant eréctis pédibus, et fácies eórum erant versæ ad exteriórem domum.

14. Fecit quoque velum ex hyacíntho, púrpura, cocco, et bysso : et intéxuit ei chérubim.

15. Ante fores étiam templi duas colúmnas, quæ trigínta et quinque cúbitos habébant altitúdinis : porro cápita eárum, quinque cubitórum.

16. Necnon et quasi caténulas in oráculo, et superpósuit eas capítibus columnárum : malogranáta étiam centum, quæ caténulis interpósuit.

17. Ipsas quoque colúmnas pósuit in vestíbulo templi, unam a dextris, et álteram a sinístris : eam quæ a dextris erat, vocávit Jachin : et quæ ad lævam, Booz.

