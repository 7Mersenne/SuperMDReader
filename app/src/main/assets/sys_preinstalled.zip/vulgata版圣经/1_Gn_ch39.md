# Liber Genesis - Caput 39

1. Ígitur Joseph ductus est in Ægýptum, emítque eum Pútiphar eunúchus Pharaónis, princeps exércitus, vir ægýptius, de manu Ismaëlitárum, a quibus perdúctus erat.

2. Fuítque Dóminus cum eo, et erat vir in cunctis próspere agens : habitavítque in domo dómini sui,

3. qui óptime nóverat Dóminum esse cum eo, et ómnia, quæ gerébat, ab eo dírigi in manu illíus.

4. Invenítque Joseph grátiam coram dómino suo, et ministrábat ei : a quo præpósitus ómnibus gubernábat créditam sibi domum, et univérsa quæ ei trádita fúerant :

5. benedixítque Dóminus dómui Ægýptii propter Joseph, et multiplicávit tam in ǽdibus quam in agris cunctam ejus substántiam :

6. nec quidquam áliud nóverat, nisi panem quo vescebátur. Erat autem Joseph pulchra fácie, et decórus aspéctu.

7. Post multos ítaque dies injécit dómina sua óculos suos in Joseph, et ait : Dormi mecum.

8. Qui nequáquam acquiéscens óperi nefário, dixit ad eam : Ecce dóminus meus, ómnibus mihi tráditis, ignórat quid hábeat in domo sua :

9. nec quidquam est quod non in mea sit potestáte, vel non tradíderit mihi, præter te, quæ uxor ejus es : quómodo ergo possum hoc malum fácere, et peccáre in Deum meum ?

10. Hujuscémodi verbis per síngulos dies, et múlier molésta erat adolescénti : et ille recusábat stuprum.

11. Áccidit autem quadam die ut intráret Joseph domum, et óperis quíppiam absque árbitris fáceret :

12. et illa, apprehénsa lacínia vestiménti ejus, díceret : Dormi mecum. Qui relícto in manu ejus pállio fugit, et egréssus est foras.

13. Cumque vidísset múlier vestem in mánibus suis, et se esse contémptam,

14. vocávit ad se hómines domus suæ, et ait ad eos : En introdúxit virum hebrǽum, ut illúderet nobis : ingréssus est ad me, ut coíret mecum : cumque ego succlamássem,

15. et audísset vocem meam, relíquit pállium quod tenébam, et fugit foras.

16. In arguméntum ergo fídei reténtum pállium osténdit márito reverténti domum,

17. et ait : Ingréssus est ad me servus hebrǽus quem adduxísti, ut illúderet mihi :

18. cumque audísset me clamáre, relíquit pállium quod tenébam, et fugit foras.

19. His audítis dóminus, et nímium crédulus verbis cónjugis, irátus est valde :

20. tradidítque Joseph in cárcerem, ubi vincti regis custodiebántur, et erat ibi clausus.

21. Fuit autem Dóminus cum Joseph, et misértus illíus dedit ei grátiam in conspéctu príncipis cárceris.

22. Qui trádidit in manu illíus univérsos vinctos qui in custódia tenebántur : et quidquid fiébat, sub ipso erat.

23. Nec nóverat áliquid, cunctis ei créditis : Dóminus enim erat cum illo, et ómnia ópera ejus dirigébat.

