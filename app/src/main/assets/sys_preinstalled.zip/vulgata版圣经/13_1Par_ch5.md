# Liber Primus Paralipomenon - Caput 5

1. Fílii quoque Ruben primogéniti Israël. (Ipse quippe fuit primogénitus ejus : sed cum violásset thorum patris sui, data sunt primogénita ejus fíliis Joseph fílii Israël, et non est ille reputátus in primogénitum.

2. Porro Judas, qui erat fortíssimus inter fratres suos, de stirpe ejus príncipes germináti sunt : primogénita autem reputáta sunt Joseph.)

3. Fílii ergo Ruben primogéniti Israël : Enoch, et Phallu, Esron, et Carmi.

4. Fílii Joël : Sámia fílius ejus, Gog fílius ejus, Sémei fílius ejus,

5. Micha fílius ejus, Reía fílius ejus, Baal fílius ejus,

6. Béera fílius ejus, quem captívum duxit Thelgathphalnásar rex Assyriórum, et fuit princeps in tribu Ruben.

7. Fratres autem ejus, et univérsa cognátio ejus, quando numerabántur per famílias suas, habuérunt príncipes Jéhiel, et Zacharíam.

8. Porro Bala fílius Azaz fílii Samma fílii Joël, ipse habitávit in Ároër usque ad Nebo, et Beélmeon.

9. Contra orientálem quoque plagam habitávit usque ad intróitum erémi, et flumen Euphráten. Multum quippe jumentórum númerum possidébant in terra Gálaad.

10. In diébus autem Saul præliáti sunt contra Agáreos, et interfecérunt illos, habitaverúntque pro eis in tabernáculis eórum, in omni plaga quæ réspicit ad oriéntem Gálaad.

11. Fílii vero Gad e regióne eórum habitavérunt in terra Basan usque Selcha :

12. Joël in cápite, et Saphan secúndus : Jánai autem et Saphat in Basan.

13. Fratres vero eórum secúndum domos cognatiónum suárum, Míchaël, et Mosóllam, et Sebe, et Jórai, et Jachan, et Zie, et Heber, septem.

14. Hi fílii Abíhail, fílii Huri, fílii Jara, fílii Gálaad, fílii Míchaël, fílii Jesési, fílii Jeddo, fílii Buz.

15. Fratres quoque, fílii Ábdiel fílii Guni, princeps domus in famíliis suis.

16. Et habitavérunt in Gálaad, et in Basan, et in vículis ejus, et in cunctis suburbánis Saron, usque ad términos.

17. Omnes hi numeráti sunt in diébus Jóathan regis Juda, et in diébus Jeróboam regis Israël.

18. Fílii Ruben, et Gad, et dimídiæ tribus Manásse, viri bellatóres, scuta portántes et gládios, et tendéntes arcum, eruditíque ad prǽlia, quadragínta quátuor míllia et septingénti sexagínta, procedéntes ad pugnam.

19. Dimicavérunt contra Agáreos : Iturǽi vero, et Naphis, et Nodab

20. præbuérunt eis auxílium. Traditíque sunt in manus eórum Agárei, et univérsi qui fúerant cum eis, quia Deum invocavérunt cum præliaréntur : et exaudívit eos, eo quod credidíssent in eum.

21. Ceperúntque ómnia quæ posséderant, camelórum quinquagínta míllia, et óvium ducénta quinquagínta míllia, et ásinos duo míllia, et ánimas hóminum centum míllia.

22. Vulneráti autem multi corruérunt : fuit enim bellum Dómini. Habitaverúntque pro eis usque ad transmigratiónem.

23. Fílii quoque dimídiæ tribus Manásse possedérunt terram a fínibus Basan usque Baal, Hermon, et Sanir, et montem Hermon : ingens quippe númerus erat.

24. Et hi fuérunt príncipes domus cognatiónis eórum : Epher, et Jesi, et Elíel, et Ézriel, et Jeremía, et Odoía, et Jédiel, viri fortíssimi et poténtes, et nomináti duces in famíliis suis.

25. Reliquérunt autem Deum patrum suórum, et fornicáti sunt post deos populórum terræ, quos ábstulit Deus coram eis.

26. Et suscitávit Deus Israël spíritum Phul regis Assyriórum, et spíritum Thelgathphalnásar regis Assur : et tránstulit Ruben, et Gad, et dimídiam tribum Manásse, et addúxit eos in Láhela, et in Habor, et Ara, et flúvium Gozan, usque ad diem hanc.

