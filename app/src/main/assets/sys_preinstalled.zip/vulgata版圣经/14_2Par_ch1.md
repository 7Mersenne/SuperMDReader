# Liber Secundus Paralipomenon - Caput 1

1. Confortátus est ergo Sálomon fílius David in regno suo, et Dóminus Deus ejus erat cum eo, et magnificávit eum in excélsum.

2. Præcepítque Sálomon univérso Israëli, tribúnis, et centuriónibus, et dúcibus, et judícibus omnis Israël, et princípibus familiárum :

3. et ábiit cum univérsa multitúdine in excélsum Gábaon, ubi erat tabernáculum fóederis Dei, quod fecit Móyses fámulus Dei in solitúdine.

4. Arcam autem Dei addúxerat David de Cariathiárim in locum quem præparáverat ei, et ubi fíxerat illi tabernáculum, hoc est, in Jerúsalem.

5. Altáre quoque ǽneum quod fabricátus fúerat Beséleel fílius Uri fílii Hur, ibi erat coram tabernáculo Dómini : quod et requisívit Sálomon, et omnis ecclésia.

6. Ascendítque Sálomon ad altáre ǽneum, coram tabernáculo fóederis Dómini, et óbtulit in eo mille hóstias.

7. Ecce autem in ipsa nocte appáruit ei Deus, dicens : Póstula quod vis, ut dem tibi.

8. Dixítque Sálomon Deo : Tu fecísti cum David patre meo misericórdiam magnam, et constituísti me regem pro eo.

9. Nunc ergo Dómine Deus, impleátur sermo tuus quem pollícitus es David patri meo : tu enim me fecísti regem super pópulum tuum multum, qui tam innumerábilis est quam pulvis terræ.

10. Da mihi sapiéntiam et intelligéntiam, ut ingrédiar et egrédiar coram pópulo tuo : quis enim potest hunc pópulum tuum digne, qui tam grandis est, judicáre ?

11. Dixit autem Deus ad Salomónem : Quia hoc magis plácuit cordi tuo, et non postulásti divítias, et substántiam, et glóriam, neque ánimas eórum qui te óderant, sed nec dies vitæ plúrimos : petísti autem sapiéntiam et sciéntiam, ut judicáre possis pópulum meum super quem constítui te regem :

12. sapiéntia et sciéntia data sunt tibi : divítias autem et substántiam et glóriam dabo tibi, ita ut nullus in régibus nec ante te nec post te fúerit símilis tui.

13. Venit ergo Sálomon ab excélso Gábaon in Jerúsalem coram tabernáculo fóederis, et regnávit super Israël.

14. Congregavítque sibi currus et équites, et facti sunt ei mille quadringénti currus, et duódecim míllia équitum : et fecit eos esse in úrbibus quadrigárum, et cum rege in Jerúsalem.

15. Præbuítque rex argéntum et aurum in Jerúsalem quasi lápides, et cedros quasi sycómoros quæ nascúntur in campéstribus multitúdine magna.

16. Adducebántur autem ei equi de Ægýpto et de Coa a negotiatóribus regis, qui ibant et emébant prétio,

17. quadrígam equórum sexcéntis argénteis, et equum centum quinquagínta : simíliter de univérsis regnis Hethæórum, et a régibus Sýriæ émptio celebrabátur.

