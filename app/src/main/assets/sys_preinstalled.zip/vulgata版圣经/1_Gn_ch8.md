# Liber Genesis - Caput 8

1. Recordátus autem Deus Noë, cunctorúmque animántium, et ómnium jumentórum, quæ erant cum eo in arca, addúxit spíritum super terram, et imminútæ sunt aquæ.

2. Et clausi sunt fontes abýssi, et cataráctæ cæli : et prohíbitæ sunt plúviæ de cælo.

3. Reversǽque sunt aquæ de terra eúntes et redeúntes : et cœpérunt mínui post centum quinquagínta dies.

4. Requievítque arca mense séptimo, vigésimo séptimo die mensis, super montes Arméniæ.

5. At vero aquæ ibant et decrescébant usque ad décimum mensem : décimo enim mense, primo die mensis, apparuérunt cacúmina móntium.

6. Cumque transíssent quadragínta dies, apériens Noë fenéstram arcæ, quam fécerat, dimísit corvum,

7. qui egrediebátur, et non revertebátur, donec siccaréntur aquæ super terram.

8. Emísit quoque colúmbam post eum, ut vidéret si jam cessássent aquæ super fáciem terræ.

9. Quæ cum non invenísset ubi requiésceret pes ejus, revérsa est ad eum in arcam : aquæ enim erant super univérsam terram : extendítque manum, et apprehénsam íntulit in arcam.

10. Expectátis autem ultra septem diébus áliis, rursum dimísit colúmbam ex arca.

11. At illa venit ad eum ad vésperam, portans ramum olívæ viréntibus fóliis in ore suo : intelléxit ergo Noë quod cessássent aquæ super terram.

12. Expectavítque nihilóminus septem álios dies : et emísit colúmbam, quæ non est revérsa ultra ad eum.

13. Ígitur sexcentésimo primo anno, primo mense, prima die mensis, imminútæ sunt aquæ super terram : et apériens Noë tectum arcæ, aspéxit, vidítque quod exsiccáta esset superfícies terræ.

14. Mense secúndo, séptimo et vigésimo die mensis arefácta est terra.

15. Locútus est autem Deus ad Noë, dicens :

16. Egrédere de arca, tu et uxor tua, fílii tui et uxóres filiórum tuórum tecum.

17. Cuncta animántia, quæ sunt apud te, ex omni carne, tam in volatílibus quam in béstiis et univérsis reptílibus, quæ reptant super terram, educ tecum, et ingredímini super terram : créscite et multiplicámini super eam.

18. Egréssus est ergo Noë, et fílii ejus : uxor illíus, et uxóres filiórum ejus cum eo.

19. Sed et ómnia animántia, juménta, et reptília quæ reptant super terram, secúndum genus suum, egréssa sunt de arca.

20. Ædificávit autem Noë altáre Dómino : et tollens de cunctis pecóribus et volúcribus mundis, óbtulit holocáusta super altáre.

21. Odoratúsque est Dóminus odórem suavitátis, et ait : Nequáquam ultra malédicam terræ propter hómines : sensus enim et cogitátio humáni cordis in malum prona sunt ab adolescéntia sua : non ígitur ultra percútiam omnem ánimam vivéntem sicut feci.

22. Cunctis diébus terræ, seméntis et messis, frigus et æstus, æstas et hiems, nox et dies non requiéscent.

