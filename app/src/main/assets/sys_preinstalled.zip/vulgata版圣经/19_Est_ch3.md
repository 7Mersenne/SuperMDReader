# Liber Esther - Caput 3

1. Post hæc rex Assúerus exaltávit Aman fílium Amadáthi, qui erat de stirpe Agag : et pósuit sólium ejus super omnes príncipes quos habébat.

2. Cunctíque servi regis, qui in fóribus palátii versabántur, flectébant génua, et adorábant Aman : sic enim præcéperat eis imperátor : solus Mardochǽus non flectébat genu, neque adorábat eum.

3. Cui dixérunt púeri regis, qui ad fores palátii præsidébant : Cur præter céteros non obsérvas mandátum regis ?

4. Cumque hoc crébrius dícerent, et ille nollet audíre, nuntiavérunt Aman, scire cupiéntes utrum perseveráret in senténtia : díxerat enim eis se esse Judǽum.

5. Quod cum audísset Aman, et experiménto probásset quod Mardochǽus non flécteret sibi genu, nec se adoráret, irátus est valde,

6. et pro níhilo duxit in unum Mardochǽum míttere manus suas : audíerat enim quod esset gentis Judǽæ ; magísque vóluit omnem Judæórum, qui erant in regno Assúeri, pérdere natiónem.

7. Mense primo (cújus vocábulum est Nisan), anno duodécimo regni Assúeri, missa est sors in urnam, quæ hebráice dícitur phur, coram Aman, quo die et quo mense gens Judæórum déberet intérfici : et exívit mensis duodécimus, qui vocátur Adar.

8. Dixítque Aman regi Assúero : Est pópulus per omnes províncias regni tui dispérsus, et a se mútuo separátus, novis utens légibus et cæremóniis, ínsuper et regis scita contémnens : et óptime nosti quod non expédiat regno tuo ut insoléscat per licéntiam.

9. Si tibi placet, decérne, ut péreat, et decem míllia talentórum appéndam arcáriis gazæ tuæ.

10. Tulit ergo rex ánnulum, quo utebátur, de manu sua, et dedit eum Aman fílio Amadáthi de progénie Agag, hosti Judæórum,

11. dixítque ad eum : Argéntum, quod tu pollíceris, tuum sit ; de pópulo age quod tibi placet.

12. Vocatíque sunt scribæ regis mense primo Nisan, tertiadécima die ejúsdem mensis : et scriptum est, ut jússerat Aman, ad omnes satrápas regis, et júdices provinciárum, diversarúmque géntium, ut quæque gens légere póterat et audíre pro varietáte linguárum ex nómine regis Assúeri : et lítteræ signátæ ipsíus ánnulo

13. missæ sunt per cursóres regis ad univérsas províncias, ut occíderent atque delérent omnes Judǽos, a púero usque ad senem, párvulos et mulíeres, uno die, hoc est tertiodécimo mensis duodécimi, qui vocátur Adar ; et bona eórum diríperent.

14. Summa autem epistolárum hæc fuit, ut omnes provínciæ scirent, et parárent se ad prædíctam diem.

15. Festinábant cursóres, qui missi erant, regis impérium éxplere. Statímque in Susan pepéndit edíctum, rege et Aman celebránte convívium, et cunctis Judǽis, qui in urbe erant, fléntibus.

