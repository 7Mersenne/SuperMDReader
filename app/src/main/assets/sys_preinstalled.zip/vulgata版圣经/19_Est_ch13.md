# Liber Esther - Caput 13

1. Rex máximus Artaxérxes ab Índia usque Æthiópiam, centum vigínti septem provinciárum princípibus et dúcibus qui ejus império subjécti sunt, salútem.

2. Cum plúrimis géntibus imperárem, et univérsum orbem meæ ditióni subjugássem, vólui nequáquam abúti poténtiæ magnitúdine, sed cleméntia et lenitáte gubernáre subjéctos, ut absque ullo terróre vitam siléntio transigéntes, optáta cunctis mortálibus pace frueréntur.

3. Quærénte autem me a consiliáriis meis quómodo posset hoc impléri, unus qui sapiéntia et fide céteros præcellébat, et erat post regem secúndus, Aman nómine,

4. indicávit mihi in toto orbe terrárum pópulum esse dispérsum, qui novis uterétur légibus, et, contra ómnium géntium consuetúdinem fáciens, regum jussa contémneret, et universárum concórdiam natiónum sua dissensióne violáret.

5. Quod cum didicissémus, vidéntes unam gentem rebéllem advérsus omne hóminum genus pervérsis uti légibus, nostrísque jussiónibus contraíre, et turbáre subjectárum nobis provinciárum pacem atque concórdiam,

6. jússimus ut quoscúmque Aman, qui ómnibus provínciis præpósitus est et secúndus a rege, et quem patris loco cólimus, monstráverit, cum conjúgibus ac líberis deleántur ab inimícis suis, nullúsque eórum misereátur, quartadécima die duodécimi mensis Adar anni præséntis :

7. ut nefárii hómines uno die ad ínferos descendéntes, reddant império nostro pacem, quam turbáverant. Pergénsque Mardochǽus, fecit ómnia quæ ei mandáverat Esther.

8. Mardochǽus autem deprecátus est Dóminum, memor ómnium óperum ejus,

9. et dixit : Dómine, Dómine rex omnípotens, in ditióne enim tua cuncta sunt pósita, et non est qui possit tuæ resístere voluntáti, si decréveris salváre Israël.

10. Tu fecísti cælum et terram, et quidquid cæli ámbitu continétur.

11. Dóminus ómnium es, nec est qui resístat majestáti tuæ.

12. Cuncta nosti, et scis quia non pro supérbia et contumélia, et áliqua glóriæ cupiditáte, fécerim hoc, ut non adorárem Aman superbíssimum

13. (libénter enim pro salúte Israël étiam vestígia pedum ejus deosculári parátus essem),

14. sed tímui ne honórem Dei mei transférrem ad hóminem, et ne quemquam adorárem, excépto Deo meo.

15. Et nunc, Dómine rex, Deus Ábraham, miserére pópuli tui, quia volunt nos inimíci nostri pérdere, et hæreditátem tuam delére.

16. Ne despícias partem tuam, quam redemísti tibi de Ægýpto.

17. Exáudi deprecatiónem meam, et propítius esto sorti et funículo tuo, et convérte luctum nostrum in gáudium, ut vivéntes laudémus nomen tuum, Dómine : et ne claudas ora te canéntium.

18. Omnis quoque Israël pari mente et obsecratióne clamávit ad Dóminum, eo quod eis certa mors impénderet.

