# Liber Tobi� - Caput 1

1. Tobías ex tribu et civitáte Nephtháli (quæ est in superióribus Galilǽæ supra Naásson, post viam quæ ducit ad occidéntem, in sinístro habens civitátem Sephet)

2. cum captus esset in diébus Salmanásar regis Assyriórum, in captivitáte tamen pósitus, viam veritátis non deséruit,

3. ita ut ómnia quæ habére póterat, quotídie concaptívis frátribus, qui erant ex ejus génere, impertíret.

4. Cumque esset júnior ómnibus in tribu Nephtháli, nihil tamen pueríle gessit in ópere.

5. Dénique, cum irent omnes ad vítulos áureos quos Jeróboam fécerat rex Israël, hic solus fugiébat consórtia ómnium.

6. Sed pergébat in Jerúsalem ad templum Dómini, et ibi adorábat Dóminum Deum Israël, ómnia primitíva sua et décimas suas fidéliter ófferens,

7. ita ut in tértio anno prosélytis et ádvenis ministráret omnem decimatiónem.

8. Hæc et his simília secúndum legem Dei puérulus observábat.

9. Cum vero factus esset vir, accépit uxórem Annam de tribu sua, genuítque ex ea fílium, nomen suum impónens ei :

10. quem ab infántia timére Deum dócuit, et abstinére ab omni peccáto.

11. Ígitur, cum per captivitátem devenísset cum uxóre sua et fílio in civitátem Níniven cum omni tribu sua

12. (cum omnes éderent ex cibis gentílium), iste custodívit ánimam suam, et numquam contaminátus est in escis eórum.

13. Et quóniam memor fuit Dómini in toto corde suo, dedit illi Deus grátiam in conspéctu Salmanásar regis,

14. et dedit illi potestátem quocúmque vellet ire, habens libertátem quæcúmque fácere voluísset.

15. Pergébat ergo ad omnes qui erant in captivitáte, et mónita salútis dabat eis.

16. Cum autem venísset in Rages civitátem Medórum, et ex his quibus honorátus fúerat a rege, habuísset decem talénta argénti :

17. et cum in multa turba géneris sui Gábelum egéntem vidéret, qui erat ex tribu ejus, sub chirográpho dedit illi memorátum pondus argénti.

18. Post multum vero témporis, mórtuo Salmanásar rege, cum regnáret Sennácherib fílius ejus pro eo, et fílios Israël exósos habéret in conspéctu suo,

19. Tobías quotídie pergébat per omnem cognatiónem suam, et consolabátur eos, dividebátque unicuíque, prout póterat, de facultátibus suis :

20. esuriéntes alébat, nudísque vestiménta præbébat, et mórtuis atque occísis sepultúram sollícitus exhibébat.

21. Dénique cum revérsus esset rex Sennácherib, fúgiens a Judǽa plagam quam circa eum fécerat Deus propter blasphémiam suam, et irátus multos occíderet ex fíliis Israël, Tobías sepeliébat córpora eórum.

22. At ubi nuntiátum est regi, jussit eum occídi, et tulit omnem substántiam ejus.

23. Tobías vero cum fílio suo et cum uxóre suo fúgiens, nudus látuit, quia multi diligébant eum.

24. Post dies vero quadragínta quinque occidérunt regem fílii ipsíus,

25. et revérsus est Tobías in domum suam, omnísque facúltas ejus restitúta est ei.

