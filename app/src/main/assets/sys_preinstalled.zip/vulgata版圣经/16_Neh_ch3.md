# Liber Nehemi� - Caput 3

1. Et surréxit Eliásib sacérdos magnus, et fratres ejus sacerdótes, et ædificavérunt portam gregis : ipsi sanctificavérunt eam, et statuérunt valvas ejus, et usque ad turrim centum cubitórum sanctificavérunt eam, usque ad turrim Hanáneel.

2. Et juxta eum ædificavérunt viri Jéricho : et juxta eum ædificávit Zachur fílius Amri.

3. Portam autem píscium ædificavérunt fílii Ásnaa : ipsi texérunt eam, et statuérunt valvas ejus, et seras, et vectes. Et juxta eos ædificávit Márimuth fílius Uríæ, fílii Accus.

4. Et juxta eum ædificávit Mosóllam fílius Barachíæ, fílii Mesezébel : et juxta eos ædificávit Sadoc fílius Baána.

5. Et juxta eos ædificavérunt Thecúeni : optimátes autem eórum non supposuérunt colla sua in ópere Dómini sui.

6. Et portam véterem ædificavérunt Jojáda fílius Phásea, et Mosóllam fílius Besódia : ipsi texérunt eam, et statuérunt valvas ejus, et seras, et vectes.

7. Et juxta eos ædificavérunt Méltias Gabaónites, et Jadon Meronáthites, viri de Gábaon et Maspha, pro duce qui erat in regióne trans flumen.

8. Et juxta eum ædificávit Éziel fílius Araía áurifex : et juxta eum ædificávit Ananías fílius pigmentárii : et dimisérunt Jerúsalem usque ad murum platéæ latióris.

9. Et juxta eum ædificávit Raphaía fílius Hur, princeps vici Jerúsalem.

10. Et juxta eum ædificávit Jedaía fílius Harómaph contra domum suam : et juxta eum ædificávit Hattus fílius Hasebóniæ.

11. Médiam partem vici ædificávit Mélchias fílius Herem, et Hasub fílius Phahath Moab, et turrim furnórum.

12. Et juxta eum ædificávit Sellum fílius Álohes, princeps médiæ partis vici Jerúsalem, ipse et fíliæ ejus.

13. Et portam vallis ædificávit Hanun, et habitatóres Zánoë : ipsi ædificavérunt eam, et statuérunt valvas ejus, et seras, et vectes, et mille cúbitos in muro usque ad portam sterquilínii.

14. Et portam sterquilínii ædificávit Mélchias fílius Rechab, princeps vici Bethacháram : ipse ædificávit eam, et státuit valvas ejus, et seras, et vectes.

15. Et portam fontis ædificávit Sellum fílius Cholhóza, princeps pagi Maspha : ipse ædificávit eam, et texit, et státuit valvas ejus, et seras, et vectes, et muros piscínæ Síloë in hortum regis, et usque ad gradus qui descéndunt de civitáte David.

16. Post eum ædificávit Nehemías fílius Azboc, princeps dimídiæ partis vici Bethsur, usque contra sepúlchrum David, et usque ad piscínam quæ grandi ópere constrúcta est, et usque ad domum fórtium.

17. Post eum ædificavérunt Levítæ, Rehum fílius Benni : post eum ædificávit Hasébias princeps dimídiæ partis vici Céilæ in vico suo.

18. Post eum ædificavérunt fratres eórum : Bávai fílius Enádad, princeps dimídiæ partis Céilæ :

19. et ædificávit juxta eum Azer fílius Jósue, princeps Maspha, mensúram secúndam, contra ascénsum firmíssimi ánguli.

20. Post eum in monte ædificávit Baruch fílius Záchai mensúram secúndam, ab ángulo usque ad portam domus Eliásib sacerdótis magni.

21. Post eum ædificávit Mérimuth fílius Uríæ fílii Haccus, mensúram secúndam, a porta domus Eliásib, donec extenderétur domus Eliásib.

22. Et post eum ædificavérunt sacerdótes, viri de campéstribus Jordánis.

23. Post eum ædificávit Bénjamin et Hasub contra domum suam : et post eum ædificávit Azarías fílius Maásiæ fílii Ananíæ contra domum suam.

24. Post eum ædificávit Bénnui fílius Henádad mensúram secúndam, a domo Azaríæ usque ad flexúram, et usque ad ángulum.

25. Phalel fílius Ozi contra flexúram, et turrim quæ éminet de domo regis excélsa, id est, in átrio cárceris : post eum Phadaía fílius Pharos.

26. Nathinǽi autem habitábant in Ophel usque contra portam aquárum ad oriéntem, et turrim quæ prominébat.

27. Post eum ædificavérunt Thecúeni mensúram secúndam e regióne, a turre magna et eminénte usque ad murum templi.

28. Sursum autem a porta equórum ædificavérunt sacerdótes, unusquísque contra domum suam.

29. Post eos ædificávit Sadoc fílius Emmer contra domum suam. Et post eum ædificávit Semaía fílius Sechéniæ, custos portæ orientális.

30. Post eum ædificávit Hanánia fílius Selémiæ, et Hanun fílius Seleph sextus, mensúram secúndam : post eum ædificávit Mosóllam fílius Barachíæ, contra gazophylácium suum. Post eum ædificávit Mélchias fílius auríficis usque ad domum Nathinæórum, et scruta vendéntium contra portam judiciálem, et usque ad cœnáculum ánguli.

31. Et inter cœnáculum ánguli in porta gregis, ædificavérunt aurífices et negotiatóres.

