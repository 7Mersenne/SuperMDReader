# Liber Esther - Caput 8

1. Die illo dedit rex Assúerus Esther regínæ domum Aman adversárii Judæórum, et Mardochǽus ingréssus est ante fáciem regis. Conféssa est enim ei Esther quod esset pátruus suus.

2. Tulítque rex ánnulum, quem ab Aman récipi jússerat, et trádidit Mardochǽo. Esther autem constítuit Mardochǽum super domum suam.

3. Nec his conténta, prócidit ad pedes regis, flevítque, et locúta ad eum orávit ut malítiam Aman Agágitæ, et machinatiónes ejus péssimas quas excogitáverat contra Judǽos, júberet írritas fíeri.

4. At ille ex more sceptrum áureum proténdit manu, quo signum cleméntiæ monstrabátur : illáque consúrgens stetit ante eum,

5. et ait : Si placet regi, et si invéni grátiam in óculis ejus, et deprecátio mea non ei vidétur esse contrária, óbsecro ut novis epístolis, véteres Aman lítteræ, insidiatóris et hostis Judæórum, quibus eos in cunctis regis provínciis períre præcéperat, corrigántur.

6. Quómodo enim pótero sustinére necem et interfectiónem pópuli mei ?

7. Respondítque rex Assúerus Esther regínæ, et Mardochǽo Judǽo : Domum Aman concéssi Esther, et ipsum jussi áffigi cruci, quia ausus est manum míttere in Judǽos.

8. Scríbite ergo Judǽis, sicut vobis placet, regis nómine, signántes lítteras ánnulo meo. Hæc enim consuetúdo erat, ut epístolis, quæ ex regis nómine mittebántur et illíus ánnulo signátæ erant, nemo áuderet contradícere.

9. Accitísque scribis et libráriis regis (erat autem tempus tértii mensis, qui appellátur Siban) vigésima et tértia die illíus scriptæ sunt epístolæ, ut Mardochǽus volúerat, ad Judǽos, et ad príncipes, procuratorésque et júdices, qui centum vigínti septem provínciis ab Índia usque ad Æthiópiam præsidébant : provínciæ atque provínciæ, pópulo et pópulo juxta linguas et lítteras suas, et Judǽis, prout légere póterant et audíre.

10. Ipsǽque epístolæ, quæ regis nómine mittebántur, ánnulo ipsíus obsignátæ sunt, et missæ per veredários : qui per omnes províncias discurréntes, véteres lítteras novis núntiis prævenírent.

11. Quibus imperávit rex, ut convenírent Judǽos per síngulas civitátes, et in unum præcíperent congregári ut starent pro animábus suis, et omnes inimícos suos cum conjúgibus ac líberis et univérsis dómibus, interfícerent atque delérent, et spólia eórum diríperent.

12. Et constitúta est per omnes províncias una ultiónis dies, id est tertiadécima mensis duodécimi Adar.

13. Summáque epístolæ hæc fuit, ut in ómnibus terris ac pópulis qui regis Assúeri subjacébant império, notum fíeret parátos esse Judǽos ad capiéndam vindíctam de hóstibus suis.

14. Egressíque sunt veredárii céleres núntia perferéntes, et edíctum regis pepéndit in Susan.

15. Mardochǽus autem de palátio et de conspéctu regis egrédiens, fulgébat véstibus régiis, hyacínthinis vidélicet et ǽriis, corónam áuream portans in cápite, et amíctus sérico pállio atque purpúreo. Omnísque cívitas exultávit atque lætáta est.

16. Judǽis autem nova lux oríri visa est, gáudium, honor, et tripúdium.

17. Apud omnes pópulos, urbes, atque províncias, quocúmque regis jussa veniébant, mira exultátio, épulæ atque convívia, et festus dies : in tantum ut plures altérius gentis et sectæ eórum religióni et cæremóniis jungeréntur. Grandis enim cunctos judáici nóminis terror inváserat.

