# Liber Genesis - Caput 40

1. His ita gestis, áccidit ut peccárent duo eunúchi, pincérna regis Ægýpti, et pistor, dómino suo.

2. Iratúsque contra eos Phárao (nam alter pincérnis prǽerat, alter pistóribus),

3. misit eos in cárcerem príncipis mílitum, in quo erat vinctus et Joseph.

4. At custos cárceris trádidit eos Joseph, qui et ministrábat eis : aliquántulum témporis flúxerat, et illi in custódia tenebántur.

5. Viderúntque ambo sómnium nocte una, juxta interpretatiónem cóngruam sibi :

6. ad quos cum introísset Joseph mane, et vidísset eos tristes,

7. sciscitátus est eos, dicens : Cur trístior est hódie sólito fácies vestra ?

8. Qui respondérunt : Sómnium vídimus, et non est qui interpretétur nobis. Dixítque ad eos Joseph : Numquid non Dei est interpretátio ? reférte mihi quid vidéritis.

9. Narrávit prior, præpósitus pincernárum, sómnium suum : Vidébam coram me vitem,

10. in qua erant tres propágines, créscere paulátim in gemmas, et post flores uvas maturéscere :

11. calicémque Pharaónis in manu mea : tuli ergo uvas, et expréssi in cálicem quem tenébam, et trádidi póculum Pharaóni.

12. Respóndit Joseph : Hæc est interpretátio sómnii : tres propágines, tres adhuc dies sunt :

13. post quos recordábitur Phárao ministérii tui, et restítuet te in gradum prístinum : dabísque ei cálicem juxta offícium tuum, sicut ante fácere consuéveras.

14. Tantum meménto mei, cum bene tibi fúerit, et fácias mecum misericórdiam : ut súggeras Pharaóni ut edúcat me de isto cárcere :

15. quia furto sublátus sum de terra Hebræórum, et hic ínnocens in lacum missus sum.

16. Videns pistórum magíster quod prudénter sómnium dissolvísset, ait : Et ego vidi sómnium : quod tria canístra farínæ habérem super caput meum :

17. et in uno canístro quod erat excélsius, portáre me omnes cibos qui fiunt arte pistória, avésque comédere ex eo.

18. Respóndit Joseph : Hæc est interpretátio sómnii : tria canístra, tres adhuc dies sunt :

19. post quos áuferet Phárao caput tuum, ac suspéndet te in cruce, et lacerábunt vólucres carnes tuas.

20. Exínde dies tértius natalítius Pharaónis erat : qui fáciens grande convívium púeris suis, recordátus est inter épulas magístri pincernárum, et pistórum príncipis.

21. Restituítque álterum in locum suum, ut porrígeret ei póculum :

22. álterum suspéndit in patíbulo, ut conjectóris véritas probarétur.

23. Et tamen succedéntibus prósperis, præpósitus pincernárum oblítus est interprétis sui.

