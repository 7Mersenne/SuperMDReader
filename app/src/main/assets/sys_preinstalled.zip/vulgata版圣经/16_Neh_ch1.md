# Liber Nehemi� - Caput 1

1. Verba Nehemíæ fílii Hélchiæ. Et factum est in mense Cásleu, anno vigésimo, et ego eram in Susis castro.

2. Et venit Hanáni, unus de frátribus meis, ipse et viri ex Juda : et interrogávi eos de Judǽis qui remánserant, et supérerant de captivitáte, et Jerúsalem.

3. Et dixérunt mihi : Qui remansérunt, et relícti sunt de captivitáte ibi in província, in afflictióne magna sunt, et in oppróbrio : et murus Jerúsalem dissipátus est, et portæ ejus combústæ sunt igni.

4. Cumque audíssem verba hujuscémodi, sedi, et flevi, et luxi diébus multis : jejunábam, et orábam ante fáciem Dei cæli :

5. et dixi : Quæso, Dómine Deus cæli fortis, magne atque terríbilis, qui custódis pactum et misericórdiam cum his qui te díligunt, et custódiunt mandáta tua :

6. fiant aures tuæ auscultántes, et óculi tui apérti, ut áudias oratiónem servi tui, quam ego oro coram te hódie nocte et die pro fíliis Israël servis tuis : et confíteor pro peccátis filiórum Israël, quibus peccavérunt tibi : ego et domus patris mei peccávimus,

7. vanitáte sedúcti sumus, et non custodívimus mandátum tuum, et cæremónias, et judícia quæ præcepísti Móysi fámulo tuo.

8. Meménto verbi quod mandásti Móysi servo tuo, dicens : Cum transgréssi fuéritis, ego dispérgam vos in pópulos :

9. et si revertámini ad me, et custodiátis præcépta mea, et faciátis ea : etiámsi abdúcti fuéritis ad extréma cæli, inde congregábo vos, et redúcam in locum quem elégi ut habitáret nomen meum ibi.

10. Et ipsi servi tui, et pópulus tuus, quos redemísti in fortitúdine tua magna, et in manu tua válida.

11. Óbsecro, Dómine, sit auris tua atténdens ad oratiónem servi tui, et ad oratiónem servórum tuórum, qui volunt timére nomen tuum : et dírige servum tuum hódie, et da ei misericórdiam ante virum hunc. Ego enim eram pincérna regis.

