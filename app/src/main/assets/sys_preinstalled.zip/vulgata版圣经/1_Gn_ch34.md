# Liber Genesis - Caput 34

1. Egréssa est autem Dina fília Liæ ut vidéret mulíeres regiónis illíus.

2. Quam cum vidísset Sichem fílius Hemor Hevǽi, princeps terræ illíus, adamávit eam : et rápuit, et dormívit cum illa, vi ópprimens vírginem.

3. Et conglutináta est ánima ejus cum ea, tristémque delinívit blandítiis.

4. Et pergens ad Hemor patrem suum : Áccipe, inquit, mihi puéllam hanc cónjugem.

5. Quod cum audísset Jacob abséntibus fíliis, et in pastu pécorum occupátis, síluit donec redírent.

6. Egrésso autem Hemor patre Sichem ut loquerétur ad Jacob,

7. ecce fílii ejus veniébant de agro : auditóque quod accíderat, iráti sunt valde, eo quod fœdam rem operátus esset in Israël et, violáta fília Jacob, rem illícitam perpetrásset.

8. Locútus est ítaque Hemor ad eos : Sichem fílii mei adhǽsit ánima fíliæ vestræ : date eam illi uxórem :

9. et jungámus vicíssim connúbia : fílias vestras trádite nobis, et fílias nostras accípite,

10. et habitáte nobíscum : terra in potestáte vestra est : exercéte, negotiámini, et possidéte eam.

11. Sed et Sichem ad patrem et ad fratres ejus ait : Invéniam grátiam coram vobis : et quæcúmque statuéritis, dabo :

12. augéte dotem, et múnera postuláte, et libénter tríbuam quod petiéritis : tantum date mihi puéllam hanc uxórem.

13. Respondérunt fílii Jacob Sichem et patri ejus in dolo, sæviéntes ob stuprum soróris :

14. Non póssumus fácere quod pétitis, nec dare sorórem nostram hómini incircumcíso : quod illícitum et nefárium est apud nos.

15. Sed in hoc valébimus fœderári, si voluéritis esse símiles nostri, et circumcidátur in vobis omne masculíni sexus ;

16. tunc dábimus et accipiémus mútuo fílias vestras ac nostras : et habitábimus vobíscum, erimúsque unus pópulus.

17. Si autem circumcídi noluéritis, tollémus fíliam nostram, et recedémus.

18. Plácuit oblátio eórum Hemor, et Sichem fílio ejus,

19. nec dístulit adoléscens quin statim quod petebátur éxpleret : amábat enim puéllam valde, et ipse erat ínclytus in omni domo patris sui.

20. Ingressíque portam urbis, locúti sunt ad pópulum :

21. Viri isti pacífici sunt, et volunt habitáre nobíscum : negotiéntur in terra, et exérceant eam, quæ spatiósa et lata cultóribus índiget : fílias eórum accipiémus uxóres, et nostras illis dábimus.

22. Unum est quo différtur tantum bonum : si circumcidámus másculos nostros, ritum gentis imitántes.

23. Et substántia eórum, et pécora, et cuncta quæ póssident, nostra erunt : tantum in hoc acquiescámus, et habitántes simul, unum efficiémus pópulum.

24. Assensíque sunt omnes, circumcísis cunctis máribus.

25. Et ecce, die tértio, quando gravíssimus vúlnerum dolor est : arréptis duo fílii Jacob, Símeon et Levi fratres Dinæ, gládiis, ingréssi sunt urbem confidénter : interfectísque ómnibus másculis,

26. Hemor et Sichem páriter necavérunt, tolléntes Dinam de domo Sichem sorórem suam.

27. Quibus egréssis, irruérunt super occísos céteri fílii Jacob : et depopuláti sunt urbem in ultiónem stupri.

28. Oves eórum, et arménta, et ásinos, cunctáque vastántes quæ in dómibus et in agris erant,

29. párvulos quoque eórum et uxóres duxérunt captívas.

30. Quibus patrátis audácter, Jacob dixit ad Símeon et Levi : Turbástis me, et odiósum fecístis me Chananǽis, et Pherezǽis habitatóribus terræ hujus : nos pauci sumus ; illi congregáti percútient me, et delébor ego, et domus mea.

31. Respondérunt : Numquid ut scorto abúti debúere soróre nostra ?

