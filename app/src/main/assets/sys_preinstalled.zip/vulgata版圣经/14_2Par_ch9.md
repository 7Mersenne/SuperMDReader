# Liber Secundus Paralipomenon - Caput 9

1. Regína quoque Saba, cum audísset famam Salomónis, venit ut tentáret eum in ænigmátibus in Jerúsalem, cum magnis ópibus et cámelis, qui portábant arómata, et auri plúrimum, gemmásque pretiósas. Cumque venísset ad Salomónem, locúta est ei quæcúmque erant in corde suo.

2. Et expósuit ei Sálomon ómnia quæ proposúerat : nec quidquam fuit, quod non perspícuum ei fécerit.

3. Quæ postquam vidit, sapiéntiam scílicet Salomónis, et domum quam ædificáverat,

4. necnon et cibária mensæ ejus, et habitácula servórum, et offícia ministrórum ejus, et vestiménta eórum, pincérnas quoque et vestes eórum, et víctimas quas immolábat in domo Dómini : non erat præ stupóre ultra in ea spíritus.

5. Dixítque ad regem : Verus est sermo quem audíeram in terra mea de virtútibus et sapiéntia tua.

6. Non credébam narrántibus donec ipsa veníssem, et vidíssent óculi mei, et probássem vix medietátem sapiéntiæ tuæ mihi fuísse narrátam : vicísti famam virtútibus tuis.

7. Beáti viri tui, et beáti servi tui, qui assístunt coram te omni témpore, et áudiunt sapiéntiam tuam.

8. Sit Dóminus Deus tuus benedíctus, qui vóluit te ordináre super thronum suum, regem Dómini Dei tui. Quia díligit Deus Israël, et vult serváre eum in ætérnum, idcírco pósuit te super eum regem ut fácias judícia atque justítiam.

9. Dedit autem regi centum vigínti talénta auri, et arómata multa nimis, et gemmas pretiosíssimas : non fuérunt arómata tália, ut hæc quæ dedit regína Saba regi Salomóni.

10. Sed et servi Hiram cum servis Salomónis attulérunt aurum de Ophir, et ligna thyína, et gemmas pretiosíssimas :

11. de quibus fecit rex, de lignis scílicet thýinis, gradus in domo Dómini, et in domo régia, cítharas quoque, et psaltéria cantóribus : numquam visa sunt in terra Juda ligna tália.

12. Rex autem Sálomon dedit regínæ Saba cuncta quæ vóluit, et quæ postulávit, et multo plura quam attúlerat ad eum : quæ revérsa ábiit in terram suam cum servis suis.

13. Erat autem pondus auri quod afferebátur Salomóni per síngulos annos, sexcénta sexagínta sex talénta auri,

14. excépta ea summa quam legáti diversárum géntium et negotiatóres afférre consuéverant, omnésque reges Arábiæ, et satrápæ terrárum, qui comportábant aurum et argéntum Salomóni.

15. Fecit ígitur rex Sálomon ducéntas hastas áureas de summa sexcentórum aureórum, qui in síngulis hastis expendebántur :

16. trecénta quoque scuta áurea trecentórum aureórum, quibus tegebántur síngula scuta : posuítque ea rex in armentário, quod erat cónsitum nemóre.

17. Fecit quoque rex sólium ebúrneum grande, et vestívit illud auro mundíssimo.

18. Sex quoque gradus, quibus ascendebátur ad sólium, et scabéllum áureum, et brachíola duo altrínsecus, et duos leónes stantes juxta brachíola,

19. sed et álios duódecim leúnculos stantes super sex gradus ex utráque parte : non fuit tale sólium in univérsis regnis.

20. Ómnia quoque vasa convívii regis erant áurea, et vasa domus saltus Líbani ex auro puríssimo. Argéntum enim in diébus illis pro níhilo reputabátur.

21. Síquidem naves regis ibant in Tharsis cum servis Hiram, semel in annis tribus : et deferébant inde aurum, et argéntum, et ebur, et símias, et pavos.

22. Magnificátus est ígitur Sálomon super omnes reges terræ præ divítiis et glória.

23. Omnésque reges terrárum desiderábant vidére fáciem Salomónis, ut audírent sapiéntiam quam déderat Deus in corde ejus :

24. et deferébant ei múnera, vasa argéntea et áurea, et vestes, et arma, et arómata, equos, et mulos, per síngulos annos.

25. Hábuit quoque Sálomon quadragínta míllia equórum in stábulis, et cúrruum equitúmque duódecim míllia : constituítque eos in úrbibus quadrigárum, et ubi erat rex in Jerúsalem.

26. Exércuit étiam potestátem super cunctos reges a flúmine Euphráte usque ad terram Philisthinórum, et usque ad términos Ægýpti.

27. Tantámque cópiam prǽbuit argénti in Jerúsalem quasi lápidum : et cedrórum tantam multitúdinem velut sycomorórum quæ gignúntur in campéstribus.

28. Adducebántur autem ei equi de Ægýpto, cunctísque regiónibus.

29. Réliqua autem óperum Salomónis priórum et novissimórum scripta sunt in verbis Nathan prophétæ, et in libris Áhiæ Silónitis, in visióne quoque Addo vidéntis contra Jeróboam fílium Nabat.

30. Regnávit autem Sálomon in Jerúsalem super omnem Israël quadragínta annis.

31. Dormivítque cum pátribus suis, et sepeliérunt eum in civitáte David : regnavítque Róboam fílius ejus pro eo.

