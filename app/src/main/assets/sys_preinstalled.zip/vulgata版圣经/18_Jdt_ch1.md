# Liber Judith - Caput 1

1. Arpháxad ítaque, rex Medórum, subjugáverat multas gentes império suo, et ipse ædificávit civitátem potentíssimam, quam appellávit Ecbatánis,

2. ex lapídibus quadrátis et sectis : fecit muros ejus in altitúdinem cubitórum septuagínta, et in latitúdinem cubitórum trigínta : turres vero ejus pósuit in altitúdinem cubitórum centum.

3. Per quadrum vero eárum latus utrúmque vicenórum pedum spátio tendebátur, posuítque portas ejus in altitúdinem túrrium :

4. et gloriabátur quasi potens in poténtia exércitus sui, et in glória quadrigárum suárum.

5. Anno ígitur duodécimo regni sui, Nabuchodonósor rex Assyriórum, qui regnábat in Nínive civitáte magna, pugnávit contra Arpháxad, et obtínuit eum

6. in campo magno qui appellátur Rágau, circa Euphráten, et Tigrin, et Jadáson, in campo Érioch regis Elicórum.

7. Tunc exaltátum est regnum Nabuchodonósor, et cor ejus elevátum est : et misit ad omnes qui habitábant in Cilícia, et Damásco, et Líbano,

8. et ad gentes quæ sunt in Carmélo et Cedar, et inhabitántes Galilǽam in campo magno Ésdrelon,

9. et ad omnes qui erant in Samaría, et trans flumen Jordánem usque ad Jerúsalem, et omnem terram Jesse quoúsque perveniátur ad términos Æthiópiæ.

10. Ad hos omnes misit núntios Nabuchodonósor rex Assyriórum :

11. qui omnes uno ánimo contradixérunt, et remisérunt eos vácuos, et sine honóre abjecérunt.

12. Tunc indignátus Nabuchodonósor rex advérsus omnem terram illam, jurávit per thronum et regnum suum quod defénderet se de ómnibus regiónibus his.

