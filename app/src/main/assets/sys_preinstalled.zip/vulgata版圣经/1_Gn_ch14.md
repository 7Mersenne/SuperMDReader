# Liber Genesis - Caput 14

1. Factum est autem in illo témpore, ut Amráphel rex Sénnaar, et Árioch rex Ponti, et Chodorlahómor rex Elamitárum, et Thadal rex géntium

2. inírent bellum contra Bara regem Sodomórum, et contra Bersa regem Gomórrhæ, et contra Sénnaab regem Adámæ, et contra Seméber regem Séboim, contráque regem Balæ, ipsa est Segor.

3. Omnes hi convenérunt in vallem Silvéstrem, quæ nunc est mare salis.

4. Duódecim enim annis serviérunt Chodorlahómor, et tertiodécimo anno recessérunt ab eo.

5. Ígitur quartodécimo anno venit Chodorlahómor, et reges qui erant cum eo : percusserúntque Ráphaim in Astarothcárnaim, et Zuzim cum eis, et Emim in Save Cariáthaim,

6. et Chorrǽos in móntibus Seir, usque ad Campéstria Pharan, quæ est in solitúdine.

7. Reversíque sunt, et venérunt ad fontem Misphat, ipsa est Cades : et percussérunt omnem regiónem Amalecitárum, et Amorrhǽum, qui habitábat in Asasonthámar.

8. Et egréssi sunt rex Sodomórum, et rex Gomórrhæ, rexque Adámæ, et rex Séboim, necnon et rex Balæ, quæ est Segor : et direxérunt áciem contra eos in valle Silvéstri :

9. scílicet advérsus Chodorlahómor regem Elamitárum, et Thadal regem Géntium, et Amráphel regem Sénnaar, et Árioch regem Ponti : quátuor reges advérsus quinque.

10. Vallis autem Silvéstris habébat púteos multos bitúminis. Ítaque rex Sodomórum, et Gomórrhæ, terga vertérunt, ceciderúntque ibi : et qui remánserant, fugérunt ad montem.

11. Tulérunt autem omnem substántiam Sodomórum et Gomórrhæ, et univérsa quæ ad cibum pértinent, et abiérunt :

12. necnon et Lot, et substántiam ejus, fílium fratris Abram, qui habitábat in Sodómis.

13. Et ecce unus, qui eváserat, nuntiávit Abram Hebrǽo, qui habitábat in conválle Mambre Amorrhǽi, fratris Escol, et fratris Aner : hi enim pepígerant fœdus cum Abram.

14. Quod cum audísset Abram, captum vidélicet Lot fratrem suum, numerávit expedítos vernáculos suos trecéntos decem et octo : et persecútus est usque Dan.

15. Et divísis sóciis, írruit super eos nocte : percussítque eos, et persecútus est eos usque Hoba, quæ est ad lævam Damásci.

16. Reduxítque omnem substántiam, et Lot fratrem suum cum substántia illíus, mulíeres quoque et pópulum.

17. Egréssus est autem rex Sodomórum in occúrsum ejus postquam revérsus est a cæde Chodorlahómor, et regum qui cum eo erant in valle Save, quæ est vallis regis.

18. At vero Melchísedech rex Salem, próferens panem et vinum, erat enim sacérdos Dei altíssimi,

19. benedíxit ei, et ait : Benedíctus Abram Deo excélso, qui creávit cælum et terram :

20. et benedíctus Deus excélsus, quo protegénte, hostes in mánibus tuis sunt. Et dedit ei décimas ex ómnibus.

21. Dixit autem rex Sodomórum ad Abram : Da mihi ánimas, cétera tolle tibi.

22. Qui respóndit ei : Levo manum meam ad Dóminum Deum excélsum possessórem cæli et terræ,

23. quod a filo subtégminis usque ad corígiam calígæ, non accípiam ex ómnibus quæ tua sunt, ne dicas : Ego ditávi Abram :

24. excéptis his, quæ comedérunt júvenes, et pártibus virórum, qui venérunt mecum, Aner, Escol et Mambre : isti accípient partes suas.

