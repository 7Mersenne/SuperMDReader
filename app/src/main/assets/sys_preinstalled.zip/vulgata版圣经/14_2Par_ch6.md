# Liber Secundus Paralipomenon - Caput 6

1. Tunc Sálomon ait : Dóminus pollícitus est ut habitáret in calígine :

2. ego autem ædificávi domum nómini ejus, ut habitáret ibi in perpétuum.

3. Et convértit rex fáciem suam, et benedíxit univérsæ multitúdini Israël (nam omnis turba stabat inténta), et ait :

4. Benedíctus Dóminus Deus Israël, qui quod locútus est David patri meo, ópere complévit, dicens :

5. A die qua edúxi pópulum meum de terra Ægýpti, non elégi civitátem de cunctis tríbubus Israël ut ædificarétur in ea domus nómini meo, neque elégi quemquam álium virum ut esset dux in pópulo Israël :

6. sed elégi Jerúsalem ut sit nomen meum in ea, et elégi David ut constitúerem eum super pópulum meum Israël.

7. Cumque fuísset voluntátis David patris mei ut ædificáret domum nómini Dómini Dei Israël,

8. dixit Dóminus ad eum : Quia hæc fuit volúntas tua, ut ædificáres domum nómini meo, bene quidem fecísti hujuscémodi habére voluntátem :

9. sed non tu ædificábis domum : verum fílius tuus, qui egrediétur de lumbis tuis, ipse ædificábit domum nómini meo.

10. Complévit ergo Dóminus sermónem suum quem locútus fúerat : et ego surréxi pro David patre meo, et sedi super thronum Israël, sicut locútus est Dóminus : et ædificávi domum nómini Dómini Dei Israël.

11. Et pósui in ea arcam in qua est pactum Dómini quod pépigit cum fíliis Israël.

12. Stetit ergo coram altári Dómini ex advérso univérsæ multitúdinis Israël, et exténdit manus suas.

13. Síquidem fécerat Sálomon basim ǽneam, et posúerat eam in médio basílicæ, habéntem quinque cúbitos longitúdinis, et quinque cúbitos latitúdinis, et tres cúbitos altitúdinis : stetítque super eam, et deínceps flexis génibus contra univérsam multitúdinem Israël, et palmis in cælum levátis,

14. ait : Dómine Deus Israël, non est símilis tui deus in cælo et in terra : qui custódis pactum et misericórdiam cum servis tuis qui ámbulant coram te in toto corde suo :

15. qui præstitísti servo tuo David patri meo quæcúmque locútus fúeras ei : et quæ ore promíseras, ópere complésti, sicut et præsens tempus probat.

16. Nunc ergo Dómine Deus Israël, imple servo tuo patri meo David quæcúmque locútus es, dicens : Non defíciet ex te vir coram me, qui sédeat super thronum Israël : ita tamen si custodíerint fílii tui vias suas, et ambuláverint in lege mea, sicut et tu ambulásti coram me.

17. Et nunc Dómine Deus Israël, firmétur sermo tuus quem locútus es servo tuo David.

18. Ergóne credíbile est ut hábitet Deus cum homínibus super terram ? si cælum et cæli cælórum non te cápiunt, quanto magis domus ista quam ædificávi ?

19. Sed ad hoc tantum facta est, ut respícias oratiónem servi tui, et obsecratiónem ejus, Dómine Deus meus, et áudias preces quas fundit fámulus tuus coram te :

20. ut apérias óculos tuos super domum istam diébus ac nóctibus, super locum in quo pollícitus es ut invocarétur nomen tuum,

21. et exaudíres oratiónem quam servus tuus orat in eo : et exáudias preces fámuli tui, et pópuli tui Israël. Quicúmque oráverit in loco isto, exáudi de habitáculo tuo, id est, de cælis, et propitiáre.

22. Si peccáverit quíspiam in próximum suum, et juráre contra eum parátus vénerit, seque maledícto constrínxerit coram altári in domo ista :

23. tu áudies de cælo, et fácies judícium servórum tuórum, ita ut reddas iníquo viam suam in caput próprium, et ulciscáris justum, retríbuens ei secúndum justítiam suam.

24. Si superátus fúerit pópulus tuus Israël ab inimícis (peccábunt enim tibi), et convérsi égerint pœniténtiam, et obsecráverint nomen tuum, et fúerint deprecáti in loco isto,

25. tu exáudies de cælo : et propitiáre peccáto pópuli tui Israël, et reduc eos in terram quam dedísti eis, et pátribus eórum.

26. Si clauso cælo plúvia non flúxerit propter peccáta pópuli, et deprecáti te fúerint in loco isto, et conféssi nómini tuo, et convérsi a peccátis suis, cum eos afflíxeris,

27. exáudi de cælo, Dómine, et dimítte peccáta servis tuis et pópuli tui Israël, et doce eos viam bonam, per quam ingrediántur : et da plúviam terræ quam dedísti pópulo tuo ad possidéndum.

28. Fames si orta fúerit in terra, et pestiléntia, ærúgo, et áurugo, et locústa, et bruchus : et hostes, vastátis regiónibus, portas obséderint civitátis, omnísque plaga et infírmitas présserit :

29. si quis de pópulo tuo Israël fúerit deprecátus, cognóscens plagam et infirmitátem suam, et expánderit manus suas in domo hac,

30. tu exáudies de cælo, de sublími scílicet habitáculo tuo : et propitiáre, et redde unicuíque secúndum vias suas, quas nosti eum habére in corde suo (tu enim solus nosti corda filiórum hóminum) :

31. ut tímeant te, et ámbulent in viis tuis cunctis diébus quibus vivunt super fáciem terræ quam dedísti pátribus nostris.

32. Extérnum quoque, qui non est de pópulo tuo Israël, si vénerit de terra longínqua propter nomen tuum magnum, et propter manum tuam robústam, et bráchium tuum exténtum, et adoráverit in loco isto,

33. tu exáudies de cælo firmíssimo habitáculo tuo, et fácies cuncta pro quibus invocáverit te ille peregrínus : ut sciant omnes pópuli terræ nomen tuum, et tímeant te sicut pópulus tuus Israël, et cognóscant quia nomen tuum invocátum est super domum hanc quam ædificávi.

34. Si egréssus fúerit pópulus tuus ad bellum contra adversários suos per viam in qua míseris eos, adorábunt te contra viam in qua cívitas hæc est, quam elegísti, et domus quam ædificávi nómini tuo,

35. tu exáudies de cælo preces eórum, et obsecratiónem : et ulciscáris.

36. Si autem peccáverint tibi (néque enim est homo qui non peccet), et irátus fúeris eis, et tradíderis hóstibus, et captívos dúxerint eos in terram longínquam, vel certe quæ juxta est,

37. et convérsi in corde suo in terra ad quam captívi ducti fúerant, égerint pœniténtiam, et deprecáti te fúerint in terra captivitátis suæ, dicéntes : Peccávimus : iníque fécimus, injúste égimus :

38. et revérsi fúerint ad te in toto corde suo, et in tota ánima sua, in terra captivitátis suæ ad quam ducti sunt, adorábunt te contra viam terræ suæ, quam dedísti pátribus eórum, et urbis quam elegísti, et domus quam ædificávi nómini tuo :

39. tu exáudies de cælo, hoc est, de firmo habitáculo tuo, preces eórum : et fácias judícium, et dimíttas pópulo tuo, quamvis peccatóri :

40. tu es enim Deus meus : aperiántur, quæso, óculi tui, et aures tuæ inténtæ sint ad oratiónem quæ fit in loco isto.

41. Nunc ígitur consúrge, Dómine Deus, in réquiem tuam, tu et arca fortitúdinis tuæ : sacerdótes tui, Dómine Deus, induántur salútem, et sancti tui læténtur in bonis.

42. Dómine Deus, ne avérteris fáciem christi tui : meménto misericordiárum David servi tui.

