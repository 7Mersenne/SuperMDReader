# Liber Exodus - Caput 26

1. Tabernáculum vero ita fácies : decem cortínas de bysso retórta, et hyacíntho, ac púrpura, coccóque bis tincto, variátas ópere plumário fácies.

2. Longitúdo cortínæ uníus habébit vigínti octo cúbitos : latitúdo, quátuor cubitórum erit. Uníus mensúræ fient univérsa tentória.

3. Quinque cortínæ sibi jungéntur mútuo, et áliæ quinque nexu símili cohærébunt.

4. Ánsulas hyacínthinas in latéribus ac summitátibus fácies cortinárum, ut possint ínvicem copulári.

5. Quinquagénas ánsulas cortína habébit in utráque parte, ita insértas ut ansa contra ansam véniat, et áltera álteri possit aptári.

6. Fácies et quinquagínta círculos áureos quibus cortinárum vela jungénda sunt, ut unum tabernáculum fiat.

7. Fácies et saga cilícina úndecim, ad operiéndum tectum tabernáculi.

8. Longitúdo sagi uníus habébit trigínta cúbitos, et latitúdo, quátuor : æqua erit mensúra sagórum ómnium.

9. E quibus quinque junges seórsum, et sex sibi mútuo copulábis, ita ut sextum sagum in fronte tecti dúplices.

10. Fácies et quinquagínta ansas in ora sagi uníus, ut conjúngi cum áltero queat, et quinquagínta ansas in ora sagi altérius, ut cum áltero copulétur.

11. Fácies et quinquagínta fíbulas ǽneas quibus jungántur ansæ, ut unum ex ómnibus operiméntum fiat.

12. Quod autem superfúerit in sagis quæ parántur tecto, id est unum sagum quod ámplius est, ex medietáte ejus opéries posterióra tabernáculi.

13. Et cúbitus ex una parte pendébit, et alter ex áltera qui plus est in sagórum longitúdine, utrúmque latus tabernáculi prótegens.

14. Fácies et operiméntum áliud tecto de péllibus aríetum rubricátis : et super hoc rursum áliud operiméntum de jánthinis péllibus.

15. Fácies et tábulas stantes tabernáculi de lignis setim,

16. quæ síngulæ denos cúbitos in longitúdine hábeant, et in latitúdine síngulos ac semíssem.

17. In latéribus tábulæ, duæ incastratúræ fient, quibus tábula álteri tábulæ connectátur : atque in hunc modum cunctæ tábulæ parabúntur.

18. Quarum vigínti erunt in látere meridiáno quod vergit ad austrum.

19. Quibus quadragínta bases argénteas fundes, ut binæ bases síngulis tábulis per duos ángulos subjiciántur.

20. In látere quoque secúndo tabernáculi quod vergit ad aquilónem, vigínti tábulæ erunt,

21. quadragínta habéntes bases argénteas, binæ bases síngulis tábulis supponéntur.

22. Ad occidentálem vero plagam tabernáculi fácies sex tábulas,

23. et rursum álias duas quæ in ángulis erigántur post tergum tabernáculi.

24. Erúntque conjúnctæ a deórsum usque sursum, et una omnes cómpago retinébit. Duábus quoque tábulis quæ in ángulis ponéndæ sunt, símilis junctúra servábitur.

25. Et erunt simul tábulæ octo, bases eárum argénteæ sédecim, duábus básibus per unam tábulam supputátis.

26. Fácies et vectes de lignis setim quinque ad continéndas tábulas in uno látere tabernáculi,

27. et quinque álios in áltero, et ejúsdem númeri ad occidentálem plagam :

28. qui mitténtur per médias tábulas a summo usque ad summum.

29. Ipsas quoque tábulas deaurábis, et fundes in eis ánnulos áureos per quos vectes tabuláta contíneant : quos opéries láminis áureis.

30. Et ériges tabernáculum juxta exémplar quod tibi in monte monstrátum est.

31. Fácies et velum de hyacíntho, et púrpura, coccóque bis tincto, et bysso retórta, ópere plumário et pulchra varietáte contéxtum :

32. quod appéndes ante quátuor colúmnas de lignis setim, quæ ipsæ quidem deaurátæ erunt, et habébunt cápita áurea, sed bases argénteas.

33. Inserétur autem velum per círculos, intra quod pones arcam testimónii, quo et sanctuárium, et sanctuárii sanctuária dividéntur.

34. Pones et propitiatórium super arcam testimónii in Sancto sanctórum,

35. mensámque extra velum, et contra mensam candelábrum in látere tabernáculi meridiáno : mensa enim stabit in parte aquilónis.

36. Fácies et tentórium in intróitu tabernáculi de hyacíntho, et púrpura, coccóque bis tincto, et bysso retórta, ópere plumárii.

37. Et quinque colúmnas deaurábis lignórum setim, ante quas ducétur tentórium : quarum erunt cápita áurea, et bases ǽneæ.

