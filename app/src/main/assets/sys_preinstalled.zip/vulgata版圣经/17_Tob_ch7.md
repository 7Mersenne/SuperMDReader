# Liber Tobi� - Caput 7

1. Ingréssi sunt autem ad Ráguelem, et suscépit eos Raguel cum gáudio.

2. Intuénsque Tobíam Raguel, dixit Annæ uxóri suæ : Quam símilis est júvenis iste consobríno meo !

3. Et cum hæc dixísset, ait : Unde estis júvenes fratres nostri ? At illi dixérunt : Ex tribu Nephtháli sumus, ex captivitáte Nínive.

4. Dixítque illis Raguel : Nostis Tobíam fratrem meum ? Qui dixérunt : Nóvimus.

5. Cumque multa bona loquerétur de eo, dixit ángelus ad Ráguelem : Tobías, de quo intérrogas, pater istíus est.

6. Et misit se Raguel, et cum lácrimis osculátus est eum, et plorans supra collum ejus

7. dixit : Benedíctio sit tibi, fili mi, quia boni et óptimi viri fílius es.

8. Et Anna uxor ejus, et Sara ipsórum fília, lacrimátæ sunt.

9. Postquam autem locúti sunt, præcépit Raguel occídi aríetem, et parári convívium. Cumque hortarétur eos discúmbere ad prándium,

10. Tobías dixit : Hic ego hódie non manducábo neque bibam, nisi prius petitiónem meam confírmes, et promíttas mihi dare Saram fíliam tuam.

11. Quo audíto verbo Raguel expávit, sciens quid evénerit illis septem viris qui ingréssi sunt ad eam : et timére cœpit ne forte et hunc simíliter contíngeret. Et cum nutáret, et non daret peténti ullum respónsum,

12. dixit ei ángelus : Noli timére dare eam isti, quóniam huic timénti Deum debétur conjux fília tua : proptérea álius non pótuit habére illam.

13. Tunc dixit Raguel : Non dúbito quod Deus preces et lácrimas meas in conspéctu suo admíserit.

14. Et credo quóniam ídeo fecit vos veníre ad me, ut ista conjungerétur cognatióni suæ secúndum legem Móysi : et nunc noli dúbium gérere quod tibi eam tradam.

15. Et apprehéndens déxteram fíliæ suæ, déxteræ Tobíæ trádidit, dicens : Deus Ábraham, et Deus Ísaac, et Deus Jacob vobíscum sit, et ipse conjúngat vos, impleátque benedictiónem suam in vobis.

16. Et accépta carta, fecérunt conscriptiónem conjúgii.

17. Et post hæc epuláti sunt, benedicéntes Deum.

18. Vocavítque Raguel ad se Annam uxórem suam, et præcépit ei ut præparáret álterum cubículum.

19. Et introdúxit illuc Saram fíliam suam, et lacrimáta est.

20. Dixítque ei : Forti ánimo esto, fília mea : Dóminus cæli det tibi gáudium pro tǽdio quod perpéssa es.

