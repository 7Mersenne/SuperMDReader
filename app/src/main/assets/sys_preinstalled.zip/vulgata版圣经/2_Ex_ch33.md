# Liber Exodus - Caput 33

1. Locutúsque est Dóminus ad Móysen, dicens : Vade, ascénde de loco isto tu, et pópulus tuus quem eduxísti de terra Ægýpti, in terram quam jurávi Ábraham, Ísaac et Jacob, dicens : Sémini tuo dabo eam :

2. et mittam præcursórem tui ángelum, ut ejíciam Chananǽum, et Amorrhǽum, et Hethǽum, et Pherezǽum, et Hevǽum, et Jebusǽum,

3. et intres in terram fluéntem lacte et melle. Non enim ascéndam tecum, quia pópulus duræ cervícis es : ne forte dispérdam te in via.

4. Audiénsque pópulus sermónem hunc péssimum, luxit : et nullus ex more indútus est cultu suo.

5. Dixítque Dóminus ad Móysen : Lóquere fíliis Israël : Pópulus duræ cervícis es : semel ascéndam in médio tui, et delébo te. Jam nunc depóne ornátum tuum, ut sciam quid fáciam tibi.

6. Deposuérunt ergo fílii Israël ornátum suum a monte Horeb.

7. Móyses quoque tollens tabernáculum, teténdit extra castra procul, vocavítque nomen ejus, Tabernáculum fóederis. Et omnis pópulus, qui habébat áliquam quæstiónem, egrediebátur ad tabernáculum fóederis, extra castra.

8. Cumque egrederétur Móyses ad tabernáculum, surgébat univérsa plebs, et stabat unusquísque in óstio papiliónis sui, aspiciebántque tergum Móysi, donec ingrederétur tentórium.

9. Ingrésso autem illo tabernáculum fóederis, descendébat colúmna nubis, et stabat ad óstium, loquebatúrque cum Móyse,

10. cernéntibus univérsis quod colúmna nubis staret ad óstium tabernáculi. Stabántque ipsi, et adorábant per fores tabernaculórum suórum.

11. Loquebátur autem Dóminus ad Móysen fácie ad fáciem, sicut solet loqui homo ad amícum suum. Cumque ille reverterétur in castra, miníster ejus Jósue fílius Nun, puer, non recedébat de tabernáculo.

12. Dixit autem Móyses ad Dóminum : Prǽcipis ut edúcam pópulum istum : et non índicas mihi quem missúrus es mecum, præsértim cum díxeris : Novi te ex nómine, et invenísti grátiam coram me.

13. Si ergo invéni grátiam in conspéctu tuo, osténde mihi fáciem tuam, ut sciam te, et invéniam grátiam ante óculos tuos : réspice pópulum tuum gentem hanc.

14. Dixítque Dóminus : Fácies mea præcédet te, et réquiem dabo tibi.

15. Et ait Móyses : Si non tu ipse præcédas, ne edúcas nos de loco isto.

16. In quo enim scire potérimus ego et pópulus tuus invenísse nos grátiam in conspéctu tuo, nisi ambuláveris nobíscum, ut glorificémur ab ómnibus pópulis qui hábitant super terram ?

17. Dixit autem Dóminus ad Móysen : Et verbum istud, quod locútus es, fáciam : invenísti enim grátiam coram me, et teípsum novi ex nómine.

18. Qui ait : Osténde mihi glóriam tuam.

19. Respóndit : Ego osténdam omne bonum tibi, et vocábo in nómine Dómini coram te : et miserébor cui volúero, et clemens ero in quem mihi placúerit.

20. Rursúmque ait : Non póteris vidére fáciem meam : non enim vidébit me homo et vivet.

21. Et íterum : Ecce, inquit, est locus apud me, et stabis supra petram.

22. Cumque transíbit glória mea, ponam te in forámine petræ, et prótegam déxtera mea, donec tránseam :

23. tollámque manum meam, et vidébis posterióra mea : fáciem autem meam vidére non póteris.

