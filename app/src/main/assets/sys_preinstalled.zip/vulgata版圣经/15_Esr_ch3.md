# Liber Esdr� - Caput 3

1. Jamque vénerat mensis séptimus, et erant fílii Israël in civitátibus suis : congregátus est ergo pópulus quasi vir unus in Jerúsalem.

2. Et surréxit Jósue fílius Jósedec, et fratres ejus sacerdótes, et Zoróbabel fílius Saláthiel, et fratres ejus, et ædificavérunt altáre Dei Israël ut offérrent in eo holocautomáta, sicut scriptum est in lege Móysi viri Dei.

3. Collocavérunt autem altáre Dei super bases suas, deterréntibus eos per circúitum pópulis terrárum : et obtulérunt super illud holocáustum Dómino mane et véspere.

4. Fecerúntque solemnitátem tabernaculórum, sicut scriptum est, et holocáustum diébus síngulis per órdinem secúndum præcéptum opus diéi in die suo.

5. Et post hæc holocáustum juge, tam in caléndis quam in univérsis solemnitátibus Dómini quæ erant consecrátæ, et in ómnibus in quibus ultro offerebátur munus Dómino.

6. A primo die mensis séptimi cœpérunt offérre holocáustum Dómino : porro templum Dei nondum fundátum erat.

7. Dedérunt autem pecúnias latómis et cæmentáriis : cibum quoque, et potum, et óleum Sidóniis Tyriísque, ut deférrent ligna cédrina de Líbano ad mare Joppe, juxta quod præcéperat Cyrus rex Persárum eis.

8. Anno autem secúndo advéntus eórum ad templum Dei in Jerúsalem, mense secúndo, cœpérunt Zoróbabel fílius Saláthiel, et Jósue fílius Jósedec, et réliqui de frátribus eórum sacerdótes, et Levítæ, et omnes qui vénerant de captivitáte in Jerúsalem, et constituérunt Levítas a vigínti annis et supra, ut úrgerent opus Dómini.

9. Stetítque Jósue et fílii ejus et fratres ejus, Cédmihel et fílii ejus, et fílii Juda, quasi vir unus, ut instárent super eos qui faciébant opus in templo Dei : fílii Henádad, et fílii eórum, et fratres eórum Levítæ.

10. Fundáto ígitur a cæmentáriis templo Dómini, stetérunt sacerdótes in ornátu suo cum tubis, et Levítæ fílii Asaph in cýmbalis, ut laudárent Deum per manus David regis Israël.

11. Et concinébant in hymnis, et confessióne Dómino : Quóniam bonus, quóniam in ætérnum misericórdia ejus super Israël. Omnis quoque pópulus vociferabátur clamóre magno in laudándo Dóminum, eo quod fundátum esset templum Dómini.

12. Plúrimi étiam de sacerdótibus et Levítis, et príncipes patrum, et senióres, qui víderant templum prius cum fundátum esset, et hoc templum, in óculis eórum, flebant voce magna : et multi vociferántes in lætítia, elevábant vocem.

13. Nec póterat quisquam agnóscere vocem clamóris lætántium, et vocem fletus pópuli : commístim enim pópulus vociferabátur clamóre magno, et vox audiebátur procul.

