# Liber Genesis - Caput 36

1. Hæ sunt autem generatiónes Ésau, ipse est Edom.

2. Ésau accépit uxóres de filiábus Chánaan : Ada fíliam Elon Hethǽi, et Oolibáma fíliam Anæ fíliæ Sébeon Hevǽi :

3. Basémath quoque fíliam Ísmaël sorórem Nabaíoth.

4. Péperit autem Ada Éliphaz : Basémath génuit Ráhuel :

5. Oolibáma génuit Jehus et Íhelon et Core. Hi fílii Ésau qui nati sunt ei in terra Chánaan.

6. Tulit autem Ésau uxóres suas et fílios et fílias, et omnem ánimam domus suæ, et substántiam, et pécora, et cuncta quæ habére póterat in terra Chánaan : et ábiit in álteram regiónem, recessítque a fratre suo Jacob.

7. Dívites enim erant valde, et simul habitáre non póterant : nec sustinébat eos terra peregrinatiónis eórum præ multitúdine gregum.

8. Habitavítque Ésau in monte Seir, ipse est Edom.

9. Hæ autem sunt generatiónes Ésau patris Edom in monte Seir,

10. et hæc nómina filiórum ejus : Éliphaz fílius Ada uxóris Ésau : Ráhuel quoque fílius Basémath uxóris ejus.

11. Fuerúntque Éliphaz fílii : Theman, Omar, Sepho, et Gatham, et Cenez.

12. Erat autem Thamna concubína Éliphaz fílii Ésau : quæ péperit ei Ámalech. Hi sunt fílii Ada uxóris Ésau.

13. Fílii autem Ráhuel : Nahath et Zara, Samma et Meza : hi fílii Basémath uxóris Ésau.

14. Isti quoque erant fílii Oolibáma fíliæ Anæ fíliæ Sébeon, uxóris Ésau, quos génuit ei, Jehus et Íhelon et Core.

15. Hi duces filiórum Ésau : fílii Éliphaz primogéniti Ésau : dux Theman, dux Omra, dux Sepho, dux Cenez,

16. dux Core, dux Gathan, dux Ámalech. Hi fílii Éliphaz in terra Edom, et hi fílii Ada.

17. Hi quoque fílii Ráhuel fílii Ésau : dux Nahath, dux Zara, dux Samma, dux Meza : hi autem duces Ráhuel in terra Edom : isti fílii Basémath uxóris Ésau.

18. Hi autem fílii Oolibáma uxóris Ésau : dux Jehus, dux Íhelon, dux Core : hi duces Oolibáma fíliæ Anæ uxóris Ésau.

19. Isti sunt fílii Ésau, et hi duces eórum : ipse est Edom.

20. Isti sunt fílii Seir Horrǽi, habitatóres terræ : Lotan, et Sobal, et Sébeon, et Ana,

21. et Dison, et Eser, et Disan : hi duces Horrǽi, fílii Seir in terra Edom.

22. Facti sunt autem fílii Lotan : Hori et Heman. Erat autem soror Lotan, Thamna.

23. Et isti fílii Sobal : Alvan et Mánahat et Ebal, et Sepho et Onam.

24. Et hi fílii Sébeon : Aja et Ana. Iste est Ana qui invénit aquas cálidas in solitúdine, cum pásceret ásinos Sébeon patris sui :

25. habuítque fílium Dison, et fíliam Oolibáma.

26. Et isti fílii Dison : Hamdan, et Eséban, et Jethram, et Charan.

27. Hi quoque fílii Eser : Bálaan, et Zavan, et Acan.

28. Hábuit autem fílios Disan : Hus et Aram.

29. Hi duces Horræórum : dux Lotan, dux Sobal, dux Sébeon, dux Ana,

30. dux Dison, dux Eser, dux Disan : isti duces Horræórum qui imperavérunt in terra Seir.

31. Reges autem qui regnavérunt in terra Edom ántequam habérent regem fílii Israël, fuérunt hi :

32. Bela fílius Beor, noménque urbis ejus Denába.

33. Mórtuus est autem Bela, et regnávit pro eo Jobab fílius Zaræ de Bosra.

34. Cumque mórtuus esset Jobab, regnávit pro eo Husam de terra Themanórum.

35. Hoc quoque mórtuo, regnávit pro eo Adad fílius Badad, qui percússit Mádian in regióne Moab : et nomen urbis ejus Avith.

36. Cumque mórtuus esset Adad, regnávit pro eo Semla de Masréca.

37. Hoc quoque mórtuo regnávit pro eo Saul de flúvio Rohóboth.

38. Cumque et hic obiísset, succéssit in regnum Balánan fílius Achóbor.

39. Isto quoque mórtuo regnávit pro eo Adar, noménque urbis ejus Phau : et appellabátur uxor ejus Meetábel, fília Matred fíliæ Mézaab.

40. Hæc ergo nómina ducum Ésau in cognatiónibus, et locis, et vocábulis suis : dux Thamna, dux Alva, dux Jetheth,

41. dux Oolibáma, dux Ela, dux Phinon,

42. dux Cenez, dux Theman, dux Mabsar,

43. dux Mágdiel, dux Hiram : hi duces Edom habitántes in terra impérii sui, ipse est Ésau pater Idumæórum.

