# Liber Esther - Caput 12

1. Morabátur autem eo témpore in aula regis cum Bagátha et Thara eunúchis regis, qui janitóres erant palátii.

2. Cumque intellexísset cogitatiónes eórum, et curas diligéntius pervidísset, dídicit quod conaréntur in regem Artaxérxem manus míttere, et nuntiávit super eo regi.

3. Qui de utróque, hábita quæstióne, conféssos jussit duci ad mortem.

4. Rex autem quod gestum erat, scripsit in commentáriis : sed et Mardochǽus rei memóriam lítteris trádidit.

5. Præcepítque ei rex, ut in aula palátii morarétur, datis ei pro delatióne munéribus.

6. Aman vero fílius Amadáthi Bugǽus erat gloriosíssimus coram rege, et vóluit nocére Mardochǽo et pópulo ejus pro duóbus eunúchis regis qui fúerant interfécti. Et diripuérunt bona, vel substántias eórum. Epístolæ autem hoc exémplar fuit.

