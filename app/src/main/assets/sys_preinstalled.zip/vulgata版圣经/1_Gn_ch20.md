# Liber Genesis - Caput 20

1. Proféctus inde Ábraham in terram austrálem, habitávit inter Cades et Sur : et peregrinátus est in Geráris.

2. Dixítque de Sara uxóre suo : Soror mea est. Misit ergo Abímelech rex Geráræ, et tulit eam.

3. Venit autem Deus ad Abímelech per sómnium nocte, et ait illi : En moriéris propter mulíerem quam tulísti : habet enim virum.

4. Abímelech vero non tetígerat eam, et ait : Dómine, num gentem ignorántem et justam interfícies ?

5. nonne ipse dixit mihi : Soror mea est : et ipsa ait : Frater meus est ? In simplicitáte cordis mei, et mundítia mánuum meárum feci hoc.

6. Dixítque ad eum Deus : Et ego scio quod símplici corde féceris : et ídeo custodívi te ne peccáres in me, et non dimísi ut tángeres eam.

7. Nunc ergo redde viro suo uxórem, quia prophéta est : et orábit pro te, et vives : si autem nolúeris réddere, scito quod morte moriéris tu, et ómnia quæ tua sunt.

8. Statímque de nocte consúrgens Abímelech, vocávit omnes servos suos : et locútus est univérsa verba hæc in áuribus eórum, timuerúntque omnes viri valde.

9. Vocávit autem Abímelech étiam Ábraham, et dixit ei : Quid fecísti nobis ? quid peccávimus in te, quia induxísti super me et super regnum meum peccátum grande ? quæ non debuísti fácere, fecísti nobis.

10. Rursúmque expóstulans, ait : Quid vidísti, ut hoc fáceres ?

11. Respóndit Ábraham : Cogitávi mecum, dicens : Fórsitan non est timor Dei in loco isto : et interfícient me propter uxórem meam :

12. álias autem et vere soror mea est, fília patris mei, et non fília matris meæ, et duxi eam in uxórem.

13. Postquam autem edúxit me Deus de domo patris mei, dixi ad eam : Hanc misericórdiam fácies mecum : in omni loco, ad quem ingrediémur, dices quod frater tuus sim.

14. Tulit ígitur Abímelech oves et boves, et servos et ancíllas, et dedit Ábraham : reddidítque illi Saram uxórem suam,

15. et ait : Terra coram vobis est, ubicúmque tibi placúerit hábita.

16. Saræ autem dixit : Ecce mille argénteos dedi fratri tuo, hoc erit tibi in velámen oculórum ad omnes qui tecum sunt, et quocúmque perréxeris : mementóque te deprehénsam.

17. Oránte autem Ábraham, sanávit Deus Abímelech et uxórem, ancillásque ejus, et peperérunt :

18. conclúserat enim Dóminus omnem vulvam domus Abímelech propter Saram uxórem Ábrahæ.

