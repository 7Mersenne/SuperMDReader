# Liber Exodus - Caput 30

1. Fácies quoque altáre ad adoléndum thymiáma, de lignis setim,

2. habens cúbitum longitúdinis, et álterum latitúdinis, id est, quadrángulum, et duos cúbitos in altitúdine. Córnua ex ipso procédent.

3. Vestiésque illud auro puríssimo, tam cratículam ejus, quam paríetes per circúitum, et córnua. Faciésque ei corónam auréolam per gyrum,

4. et duos ánnulos áureos sub coróna per síngula látera, ut mittántur in eos vectes, et altáre portétur.

5. Ipsos quoque vectes fácies de lignis setim, et inaurábis.

6. Ponésque altáre contra velum, quod ante arcum pendet testimónii coram propitiatório quo tégitur testimónium, ubi loquar tibi.

7. Et adolébit incénsum super eo Áaron, suáve fragrans, mane. Quando compónet lucérnas, incéndet illud :

8. et quando collocábit eas ad vésperum, uret thymiáma sempitérnum coram Dómino in generatiónes vestras.

9. Non offerétis super eo thymiáma compositiónis altérius, nec oblatiónem, et víctimam, nec libábitis libámina.

10. Et deprecábitur Áaron super córnua ejus semel per annum, in sánguine quod oblátum est pro peccáto, et placábit super eo in generatiónibus vestris. Sanctum sanctórum erit Dómino.

11. Locutúsque est Dóminus ad Móysen, dicens :

12. Quando túleris summam filiórum Israël juxta númerum, dabunt sínguli prétium pro animábus suis Dómino, et non erit plaga in eis, cum fúerint recensíti.

13. Hoc autem dabit omnis qui transit ad nomen, dimídium sicli juxta mensúram templi (siclus vigínti óbolos habet) ; média pars sicli offerétur Dómino.

14. Qui habétur in número, a vigínti annis et supra, dabit prétium.

15. Dives non addet ad médium sicli, et pauper nihil mínuet.

16. Susceptámque pecúniam, quæ colláta est a fíliis Israël, trades in usus tabernáculi testimónii, ut sit moniméntum eórum coram Dómino, et propitiétur animábus eórum.

17. Locutúsque est Dóminus ad Móysen, dicens :

18. Fácies et labrum ǽneum cum basi sua ad lavándum : ponésque illud inter tabernáculum testimónii et altáre. Et missa aqua,

19. lavábunt in ea Áaron et fílii ejus manus suas ac pedes,

20. quando ingressúri sunt tabernáculum testimónii, et quando accessúri sunt ad altáre, ut ófferant in eo thymiáma Dómino,

21. ne forte moriántur ; legítimum sempitérnum erit ipsi, et sémini ejus per successiónes.

22. Locutúsque est Dóminus ad Móysen,

23. dicens : Sume tibi arómata, primæ myrrhæ et eléctæ quingéntos siclos, et cinnamómi médium, id est, ducéntos quinquagínta siclos, cálami simíliter ducéntos quinquagínta,

24. cásiæ autem quingéntos siclos, in póndere sanctuárii, ólei de olivétis mensúram hin :

25. faciésque unctiónis óleum sanctum, unguéntum compósitum ópere unguentárii,

26. et unges ex eo tabernáculum testimónii, et arcam testaménti,

27. mensámque cum vasis suis, et candelábrum, et utensília ejus, altária thymiamátis,

28. et holocáusti, et univérsam supelléctilem quæ ad cultum eórum pértinet.

29. Sanctificabísque ómnia, et erunt Sancta sanctórum ; qui tetígerit ea, sanctificábitur.

30. Áaron et fílios ejus unges, sanctificabísque eos, ut sacerdótio fungántur mihi.

31. Fíliis quoque Israël dices : Hoc óleum unctiónis sanctum erit mihi in generatiónes vestras.

32. Caro hóminis non ungétur ex eo, et juxta compositiónem ejus non faciétis áliud, quia sanctificátum est, et sanctum erit vobis.

33. Homo quicúmque tale composúerit, et déderit ex eo aliéno, exterminábitur de pópulo suo.

34. Dixítque Dóminus ad Móysen : Sume tibi arómata, stacten et ónycha, galbánum boni odóris, et thus lucidíssimum ; æquális pónderis erunt ómnia :

35. faciésque thymiáma compósitum ópere unguentárii, mistum diligénter, et purum, et sanctificatióne digníssimum.

36. Cumque in tenuíssimum púlverem univérsa contúderis, pones ex eo coram tabernáculo testimónii, in quo loco apparébo tibi. Sanctum sanctórum erit vobis thymiáma.

37. Talem compositiónem non faciétis in usus vestros, quia sanctum est Dómino.

38. Homo quicúmque fécerit símile, ut odóre illíus perfruátur, períbit de pópulis suis.

