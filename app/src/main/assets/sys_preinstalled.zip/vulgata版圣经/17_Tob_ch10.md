# Liber Tobi� - Caput 10

1. Cum vero moras fáceret Tobías, causa nuptiárum, sollícitus erat pater ejus Tobías, dicens : Putas quare morátur fílius meus, aut quare deténtus est ibi ?

2. Putásne Gábelus mórtuus est, et nemo reddet illi pecúniam ?

3. Cœpit autem contristári nimis ipse, et Anna uxor ejus cum eo : et cœpérunt ambo simul flere, eo quod die statúto mínime reverterétur fílius eórum ad eos.

4. Flebat ígitur mater ejus irremediabílibus lácrimis, atque dicébat : Heu, heu me, fili mi ! ut quid te mísimus peregrinári, lumen oculórum nostrórum, báculum senectútis nostræ, solátium vitæ nostræ, spem posteritátis nostræ ?

5. ómnia simul in te uno habéntes, te non debúimus dimíttere a nobis.

6. Cui dicébat Tobías : Tace, et noli turbári : sanus est fílius noster : satis fidélis est vir ille, cum quo mísimus eum.

7. Illa autem nullo modo consolári póterat, sed quotídie exíliens circumspiciébat, et circuíbat vias omnes per quas spes remeándi videbátur, ut procul vidéret eum, si fíeri posset, veniéntem.

8. At vero Raguel dicébat ad génerum suum : Mane hic, et ego mittam núntium salútis de te ad Tobíam patrem tuum.

9. Cui Tobías ait : Ego novi quia pater meus et mater mea modo dies cómputant, et cruciátur spíritus eórum in ipsis.

10. Cumque verbis multis rogáret Raguel Tobíam, et ille eum nulla ratióne vellet audíre, trádidit ei Saram, et dimídiam partem omnis substántiæ suæ in púeris, in puéllis, in pecúdibus, in cámelis, et in vaccis, et in pecúnia multa : et salvum atque gaudéntem dimísit eum a se,

11. dicens : Ángelus Dómini sanctus sit in itínere vestro, perducátque vos incólumes, et inveniátis ómnia recte circa paréntes vestros, et vídeant óculi mei fílios vestros priúsquam móriar.

12. Et apprehendéntes paréntes fíliam suam, osculáti sunt eam : et dimisérunt ire,

13. monéntes eam honoráre sóceros, dilígere máritum, régere famíliam, gubernáre domum, et seípsam irreprehensíbilem exhibére.

