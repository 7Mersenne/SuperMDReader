# Liber Tobi� - Caput 9

1. Tunc vocávit Tobías ángelum ad se, quem quidem hóminem existimábat, dixítque ei : Azaría frater, peto ut auscúltes verba mea.

2. Si meípsum tradam tibi servum, non ero condígnus providéntiæ tuæ :

3. tamen óbsecro te ut assúmas tibi animália sive servítia, et vadas ad Gábelum in Rages civitátem Medórum, reddásque ei chirográphum suum, et recípias ab eo pecúniam, et roges eum veníre ad núptias meas.

4. Scis enim ipse quóniam númerat pater meus dies, et si tardávero una die plus, contristátur ánima ejus.

5. Et certe vides quómodo adjurávit me Raguel, cujus adjuraméntum spérnere non possum.

6. Tunc Ráphaël assúmens quátuor ex servis Ráguelis, et duos cámelos, in Rages civitátem Medórum perréxit : et invéniens Gábelum, réddidit ei chirográphum suum, et recépit ab eo omnem pecúniam.

7. Indicavítque ei de Tobía fílio Tobíæ ómnia quæ gesta sunt, fecítque eum secum veníre ad núptias.

8. Cumque ingréssus esset domum Ráguelis, invénit Tobíam discumbéntem : et exíliens, osculáti sunt se ínvicem : et flevit Gábelus, benedixítque Deum,

9. et dixit : Benedícat te Deus Israël, quia fílius es óptimi viri et justi, et timéntis Deum, et eleemósynas faciéntis :

10. et dicátur benedíctio super uxórem tuam, et super paréntes vestros,

11. et videátis fílios vestros, et fílios filiórum vestrórum, usque in tértiam et quartam generatiónem : et sit semen vestrum benedíctum a Deo Israël, qui regnat in sǽcula sæculórum.

12. Cumque omnes dixíssent : Amen : accessérunt ad convívium : sed et cum timóre Dómini nuptiárum convívium exercébant.

