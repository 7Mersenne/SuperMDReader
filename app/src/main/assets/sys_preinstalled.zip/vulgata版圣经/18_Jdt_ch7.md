# Liber Judith - Caput 7

1. Holoférnes autem áltera die præcépit exercítibus suis ut ascénderent contra Bethúliam.

2. Erant autem pédites bellatórum centum vigínti míllia, et équites vigínti duo míllia, præter præparatiónes virórum illórum quos occupáverat captívitas, et abdúcti fúerant de provínciis et úrbibus univérsæ juventútis.

3. Omnes paravérunt se páriter ad pugnam contra fílios Israël, et venérunt per crepídinem montis usque ad ápicem, qui réspicit super Dóthain, a loco qui dícitur Belma usque ad Chelmon, qui est contra Ésdrelon.

4. Fílii autem Israël, ut vidérunt multitúdinem illórum, prostravérunt se super terram, mitténtes cínerem super cápita sua, unánimes orántes ut Deus Israël misericórdiam suam osténderet super pópulum suum.

5. Et assuméntes arma sua béllica, sedérunt per loca quæ ad angústi itíneris trámitem dírigunt inter montósa, et erant custodiéntes ea tota die et nocte.

6. Porro Holoférnes, dum círcuit per gyrum, réperit quod fons qui influébat, aquædúctum illórum a parte austráli extra civitátem dirígeret : et íncidi præcépit aquædúctum illórum.

7. Erant tamen non longe a muris fontes, ex quibus furtim videbántur hauríre aquam ad refocillándum pótius quam ad potándum.

8. Sed fílii Ammon et Moab accessérunt ad Holoférnem, dicéntes : Fílii Israël non in láncea nec in sagítta confídunt, sed montes deféndunt illos, et múniunt illos colles in præcipítio constitúti.

9. Ut ergo sine congressióne pugnæ possis superáre eos, pone custódes fóntium, ut non háuriant aquam ex eis, et sine gládio interfícies eos, vel certe fatigáti tradent civitátem suam, quam putant in móntibus pósitam superári non posse.

10. Et placuérunt verba hæc coram Holoférne et coram satellítibus ejus, et constítuit per gyrum centenários per síngulos fontes.

11. Cumque ista custódia per dies vigínti fuísset expléta, defecérunt cistérnæ et collectiónes aquárum ómnibus habitántibus Bethúliam, ita ut non esset intra civitátem unde satiaréntur vel una die, quóniam ad mensúram dabátur pópulis aqua quotídie.

12. Tunc ad Ozíam congregáti omnes viri feminǽque, júvenes et párvuli, omnes simul una voce

13. dixérunt : Júdicet Deus inter nos et te, quóniam fecísti in nos mala, nolens loqui pacífice cum Assýriis, et propter hoc véndidit nos Deus in mánibus eórum.

14. Et ídeo non est qui ádjuvet, cum prosternámur ante óculos eórum in siti, et perditióne magna.

15. Et nunc congregáte univérsos qui in civitáte sunt, ut sponte tradámus nos omnes pópulo Holoférnis.

16. Mélius est enim ut captívi benedicámus Dóminum vivéntes, quam moriámur, et simus oppróbrium omni carni, cum vidérimus uxóres nostras et infántes nostros mori ante óculos nostros.

17. Contestámur hódie cælum et terram, et Deum patrum nostrórum, qui ulcíscitur nos secúndum peccáta nostra, ut jam tradátis civitátem in manu milítiæ Holoférnis, et sit finis noster brevis in ore gládii, qui lóngior effícitur in ariditáte sitis.

18. Et cum hæc dixíssent, factus est fletus et ululátus magnus in ecclésia ab ómnibus, et per multas horas una voce clamavérunt ad Deum, dicéntes :

19. Peccávimus cum pátribus nostris : injúste égimus, iniquitátem fécimus.

20. Tu, quia pius es, miserére nostri, aut in tuo flagéllo víndica iniquitátes nostras, et noli trádere confiténtes te pópulo qui ignórat te,

21. ut non dicant inter gentes : Ubi est Deus eórum ?

22. Et cum fatigáti ex his clamóribus et his flétibus lassáti siluíssent,

23. exsúrgens Ozías infúsus lácrimis, dixit : Æquo ánimo estóte, fratres, et hos quinque dies expectémus a Dómino misericórdiam.

24. Fórsitan enim indignatiónem suam abscíndet, et dabit glóriam nómini suo.

25. Si autem transáctis quinque diébus non vénerit adjutórium, faciémus hæc verba quæ locúti estis.

