# Liber Exodus - Caput 14

1. Locútus est autem Dóminus ad Móysen, dicens :

2. Lóquere fíliis Israël : Revérsi castrameténtur e regióne Phihahíroth, quæ est inter Magdálum et mare contra Beélsephon : in conspéctu ejus castra ponétis super mare.

3. Dicturúsque est Phárao super fíliis Israël : Coarctáti sunt in terra ; conclúsit eos desértum.

4. Et indurábo cor ejus, ac persequétur vos : et glorificábor in Pharaóne, et in omni exércitu ejus ; sciéntque Ægýptii quia ego sum Dóminus. Fecerúntque ita.

5. Et nuntiátum est regi Ægyptiórum quod fugísset pópulus : immutatúmque est cor Pharaónis et servórum ejus super pópulo, et dixérunt : Quid volúimus fácere ut dimitterémus Israël, ne servíret nobis ?

6. Junxit ergo currum, et omnem pópulum suum assúmpsit secum.

7. Tulítque sexcéntos currus eléctos, et quidquid in Ægýpto cúrruum fuit : et duces tótius exércitus.

8. Induravítque Dóminus cor Pharaónis regis Ægýpti, et persecútus est fílios Israël : at illi egréssi sunt in manu excélsa.

9. Cumque persequeréntur Ægýptii vestígia præcedéntium, reperérunt eos in castris super mare : omnis equitátus et currus Pharaónis, et univérsus exércitus, erant in Phihahíroth contra Beélsephon.

10. Cumque appropinquásset Phárao, levántes fílii Israël óculos, vidérunt Ægýptios post se, et timuérunt valde : clamaverúntque ad Dóminum,

11. et dixérunt ad Móysen : Fórsitan non erant sepúlchra in Ægýpto, ídeo tulísti nos ut morerémur in solitúdine : quid hoc fácere voluísti, ut edúceres nos ex Ægýpto ?

12. nonne iste est sermo, quem loquebámur ad te in Ægýpto, dicéntes : Recéde a nobis, ut serviámus Ægýptiis ? multo enim mélius erat servíre eis, quam mori in solitúdine.

13. Et ait Móyses ad pópulum : Nolíte timére : state, et vidéte magnália Dómini quæ factúrus est hódie : Ægýptios enim, quos nunc vidétis, nequáquam ultra vidébitis usque in sempitérnum.

14. Dóminus pugnábit pro vobis, et vos tacébitis.

15. Dixítque Dóminus ad Móysen : Quid clamas ad me ? lóquere fíliis Israël ut proficiscántur.

16. Tu autem éleva virgam tuam, et exténde manum tuam super mare, et dívide illud : ut gradiántur fílii Israël in médio mari per siccum.

17. Ego autem indurábo cor Ægyptiórum ut persequántur vos : et glorificábor in Pharaóne, et in omni exércitu ejus, et in cúrribus et in equítibus illíus.

18. Et scient Ægýptii quia ego sum Dóminus cum glorificátus fúero in Pharaóne, et in cúrribus atque in equítibus ejus.

19. Tollénsque se ángelus Dei, qui præcedébat castra Israël, ábiit post eos : et cum eo páriter colúmna nubis, prióra dimíttens, post tergum

20. stetit, inter castra Ægyptiórum et castra Israël : et erat nubes tenebrósa, et illúminans noctem, ita ut ad se ínvicem toto noctis témpore accédere non válerent.

21. Cumque extendísset Móyses manum super mare, ábstulit illud Dóminus flante vento veheménti et urénte tota nocte, et vertit in siccum : divisáque est aqua.

22. Et ingréssi sunt fílii Israël per médium sicci maris : erat enim aqua quasi murus a dextra eórum et læva.

23. Persequentésque Ægýptii ingréssi sunt post eos, et omnis equitátus Pharaónis, currus ejus et équites per médium maris.

24. Jamque advénerat vigília matutína, et ecce respíciens Dóminus super castra Ægyptiórum per colúmnam ignis et nubis, interfécit exércitum eórum,

25. et subvértit rotas cúrruum, ferebantúrque in profúndum. Dixérunt ergo Ægýptii : Fugiámus Israëlem : Dóminus enim pugnat pro eis contra nos.

26. Et ait Dóminus ad Móysen : Exténde manum tuam super mare, ut revertántur aquæ ad Ægýptios super currus et équites eórum.

27. Cumque extendísset Móyses manum contra mare, revérsum est primo dilúculo ad priórem locum : fugientibúsque Ægýptiis occurrérunt aquæ, et invólvit eos Dóminus in médiis flúctibus.

28. Reversǽque sunt aquæ, et operuérunt currus et équites cuncti exércitus Pharaónis, qui sequéntes ingréssi fúerant mare : nec unus quidem supérfuit ex eis.

29. Fílii autem Israël perrexérunt per médium sicci maris, et aquæ eis erant quasi pro muro a dextris et a sinístris :

30. liberavítque Dóminus in die illa Israël de manu Ægyptiórum.

31. Et vidérunt Ægýptios mórtuos super littus maris, et manum magnam quam exercúerat Dóminus contra eos : timuítque pópulus Dóminum, et credidérunt Dómino, et Móysi servo ejus.

