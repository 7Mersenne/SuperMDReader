# Liber Genesis - Caput 6

1. Cumque cœpíssent hómines multiplicári super terram, et fílias procreássent,

2. vidéntes fílii Dei fílias hóminum quod essent pulchræ, accepérunt sibi uxóres ex ómnibus, quas elégerant.

3. Dixítque Deus : Non permanébit spíritus meus in hómine in ætérnum, quia caro est : erúntque dies illíus centum vigínti annórum.

4. Gigántes autem erant super terram in diébus illis : postquam enim ingréssi sunt fílii Dei ad fílias hóminum, illǽque genuérunt, isti sunt poténtes a sǽculo viri famósi.

5. Videns autem Deus quod multa malítia hóminum esset in terra, et cuncta cogitátio cordis inténta esset ad malum omni témpore,

6. pœnítuit eum quod hóminum fecísset in terra. Et tactus dolóre cordis intrínsecus,

7. Delébo, inquit, hóminem, quem creávi, a fácie terræ, ab hómine usque ad animántia, a réptili usque ad vólucres cæli : póenitet enim me fecísse eos.

8. Noë vero invénit grátiam coram Dómino.

9. Hæ sunt generatiónes Noë : Noë vir justus atque perféctus fuit in generatiónibus suis ; cum Deo ambulávit.

10. Et génuit tres fílios, Sem, Cham et Japheth.

11. Corrúpta est autem terra coram Deo, et repléta est iniquitáte.

12. Cumque vidísset Deus terram esse corrúptam (ómnis quippe caro corrúperat viam suam super terram),

13. dixit ad Noë : Finis univérsæ carnis venit coram me : repléta est terra iniquitáte a fácie eórum, et ego dispérdam eos cum terra.

14. Fac tibi arcam de lignis lævigátis ; mansiúnculas in arca fácies, et bitúmine línies intrínsecus et extrínsecus.

15. Et sic fácies eam : trecentórum cubitórum erit longitúdo arcæ, quinquagínta cubitórum latitúdo, et trigínta cubitórum altitúdo illíus.

16. Fenéstram in arca fácies, et in cúbito consummábis summitátem ejus : óstium autem arcæ pones ex látere ; deórsum, cœnácula et trístega fácies in ea.

17. Ecce ego addúcam aquas dilúvii super terram, ut interfíciam omnem carnem, in qua spíritus vitæ est subter cælum : univérsa quæ in terra sunt, consuméntur.

18. Ponámque fœdus meum tecum : et ingredíeris arcam tu et fílii tui, uxor tua, et uxóres filiórum tuórum tecum.

19. Et ex cunctis animántibus univérsæ carnis bina indúces in arcam, ut vivant tecum : masculíni sexus et femínini.

20. De volúcribus juxta genus suum, et de juméntis in génere suo, et ex omni réptili terræ secúndum genus suum : bina de ómnibus ingrediéntur tecum, ut possint vívere.

21. Tolles ígitur tecum ex ómnibus escis, quæ mandi possunt, et comportábis apud te : et erunt tam tibi, quam illis in cibum.

22. Fecit ígitur Noë ómnia quæ præcéperat illi Deus.

